---
type: product-category
id: CAT-AP-02
domain: apparel
layer: 2
name: Knit Apparel
risk_level: medium
lead_time_days: "60–90"
wip_stages: 7
products:
  - T-shirts
  - Polos
  - Activewear
  - Innerwear
  - Thermals
  - Socks
key_risk: "Yarn sourcing volatility (cashmere/merino); machine availability in peak season; pilling grade"
regulations:
  - REG-REACH
  - REG-UFLPA
combos:
  - COMBO-001
  - COMBO-002
  - COMBO-006
  - COMBO-007
---

# CAT-AP-02: Knit Apparel

> **Risk Level:** 🟡 MEDIUM
> **Lead Time:** 60–90 days | **WIP Stages:** 7

## Properties

| Property | Value |
|---|---|
| ID | CAT-AP-02 |
| Domain | Apparel |
| Name | Knit Apparel |
| Risk Level | Medium |
| Lead Time | 60–90 days |
| WIP Stages | 7 |
| Products | T-shirts, Polos, Activewear, Innerwear, Thermals, Socks |
| Raw Material | Yarn (cotton, poly, blends) |
| FOB Per Unit | $4.00–5.80 (basic T-shirt) / $5.00–80.00+ (knitwear/sweater) |
| Typical Margin Band | 8–12% |
| Seasonality | Basic knit: year-round; Knitwear/sweater: EXTREME (70%+ revenue Jul–Nov) |

---

## WIP Stages

1. **Yarn / Fabric Receipt** — Incoming yarn or grey fabric inspected for weight, twist, shrinkage *(~2 days)*
2. **Cut (basic) OR Machine Programming + Panel Knit (knitwear) 🔑** — For cut-and-sew: fabric rolled and cut; for fully fashioned: programs loaded, panels knitted to shape *(~5–7 days)*
3. **Sew / Link (knitwear)** — Panels joined; linking machines used for seamless finish on knitwear *(~7 days)*
4. **Wet Finish 🔑** — Softening, anti-pilling treatment, fulling, pre-shrink wash, garment dye as applicable *(~5 days)*
5. **Block & Press (knitwear)** — Steam-blocked on forms to set dimensions; critical for sweaters *(~3 days)*
6. **QC** — Pilling grade, gauge accuracy, hand-feel, shrinkage check *(~2 days)*
7. **Pack & Ship** — Folding, tagging, export packing *(~2 days)*

---

## Cost Structure

| Component | % of FOB |
|---|---|
| Fabric / Yarn | 45–55% |
| Labor | 15–25% |
| Wet Process (basic softener) | 2–3% |
| Machine Depreciation (basic) | 1–3% |
| Machine Depreciation (sweater) | 8–15% |

**FOB Range:**
- Basic T-shirt: $4.00–5.80 USD
- Knitwear / Sweater: $5.00–80.00+ USD

**Margin Band:** 8–12%

### Fiber Price Volatility
| Fiber | Price per kg |
|---|---|
| Cotton | $3–6 |
| Acrylic | $2–4 |
| Merino wool | $12–20 |
| Cashmere | $80–200 |

---

## Seasonality

- **Basic knit (T-shirts, polos, innerwear):** Year-round demand; no extreme seasonal skew.
- **Knitwear / Sweaters:** EXTREME concentration — **70%+ of annual revenue falls Jul–Nov**. Factories fill capacity by February; late orders face machine unavailability or premium surcharges.

---

## Bottlenecks

- **Yarn sourcing** — Cashmere and merino prices are highly volatile; supply can tighten on weather events in Inner Mongolia or New Zealand. Price swings of 20–40% possible within a season.
- **Machine availability (sweater peak)** — Flat-knitting machines are fully booked Jul–Nov. Any order placed after Feb risks delayed allocation or outsourced production with quality variance.

---

## Key Compliance

| Area | Requirement |
|---|---|
| **REG-REACH** | Dyes (disperse, reactive, azo) must meet restricted substance limits; required for EU market |
| **REG-UFLPA** | Required if cotton fiber sourced from Xinjiang region destined for US |
| **OEKO-TEX Standard 100** | Common buyer requirement; tests for 100+ harmful substances in finished article |

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-001: South Asian Small Knit](../../personas/COMBO-001.md)
- [COMBO-002: Bangladesh Bank LC](../../personas/COMBO-002.md)
- [COMBO-006: Vietnam FDI Knit](../../personas/COMBO-006.md)
- [COMBO-007: Indonesia Family Run](../../personas/COMBO-007.md)

### Buyer Types
- [EUFastFashion](../../buyer-types/EUFastFashion.md)
- [USMassRetail](../../buyer-types/USMassRetail.md)

### Raw Materials
- RM-COTTON-JERSEY — cotton jersey; UFLPA if US-bound
- RM-YARN-ACRYLIC — acrylic yarn; $2–4/kg; REACH dye compliance
- RM-YARN-MERINO — merino wool; $12–20/kg; mulesing/welfare standard
- RM-YARN-CASHMERE — cashmere; $80–200/kg; extreme price volatility
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)
- [PP-REG-UFLPA-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-UFLPA-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-UFLPA](../../regulations/REG-UFLPA.md)

### ESG Standards
- [OEKO-TEX Standard 100](../../esg-standards/ESG-OEKO-TEX-100.md)

---

*Source: Alice Wong expert review, Jun 2026*
