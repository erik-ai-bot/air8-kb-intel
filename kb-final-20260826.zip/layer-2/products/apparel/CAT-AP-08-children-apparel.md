---
type: product-category
id: CAT-AP-08
domain: apparel
layer: 2
name: Children's Apparel / Babywear Overlay
risk_level: high
lead_time_days: "Underlying category + 5-15 days compliance buffer"
wip_stages: 8
products:
  - Babywear
  - Children's tops and bottoms
  - Children's sleepwear
  - Kids denim
  - Kids swimwear
  - Schoolwear
  - Children's outerwear
key_risk: "Small parts, drawcord safety, flammability, restricted substances, size/age grading, label compliance"
regulations:
  - REG-REACH
  - REG-UFLPA
combos:
  - COMBO-001
  - COMBO-004
---

# CAT-AP-08: Children's Apparel / Babywear Overlay

> Source: Uploaded Alice WIP pack, children-apparel-wip-flow-v1.html; normalized into CAT markdown. This is an overlay category applied on top of knit, woven, denim, swimwear, and outerwear WIP flows.

## WIP Flow — Children's Apparel / Babywear Overlay

| Step | Name | Lead Time | What Happens | What To Check | Pain Point / Failure Risk | Suggested Evidence / BD Ask |
|---|---|---:|---|---|---|---|
| G1 | Material / Trim Safety Sourcing | Underlying category + 3-7 days | Fabric, trims, buttons, snaps, zippers, elastics, prints, and packaging are sourced under child-safety constraints. | Restricted substances, lead/cadmium, nickel, phthalates, small-parts risk, softener/print chemical safety. | Children’s products have lower tolerance for chemical and choking hazards; non-compliance creates recall risk. | Material certs, REACH/CPSIA/Prop 65 evidence, trim safety declarations. |
| G2 | Design Safety Review | 3-7 days | Design is reviewed for age grade, cords, functional trims, embellishments, and hazard points. | Drawcord/cord length, detachable parts, sharp edges, buttons/snaps security, age labeling. | Drawcord or small-part non-compliance can block shipment or trigger product recall. | Tech pack safety review, trim pull-test plan, age-grade confirmation. |
| S2 | Production Under Base Category | Same as base category | Garment production follows knit/woven/denim/swimwear/outerwear WIP. | Base category controls plus child-specific traceability and hazard checks. | Base production defects are amplified because child safety standards are stricter. | Base WIP evidence plus child-safety checklist. |
| G3 | Print / Embellishment Safety | 2-5 days | Prints, transfers, embroidery, sequins, appliqués, or decorations are applied. | Print adhesion, heavy metals, phthalates, detachable embellishments, needle control. | Detachable decorations and unsafe print chemicals are high-risk child-product failures. | Print chemical report, adhesion test, embellishment pull test, needle detection log. |
| G4 | Flammability / Sleepwear Gate | 3-10 days if applicable | Flammability testing is performed for sleepwear or applicable markets. | Sleepwear classification, flame resistance, snug-fit labeling, fiber content. | Sleepwear flammability failure can block sale and trigger regulatory action. | Flammability test report, sleepwear classification, label approval. |
| G5 | Lab Testing / Compliance | 5-10 days | Chemical and safety tests are completed. | CPSIA, REACH, azo dyes, formaldehyde, lead/cadmium, nickel release, drawcord safety, small parts. | Lab failure after production creates high recall and detention risk. | Third-party lab report, compliance certificate, buyer-approved test package. |
| G6 | Final Inspection / Safety AQL | 2-4 days | Final inspection includes both garment quality and safety checks. | AQL, button/snap pull, needle detection, label, measurement, seam strength. | A normal apparel AQL is not enough; safety defects are critical and may require zero tolerance. | Final inspection report, metal detection record, pull-test report, buyer QA sign-off. |
| S3 | Packing & Shipment | 1-3 days | Goods are packed and shipped with required warnings/labels. | Warning labels, age labels, care labels, fiber content, carton marks. | Incorrect labeling can block retail sale or customs clearance. | Packing list, label artwork proof, carton photos, BL/export docs. |

## Key Pain Points and Suggestions

- Treat children’s apparel as a compliance overlay, not only a product category. Apply it whenever the end product is for children or babies.
- Require safety lab testing before shipment release, especially for sleepwear, drawcords, prints, and small parts.
- Critical safety defects should be zero tolerance; do not rely on normal apparel AQL alone.
- For kids denim or kids swimwear, combine this file with CAT-AP-01 or CAT-AP-07.
