---
type: product-category
id: CAT-AP-04
domain: apparel
layer: 2
name: Home Textiles
risk_level: medium
lead_time_days: "60–90"
wip_stages: 7
products:
  - Towels
  - Bed sheets
  - Curtains
  - Table linen
  - Soft furnishings
  - Rugs
key_risk: "Lab dip shade consistency; fire retardant compliance (if FR grade required)"
regulations:
  - REG-REACH
  - REG-UFLPA
combos:
  - COMBO-009
  - COMBO-001
---

# CAT-AP-04: Home Textiles

> **Risk Level:** 🟡 MEDIUM
> **Lead Time:** 60–90 days | **WIP Stages:** 7

## Properties

| Property | Value |
|---|---|
| ID | CAT-AP-04 |
| Domain | Apparel / Home |
| Name | Home Textiles |
| Risk Level | Medium |
| Lead Time | 60–90 days |
| WIP Stages | 7 |
| Products | Towels, Bed sheets, Curtains, Table linen, Soft furnishings, Rugs |
| Raw Material | Cotton yarn/fabric (often thicker gauges) |
| FOB Per Unit | $2.50–12.00 USD |
| Typical Margin Band | 7–11% |
| Seasonality | Moderate — Q3–Q4 peak for holiday gifting |

### Country Strengths
| Country | Specialty |
|---|---|
| Pakistan | World-leading terry/woven — dominant in towels and bath linen |
| India | Bed linen, rugs — large export base |
| Turkey | Premium home textiles — higher price point |
| Egypt | Long-staple cotton — premium quality for bedding |

---

## WIP Stages

1. **Yarn / Fabric Receipt** — Incoming cotton yarn or grey fabric checked for count, twist, GSM *(~2 days)*
2. **Weaving / Terry Loop Formation** — Shuttle or rapier looms for flat weave; pile looms for terry; rug tufting/weaving *(~7 days)*
3. **Bleaching & Dyeing** — Scouring, bleaching, reactive/vat dyeing in open-width or rope form *(~5 days)*
4. **Lab Dip Approval — BOT 🔑** — Shade samples submitted to buyer for approval; shade consistency across lot dye runs is critical *(~3 days)*
5. **Cutting & Hemming / Stitching** — Cutting to size, hemming, mitered corners, embroidery, appliqué *(~5 days)*
6. **QC 🔑** — GSM check, shrinkage test, colorfastness, FR compliance (if applicable) *(~3 days)*
7. **Pack & Ship** — Folding, banding, poly-bag, export carton *(~2 days)*

---

## Cost Structure

| Component | % of FOB |
|---|---|
| Fabric / Yarn | 50–60% |
| Labor | 18–25% |
| Wet Process | 4–7% |
| Finishing | 3–5% |

**FOB Range:** $2.50–12.00 USD per unit
**Margin Band:** 7–11%

---

## Seasonality

**Moderate.** Q3–Q4 represents the dominant peak driven by holiday gifting seasons (Thanksgiving, Christmas, Chinese New Year sets). Towel replenishment for hospitality is relatively counter-cyclical and steadier. Curtains and soft furnishings track home renovation cycles.

---

## Bottlenecks

- **Lab dip shade consistency** — Home textile buyers (especially for bedding sets) require exact shade matching across multiple components (pillowcase + duvet + flat sheet). Even minor lot-to-lot dye variance triggers rejection. Multiple approval rounds can add 1–2 weeks.
- **FR compliance** — Fire retardant (FR) grades for curtains, upholstery, and hospitality textiles require specific chemical treatments and test certifications (EN 13501, BS 5867, NFPA 701). FR chemicals are REACH-restricted; compliant alternatives add cost and may affect hand-feel.

---

## Key Compliance

| Area | Requirement |
|---|---|
| **REG-REACH** | Dyes and FR chemicals must comply; especially reactive dyes, optical brighteners, and flame retardants |
| **REG-UFLPA** | Required if cotton destined for US market — Pakistan and India cotton chains require traceability documentation |
| **OEKO-TEX Standard 100** | Common buyer requirement for retail home textiles; tests 100+ harmful substances in finished article |
| **FR Standards** | EN 13501 (EU) / BS 5867 (UK) / NFPA 701 (US) — required for curtains/drapes in hospitality and contract markets |

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-009: Pakistan Home Textile](../../personas/COMBO-009.md)
- [COMBO-001: South Asian Small Knit](../../personas/COMBO-001.md)

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)

### Raw Materials
- RM-COTTON-YARN — cotton yarn; UFLPA traceability required for US
- RM-COTTON-FABRIC — woven/terry cotton fabric
- RM-FR-CHEMICALS — fire retardant finishing chemicals; REACH restricted substances compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)
- [PP-REG-UFLPA-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-UFLPA-001.md)
- [PP-REG-TARIFF-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-TARIFF-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-UFLPA](../../regulations/REG-UFLPA.md)

### ESG Standards
- [OEKO-TEX Standard 100](../../esg-standards/ESG-OEKO-TEX-100.md)

---

*Source: KB home textiles data, Jun 2026*
