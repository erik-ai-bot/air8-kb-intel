---
type: product-category
id: CAT-AP-06
domain: apparel
layer: 2
name: Down Jacket / Padded Outerwear
risk_level: high
lead_time_days: "90-140"
wip_stages: 9
products:
  - Down jackets
  - Puffer jackets
  - Quilted jackets
  - Padded vests
  - Synthetic-fill outerwear
  - Ski / cold-weather jackets
key_risk: "Down/fill traceability, thermal performance, quilting migration, shell water repellency, needle leakage, final warmth testing"
regulations:
  - REG-REACH
  - REG-UFLPA
combos:
  - COMBO-004
---

# CAT-AP-06: Down Jacket / Padded Outerwear

> Source: Uploaded Alice WIP pack, downjacket-wip-flow-v1.html; normalized into CAT markdown.

## WIP Flow — Down Jacket / Padded Outerwear

> Standard WIP structure: `S` = production stage, `G` = approval/control gate, `BOT` = bottleneck / must-start-early gate, `PP` = pre-production sample sign-off gate.

| Step | Name | Lead Time | What Happens | What To Check | Pain Point / Failure Risk | Suggested Evidence / BD Ask |
|---|---|---:|---|---|---|---|
| G1 | Shell Fabric / Fill Sourcing | 3-8 weeks | Shell fabric, lining, down/synthetic fill, zippers, trims, drawcords, labels, and packaging are sourced. | Down origin, fill power, RDS/traceability if claimed, shell fabric spec, DWR chemistry, color lab dip, buyer material approval. | Fill is high-value and easy to substitute; uncertified down or restricted DWR chemistry can block buyer acceptance. | Down/fill certificate, RDS/traceability documents, shell fabric test report, lab dip approval, trim PI. |
| S2 | Material Receipt / Fill Storage | 2-5 days | Shell fabric, lining, trims, and down/fill are received and stored. | Fill weight received, moisture control, lot segregation, fabric defects, color shade, zipper/trim matching. | Down can absorb moisture or be mixed across lots; fill shortage causes underfilled garments and warmth failures. | Incoming QC, fill weight reconciliation, humidity/moisture record, lot register. |
| G2 | Pattern / Fit / Thermal Spec Approval | 5-14 days | Fit sample, size grading, quilting layout, fill distribution plan, and warmth target are approved. | Fit comments, quilting map, fill grams per panel, seam allowance, buyer-approved spec. | Incorrect baffle/quilt design causes cold spots and migration; fit changes after quilting are costly. | Fit approval, quilting/fill map, size set, buyer comments closure. |
| S3 | Cutting / Panel Preparation | 3-7 days | Shell/lining panels are cut; insulation pieces or fill zones are prepared. | Nap/face direction, panel matching, coating side, bundle tracking, shade-lot control. | Wrong face direction or coating damage affects water resistance and visual consistency. | Cutting report, bundle tickets, shade control sheet. |
| G3 | Quilting / Baffle / Fill Control | 5-12 days | Quilting channels or baffles are made; down/synthetic fill is inserted. | Fill weight by panel, fill distribution, needle leakage, seam strength, anti-migration controls. | Underfill, uneven fill, or feather leakage causes performance failure and high return risk. | Fill-weight check sheet, in-line QC, leakage test, quilting inspection. |
| S4 | Sewing Assembly | 7-14 days | Outer shell, lining, zippers, hood, cuffs, pockets, and trims are assembled. | Seam strength, zipper function, hood/cuff attachment, drawcord safety, SPI, needle damage. | Sewing defects can compromise water resistance or create safety issues. | In-line AQL, seam strength test, zipper function check. |
| G4 | Functional Finishing / DWR | 3-7 days | Water repellent or functional finish is applied or verified. | DWR performance, restricted chemistry, hand-feel, color impact, curing condition. | Non-compliant DWR or poor water repellency can trigger buyer rejection. | DWR test, REACH/PFAS declaration, chemical inventory, finish approval. |
| G5 | Lab / Performance Testing | 5-10 days | Warmth, fill power, colorfastness, seam strength, dimensional stability, and restricted substances are tested. | Fill power, thermal/clo if required, down composition, feather leakage, REACH/Prop 65, colorfastness. | Lab failure after production makes goods hard to sell; down substitution can create claim/fraud risk. | SGS/Intertek/BV report, fill-power test, composition test, REACH report. |
| G6 | Final Inspection / PP Sign-off | 2-4 days | Final AQL and buyer/third-party inspection are completed. | Fill evenness, measurement, visual defects, zipper/drawcord function, carton compression recovery. | Final-stage rejection happens after high material and labor spend. | Final inspection report, buyer QA sign-off, PP sample approval. |
| S5 | Packing & Shipment | 2-5 days | Garments are compressed/folded, packed, labeled, and shipped. | Compression recovery, moisture control, carton cube, labeling, packing ratio, export docs. | Poor compression or moisture causes loft loss and mould risk. | Packing list, moisture checklist, carton photos, BL/export docs. |

## Key Pain Points and Suggestions

- Require fill-origin and fill-power evidence before financing material drawdown.
- Verify DWR chemistry early where EU/US buyers restrict PFAS or other treatments.
- Use fill-weight checkpoints during quilting, not only at final inspection.
- Treat lab/performance testing as a release gate for premium cold-weather programs.
