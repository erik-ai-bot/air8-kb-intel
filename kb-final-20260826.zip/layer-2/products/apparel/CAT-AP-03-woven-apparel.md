---
type: product-category
id: CAT-AP-03
domain: apparel
layer: 2
name: Woven Apparel
risk_level: medium-high
lead_time_days: "90–120"
wip_stages: 6
products:
  - Shirts
  - Trousers
  - Jackets
  - Formal wear
key_risk: "Dimensional accuracy, colorfastness, seam strength; longer lead time vs knit due to complexity"
regulations:
  - REG-REACH
  - REG-UFLPA
combos:
  - COMBO-004
  - COMBO-014
---

# CAT-AP-03: Woven Apparel

> **Risk Level:** 🟠 MEDIUM-HIGH
> **Lead Time:** 90–120 days | **WIP Stages:** 6

## Properties

| Property | Value |
|---|---|
| ID | CAT-AP-03 |
| Domain | Apparel |
| Name | Woven Apparel |
| Risk Level | Medium-High |
| Lead Time | 90–120 days |
| WIP Stages | 6 |
| Products | Shirts, Trousers, Jackets, Formal wear |
| Raw Material | Woven fabric (cotton, poly, linen, blends) |
| FOB Per Unit | $6.00–18.00 USD |
| Typical Margin Band | 9–13% |
| Seasonality | Moderate — spring/fall collections drive peaks |

---

## WIP Stages

1. **Fabric Receipt & Inspection** — Roll-by-roll inspection for defects, width, GSM, shrinkage pre-wash *(~3 days)*
2. **Cut & Bundle** — Marker planning, fabric spreading, cutting; bundles tied with ticket numbers for tracking *(~5 days)*
3. **Sew 🔑** — Higher complexity vs knit: collars, cuffs, fly seams, pockets, belt loops; multi-operation assembly lines *(~10 days)*
4. **Finishing & Pressing** — Steam press, shape setting, button attachment, embroidery/embellishment if applicable *(~5 days)*
5. **QC 🔑** — Dimensional accuracy (measurements vs spec), colorfastness, seam strength testing *(~3 days)*
6. **Pack & Ship** — Folding, tagging, poly-bag, export carton *(~3 days)*

---

## Cost Structure

| Component | % of FOB |
|---|---|
| Fabric | 45–55% |
| Labor | 20–28% |
| Wet Process | 3–6% |
| Finishing | 2–4% |

**FOB Range:** $6.00–18.00 USD per unit
**Margin Band:** 9–13%

---

## Seasonality

**Moderate.** Spring and Fall collections are the primary demand peaks driven by wholesale buying calendars. Formal wear (suits, dress shirts) has a more stable year-round base with modest Q1/Q3 spikes for trade show and graduation seasons.

---

## Bottlenecks

- **Sew complexity** — Woven garments require significantly more sewing operations than knit equivalents (e.g., a woven dress shirt: 25–35 operations vs. 10–15 for a basic T-shirt), driving longer cycle times and higher skill requirements.
- **Lead time gap vs knit** — 90–120 days vs 60–90 days for knit makes woven less responsive to trend-driven reorders. Buyers must commit earlier.
- **Colorfastness** — Finishing chemicals (fixatives, softeners, resins) can compromise wash/rub fastness if not properly managed; especially critical for dark shades.

---

## Key Compliance

| Area | Requirement |
|---|---|
| **REG-REACH** | Finishing chemicals (softeners, resins, fixatives) must be tested; applicable to EU market shipments |
| **REG-UFLPA** | Required if cotton fiber sourced or transiting from restricted regions destined for US |

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-004: China Medium Woven](../../personas/COMBO-004.md)
- [COMBO-014: India Small Woven](../../personas/COMBO-014.md)

### Buyer Types
- [EUFastFashion](../../buyer-types/EUFastFashion.md)
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)

### Raw Materials
- RM-COTTON-WOVEN-FABRIC — woven cotton; UFLPA if US-bound
- RM-POLYESTER-BLEND — poly/cotton blend fabric; REACH finishing chemicals
- RM-LINEN — linen fabric; EU/US low compliance burden
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)
- [PP-REG-UFLPA-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-UFLPA-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-UFLPA](../../regulations/REG-UFLPA.md)

---

*Source: Alice Wong expert review + KB apparel data, Jun 2026*
