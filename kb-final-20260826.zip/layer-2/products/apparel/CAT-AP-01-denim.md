---
type: product-category
id: CAT-AP-01
domain: apparel
layer: 2
name: Denim
risk_level: high
lead_time_days: "90–120"
wip_stages: 7
products:
  - Jeans
  - Jackets
  - Shorts
  - Denim skirts
key_risk: "Wash/finish consistency (laser, ozone, stone wash must match across lots); REACH chemical exposure"
regulations:
  - REG-REACH
  - REG-UFLPA
combos:
  - COMBO-005
  - COMBO-004
---

# CAT-AP-01: Denim

> **Risk Level:** 🔴 HIGH (HIGHEST chemical exposure in apparel)
> **Lead Time:** 90–120 days | **WIP Stages:** 7

## Properties

| Property | Value |
|---|---|
| ID | CAT-AP-01 |
| Domain | Apparel |
| Name | Denim |
| Risk Level | **High** (highest chemical exposure) |
| Lead Time | 90–120 days |
| WIP Stages | 7 |
| Products | Jeans, Jackets, Shorts, Denim skirts |
| Raw Material | Denim fabric (indigo-dyed cotton) |
| FOB Per Unit | $6.00–15.00 USD |
| Typical Margin Band | 8–14% |
| Seasonality | Low–Medium |
| Water Intensity | HIGH — 50–80 L/garment (eco: 5–15 L with laser/ozone) |

---

## WIP Stages

1. **Fabric Receipt & Inspection** — Incoming denim fabric checked for defects, shrinkage, weight *(~3 days)*
2. **Cut** — Patterns laid and fabric cut into panels *(~5 days)*
3. **Sew** — Panels assembled; bartacks, rivets, pocketing applied *(~7 days)*
4. **Wash Development — BOT 🔑** — New recipe development (normal: 10–12 wks; rush: 6 wks); bulk wash runs *(~10 days bulk)*
5. **Washing & Finish** — Stone/enzyme/acid/laser/ozone/sand/resin/overdye treatments applied *(~7 days)*
6. **QC — Shade Consistency 🔑** — Critical lot-to-lot shade matching; measurements and defect audit *(~3 days)*
7. **Pack & Ship** — Final tagging, packing, export documentation *(~3 days)*

---

## Cost Structure

| Component | % of FOB |
|---|---|
| Fabric | 30–40% |
| Labor | 20–30% |
| Wet Process (standard) | 8–12% |
| Wet Process (complex/eco) | 10–15% |
| Machine Depreciation | 3–5% |

**FOB Range:** $6.00–15.00 USD per unit
**Margin Band:** 8–14%

### Key Equipment CapEx
| Equipment | Cost |
|---|---|
| Laser machine | $150–300K |
| Ozone machine | $80–150K |
| Wash drums | $50–100K |
| **Total plant** | **$2–5M** |

---

## Seasonality

**Low–Medium.** Denim is relatively evergreen; limited seasonal concentration compared to knitwear. Spring/Summer styles (shorts, lighter washes) and Fall/Winter (heavier weights, darker washes) drive mild peaks.

---

## Bottlenecks

- **Wash development** — New recipe adds **2–3 weeks** to calendar. Any design change post-approval triggers redevelopment.
- **Shade variance across lots** — Indigo dye uptake varies by water chemistry, drum load, fabric weight; lot-to-lot consistency is the #1 rejection cause.
- **Eco compliance switch** — Switching from stone/chemical wash to laser/ozone requires CapEx and operator retraining.

---

## Key Compliance

| Area | Requirement |
|---|---|
| **REG-REACH** | CRITICAL — covers indigo, permanganate, PP spray, resin finishes; restricted substance list must be tested pre-shipment |
| **REG-UFLPA** | Required if cotton destined for US market — traceability to gin/farm level |
| **ESG-ZDHC** | MRSL (Manufacturing Restricted Substances List) Gateway adherence required for wet-process chemicals |

> ⚠️ **REACH is the primary compliance risk for Denim.** Permanganate spray (widely used for vintage distressing) is restricted in EU markets. Laser and ozone finishing offer compliant alternatives.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-005: Turkey Denim Specialist](../../personas/COMBO-005.md)
- [COMBO-004: China Medium Woven](../../personas/COMBO-004.md)

### Buyer Types
- [EUFastFashion](../../buyer-types/EUFastFashion.md)
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)

### Raw Materials
- RM-COTTON-DENIM-FABRIC — indigo-dyed cotton; UFLPA traceability if US-bound
- RM-INDIGO-DYE — REACH restricted; permanganate spray also restricted in EU
- RM-SPECIALTY-WASH-CHEMICALS — stone/enzyme/acid/laser chemicals; ZDHC MRSL compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)
- [PP-REG-UFLPA-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-UFLPA-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-UFLPA](../../regulations/REG-UFLPA.md)

### ESG Standards
- [ESG-ZDHC (MRSL Gateway)](../../esg-standards/ESG-ZDHC.md)

---

*Source: Alice Wong expert review, Jun 2026*
