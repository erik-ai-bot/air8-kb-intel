---
type: product-category
id: CAT-AP-07
domain: apparel
layer: 2
name: Swimwear / Performance Stretch Apparel
risk_level: high
lead_time_days: "75-120"
wip_stages: 8
products:
  - Women's swimwear
  - Men's swim trunks
  - Kids swimwear
  - Rash guards
  - Performance stretch apparel
  - Active swim separates
key_risk: "Elastic recovery, colorfastness to chlorine/saltwater, stretch fabric sourcing, size/fit risk, lining and opacity"
regulations:
  - REG-REACH
  - REG-UFLPA
combos:
  - COMBO-006
---

# CAT-AP-07: Swimwear / Performance Stretch Apparel

> Source: Uploaded Alice WIP pack, swimwear-wip-flow-v1.html; normalized into CAT markdown.

## WIP Flow — Swimwear / Performance Stretch Apparel

| Step | Name | Lead Time | What Happens | What To Check | Pain Point / Failure Risk | Suggested Evidence / BD Ask |
|---|---|---:|---|---|---|---|
| G1 | Stretch Fabric / Trim Sourcing | 3-8 weeks | Nylon/spandex, polyester/spandex, lining, elastic, pads, clips, rings, drawcords, and labels are sourced. | Spandex content, fabric weight, stretch/recovery, opacity, chlorine/saltwater resistance, lab dip/print strike-off. | Fabric performance drives the whole product; poor recovery or opacity failure causes immediate buyer rejection. | Fabric PI, stretch/recovery test, opacity test, color/print approval, trim approval. |
| G2 | Fit / Grading / Size Set Approval | 7-21 days | Fit sample and graded size set are approved on body/form. | Stretch fit, coverage, elastic tension, cup/pad placement, seam comfort, size grading. | Swimwear fit is unforgiving; small measurement errors create high return risk. | Fit approval, size set, buyer comments closure, model/form fitting record. |
| S2 | Fabric Receipt / Relaxation | 1-3 days | Stretch fabric rolls are received and relaxed before cutting. | Roll width, GSM, stretch recovery, shade lot, print registration, relaxation. | Cutting before relaxation causes twisting, shrinkage, or size instability. | Incoming QC, relaxation log, stretch test, shade register. |
| G3 | Cutting / Print Placement Control | 3-6 days | Fabric is cut; prints/stripes are matched where required. | Directional stretch, print placement, panel matching, lining match, waste rate. | Wrong stretch direction or print placement affects fit and appearance across the order. | Cut report, marker plan, print placement approval, bundle tickets. |
| S3 | Sewing / Elastic Application | 5-12 days | Panels are assembled with overlock/coverstitch; elastics, cups, pads, and trims are attached. | Stitch stretch, elastic tension, seam strength, needle damage, trim security. | Broken stitches or incorrect elastic tension causes fit failure and returns. | In-line AQL, elastic tension check, seam stretch test, needle policy. |
| G4 | Performance / Colorfastness Testing | 5-10 days | Fabric and finished garment are tested for pool/beach use. | Chlorine fastness, saltwater fastness, light fastness, rubbing, stretch recovery, pH, REACH. | Color bleeding, loss of elasticity, and transparency are high-severity failures. | Lab test report, chlorine/saltwater test, stretch recovery, opacity test. |
| G5 | Final Inspection / Fit Recheck | 2-4 days | AQL and final fit/function checks are completed. | Measurement, elastic recovery after stretch, seam stretch, cup/pad placement, visual defects. | Final fit failure creates high return and chargeback risk. | Final inspection report, fit recheck record, buyer QA sign-off. |
| S4 | Packing & Shipment | 1-3 days | Garments are tagged, hygiene-labeled, packed, and shipped. | Hygiene liner, warning labels, size stickers, set completeness, carton labels. | Missing hygiene liner/label can block retail sale. | Packing list, label artwork proof, carton photos, BL/export docs. |

## Key Pain Points and Suggestions

- Collect stretch/recovery and chlorine/saltwater test evidence before shipment release.
- Require buyer-approved fit and size set before bulk cutting.
- For printed swimwear, treat strike-off and print placement as a control gate.
- For kids swimwear, apply the Children’s Apparel compliance overlay in CAT-AP-08.
