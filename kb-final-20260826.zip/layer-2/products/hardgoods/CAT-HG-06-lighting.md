---
type: product-category
id: CAT-HG-06
domain: hardgoods
layer: 2
name: Lighting
risk_level: high
wip_gates: 5
products:
  - Luminaire (LED chandeliers)
  - Table lamps
  - Pendant lights
  - String lights
  - Smart lighting accessories
key_risk: "T1 copper tariff double compression (finished goods + copper inputs); UL/CE certs do NOT transfer on geo shift (2–4 weeks re-test)"
regulations:
  - REG-REACH
  - REG-TARIFF
  - REG-CE-LVD-EMC
  - REG-FCC-PART15
  - REG-UL-1598
  - REG-GPSR
combos:
  - COMBO-HG-004-china-decorative-lighting
---

# CAT-HG-06 — Lighting

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-06 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | High |
| **WIP Gates** | 5 |
| **Products** | Luminaire (LED chandeliers), Table lamps, Pendant lights, String lights, Smart lighting accessories |
| **Key Risk** | T1 copper tariff double compression (finished goods + copper inputs); UL/CE certs do NOT transfer on geo shift (2–4 weeks re-test) |
| **Regulations** | REG-REACH, REG-TARIFF, REG-CE-LVD-EMC, REG-FCC-PART15, REG-UL-1598, REG-GPSR |
| **Combos** | COMBO-HG-004-china-decorative-lighting |

---

## WIP Flow

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Component Sourcing / Receipt | 3–5 days | Driver, wiring, housing, shade components received and inspected |
| G1 | Electrical Safety Sign-off | 3–5 days | Driver/transformer spec + wiring diagram approved before PCB production |
| S2 | PCB / Driver Production | 7–10 days | Circuit board and driver manufactured |
| G2 | Color Swatch (if decorative) | 2–3 days | Shade material/color confirmed |
| S3 | Assembly | 5–7 days | Components assembled into final luminaire |
| G3 🔑 | Safety Certification — UL / CE | 14–28 days | UL 1598 (US) / CE LVD (EU) / ETL. External test lab. Does NOT transfer on geo shift — re-test required for any origin change. |
| G4 🔑 | EMC / EMI Test | 7–14 days | FCC Part 15 (US) / CE EMC (EU) for any electronic driver |
| G5 ★ | PP Sample | 7–10 days | Fully wired and operational sample; written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G3 🔑 Safety Certification — UL / CE:** ⚠️ Certification does NOT transfer on geo shift — any origin change (e.g. China → Vietnam) requires full re-certification: CE 2–3 weeks, UL up to 4 months. This makes China lighting factories sticky to buyers but also slow to recover if orders decline. (Ref: PP-HG-007) ✅ Lock production origin before cert application; factor re-cert timeline into any origin-shift assessment; do not expand multi-year facilities against US book if buyer re-cert signals are active.
- **G4 🔑 EMC / EMI Test:** ⚠️ Driver design failure discovered at G4 = full PCB redesign required — expensive and late-stage. ✅ Pre-test driver design at prototype stage; use pre-certified components where possible to shorten G4 timeline.
- **G5 ★ PP Sample:** ⚠️ Lumen output variation between production batches may not match certified spec. ✅ Include lumen measurement in PP protocol; require ±10% tolerance cert from factory.

---

## Key Compliance & Market Intelligence

- **T1 Copper Tariff — Most Severe Category Impact:** China decorative lighting faces the highest margin squeeze among all copper-affected hardgoods categories. Two reasons:
  1. **Double compression:** Section 301 on finished goods + T1 on copper in wiring, drivers, heat sinks
  2. **No clean geo escape:** VN and India are assembling some lighting but LED drivers, chips, PCBs remain China-sourced. Moving T1 assembly to VN/India does NOT escape the copper input cost — this is a FALSE diversification signal. Do not treat VN lighting assembly as T1 relief.
  
  UL/CE certs also do NOT transfer on geo shift (2–4 weeks for CE, up to 4 months for UL). China lighting factories are structurally sticky — buyers cannot easily shift, but the factories are simultaneously the most cash-flow-stressed segment.

  **Air8 risk level: 🔴 HIGH.** Financing demand from this segment is expected to spike as margin compression worsens. Screen harder: higher fragility, not lower.
- **UL 1598 (US):** Luminaire safety standard; mandatory for US market electrical safety compliance.
- **CE LVD (EU):** Low Voltage Directive compliance required for all EU-market luminaires.
- **FCC Part 15 / CE EMC:** Electromagnetic compatibility certification required for US and EU markets respectively — applies to all electrical lighting products.
- **REACH:** Restricted substances in materials (coatings, wiring insulation, plastics).
- **GPSR:** General Product Safety Regulation — EU market safety assessment.
- **Market Alert:** China lighting suppliers are at **high cash-flow deterioration risk** due to tariff double compression. Financing demand from this segment is expected to increase — elevated credit risk in financing decisions.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-HG-004-china-decorative-lighting](../../personas/hardgoods/COMBO-HG-004-china-decorative-lighting.md)

### Buyer Types
- [EUPremiumLighting](../../buyer-types/EUPremiumLighting.md)
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [MiddleEastPremium](../../buyer-types/MiddleEastPremium.md)

### Raw Materials
- RM-LED-COMPONENTS-CN — LED drivers, PCB, copper wiring; moderate T1 copper tariff exposure
- RM-COPPER-WIRING — wiring and heat sinks; direct copper input cost pressure
- RM-ALUMINIUM-HOUSING — extruded aluminium housing/heatsink
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-HG-002-tariff-double-compress](../../../layer-1-reasoning/pain-points/hardgoods/PP-HG-002-tariff-double-compress.md)
- [PP-HG-007-ce-ul-certification-barrier](../../../layer-1-reasoning/pain-points/hardgoods/PP-HG-007-ce-ul-certification-barrier.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-TARIFF](../../regulations/REG-TARIFF.md)
- [REG-CE-LVD-EMC](../../regulations/REG-CE-LVD-EMC.md)
- [REG-FCC-PART15](../../regulations/REG-FCC-PART15.md)
- [REG-UL-1598](../../regulations/REG-UL-1598.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
