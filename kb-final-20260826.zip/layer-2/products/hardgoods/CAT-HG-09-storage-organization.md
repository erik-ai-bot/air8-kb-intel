---
type: product-category
id: CAT-HG-09
domain: hardgoods
layer: 2
name: Storage & Organization
risk_level: medium
wip_gates: "4"
products:
  - Storage boxes
  - Shelving units
  - Drawer organizers
  - Closet systems
  - Hampers
key_risk: "—"
regulations:
  - REG-REACH
  - REG-GPSR
combos: []
---

# CAT-HG-09 — Storage & Organization

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-09 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | Medium |
| **WIP Gates** | 4 |
| **Products** | Storage boxes, Shelving units, Drawer organizers, Closet systems, Hampers |
| **Key Risk** | Structural load / tip-over (shelving, closet systems); coating adhesion; ASTM F2057 compliance for load-bearing units |
| **Regulations** | REG-REACH, REG-GPSR |
| **Combos** | — |

---

## WIP Flow — Storage & Organization

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

| Step | Name | Lead Time | Description |
|---|---|---|---|
| G1 🔑 | Material Cert & Structural Design Review (BOT) | 3–5 days | Material spec sign-off for plastic, metal, and wood components; structural load spec reviewed and confirmed against design drawings. Blocks production start. |
| G2 | Prototype / First Article Inspection | 5–7 days | FAI: dimensional check, assembly fit, load test (shelving units tested to 2× rated load); finish and surface quality confirmed on prototype. |
| PP ★ | Pre-Production Sample | 7–14 days | Full PP: structural load test (ASTM F2057 analog), tip-over stability test, finish/surface check; written sign-off required. |
| G3 | Production Monitoring | Ongoing | Inline checks: welding/joinery quality (metal units), injection mould dimensional consistency (plastic), coating adhesion spot-check. |
| G4 | Final QC & Safety Release | 3–5 days | AQL final inspection; tip-over stability test on production samples; packaging and label verification before shipment release. |

**Lead Times:** 4–8 weeks for most products; 8–12 weeks for load-bearing furniture/closet systems requiring structural certification.

**Stage Notes:**
- **G1 🔑 Material Cert & Structural Design Review (BOT):** ⚠️ Structural design reviewed only at BOT is too late if the design fails load specs — re-engineering post-tooling is costly; material downgrades (thinner steel gauge, lower-grade plastic) by factory to cut cost cause structural failure in field. ✅ Review structural design drawings against rated load spec before approving tooling; require mill cert for steel with thickness and grade; require material spec sheet for plastic with impact strength (Izod/Charpy) data.
- **G2 Prototype / First Article Inspection:** ⚠️ First-article dimensional deviation on injection-moulded parts propagates across entire production run if not caught; load-bearing joint failure at 1.5× rated load (below the 2× target) indicates design or material non-compliance. ✅ Test prototype to 2× rated load with 15-minute hold; measure all critical dimensions against engineering drawings; check assembly fit for all connectors and fasteners before approving tooling changes for full production.
- **PP ★ Pre-Production Sample:** ⚠️ Tip-over instability discovered post-production on load-bearing shelving = ASTM F2057 non-compliance = product recall risk for US market; surface finish defects (scratches, coating bubbles) accepted at PP stage propagate through entire production run. ✅ Perform tip-over test (ASTM F2057 or equivalent) with rated contents and 3× rated top load; inspect surface finish under standard lighting at 500 lux; written sign-off required before mass production proceeds.
- **G3 Production Monitoring:** ⚠️ Welding inconsistency in metal shelving (incomplete penetration, porosity) causes structural failure under rated load; injection mould wear mid-run causes dimensional drift that affects assembly fit. ✅ Pull 3 units at 30% and 60% of run for dimensional check and visual weld inspection; torque-test fastener joints on metal units; check mould for flash and dimensional drift at 60% inspection.
- **G4 Final QC & Safety Release:** ⚠️ Labeling errors (incorrect rated load, missing assembly instructions, incorrect country-of-origin) trigger retail deductions and re-labeling costs; tip-over test on production units may reveal degradation from G3 production consistency issues. ✅ Pull final tip-over stability test on 3 production units; verify rated load label is correct and legible; confirm all assembly instructions are included and correct language version for destination market.

---

## Key Compliance & Market Intelligence

- **REACH:** Restricted substances compliance required across plastics, metals, and fabric components — especially coatings, dyes, and any adhesives used in assembly.
- **GPSR (EU):** General Product Safety Regulation applies to all storage products sold in the EU; structural stability and load-bearing products (shelving units, closet systems) may require additional safety assessments.
- For shelving and closet systems, structural load and tip-over stability standards (e.g., ASTM F2057, IKEA-style stability tests) should be incorporated into WIP gates when defined.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)

### Raw Materials
- RM-PLASTIC-COMPOUND — PP/HDPE storage units; REACH compliance
- RM-STEEL-SHELVING — steel wire/tube shelving; REACH surface coating compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
