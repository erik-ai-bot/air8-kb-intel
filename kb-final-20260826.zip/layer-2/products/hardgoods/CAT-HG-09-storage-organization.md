---
type: product-category
id: CAT-HG-09
domain: hardgoods
layer: 2
name: Storage & Organization
risk_level: "—"
wip_gates: "—"
products:
  - Storage boxes
  - Shelving units
  - Drawer organizers
  - Closet systems
  - Hampers
key_risk: "—"
regulations:
  - REG-REACH
  - REG-GPSR
combos: []
---

# CAT-HG-09 — Storage & Organization

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-09 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | — *(not yet assessed)* |
| **WIP Gates** | — *(not yet defined)* |
| **Products** | Storage boxes, Shelving units, Drawer organizers, Closet systems, Hampers |
| **Key Risk** | — *(not yet assessed)* |
| **Regulations** | REG-REACH, REG-GPSR |
| **Combos** | — |

---

## WIP Gates

> **WIP not yet defined.** Production gates for Storage & Organization have not been mapped. When defined, gates should address structural load testing (shelving units), material compliance (plastics, metals, fabrics), and surface treatment/finish approvals.

---

## Key Compliance & Market Intelligence

- **REACH:** Restricted substances compliance required across plastics, metals, and fabric components — especially coatings, dyes, and any adhesives used in assembly.
- **GPSR (EU):** General Product Safety Regulation applies to all storage products sold in the EU; structural stability and load-bearing products (shelving units, closet systems) may require additional safety assessments.
- For shelving and closet systems, structural load and tip-over stability standards (e.g., ASTM F2057, IKEA-style stability tests) should be incorporated into WIP gates when defined.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)

### Raw Materials
- RM-PLASTIC-COMPOUND — PP/HDPE storage units; REACH compliance
- RM-STEEL-SHELVING — steel wire/tube shelving; REACH surface coating compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
