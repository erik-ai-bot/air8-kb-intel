---
type: product-category
id: CAT-HG-03
domain: hardgoods
layer: 2
name: Kitchen & Dining
risk_level: medium
wip_gates: "4 (cookware only)"
products:
  - Cookware (hard-anodized, coated, uncoated)
  - Tableware
  - Drinkware
  - Table linens
key_risk: "PFAS compliance (EU); food contact migration; G3 migration test 7-10 days - must start early"
regulations:
  - REG-REACH
  - REG-GPSR
combos: []
---

# CAT-HG-03 - Kitchen & Dining

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-03 |
| **Domain** | Hardgoods |
| **Layer** | 2 - Entity |
| **Risk Level** | Medium |
| **WIP Gates** | 4 (cookware only; other sub-types TBD) |
| **Products** | Cookware (hard-anodized, coated, uncoated), Tableware, Drinkware, Table linens |
| **Key Risk** | PFAS compliance (EU); food contact migration; G3 migration test 7-10 days - must start early |
| **Regulations** | REG-REACH, REG-GPSR |
| **Combos** | - |

---

## WIP Flow — Hard-Anodized Cookware

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Material Receipt — Aluminium Billet | 1–2 days | Incoming aluminium checked for grade and dimensions |
| G1 🔑 | PFOA / PFAS-Free Declaration | 1–2 days | Must name specific coating compound (not just “PFOA-free”). Blocks production start. |
| S2 | Forming / Hard Anodizing Process | 5–7 days | Aluminium formed and anodized |
| G2 | Anodizing Spec Sign-off | 2–3 days | Hardness (Vickers), thickness (μm), color confirmed |
| S3 | Non-stick Coating Application | 3–5 days | Coating applied to cooking surface |
| G3 🔑 | Food Safety / FDA Migration Test | 7–10 days | FDA CFR 21 / EU 10/2011 migration test. Must be scheduled early — cannot compress. |
| S4 | Handle / Hardware Assembly | 3–5 days | Handles, lids, and hardware attached |
| G4 ★ | PP Sample | 5–7 days | Written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G1 🔑 PFOA / PFAS-Free Declaration:** ⚠️ Suppliers often issue generic "PFOA-free" declarations without naming the specific compound — EU's expanding PFAS restrictions may cover the compound currently in use. ✅ Require chemical identity disclosure including CAS number; cross-check against EU REACH PFAS restriction candidate list.
- **S3 Non-stick Coating Application:** ⚠️ Coating adhesion failure = peeling/flaking in use = critical safety defect and product recall risk (Josephine defect classification). ✅ Run adhesion test (fingernail scratch — must not lift) on first 10 units of production run; verify substrate activation before coating.
- **G3 🔑 Food Safety / FDA Migration Test:** ⚠️ 7–10 day test cannot be compressed; delayed scheduling extends entire production cycle by the same amount. ✅ Send samples to lab on Day 1 of S3 coating application — do not wait for the full coating run to complete.
- **G4 ★ PP Sample:** ⚠️ Coating micro-defects may only be visible under magnification. ✅ Include 10× magnification check of cooking surface in PP review protocol; written sign-off required.

---

### Tableware, Drinkware, Table Linens

> **WIP not yet defined.** Sub-type gates for tableware, drinkware, and table linens are pending. Apply food-contact and migration testing requirements as applicable once defined.

---

## Key Compliance & Market Intelligence

- **PFAS (EU):** Broad restriction on per- and polyfluoroalkyl substances in food-contact materials; declaration at G1 must specify the exact compound, not just claim "PFOA-free."
- **EU 10/2011:** Plastic materials and articles in contact with food - migration limits must be confirmed by lab test.
- **FDA CFR 21:** US food contact material requirements for all cookware sold in North America.
- **REACH:** Restricted substances apply across all kitchen and dining products; chemicals in coatings and finishes must comply.
- **GPSR:** General Product Safety Regulation applies to all products sold in the EU.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUSpecialty](../../buyer-types/EUSpecialty.md)

### Raw Materials
- RM-ALUMINIUM-BILLET — hard-anodized cookware base; grade 6061/6063
- RM-PTFE-COATING — non-stick coating compound; PFAS compliance critical for EU
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-HG-005-reach-rohs-compliance](../../../layer-1-reasoning/pain-points/hardgoods/PP-HG-005-reach-rohs-compliance.md)
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
