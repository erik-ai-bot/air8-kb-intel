---
type: product-category
id: CAT-HG-01
domain: hardgoods
layer: 2
name: Home Textile & Bedding
risk_level: medium
wip_gates: 4
products:
  - Towels
  - Bedding (duvet covers, bed sheets, pillowcases)
  - Blankets
  - Soft furnishings
key_risk: "Lab dip shade consistency (±5% max; each rejection iteration = 5–7 days)"
regulations:
  - REG-REACH
  - REG-TARIFF
combos:
  - COMBO-009-pakistan-home-textile
---

# CAT-HG-01 — Home Textile & Bedding

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-01 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | Medium |
| **WIP Gates** | 4 |
| **Products** | Towels, Bedding (duvet covers, bed sheets, pillowcases), Blankets, Soft furnishings |
| **Key Risk** | Lab dip shade consistency (±5% max; each rejection iteration = 5–7 days) |
| **Regulations** | REG-REACH, REG-TARIFF |
| **Combos** | COMBO-009-pakistan-home-textile |

---

## WIP Flow

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Yarn / Fabric Receipt & Inspection | 1–2 days | Incoming material checked for spec, weight, defects |
| S2 | Weaving / Terry Loop Formation | 5–7 days | Fabric construction or terry weaving |
| S3 | Bleaching & Dyeing | 3–5 days | Base colour treatment applied |
| G1 🔑 | Lab Dip Approval | 5–7 days | Dyed sample vs buyer standard; shade band ±5% max. Rejection restarts the clock. |
| S4 | Bulk Dyeing | 5–7 days | Full production dyeing run after G1 sign-off |
| G2 | Color Range Sample | 3–5 days | Full colorway range (all PO options) confirmed |
| S5 | Cutting & Hemming / Stitching | 5 days | Fabric cut and sewn to final form |
| G3 | Bulk Fabric Approval | 3–5 days | Washed/shrunk panel approved before cutting; includes shrinkage test |
| G4 ★ | PP Sample | 5–7 days | Fully sewn piece with approved color; written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G1 🔑 Lab Dip Approval:** ⚠️ Shade band >±5% triggers full restart — each iteration adds 5–7 days; buyer colour standards may shift between seasons without notice. ✅ Submit 3–5 lab dip options in first round; confirm exact Pantone/buyer colour standard in writing before first submission.
- **G3 Bulk Fabric Approval:** ⚠️ Shrinkage discovered after cutting wastes entire cut panel run. ✅ Complete shrinkage test before any cutting commences — do not parallelize.
- **G4 ★ PP Sample:** ⚠️ Full production cost already sunk at this stage — defects are expensive to remediate. ✅ Written sign-off required; mass production must not commence without it.

---

## Key Compliance & Market Intelligence

- **REACH** compliance required for textile chemicals and dyes (restricted substances list).
- **Tariff exposure** applies to all textile imports; monitor origin/duty rates per shipment.
- Lab dip shade band of **±5% maximum** is the industry threshold; tighter requirements from buyer may reduce this.
- Shrinkage test at G3 is mandatory before cutting begins — failure at this stage causes significant rework.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-009-pakistan-home-textile](../../personas/COMBO-009-pakistan-home-textile.md)

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)

### Raw Materials
- RM-COTTON-YARN — cotton yarn; UFLPA traceability required for US
- RM-COTTON-FABRIC — woven/terry cotton fabric; FR-treated variants for certain SKUs
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)
- [PP-REG-TARIFF-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-TARIFF-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-TARIFF](../../regulations/REG-TARIFF.md)
