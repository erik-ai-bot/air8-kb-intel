---
type: product-category
id: CAT-HG-02
domain: hardgoods
layer: 2
name: Home Decor
risk_level: high
wip_gates: "varies (3–5 by sub-type)"
products:
  - Metal décor
  - Brass artware
  - Glass artware
  - Ceramic & resin artware
  - Candles
  - Vases
  - Picture frames
  - Figurines
  - Holiday décor
  - Christmas trees
key_risk: "Copper/brass T1 tariff exposure; annealing defect rate (glass); glost firing BOT (ceramic); FR flammability (Christmas trees — Gate 1)"
regulations:
  - REG-REACH
  - REG-TARIFF
  - REG-GPSR
  - REG-UFLPA
combos:
  - COMBO-HG-002-china-brass-artware
  - COMBO-HG-003-india-moradabad-brass-artware
---

# CAT-HG-02 — Home Decor

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-02 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | High |
| **WIP Gates** | Varies (3–5 by sub-type) |
| **Products** | Metal décor, Brass artware, Glass artware, Ceramic & resin artware, Candles, Vases, Picture frames, Figurines, Holiday décor, Christmas trees |
| **Key Risk** | Copper/brass T1 tariff exposure; annealing defect rate (glass); glost firing BOT (ceramic); FR flammability (Christmas trees — Gate 1) |
| **Regulations** | REG-REACH, REG-TARIFF, REG-GPSR, REG-UFLPA |
| **Combos** | COMBO-HG-002-china-brass-artware, COMBO-HG-003-india-moradabad-brass-artware |

---

## WIP Flow

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

### Metal Décor

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Material Receipt & Inspection | 1–2 days | Incoming metal checked against alloy/grade spec |
| G1 | Material Spec Sign-off | 1–2 days | Alloy, thickness, finish spec confirmed before production begins |
| S2 | Forming / Cutting / Casting | 3–7 days | Metal shaped to product form |
| G2 | Color Swatch Approval | 2–3 days | Anodizing tone / powder coat / paint confirmed |
| S3 | Initial Surface Treatment | 3–5 days | First-pass surface treatment applied |
| G3 | Finishing Swatch Approval | 2–3 days | Matte/gloss/brushed/hammered/antique finish confirmed; swatch retained as reference |
| G4 🔑 | REACH Heavy Metal Test | 3–5 days | Cr VI, Ni, Pb, Cd external lab report. Blocks bulk finishing. |
| S4 | Bulk Finishing | 5–7 days | Full-volume surface finishing after G4 pass |
| G5 ★ | PP Sample | 5–7 days | Fully finished piece; written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G1 Material Spec Sign-off:** ⚠️ Suppliers often describe zamak as "brass" — this misidentifies T1 copper tariff exposure and REACH test scope entirely. ✅ Require alloy spec sheet with % composition; zamak (<1% copper) and true brass (60–70% copper) are completely different risk profiles. (Ref: PP-HG-002)
- **S3 Initial Surface Treatment:** ⚠️ Surface treatment adhesion failure is the highest WIP risk — it is discovered at QC after full production cost is already sunk. Factories without a formal surface treatment approval process carry elevated QC risk. ✅ Require documented surface treatment approval process; flag factories that skip it. (Ref: PP-HG-005)
- **G4 🔑 REACH Heavy Metal Test:** ⚠️ Alloy mismatch (zamak vs brass) only confirmed here — blocks bulk finishing for 3–5 days; albright/yellow lead alloy = environmental regulatory violation, do not finance. ✅ Pre-screen with supplier mill cert at G1; use accredited lab (SGS/Intertek/BV) per batch, not per SKU. (Ref: PP-HG-005)
- **G5 ★ PP Sample:** ⚠️ Cosmetic defects discovered post-production are expensive to remediate. ✅ Align acceptance criteria with buyer before PP review; written sign-off required before mass production.

### Brass Artware

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Material Receipt & Inspection | 1–2 days | Brass alloy received and checked |
| G1 | Material Spec Sign-off | 1–2 days | Alloy composition (60–70% copper) confirmed |
| S2 | Forming / Casting | 3–7 days | Brass shaped to product form |
| G2 | Color Swatch Approval | 2–3 days | Color confirmed |
| S3 | Electroplating / Surface Treatment | 5–7 days | Plating applied |
| G3 | Finishing Swatch Approval | 2–3 days | Surface treatment confirmed |
| G4 🔑 | REACH Heavy Metal (Electroplating) | 3–5 days | Electroplating gate doubles as REACH gate; Cr VI, Ni, Pb, Cd external lab test |
| S4 | Bulk Finishing | 5–7 days | Full-volume finishing after G4 pass |
| G5 ★ | PP Sample | 5–7 days | Written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G1 Material Spec Sign-off:** ⚠️ Scrap copper inputs vary in purity — alloy composition may be inconsistent batch-to-batch; T1 copper tariff impact (PP-HG-002) depends on verified copper content, not supplier claims. ✅ Require mill cert per batch; confirm copper % before T1 tariff exposure assessment.
- **G4 🔑 REACH Heavy Metal (Electroplating):** ⚠️ Electroplating bath contamination can introduce Cr VI into plating — EU customs detention risk if undeclared. ✅ Require test cert per batch from SGS/Intertek/BV; mandate factory maintain bath chemistry log. (Ref: PP-HG-005)
- **G5 ★ PP Sample:** ⚠️ Plating adhesion failures may not be visible until post-production stress testing. ✅ Include scratch adhesion test in PP review; written sign-off required.

### Glass Artware

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Raw Material / Batch Preparation | 1–2 days | Glass batch mixed; furnace loaded |
| S2 | Kiln Production / Blowing / Casting | 3–5 days | Glass formed into product shape |
| G1 | Color / Design Proof | 3–5 days | Kiln-test piece reviewed for color match and pattern accuracy |
| S3 | Annealing Process | 1–2 days | Controlled cooling cycle to relieve internal stress |
| G2 🔑 | Annealing Test — Polariscope | 2–3 days | Stress-free annealing confirmed. Failure = kiln temperature profile reset. |
| S4 | Finishing / Decoration | 3–5 days | Surface decoration, etching, or painting applied |
| G3 | REACH Compliance Test | 3–5 days | Lead crystal / surface treatment chemicals tested |
| G4 ★ | PP Sample | 5–7 days | Written sign-off required |

**Stage Notes (Josephine Cheung):**
- **S3 Annealing Process:** ⚠️ Too-fast cooling introduces residual stress — spontaneous breakage in field is a critical safety defect (Josephine defect classification). ✅ Log and control cooling curve for every kiln batch; document cooling profile by product weight/thickness.
- **G2 🔑 Annealing Test — Polariscope:** ⚠️ Failure requires full kiln temperature profile redesign — delays all subsequent batches. ✅ Run polariscope check on first 5 pieces before committing to full bulk run; do not skip.
- **G3 REACH Compliance Test:** ⚠️ Lead crystal suppliers may rely on annual certs that don't cover current batch chemistry. ✅ Require test cert per batch; specify accredited lab; do not accept certs >6 months old.

### Ceramic & Resin Artware

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Clay / Body Preparation | 1–2 days | Clay body mixed and prepared |
| S2 | Forming / Moulding | 2–3 days | Product shaped by casting, throwing, or pressing |
| S3 | Bisque Firing | 2–3 days | First firing to harden body before glazing |
| G1 🔑 | Glaze / Color Swatch — Glost Firing | 5–7 days | FIRED tile swatch only (unfired not representative). BOT — glost firing costliest gate; cooling too fast = dunting cracks. |
| G2 | Finishing Swatch | 2–3 days | Gloss/matte/textured/crackle glaze confirmed |
| G3 🔑 | Heavy Metal Test | 3–5 days | ASTM C738/C927, EN 1388, FDA CFR 21, CA Prop 65. Run in PARALLEL with S3/G1/G2. |
| S4 | Bulk Glazing & Glost Firing | 7–10 days | Full production glost firing after G1/G2/G3 pass |
| G4 ★ | PP Sample | 5–7 days | Written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G1 🔑 Glaze / Color Swatch — Glost Firing:** ⚠️ Glost firing is the most expensive gate — cooling too fast = dunting cracks; pieces touching = fused together; refire = full cost repeat. ✅ Review kiln load plan before every firing; enforce load spacing spec; use controlled cooling curve.
- **G3 🔑 Heavy Metal Test:** ⚠️ Traditional glaze pigments may contain lead/cadmium — leaching above FDA/EU limits = product recall (critical defect per Josephine). Sequential scheduling extends lead time unnecessarily. ✅ Run in PARALLEL with S3/G1/G2, not sequentially; pre-qualify all glaze pigment suppliers against approved pigment list.
- **S4 Bulk Glazing & Glost Firing:** ⚠️ Crazing (micro-cracks in glaze) may appear after cooling and is not visible during production — creates bacterial harbor risk, critical defect. ✅ QC first batch before continuing full run; retain kiln temperature log.

### Holiday Décor

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Material Receipt | 1–2 days | Incoming materials checked |
| G1 | Color Swatch | 2–3 days | Color palette confirmed |
| S2 | Production / Assembly | 5–7 days | Components manufactured and assembled |
| G2 | Finishing Swatch | 2–3 days | Surface finish/coating confirmed |
| G3 ★ | PP Sample | 5–7 days | Written sign-off required |

**Stage Notes (Josephine Cheung):**
- **S2 Production / Assembly:** ⚠️ Small detachable parts = choking hazard for children's range; restricted substances in painted/coated surfaces for EU/US. ✅ Pull-force test per EN 71 / ASTM F963 for children's items; REACH RS test required for all EU/US-bound product.
- **G3 ★ PP Sample:** ⚠️ Packaging fit issues cause damage in transit — not caught until delivery. ✅ Include retail packaging in PP review; test pack/unpack cycle.

### Christmas Trees

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Material Receipt | 1–2 days | Incoming materials checked |
| G1 🔑 | FR Flammability Test | 5–7 days | **Must pass before all other gates.** BS 5852 / CA TB 117 / EN 13501. Failure resets sequence. |
| S2 | Production / Assembly | 7–10 days | Tree structure and branches assembled |
| G2 | Color Swatch | 2–3 days | Color approved (only after G1 pass) |
| G3 | Finishing Swatch | 2–3 days | Surface treatment approved |
| G4 ★ | PP Sample | 5–7 days | Written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G1 🔑 FR Flammability Test:** ⚠️ Starting colour work before FR pass wastes all sample materials if FR fails — this is a non-negotiable gate sequence. PVC FR additive may not be declared on incoming material data sheets. ✅ Always run FR first — never proceed to G2 without G1 pass; require material data sheet with FR additive specification and CAS number.

---

## Key Compliance & Market Intelligence

- **T1 Copper Tariff (July 2026):** True brass has the **highest exposure**; zamak alloy is near-zero exposure. India (Moradabad) is the primary diversification destination.

### Decor: Material Composition Determines T1 Exposure

“Copper” or “brass” look ≠ high copper content. Material substitution is widespread in Chinese decor:

| Material | Copper content | T1 exposure | Typical products | Buyer segment |
|---|---|---|---|---|
| **True solid brass** | 60–70% | 🔴 High | Premium candleholders, artware, figurines | Premium (RH, Williams-Sonoma, C&B) |
| **Zinc alloy (zamak)** | Near zero | 🟢 Low | Mass-market brass-look décor | Mass (Walmart, Target, Amazon) |
| **Iron/steel + copper plating** | Plating only | 🟢 Very low | Wall art, lanterns, industrial décor | Mid-market |
| **Aluminium + copper coating** | Plating only | 🟢 Very low | Lightweight decorative pieces | Mid-market |

### Buyer Bifurcation in Decor (T1 Effect)

- **Premium buyers** (Restoration Hardware, Williams-Sonoma, Crate & Barrel): scrutinising material authenticity → T1 accelerating shift to India for genuine brass. These buyers are ACTIVELY qualifying Moradabad in 2026.
- **Mass market buyers** (Walmart, Target, Amazon): prioritise price and volume, do not require material authenticity → China zamak decor holds ground. T1 barely touches zamak; no meaningful buyer shift expected.

### Air8 Decor Assessment Protocol

When evaluating a China decor supplier’s T1 exposure:
1. **First question:** What is their actual alloy composition? (zamak vs true brass — request mill cert or alloy spec sheet)
2. **Check via:** G4 REACH Heavy Metal test report — this confirms actual alloy (Cr VI, Ni, Pb testing also reveals alloy family)
3. **Buyer concentration:** Which retail channel? Premium buyer → India risk applies; mass market buyer → stable

Decision tree:
- Zamak + mass market buyer = CONDITIONAL EXPAND (no T1 exposure; EU demand viable)
- True brass + EU/ME buyer = CAUTION (input cost rise; margin compressed)
- True brass + US premium buyer = DO_NOT_EXPAND (double compression + buyer qualifying India)

- **REACH:** Heavy metal compliance (Cr VI, Ni, Pb, Cd) is mandatory for all metal and plated products; test lead time is 3–5 days.
- **GPSR (EU):** General Product Safety Regulation applies to all décor sold in the EU.
- **UFLPA:** Uyghur Forced Labor Prevention Act — supply chain traceability required for all China-origin shipments.
- **India Moradabad:** Established brass artware cluster; viable alternative to China for brass, lower T1 tariff exposure.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-HG-002-china-brass-artware](../../personas/hardgoods/COMBO-HG-002-china-brass-artware.md)
- [COMBO-HG-003-india-moradabad-brass-artware](../../personas/hardgoods/COMBO-HG-003-india-moradabad-brass-artware.md)

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [USPremiumHome](../../buyer-types/USPremiumHome.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)
- [EUSpecialty](../../buyer-types/EUSpecialty.md)
- [MiddleEastPremium](../../buyer-types/MiddleEastPremium.md)

### Raw Materials
- RM-COPPER-CN-IMPORTED — true brass (60–70% copper); highest T1 tariff exposure
- RM-ZAMAK-CN — zinc alloy (<1% copper); NO copper tariff exposure; often misidentified as brass
- RM-COPPER-DOMESTIC-IND — India domestic copper; T1 insulation (per-factory verification required)
- RM-COPPER-SCRAP-IND — imported scrap copper (Moradabad predominant); partial insulation only
- RM-GLASS-BATCH — silica/soda ash batch for glass artware
- RM-CERAMIC-GLAZE — glaze pigments; lead/cadmium compliance critical
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-HG-002-tariff-double-compress](../../../layer-1-reasoning/pain-points/hardgoods/PP-HG-002-tariff-double-compress.md)
- [PP-HG-003-india-copper-hedge](../../../layer-1-reasoning/pain-points/hardgoods/PP-HG-003-india-copper-hedge.md)
- [PP-HG-005-reach-rohs-compliance](../../../layer-1-reasoning/pain-points/hardgoods/PP-HG-005-reach-rohs-compliance.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-TARIFF](../../regulations/REG-TARIFF.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
- [REG-UFLPA](../../regulations/REG-UFLPA.md)
