---
type: product-category
id: CAT-HG-07
domain: hardgoods
layer: 2
name: Consumer Electronics
risk_level: high
wip_gates: "4"
products:
  - Speakers
  - Clocks
  - Smart home accessories
key_risk: "—"
regulations:
  - REG-CE-LVD-EMC
  - REG-FCC-PART15
  - REG-GPSR
combos: []
---

# CAT-HG-07 — Consumer Electronics

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-07 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | High |
| **WIP Gates** | 4 |
| **Products** | Speakers, Clocks, Smart home accessories |
| **Key Risk** | EMC/EMI certification (CE/FCC); electrical safety (LVD); battery safety; certification lead time 2–6 weeks is critical path |
| **Scope Note** | Finished goods only — excludes components and sub-assemblies |
| **Regulations** | REG-CE-LVD-EMC, REG-FCC-PART15, REG-GPSR |
| **Combos** | — |

---

## WIP Flow — Consumer Electronics

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

| Step | Name | Lead Time | Description |
|---|---|---|---|
| G1 🔑 | Factory Cert & Component Compliance (BOT) | 3–5 days | Factory electrical safety cert confirmed; RoHS component declaration obtained for all electronic components. Blocks production start. |
| G2 | EMC/EMI Pre-compliance Check | 5–7 days | Preliminary EMC test conducted on prototypes to identify interference issues before full production tooling is committed. |
| PP ★ | Pre-Production Sample | 7–14 days | Full functional and safety test: insulation resistance, earth continuity (where applicable), plug/connector compliance; written sign-off required. |
| G3 | Production Monitoring | Ongoing | AQL inline at 30%, 50%, 100% of production run; batch EMC spot-check on production units. |
| G4 🔑 | Certification & Release | 14–42 days | CE/FCC test report obtained; battery safety compliance confirmed (if applicable); market-specific label approval; lab report reviewed before shipment release. |

**Lead Times:** 8–12 weeks total; certification (G4) 2–6 weeks must be factored into scheduling from Day 1 of production.

**Stage Notes:**
- **G1 🔑 Factory Cert & Component Compliance (BOT):** ⚠️ Non-certified factories producing electrical goods expose Air8 clients to CE/FCC invalidation; RoHS-violating components (lead, cadmium in PCBs) discovered post-production = shipment rejection. ✅ Verify factory electrical safety certification before purchase order release; require full RoHS component declaration with test evidence at booking stage; do not accept self-declaration alone.
- **G2 EMC/EMI Pre-compliance Check:** ⚠️ EMC failures discovered at full certification stage (G4) require design changes that invalidate completed production tooling; re-testing cycle adds 2–4 weeks. ✅ Conduct pre-compliance EMC test on first prototype before tooling is finalized; document and resolve any interference issues at G2 before G3 production run begins.
- **PP ★ Pre-Production Sample:** ⚠️ Insulation resistance and earth continuity defects are latent safety hazards that may not manifest until field use; plug/connector non-compliance triggers immediate market withdrawal in EU/US. ✅ Test all electrical safety parameters (insulation resistance min 10 MΩ, earth continuity <0.1Ω) on PP sample; verify connector spec against target market plug standard; written sign-off required before proceeding.
- **G3 Production Monitoring:** ⚠️ Component substitution mid-run (cost-cutting by factory) can invalidate EMC certification; solder joint defects create latent failure risk. ✅ Verify component BoM at 50% inspection checkpoint matches certified design; include X-ray or AOI solder inspection in G3 protocol for critical assemblies.
- **G4 🔑 Certification & Release:** ⚠️ CE/FCC certification 2–6 weeks is non-compressible; late start = direct delivery delay; selling uncertified electronics in EU/US = criminal liability for importer. ✅ Submit to certification lab at earliest possible date (Day 1 of G3 production); budget 6 weeks for complex wireless/Bluetooth products; do not ship before certificate received.

---

## Key Compliance & Market Intelligence

- **Scope:** This category covers **finished goods only** — speakers, clocks, smart home accessories. Components and sub-assemblies are excluded from Air8 hardgoods scope.
- **CE LVD / EMC (EU):** All electrical consumer electronics sold in the EU require CE marking under the Low Voltage Directive and EMC Directive. Certification is product- and geography-specific.
- **FCC Part 15 (US):** Electromagnetic compatibility certification required for any device that emits radio frequency energy sold in the US.
- **GPSR (EU):** General Product Safety Regulation applies to all consumer electronics sold in the EU.
- Certification lead times typically 2–6 weeks; must be factored into production scheduling when WIP gates are formalized.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUSpecialty](../../buyer-types/EUSpecialty.md)

### Raw Materials
- RM-PCB-COMPONENTS — printed circuit boards; REACH/RoHS compliance
- RM-PLASTIC-HOUSING — ABS/PC housing; REACH compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-CE-LVD-EMC](../../regulations/REG-CE-LVD-EMC.md)
- [REG-FCC-PART15](../../regulations/REG-FCC-PART15.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
