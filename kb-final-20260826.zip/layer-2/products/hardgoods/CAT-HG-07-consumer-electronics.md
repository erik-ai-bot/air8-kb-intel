---
type: product-category
id: CAT-HG-07
domain: hardgoods
layer: 2
name: Consumer Electronics
risk_level: "—"
wip_gates: "—"
products:
  - Speakers
  - Clocks
  - Smart home accessories
key_risk: "—"
regulations:
  - REG-CE-LVD-EMC
  - REG-FCC-PART15
  - REG-GPSR
combos: []
---

# CAT-HG-07 — Consumer Electronics

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-07 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | — *(not yet assessed)* |
| **WIP Gates** | — *(not yet defined)* |
| **Products** | Speakers, Clocks, Smart home accessories |
| **Key Risk** | — *(not yet assessed)* |
| **Scope Note** | Finished goods only — excludes components and sub-assemblies |
| **Regulations** | REG-CE-LVD-EMC, REG-FCC-PART15, REG-GPSR |
| **Combos** | — |

---

## WIP Gates

> **WIP not yet defined.** Production gates for Consumer Electronics have not been mapped. When defined, gates should address electrical safety (LVD), EMC/EMI testing, and market certification requirements for target geographies (US: FCC; EU: CE marking).

---

## Key Compliance & Market Intelligence

- **Scope:** This category covers **finished goods only** — speakers, clocks, smart home accessories. Components and sub-assemblies are excluded from Air8 hardgoods scope.
- **CE LVD / EMC (EU):** All electrical consumer electronics sold in the EU require CE marking under the Low Voltage Directive and EMC Directive. Certification is product- and geography-specific.
- **FCC Part 15 (US):** Electromagnetic compatibility certification required for any device that emits radio frequency energy sold in the US.
- **GPSR (EU):** General Product Safety Regulation applies to all consumer electronics sold in the EU.
- Certification lead times typically 2–6 weeks; must be factored into production scheduling when WIP gates are formalized.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUSpecialty](../../buyer-types/EUSpecialty.md)

### Raw Materials
- RM-PCB-COMPONENTS — printed circuit boards; REACH/RoHS compliance
- RM-PLASTIC-HOUSING — ABS/PC housing; REACH compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-CE-LVD-EMC](../../regulations/REG-CE-LVD-EMC.md)
- [REG-FCC-PART15](../../regulations/REG-FCC-PART15.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
