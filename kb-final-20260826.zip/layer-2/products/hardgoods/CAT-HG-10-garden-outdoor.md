---
type: product-category
id: CAT-HG-10
domain: hardgoods
layer: 2
name: Garden & Outdoor
risk_level: "—"
wip_gates: "— (outdoor furniture → see CAT-HG-04)"
products:
  - Outdoor furniture (→ see CAT-HG-04 for WIP)
  - Garden décor
  - Planters
  - BBQ/grill accessories
  - Outdoor storage
  - Garden hand tools
key_risk: "Outdoor furniture: salt spray + UV 21-day critical path; tariff-driven China→Vietnam shift"
regulations:
  - REG-REACH
  - REG-TARIFF
  - REG-UFLPA
combos:
  - COMBO-HG-001-china-outdoor-furniture
---

# CAT-HG-10 — Garden & Outdoor

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-10 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | — *(not yet assessed for non-furniture sub-types)* |
| **WIP Gates** | — (outdoor furniture WIP → cross-ref [CAT-HG-04](CAT-HG-04-furniture.md)) |
| **Products** | Outdoor furniture, Garden décor, Planters, BBQ/grill accessories, Outdoor storage, Garden hand tools |
| **Key Risk** | Outdoor furniture: salt spray + UV 21-day critical path; tariff-driven China→Vietnam shift |
| **Regulations** | REG-REACH, REG-TARIFF, REG-UFLPA |
| **Combos** | COMBO-HG-001-china-outdoor-furniture |

---

## WIP Gates

### Outdoor Furniture
> **Cross-reference [CAT-HG-04 — Furniture](CAT-HG-04-furniture.md)** for the full 5-gate outdoor furniture WIP, including the 21-day salt spray + UV critical path (G3).

---

### Garden Décor, Planters, BBQ/Grill Accessories, Outdoor Storage, Garden Hand Tools

> **WIP not yet defined.** Production gates for non-furniture outdoor sub-types have not been mapped. When defined, consider:
> - **Planters:** Material durability (UV, frost resistance), drainage compliance
> - **BBQ/Grill accessories:** Food-contact safety (coatings), heat resistance testing
> - **Garden hand tools:** Ergonomics, blade/edge safety, material durability
> - **Outdoor storage:** Weatherproofing, structural load, UV resistance

---

## Key Compliance & Market Intelligence

- **Outdoor Furniture — 21-Day Critical Path:** Salt spray (ASTM B117, min 500 hr) + UV test (AATCC 16) cannot be compressed. Production timeline for outdoor furniture is anchored to this gate — see [CAT-HG-04](CAT-HG-04-furniture.md).
- **Tariff-Driven Sourcing Shift:** China→Vietnam sourcing shift for outdoor furniture is a **tariff-risk policy decision**, not cost arbitrage. Outdoor furniture is seasonal — the decision is **binary and annual**. Mid-season origin changes are not viable.
- **REACH:** Applies to coatings, finishes, and materials across all garden and outdoor products — powder coat, galvanized surfaces, plastic planters.
- **UFLPA:** Supply chain traceability required for all China-origin products entering the US market.
- **Tariff Exposure:** Outdoor furniture and metal garden products may face significant tariff impact; monitor T1 commodity tariff changes.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-HG-001-china-outdoor-furniture](../../personas/hardgoods/COMBO-HG-001-china-outdoor-furniture.md)

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [USPremiumHome](../../buyer-types/USPremiumHome.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [MiddleEastPremium](../../buyer-types/MiddleEastPremium.md)

### Raw Materials
- RM-ALUMINUM-CN — aluminium for garden structures; tariff exposure
- RM-WOOD-FSC-OUTDOOR — FSC timber for planters/furniture; UFLPA chain-of-custody
- RM-CERAMIC-TERRACOTTA — terracotta/ceramic planters; REACH compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-UFLPA-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-UFLPA-001.md)
- [PP-REG-TARIFF-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-TARIFF-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-TARIFF](../../regulations/REG-TARIFF.md)
- [REG-UFLPA](../../regulations/REG-UFLPA.md)

### Related Categories
- [CAT-HG-04 — Furniture](CAT-HG-04-furniture.md) *(outdoor furniture WIP gates)*
