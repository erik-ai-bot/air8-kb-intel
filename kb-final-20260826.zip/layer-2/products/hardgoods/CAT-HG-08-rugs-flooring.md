---
type: product-category
id: CAT-HG-08
domain: hardgoods
layer: 2
name: Rugs & Flooring
risk_level: medium
wip_gates: "4"
products:
  - Area rugs
  - Bath mats
  - Door mats
  - Vinyl/LVT flooring
  - Carpet tiles
key_risk: "—"
regulations:
  - REG-REACH
  - REG-GPSR
combos: []
---

# CAT-HG-08 — Rugs & Flooring

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-08 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | Medium |
| **WIP Gates** | 4 |
| **Products** | Area rugs, Bath mats, Door mats, Vinyl/LVT flooring, Carpet tiles |
| **Key Risk** | Phthalate/VOC compliance (vinyl/LVT); dye lot consistency; CARB/FloorScore certification 10–14 week critical path |
| **Regulations** | REG-REACH, REG-GPSR |
| **Combos** | — |

---

## WIP Flow — Rugs & Flooring

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

| Step | Name | Lead Time | Description |
|---|---|---|---|
| G1 🔑 | Yarn/Dye Lot Cert & Material Check (BOT) | 3–5 days | Fiber content declaration obtained; dye lot traceability confirmed; carpet yarn cert reviewed. Blocks production start. |
| G2 | Strike-off / Colorway Approval | 3–5 days | Buyer sign-off on pattern, colorway, and construction spec against reference sample; no production until confirmed. |
| PP ★ | Pre-Production Sample | 7–14 days | Dimensional stability test, pile height measurement, backing adhesion test, phthalate/VOC compliance test on PP sample; written sign-off required. |
| G3 | Production Monitoring | Ongoing | Inline checks: weave/dye consistency across lots; phthalate spot-check for vinyl/LVT production runs. |
| G4 | Final QC & Compliance Release | 5–10 days | AQL final inspection; VOC emission test report (vinyl/LVT); formaldehyde test report (wood flooring); label verification before shipment release. |

**Lead Times:** 6–10 weeks for most products; 10–14 weeks if CARB/FloorScore certification required (vinyl/LVT for US market).

**Stage Notes:**
- **G1 🔑 Yarn/Dye Lot Cert & Material Check (BOT):** ⚠️ Dye lot substitution mid-production causes color inconsistency that is undetectable until final inspection; undeclared synthetic fiber blends can violate fiber content labeling laws (FTC Textile Act in the US). ✅ Require dye lot certificate with purchase order; lock dye lot before production start; verify fiber content declaration matches FTC label requirements for US-bound product.
- **G2 Strike-off / Colorway Approval:** ⚠️ Color metameric failure (correct under factory lighting, wrong under retail D65 lighting) results in buyer rejection and re-production; pattern repeat errors discovered post-production = material waste. ✅ Review strike-off under D65/TL84 standard lighting box; confirm pattern repeat dimensions against buyer tech pack before approving full production.
- **PP ★ Pre-Production Sample:** ⚠️ Phthalate violations in vinyl backing are not detectable by visual inspection and trigger REACH enforcement action in the EU; pile height deviation >10% causes buyer deduction or return. ✅ Send PP sample to accredited lab for phthalate testing (REACH Annex XVII, Regulation (EC) No 1907/2006) before production run; measure pile height at 5 points across sample; written sign-off required.
- **G3 Production Monitoring:** ⚠️ Dye batch change mid-run (factory expedience) causes lot-to-lot color variation; phthalate content in vinyl substrate can vary between production batches from the same factory. ✅ Pull color swatches at 30% and 60% completion for visual and spectrophotometer check against G2 approved standard; spot-check phthalate content on vinyl/LVT at each batch change.
- **G4 Final QC & Compliance Release:** ⚠️ VOC emissions test for vinyl/LVT (CARB FloorScore; French A+ regulation) takes 5–10 days and cannot be compressed; non-compliant product triggers US/EU customs detention. ✅ Submit samples for VOC/formaldehyde testing at G3 final inspection stage; do not ship before receiving test report; verify all labels (fiber content, country of origin, flammability) are correct before container loading.

---

## Key Compliance & Market Intelligence

- **REACH:** Restricted substances apply to dyes, backing materials, adhesives, and any chemical treatments. Phthalate restrictions are especially relevant for vinyl/LVT flooring.
- **GPSR (EU):** General Product Safety Regulation applies to all flooring and rug products sold in the EU; includes requirements for slip resistance and flammability where relevant.
- VOC emissions from vinyl/LVT flooring may be subject to additional standards (e.g., CARB/FloorScore in the US, A+ in France) — to be mapped when WIP gates are defined.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)

### Raw Materials
- RM-POLYPROPYLENE-YARN — PP yarn for area rugs; REACH VOC compliance
- RM-COTTON-YARN — cotton rugs; UFLPA if US-bound
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
