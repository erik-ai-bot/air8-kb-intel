---
type: product-category
id: CAT-HG-08
domain: hardgoods
layer: 2
name: Rugs & Flooring
risk_level: "—"
wip_gates: "—"
products:
  - Area rugs
  - Bath mats
  - Door mats
  - Vinyl/LVT flooring
  - Carpet tiles
key_risk: "—"
regulations:
  - REG-REACH
  - REG-GPSR
combos: []
---

# CAT-HG-08 — Rugs & Flooring

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-08 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | — *(not yet assessed)* |
| **WIP Gates** | — *(not yet defined)* |
| **Products** | Area rugs, Bath mats, Door mats, Vinyl/LVT flooring, Carpet tiles |
| **Key Risk** | — *(not yet assessed)* |
| **Regulations** | REG-REACH, REG-GPSR |
| **Combos** | — |

---

## WIP Gates

> **WIP not yet defined.** Production gates for Rugs & Flooring have not been mapped. When defined, gates should address dye/colorway consistency (area rugs), phthalate/VOC compliance for vinyl/LVT flooring, slip resistance testing, and formaldehyde emissions where applicable.

---

## Key Compliance & Market Intelligence

- **REACH:** Restricted substances apply to dyes, backing materials, adhesives, and any chemical treatments. Phthalate restrictions are especially relevant for vinyl/LVT flooring.
- **GPSR (EU):** General Product Safety Regulation applies to all flooring and rug products sold in the EU; includes requirements for slip resistance and flammability where relevant.
- VOC emissions from vinyl/LVT flooring may be subject to additional standards (e.g., CARB/FloorScore in the US, A+ in France) — to be mapped when WIP gates are defined.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)

### Raw Materials
- RM-POLYPROPYLENE-YARN — PP yarn for area rugs; REACH VOC compliance
- RM-COTTON-YARN — cotton rugs; UFLPA if US-bound
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
