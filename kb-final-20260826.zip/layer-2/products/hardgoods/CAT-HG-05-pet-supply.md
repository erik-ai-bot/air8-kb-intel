---
type: product-category
id: CAT-HG-05
domain: hardgoods
layer: 2
name: Pet Supply
risk_level: medium
wip_gates: "4"
products:
  - Pet beds
  - Feeding bowls
  - Toys
  - Carriers
  - Grooming accessories
key_risk: "—"
regulations:
  - REG-REACH
  - REG-GPSR
combos: []
---

# CAT-HG-05 — Pet Supply

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-05 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | Medium |
| **WIP Gates** | 4 |
| **Products** | Pet beds, Feeding bowls, Toys, Carriers, Grooming accessories |
| **Key Risk** | Food-grade compliance (feeding bowls); choking hazard / toy safety; textile flame retardancy (pet beds) |
| **Regulations** | REG-REACH, REG-GPSR |
| **Combos** | — |

---

## WIP Flow — Pet Supply

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

| Step | Name | Lead Time | Description |
|---|---|---|---|
| G1 🔑 | Mold/Tool & Material Cert (BOT) | 3–5 days | Plastic pellets and metal components verified for food-grade compliance; must confirm at booking of tools. Blocks production start for feeding bowls. |
| G2 | Color Swatch / Prototype Approval | 3–5 days | Color match, texture, and choking-hazard check confirmed on prototype; buyer sign-off required before production run. |
| PP ★ | Pre-Production Sample | 5–7 days | Full PP sample sign-off: drop test, bite test, structural load test for carriers; written sign-off required. |
| G3 | Production Monitoring | Ongoing | AQL inline at 30%, 60%, 100% of production run; textile flame retardancy spot-check for pet beds. |
| G4 | Final QC & Safety Release | 3–5 days | Final QC inspection: packaging, labeling, warning labels; lab test report review before shipment release. |

**Lead Times:** 30–45 days for plastics/metal; 45–60 days if textile components (pet beds) included.

**Stage Notes:**
- **G1 🔑 Mold/Tool & Material Cert (BOT):** ⚠️ Suppliers may use non-food-grade plastic resins for feeding bowls to reduce cost; mold tooling defects can introduce sharp edges that become choking hazards. ✅ Require food-grade resin declaration with material specification (FDA CFR 21 / EU 10/2011 analog); inspect first shots from new tooling for flash, sharp edges, and dimensional compliance before approving production run.
- **G2 Color Swatch / Prototype Approval:** ⚠️ Color dyes in pet toys may contain restricted substances (REACH); fabric texture for pet beds may differ from buyer spec at scale. ✅ Cross-check colorants against REACH SVHCs; confirm texture and softness spec on prototype against buyer reference sample.
- **PP ★ Pre-Production Sample:** ⚠️ Drop test and bite test failures discovered post-production = safety recall risk; carrier structural load failure = critical defect. ✅ Conduct drop test from 1m height (all faces); bite test on exposed soft components; load test carriers to 2× rated weight; written sign-off required before proceeding.
- **G3 Production Monitoring:** ⚠️ Inline defect rates can spike mid-run on injection moulded pet toys if tooling wears; flame retardancy of textile pet beds may degrade if fabric lot is substituted. ✅ Verify fabric lot certificates match approved spec at 60% inspection; pull mould from production at G3 final check if dimensional drift detected.
- **G4 Final QC & Safety Release:** ⚠️ Missing or incorrect warning labels (age grading, choking hazard) on pet toys can trigger customs holds and market withdrawal. ✅ Verify all required warning labels present and legible; confirm lab test report covers relevant categories (REACH, food-contact where applicable) before releasing shipment.

---

## Key Compliance & Market Intelligence

- **REACH:** Restricted substances compliance required for all materials — especially relevant for plastic feeding bowls, fabric beds, and rubber toys.
- **GPSR (EU):** General Product Safety Regulation applies to all pet supply products sold in the EU; includes safety assessment requirements for toys and accessories.
- Additional pet-specific regulations (e.g., ASTM F963 analog for pet toys, FDA for food-contact bowls) to be mapped when WIP gates are defined.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUSpecialty](../../buyer-types/EUSpecialty.md)

### Raw Materials
- RM-PLASTIC-COMPOUND — injection-moulded components; REACH phthalate/lead compliance
- RM-POLYESTER-FABRIC — pet bed fabrics; OEKO-TEX/REACH compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
