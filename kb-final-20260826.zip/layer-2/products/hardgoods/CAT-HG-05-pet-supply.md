---
type: product-category
id: CAT-HG-05
domain: hardgoods
layer: 2
name: Pet Supply
risk_level: "—"
wip_gates: "—"
products:
  - Pet beds
  - Feeding bowls
  - Toys
  - Carriers
  - Grooming accessories
key_risk: "—"
regulations:
  - REG-REACH
  - REG-GPSR
combos: []
---

# CAT-HG-05 — Pet Supply

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-05 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | — *(not yet assessed)* |
| **WIP Gates** | — *(not yet defined)* |
| **Products** | Pet beds, Feeding bowls, Toys, Carriers, Grooming accessories |
| **Key Risk** | — *(not yet assessed)* |
| **Regulations** | REG-REACH, REG-GPSR |
| **Combos** | — |

---

## WIP Gates

> **WIP not yet defined.** Production gates for Pet Supply have not been mapped. Once defined, gates should address material safety (food-grade bowls), choking hazard / toy safety testing, and structural integrity for carriers.

---

## Key Compliance & Market Intelligence

- **REACH:** Restricted substances compliance required for all materials — especially relevant for plastic feeding bowls, fabric beds, and rubber toys.
- **GPSR (EU):** General Product Safety Regulation applies to all pet supply products sold in the EU; includes safety assessment requirements for toys and accessories.
- Additional pet-specific regulations (e.g., ASTM F963 analog for pet toys, FDA for food-contact bowls) to be mapped when WIP gates are defined.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
— *(No combos defined yet)*

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUSpecialty](../../buyer-types/EUSpecialty.md)

### Raw Materials
- RM-PLASTIC-COMPOUND — injection-moulded components; REACH phthalate/lead compliance
- RM-POLYESTER-FABRIC — pet bed fabrics; OEKO-TEX/REACH compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-REACH-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-GPSR](../../regulations/REG-GPSR.md)
