---
type: product-category
id: CAT-HG-04
domain: hardgoods
layer: 2
name: Furniture
risk_level: high
wip_gates: "5 (indoor) / 5 (outdoor)"
products:
  - Indoor furniture (case goods, upholstered)
  - Outdoor furniture (dining sets, lounge, umbrellas, shade structures)
key_risk: "CARB Phase 2 formaldehyde (indoor); salt spray + UV 21-day critical path (outdoor); outdoor sourcing shift China→Vietnam"
regulations:
  - REG-REACH
  - REG-TARIFF
  - REG-UFLPA
  - REG-CSDDD
combos:
  - COMBO-HG-001-china-outdoor-furniture
---

# CAT-HG-04 — Furniture

## Properties

| Property | Value |
|---|---|
| **ID** | CAT-HG-04 |
| **Domain** | Hardgoods |
| **Layer** | 2 — Entity |
| **Risk Level** | High |
| **WIP Gates** | 5 (indoor) / 5 (outdoor) |
| **Products** | Indoor furniture (case goods, upholstered), Outdoor furniture (dining sets, lounge, umbrellas, shade structures) |
| **Key Risk** | CARB Phase 2 formaldehyde (indoor); salt spray + UV 21-day critical path (outdoor); outdoor sourcing shift China→Vietnam |
| **Regulations** | REG-REACH, REG-TARIFF, REG-UFLPA, REG-CSDDD |
| **Combos** | COMBO-HG-001-china-outdoor-furniture |

---

## WIP Flow

> **Legend:** S = Production Stage | G = Gate (approval checkpoint) | 🔑 = Key Gate (test-lab / BOT / must-start-Day-1) | ★ = PP Sample (written sign-off required)

### Indoor Furniture

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Material Sourcing / Receipt | 3–5 days | Timber, panels, hardware received and inspected |
| G1 | Material Cert | 3–5 days | FSC chain of custody + CARB Phase 2 compliance documentation confirmed |
| G2 | Color / Finish Swatch | 3–5 days | Wood stain/paint/lacquer/varnish + fabric colorway confirmed |
| G3 🔑 | Formaldehyde / VOC Test | 7–14 days | CARB Phase 2 / EU E1 / JIS F★★★★. **Start Day 1 of production** — run concurrent with S2; cannot wait for G2 sign-off. |
| S2 | Production / Assembly | 10–14 days | Cutting, joinery, upholstery, assembly (concurrent with G3) |
| G4 | Structural Load Test | 5–7 days | ASTM F2057 tip-over test mandatory for US case goods |
| G5 ★ | PP Sample | 7–10 days | Fully assembled; written sign-off required |

**Stage Notes (Josephine Cheung):**
- **G1 Material Cert:** ⚠️ FSC certificates can be fraudulent; CARB Phase 2 certs for composite panels may be expired. ✅ Verify FSC cert serial numbers against fsc.org database; require CARB cert dated within 12 months; pre-qualify certified suppliers only.
- **G3 🔑 Formaldehyde / VOC Test:** ⚠️ 7–14 day test blocks delivery if started late — CARB Phase 2 non-compliance = critical defect and US customs detention (Josephine). ✅ Start test on Day 1 of production; run concurrent with S2 assembly; cannot wait for G2 sign-off.
- **G4 Structural Load Test:** ⚠️ Tip-over test failure post-production = costly redesign; ASTM F2057 non-compliance = product recall risk for US market. ✅ Pre-assess design against ASTM F2057 before production starts; do not rely solely on post-production test.

### Outdoor Furniture

| Step | Name | Lead Time | Description |
|---|---|---|---|
| S1 | Material Sourcing / Receipt | 3–5 days | Aluminium/steel frame, teak/eucalyptus, hardware received |
| G1 | Material Cert | 3–5 days | FSC (teak) + stainless/galvanized spec + REACH powder coat confirmed |
| G2 | Color / Finish Swatch | 3–5 days | Frame powder coat / teak oil / PE wicker color confirmed |
| G3 🔑 | Salt Spray + UV Test | **21 days min** | ASTM B117 (500 hrs) + UV AATCC 16. **BOT — start Day 1. Run concurrent with S2. Cannot compress. Critical path.** |
| S2 | Frame / Structure Production | 14–21 days | Frame welded/assembled, surfaces treated (concurrent with G3) |
| G4 | Structural Load Test | 5–7 days | Frame integrity under rated outdoor load (wind + dynamic) |
| G5 ★ | PP Sample | 7–10 days | Fully assembled outdoor piece; written sign-off required |

**Stage Notes (Josephine Cheung):**
- **S1 Material Sourcing / Receipt:** ⚠️ Teak origin documentation gaps = UFLPA / FSC chain-of-custody risk; hot-dipped galvanized grade mismatch causes premature corrosion failure in field. ✅ Require full chain-of-custody documents for teak; require mill cert with zinc coating weight (g/m²) for all steel hardware.
- **G3 🔑 Salt Spray + UV Test:** ⚠️ 21-day minimum is non-negotiable — the entire outdoor furniture schedule is anchored to this gate; late start = exactly 21-day delivery delay. Salt spray failure (<500 hours) = critical defect (Josephine). ✅ Start test samples Day 1 and run concurrent with S2 frame production; no exceptions.
- **G4 Structural Load Test:** ⚠️ Dynamic load failure discovered post-production = product recall risk for high-value outdoor furniture. ✅ Pre-assess design against rated load standards before production; include wicker/sling stretch-under-load test in G4.

---

## Key Compliance & Market Intelligence

- **CARB Phase 2 (Indoor):** California Air Resources Board formaldehyde emission standard for composite wood products — mandatory for US market; one of the strictest standards globally.
- **EU E1 / JIS:** European and Japanese formaldehyde standards; often required for EU and Japan-destined product alongside CARB.
- **REACH:** Powder coat and surface treatments must comply with restricted substances list; especially relevant for outdoor powder-coated aluminium and steel.
- **UFLPA:** Supply chain traceability required for all China-origin furniture shipments entering the US.
- **CSDDD (EU):** Corporate Sustainability Due Diligence Directive — supply chain due diligence obligations apply to furniture supply chains.
- **Tariff & Sourcing Shift:** China→Vietnam outdoor furniture diversification is **tariff-driven policy**, not cost arbitrage. Outdoor furniture is a seasonal product — sourcing decisions are **binary and annual**; switching origin mid-season is not viable.

---

## 🔗 Edges / Links

### Affected Combos (Suppliers)
- [COMBO-HG-001-china-outdoor-furniture](../../personas/hardgoods/COMBO-HG-001-china-outdoor-furniture.md)

### Buyer Types
- [USMassRetail](../../buyer-types/USMassRetail.md)
- [USPremiumHome](../../buyer-types/USPremiumHome.md)
- [EUMassHomeDecor](../../buyer-types/EUMassHomeDecor.md)
- [EUPremiumHome](../../buyer-types/EUPremiumHome.md)
- [MiddleEastPremium](../../buyer-types/MiddleEastPremium.md)

### Raw Materials
- RM-ALUMINUM-CN — extruded aluminium frame; Section 232/301 tariff exposure for US
- RM-WOOD-FSC-OUTDOOR — FSC-certified teak/eucalyptus/acacia; UFLPA + EUTR chain-of-custody required
- RM-STEEL-HARDWARE — hot-dipped galvanized steel joints/fasteners; zinc coating grade critical
- RM-MDF-PANELS — composite wood panels (indoor); CARB Phase 2 formaldehyde compliance
*(No individual RM files; see [ENTITY-RawMaterial](../../../data-entities/ENTITY-RawMaterial.md))*

### Compliance / Pain Points
- [PP-REG-UFLPA-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-UFLPA-001.md)
- [PP-REG-TARIFF-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-TARIFF-001.md)
- [PP-REG-CSDDD-001](../../../layer-1-reasoning/pain-points/compliance/PP-REG-CSDDD-001.md)

### Regulation References
- [REG-REACH](../../regulations/REG-REACH.md)
- [REG-TARIFF](../../regulations/REG-TARIFF.md)
- [REG-UFLPA](../../regulations/REG-UFLPA.md)
- [REG-CSDDD](../../regulations/REG-CSDDD.md)
