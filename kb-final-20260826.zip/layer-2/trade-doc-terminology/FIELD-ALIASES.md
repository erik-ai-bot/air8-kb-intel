---
type: terminology-fields
id: TRADE-DOC-FIELD-ALIASES
layer: 2
version: 2026-08-13
owner: Jerri Zhou
---

# Trade Document Field Aliases
> OCR normalization map: canonical field name → all label variants found on real trade docs.
> Applies across: Purchase Order, Commercial Invoice, Packing List, Bill of Lading, Letter of Credit.
> For value aliases (T/T, FOB, USD, PCS…) → see VALUE-ALIASES.md

---

## 1. Document Identity

### PO_NUMBER
Aliases: `Order No`, `Order Number`, `PO No`, `PO#`, `P.O. No.`, `P.O. Number`,
`Purchase Order No`, `Purchase Order Number`, `Order Ref`, `Reference No`, `Ref No`,
`Order Reference`, `Buyer's Order No`, `Your Order No`, `Order ID`, `Procurement No`

### INVOICE_NUMBER
Aliases: `Invoice No`, `Invoice Number`, `Invoice#`, `Inv No`, `Inv#`, `Doc No`,
`Document No`, `Bill No`, `Commercial Invoice No`, `CI No`, `Invoice Ref`

### PACKING_LIST_NUMBER
Aliases: `Packing List No`, `P/L No`, `PL No`, `Packing No`, `Packing List Number`

### BL_NUMBER
Aliases: `B/L No`, `BL No`, `Bill of Lading No`, `B/L Number`, `BL#`,
`Booking No`, `Booking Reference`
AWB: `Air Waybill No`, `AWB No`, `AWB#`, `Waybill No`

### LC_NUMBER
Aliases: `L/C No`, `LC No`, `Letter of Credit No`, `Credit No`, `L/C Number`,
`L/C Reference`, `Documentary Credit No`, `Credit Number`

### CONTRACT_NUMBER
Aliases: `Contract No`, `Sales Contract No`, `Contract Number`, `Agreement No`,
`Sales Confirmation No`, `Confirmation No`

---

## 2. Dates

### DOCUMENT_DATE
Aliases: `Date`, `Date of Issue`, `Issue Date`, `Dated`, `Date Issued`,
`Invoice Date`, `PO Date`, `Order Date`, `Document Date`, `Billing Date`,
`Created Date`, `P/L Date`, `Packing List Date`

### BL_DATE
Aliases: `Date of B/L`, `B/L Date`, `On Board Date`, `Shipped on Board Date`,
`Date of Shipment`, `Laden on Board`, `Date Laden on Board`

### DELIVERY_DATE
Aliases: `Delivery Date`, `Required Delivery Date`, `Ship By Date`, `Ship By`,
`Must Arrive By`, `Delivery By`, `Ex-Factory Date`, `EX-FACTORY`, `Ex Factory Date`,
`Latest Shipment Date`, `Last Ship Date`, `Requested Ship Date`, `Ready Date`,
`Production Deadline`, `Handover Date`

### EXPIRY_DATE (LC)
Aliases: `Expiry Date`, `Date of Expiry`, `Valid Until`, `Valid to`, `Validity Date`,
`LC Expiry`, `Credit Expiry Date`, `Expiry`

### PRESENTATION_PERIOD (LC)
Aliases: `Presentation Period`, `Documents to be Presented Within`, `Days for Presentation`,
`Days after Shipment Date`, `Presented within X days`
Pattern: `(?:within|not later than)\s*(\d+)\s*days?\s*(?:after|from)?\s*(?:shipment|B\/L)\s*date`

### ETD
Aliases: `ETD`, `Departure Date`, `Sailing Date`, `Date of Departure`, `Sail Date`

### ETA
Aliases: `ETA`, `Arrival Date`, `Expected Arrival`, `Date of Arrival`

---

## 3. Parties

### SELLER / EXPORTER
Aliases: `Seller`, `Exporter`, `Shipper`, `Supplier`, `Vendor`, `Manufacturer`,
`From`, `Sold By`, `Consignor`, `Beneficiary`
Note: On Chinese factory invoices sometimes: "Name and Address of Shipper"

### BUYER / IMPORTER
Aliases: `Buyer`, `Importer`, `Consignee` (invoice context), `Bill To`, `Purchaser`,
`To`, `Customer`, `Sold To`, `Account To`, `Billed To`, `Ordering Party`

### CONSIGNEE (BL context)
Aliases: `Consignee`, `To`, `To the Order of`, `To Order`, `To the Order`
Note: "To the Order of [Bank]" = negotiable BL under LC; bank holds title

### NOTIFY_PARTY
Aliases: `Notify Party`, `Also Notify`, `Notify`, `Notify Address`,
`Notification Party`, `2nd Notify`, `Also Notify 2`

### APPLICANT (LC)
Aliases: `Applicant`, `Account Party`, `Opener`, `Instructing Party`, `Account of`

### BENEFICIARY (LC)
Aliases: `Beneficiary`, `In favour of`, `In favor of`, `Favoring`

### ISSUING_BANK
Aliases: `Issuing Bank`, `Opening Bank`, `L/C Issuing Bank`, `Documentary Credit Issuing Bank`

### ADVISING_BANK
Aliases: `Advising Bank`, `Notifying Bank`, `Notification Bank`, `Correspondent Bank`

---

## 4. Commercial Terms

### PAYMENT_TERMS
Aliases: `Payment Terms`, `Terms of Payment`, `Terms of Payments`, `Payment Conditions`,
`Terms`, `Payment`, `Settlement Terms`, `Net`, `Credit Terms`, `Payment Method`,
`Payment Clause`, `Net Terms`
→ See VALUE-ALIASES.md §1–2 for value normalization (T/T, O/A, NET X, etc.)

### INCOTERMS
Aliases: `Incoterms`, `Incoterm`, `Trade Terms`, `Delivery Terms`, `Shipment Terms`,
`Terms of Delivery`, `Price Terms`, `FOB terms`, `CIF terms`
→ See VALUE-ALIASES.md §3 for value normalization

### CURRENCY
Aliases: `Currency`, `CCY`, `Ccy`, `Invoice Currency`, `Transaction Currency`
→ See VALUE-ALIASES.md §4 for value normalization

---

## 5. Product / Line Item Fields

### STYLE_NUMBER
Aliases: `Style No`, `Style Number`, `Style#`, `Style Ref`, `Item No`, `Item Number`,
`Item Code`, `Article No`, `Article Number`, `SKU`, `SKU No`, `Product Code`,
`Product No`, `Part No`, `Model No`, `Design No`, `Code`, `Reference`, `Ref`

### PRODUCT_DESCRIPTION
Aliases: `Description`, `Description of Goods`, `Item Description`, `Product Description`,
`Goods Description`, `Article Description`, `Commodity`, `Item`, `Product`,
`Particulars`, `Details`, `Nature of Goods`, `Cargo Description`

### HS_CODE
Aliases: `HS Code`, `HS`, `H.S. Code`, `HS Tariff Code`, `HTS Code`, `HTS`,
`Tariff Code`, `Commodity Code`, `Customs Code`, `Tariff No`, `HTSUS`

### COUNTRY_OF_ORIGIN
Aliases: `Country of Origin`, `Origin`, `Origin Country`, `Country of Manufacture`,
`Made In`, `Made in`, `Country of Production`, `Manufactured In`, `Place of Origin`

### COLOR
Aliases: `Color`, `Colour`, `Col`, `Col.`, `Shade`, `Color Code`, `Colour Code`

### SIZE
Aliases: `Size`, `Size Code`, `Size Range`, `Sizes`, `SZ`

### QUANTITY
Aliases: `Quantity`, `Qty`, `Qty.`, `QTY`, `PCS`, `Units`, `Nos`, `Pieces`,
`Order Qty`, `Ordered Qty`, `Total Qty`
→ See VALUE-ALIASES.md §5 for unit normalization

### UNIT_PRICE
Aliases: `Unit Price`, `Price`, `Price per Unit`, `Price/Unit`, `Rate`, `Unit Cost`,
`Per PCS`, `Per Piece`, `Each`, `FOB Unit Price`, `CIF Unit Price`, `Agreed Price`

### LINE_AMOUNT
Aliases: `Amount`, `Total Amount`, `Line Total`, `Extended Amount`, `Value`,
`Total`, `Line Value`

---

## 6. Invoice Totals

### SUBTOTAL
Aliases: `Subtotal`, `Sub-total`, `Merchandise Value`, `Goods Value`, `FOB Value`,
`Total Goods Value`

### FREIGHT_CHARGES
Aliases: `Freight`, `Freight Charges`, `Freight Cost`, `Ocean Freight`,
`Sea Freight`, `Air Freight`, `Shipping Cost`, `Transportation Cost`

### INSURANCE
Aliases: `Insurance`, `Insurance Charges`, `Marine Insurance`, `Cargo Insurance`

### GRAND_TOTAL
Aliases: `Grand Total`, `Total Amount`, `Total Invoice Amount`, `Invoice Total`,
`Total`, `Amount Due`, `Total Due`, `Total Payable`, `Net Amount`,
`Total CIF Value`, `Total FOB Value`

---

## 7. Shipping & Routing

### PORT_OF_LOADING
Aliases: `Port of Loading`, `POL`, `Loading Port`, `Origin Port`, `Port of Shipment`,
`From Port`, `Place of Loading`, `Place of Receipt`, `Port of Export`,
`Port of Departure`, `Departure Port`
AWB: `Airport of Departure`, `Origin Airport`, `Departure Airport`

### PORT_OF_DISCHARGE
Aliases: `Port of Discharge`, `POD`, `Destination Port`, `To Port`, `Discharge Port`,
`Port of Arrival`, `Port of Destination`, `Arrival Port`
AWB: `Airport of Destination`, `Destination Airport`, `Arrival Airport`

### PLACE_OF_DELIVERY
Aliases: `Place of Delivery`, `Final Destination`, `Delivery Place`,
`Place of Final Delivery`, `Final Place`, `Delivery Point`

### PORT_OF_TRANSHIPMENT
Aliases: `Port of Transhipment`, `Transhipment Port`, `T/S Port`,
`Via`, `Via Port`, `Transit Port`, `Port of Transit`

### VESSEL_NAME
Aliases: `Vessel`, `Vessel Name`, `Ship Name`, `MV`, `S.S.`, `Per Vessel`,
`Ocean Vessel`, `Mother Vessel`
AWB: `Airline`, `Carrier`, `Flight No`, `Flight Number`

### VOYAGE_NUMBER
Aliases: `Voyage No`, `Voyage`, `Voy`, `Voy.`, `Trip No`

### SHIPMENT_MODE
Aliases: `Shipment Mode`, `Mode of Shipment`, `Transport Mode`, `Via`, `By`,
`Freight Mode`, `Shipping Method`
→ See VALUE-ALIASES.md §7 for value normalization (FCL, LCL, AIR, SEA…)

---

## 8. Packing & Weight (Packing List / BL)

### CARTON_NUMBER
Aliases: `Carton No`, `CTN No`, `CTN#`, `Case No`, `Box No`, `Carton Mark`,
`Mark No`, `Carton Nos`, `Case Nos`, `Nos.`, `Packing No`, `Carton Range`

### TOTAL_CARTONS
Aliases: `Total Cartons`, `Total Ctns`, `Total Cases`, `Total Boxes`,
`No. of Cartons`, `No. of Cases`, `Total Pkgs`, `Total Packages`, `Pkgs`

### CARTON_DIMENSIONS
Aliases: `Carton Size`, `Dimensions`, `Measurement`, `L x W x H`, `L/W/H`,
`Outer Dimensions`, `Carton Measurement`, `Size (cm)`, `Outer Carton Size`

### QTY_PER_CARTON
Aliases: `Qty per Carton`, `Qty/CTN`, `PCS per Carton`, `Units per Carton`,
`Pack per Carton`, `Inner Qty`, `Pack`

### GROSS_WEIGHT
Aliases: `Gross Weight`, `G.W.`, `GW`, `Gross Wt`, `Gross Wt.`, `Total Gross Weight`

### NET_WEIGHT
Aliases: `Net Weight`, `N.W.`, `NW`, `Net Wt`, `Net Wt.`, `Total Net Weight`

### TOTAL_CBM
Aliases: `Total CBM`, `CBM`, `Total Volume`, `Total M3`, `Total Measurement`,
`Meas.`, `Volume`, `M3`
→ See VALUE-ALIASES.md §6 for unit normalization

---

## 9. Container (BL)

### CONTAINER_NUMBER
Aliases: `Container No`, `Container Number`, `CNTR No`, `CTR No`, `Container#`, `Equipment No`

### SEAL_NUMBER
Aliases: `Seal No`, `Seal Number`, `SL No`, `Seal#`, `Seal`

### CONTAINER_TYPE
Aliases: `Container Type`, `Equipment Type`, `Type of Container`, `Container Size/Type`
→ See VALUE-ALIASES.md §8 for value normalization (20GP, 40HC…)

### FREIGHT_TERMS
Aliases: `Freight`, `Freight Terms`, `Freight Payable`, `Charges`
Values: `PREPAID` ("Freight Prepaid", "PP") | `COLLECT` ("Freight Collect", "CC")

---

## 10. LC-Specific Fields

### LC_TYPE
Aliases: `Form of Documentary Credit`, `Type of Credit`, `LC Type`, `Credit Type`

### LATEST_SHIPMENT_DATE
Aliases: `Latest Shipment Date`, `Last Date of Shipment`, `Latest Date of Shipment`,
`Shipment Not Later Than`, `Shipment Before`, `Last Shipment Date`

### LC_AMOUNT
Aliases: `Amount`, `Credit Amount`, `L/C Amount`, `Maximum Credit Amount`,
`LC Value`, `For the Amount of`, `Not Exceeding`, `Up to`

### USANCE_TENOR
Aliases: `Tenor`, `Usance`, `Draft Tenor`, `Bill Tenor`, `At X days sight`,
`At X days from BL date`, `Draft at X days`, `Maturity`
Pattern: `(?:at|tenor)\s*(\d+)\s*days?\s*(?:sight|from\s*(?:B\/L|bill of lading|invoice|shipment)\s*date)?`

### PARTIAL_SHIPMENT
Aliases: `Partial Shipment`, `Partial Shipments`, `Partial Drawings`
Values: `ALLOWED` | `PROHIBITED` | `NOT ALLOWED`

### TRANSHIPMENT_ALLOWED
Aliases: `Transhipment`, `Transshipment`, `Trans-shipment`
Values: `ALLOWED` | `PROHIBITED` | `NOT ALLOWED`

### DOCUMENTS_REQUIRED
Aliases: `Documents Required`, `Required Documents`, `Documents Needed`,
`LC Documents`, `Presentation Documents`, `Documentary Requirements`

---

## 11. Shipping Marks & References

### SHIPPING_MARK
Aliases: `Shipping Mark`, `Marks`, `Marks & Numbers`, `Marks and Numbers`,
`Shipper's Mark`, `Outer Mark`, `Carton Mark`, `Case Mark`

### REMARKS
Aliases: `Remarks`, `Notes`, `Special Instructions`, `Comments`, `Note`,
`Instructions`, `Special Requirements`, `Additional Notes`, `Memo`, `Additional Conditions`

### SEASON
Aliases: `Season`, `Season Code`, `Collection`, `Collection Season`, `Range`

### ASSORTMENT
Aliases: `Assortment`, `Asst`, `Ratio`, `Color Ratio`, `Size Ratio`,
`Breakdown`, `Mix`, `Color Mix`, `Size Mix`
