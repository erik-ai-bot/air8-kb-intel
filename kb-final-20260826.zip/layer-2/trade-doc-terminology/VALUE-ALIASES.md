---
type: terminology-values
id: TRADE-DOC-VALUE-ALIASES
layer: 2
version: 2026-08-13
owner: Jerri Zhou
---

# Trade Document Value Aliases
> Normalize extracted values into canonical forms.
> For field label aliases → see FIELD-ALIASES.md

---

## 1. Payment Method

| Canonical | Aliases |
|---|---|
| `T/T` | `TT`, `T.T.`, `Telegraphic Transfer`, `Wire Transfer`, `Bank Transfer`, `SWIFT Transfer`, `Electronic Transfer`, `Bank Wire` |
| `O/A` | `OA`, `O.A.`, `Open Account`, `Open Acct`, `Net Terms`, `Account Terms` |
| `D/A` | `DA`, `D.A.`, `Documents Against Acceptance`, `Documents vs Acceptance`, `Bill of Exchange - Acceptance` |
| `D/P` | `DP`, `D.P.`, `Documents Against Payment`, `Cash Against Documents`, `CAD`, `Documents vs Payment` |
| `L/C` | `LC`, `L.C.`, `Letter of Credit`, `Documentary Credit`, `Irrevocable LC`, `Irrevocable L/C`, `SBLC`, `Standby LC` |
| `COD` | `Cash on Delivery`, `Cash On Delivery`, `Payment on Delivery` |
| `CIA` | `Cash in Advance`, `Advance Payment`, `Prepayment`, `Pre-payment`, `100% TT in Advance`, `Payment in Advance` |

---

## 2. Payment Tenor Patterns

Extract method + number of days + reference event from freetext.

### T/T with tenor
```
Pattern: (?:T/?T|Telegraphic Transfer)\s*(\d+)\s*days?\s*(?:after|from)?\s*(.+)?
```
Reference event aliases → normalize to:
- `BL_DATE`: "BL date", "B/L date", "Bill of Lading date", "date of B/L", "date of shipment"
- `INVOICE_DATE`: "invoice date", "date of invoice"
- `SIGHT`: "sight", "at sight"

Examples → all normalize to `T/T 30 days BL_DATE`:
- "TT 30 days after BL date"
- "T/T 30 days from B/L date"
- "30 days T/T from bill of lading"
- "T/T net 30 days after shipment"

### NET X days
```
Pattern: (?:Net|NET)\s*(\d+)\s*days?
```
Examples: "Net 30", "Net 30 days", "NET 60", "Net 90 days"

### O/A X days
```
Pattern: (?:O/?A|Open\s*Account)\s*(\d+)\s*days?\s*(?:from|after)?\s*(.+)?
```
Examples: "OA 60 days", "O/A 90 days from invoice date", "Open Account 30 days"

### D/A X days
```
Pattern: (?:D/?A|Documents?\s*Against\s*Acceptance)\s*(\d+)\s*days?
```
Examples: "DA 60", "D/A 90 days", "60 days D/A"

### Split payment
Examples to parse as two legs:
- "30% TT in advance, 70% TT against BL copy"
- "30% deposit, balance against documents"
- "50% advance, 50% on delivery"

---

## 3. Incoterms

| Canonical | Aliases |
|---|---|
| `FOB` | `F.O.B.`, `Free On Board` |
| `CIF` | `C.I.F.`, `Cost Insurance Freight`, `Cost, Insurance and Freight` |
| `CFR` | `C.F.R.`, `CNF`, `C&F`, `C+F`, `C and F`, `Cost and Freight`, `Cost & Freight` |
| `EXW` | `Ex Works`, `Ex-Works`, `Ex Factory`, `Ex-Factory`, `Ex Warehouse` |
| `DDP` | `D.D.P.`, `Delivered Duty Paid` |
| `DAP` | `Delivered At Place`, `Delivered to Place` |
| `FCA` | `F.C.A.`, `Free Carrier` |
| `CPT` | `Carriage Paid To`, `Carriage Paid` |
| `CIP` | `Carriage and Insurance Paid` |

---

## 4. Currency

| Canonical | Aliases |
|---|---|
| `USD` | `US$`, `U.S. Dollar`, `US Dollar`, `United States Dollar`, `$` |
| `EUR` | `Euro`, `€`, `EURO` |
| `GBP` | `Pound`, `British Pound`, `Sterling`, `£` |
| `CNY` | `RMB`, `Yuan`, `Renminbi`, `¥` (China context) |
| `HKD` | `HK$`, `Hong Kong Dollar` |
| `JPY` | `Yen`, `¥` (Japan context) |
| `AUD` | `A$`, `AU$`, `Australian Dollar` |
| `CAD` | `C$`, `CA$`, `Canadian Dollar` |

---

## 5. Quantity Units

| Canonical | Aliases | Common For |
|---|---|---|
| `PCS` | `pcs`, `pcs.`, `Pieces`, `Units`, `Nos`, `Nos.`, `EA`, `Each`, `PC` | Apparel, hardgoods |
| `DZ` | `DOZ`, `Dozen`, `Dozens`, `dz.` | Socks, gloves |
| `SET` | `Set`, `Sets`, `Kit`, `Kits` | Bundled products |
| `PR` | `Pr.`, `Pair`, `Pairs` | Footwear, gloves |
| `KG` | `kg`, `KGS`, `Kgs`, `Kilogram`, `Kilograms` | Raw materials, fabric |
| `MT` | `M/T`, `Metric Ton`, `Metric Tonne`, `T` | Bulk raw materials |
| `YD` | `Yd`, `Yards`, `Yard` | Fabric |
| `M` | `MTR`, `Meters`, `Metres` | Fabric |
| `SQM` | `M2`, `m²`, `Square Meters`, `Sq.M` | Leather, floor coverings |

---

## 6. Weight & Volume Units

| Canonical | Aliases |
|---|---|
| `KG` | `kg`, `KGS`, `Kgs`, `Kilogram`, `KG.` |
| `G` | `g`, `GMS`, `Grams`, `Gram` |
| `LB` | `lbs`, `LBS`, `Pounds`, `Pound` |
| `MT` | `M/T`, `Tonne`, `Metric Ton`, `1000KG` |
| `CBM` | `M3`, `m³`, `Cubic Meter`, `Cubic Metre`, `CUM`, `cu.m` |
| `CFT` | `ft³`, `Cubic Feet`, `cu.ft` |
| `CM` | `cm`, `Centimeter`, `Centimetre` |
| `MM` | `mm`, `Millimeter` |
| `INCH` | `in`, `"`, `Inch`, `Inches` |

---

## 7. Shipment Mode

| Canonical | Aliases |
|---|---|
| `FCL` | `Full Container`, `Full Container Load`, `Container Load` |
| `LCL` | `Less Container`, `Less than Container Load`, `Consolidation`, `Consolidated` |
| `AIR` | `Air Freight`, `By Air`, `Airfreight`, `Air Cargo` |
| `SEA` | `Sea Freight`, `By Sea`, `Ocean Freight`, `Seafreight` |
| `COURIER` | `Express`, `DHL`, `FedEx`, `UPS`, `TNT` |

---

## 8. Container Types

| Canonical | Aliases |
|---|---|
| `20GP` | `20'`, `20 ft`, `20 foot`, `20' GP`, `20-foot` |
| `40GP` | `40'`, `40 ft`, `40 foot`, `40' GP` |
| `40HC` | `40'HC`, `40HQ`, `40 HC`, `40 High Cube`, `40' HQ` |
| `45HC` | `45'HC`, `45 HC`, `45 High Cube` |

---

## 9. BL Type / Negotiability

| Canonical | Aliases |
|---|---|
| `ORIGINAL_BL` | `Original`, `OBL`, `3/3 Originals`, `Full Set`, `Full set of 3/3 original BL` |
| `SEA_WAYBILL` | `Sea Waybill`, `Waybill`, `Non-Negotiable`, `Express BL` |
| `SURRENDERED` | `Surrendered`, `Telex Release`, `Express Release`, `Seaway Bill` |

---

## 10. Freight Payment Terms

| Canonical | Aliases |
|---|---|
| `PREPAID` | `Freight Prepaid`, `Prepaid`, `PP`, `Freight Paid` |
| `COLLECT` | `Freight Collect`, `Collect`, `CC`, `To Collect` |
| `AS_ARRANGED` | `As Arranged`, `As Per Agreement` |

---

## 11. LC Availability Type

| Canonical | Aliases |
|---|---|
| `BY_SIGHT` | `at sight`, `sight`, `by sight payment`, `Sight LC` |
| `BY_ACCEPTANCE` | `by acceptance`, `usance`, `term`, `Usance LC` |
| `BY_DEFERRED_PAYMENT` | `deferred payment`, `deferred` |
| `BY_NEGOTIATION` | `by negotiation`, `negotiation` |
