---
type: raw-material
id: RM-WOOD-FSC-OUTDOOR
domain: hardgoods
layer: 2
name: FSC-Certified Timber (Outdoor — Teak/Eucalyptus/Acacia)
material_type: wood
sourcing_countries: [ID, MY, VN, BR, IN]
price_unit: m3
price_range: "400–1200 USD/m3 (teak premium)"
price_volatility: medium
tariff_exposure: medium
compliance_flags: [FSC, UFLPA, EUTR, CSDDD, REG-REACH]
---

# RM-WOOD-FSC-OUTDOOR — FSC-Certified Timber (Outdoor — Teak/Eucalyptus/Acacia)

## Sourcing & Pricing
- Teak (premium hardwood) primarily sourced from Indonesia, Myanmar plantation forestry, and India; eucalyptus and acacia as more cost-competitive alternatives from Brazil and Vietnam.
- FSC Chain of Custody (CoC) certification is mandatory for EU buyers and most premium US buyers — cert serial number must be verified at fsc.org before purchase.
- Supply is constrained by plantation maturity cycles and export licensing regimes; Indonesian teak plantation supply is managed by Perum Perhutani (state enterprise).
- EU Timber Regulation (EUTR) and incoming EU Deforestation Regulation (EUDR/CSDDD) require documented due diligence on legality and deforestation-free harvest origin — increasing documentation overhead.

## Compliance Risks
- **FSC CoC** — certificate must be current and verified independently at fsc.org; fraudulent FSC certs are known in Asian timber supply; cert expiry and scope must be checked per order.
- **EUTR / EUDR** — EU requires documented evidence of legal harvest origin and deforestation-free supply; EUDR enters full force progressively; due diligence file required per shipment for EU-bound product.
- **UFLPA** — US Customs requires supply chain traceability for timber products; GPS-linked harvest documentation increasingly expected.
- **CSDDD** — EU Corporate Sustainability Due Diligence Directive requires deforestation-free supply chain evidence; Air8 financing of outdoor wood furniture requires supplier EUDR readiness assessment.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-04|CAT-HG-04 — Outdoor Furniture]]
- [[CAT-HG-10|CAT-HG-10 — Garden & Outdoor]]

### Sourced By Combos
- [[COMBO-HG-001-china-outdoor-furniture|COMBO-HG-001 — China Outdoor Furniture]]

### Regulation References
- [[REG-UFLPA]]
- [[REG-CSDDD]]
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-REG-UFLPA-001]]
- [[PP-REG-CSDDD-001]]
