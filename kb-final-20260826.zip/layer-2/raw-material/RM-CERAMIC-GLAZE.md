---
type: raw-material
id: RM-CERAMIC-GLAZE
domain: hardgoods
layer: 2
name: Ceramic Glaze Pigments & Compounds
material_type: ceramic
sourcing_countries: [CN, DE, ES]
price_unit: kg
price_range: "3–15 USD/kg (varies by pigment)"
price_volatility: low
tariff_exposure: low
compliance_flags: [REACH, FDA-CFR21, EN1388, CA-PROP65]
---

# RM-CERAMIC-GLAZE — Ceramic Glaze Pigments & Compounds

## Sourcing & Pricing
- Metal oxide pigments (iron oxide, cobalt oxide, manganese dioxide, chromium oxide) provide colour in ceramic glazes; fired at 1000–1300°C to fuse with ceramic body.
- Lead and cadmium were historically standard in traditional glazes for brilliance and adhesion — now heavily restricted in EU and US markets; EU/US suppliers offer compliant lead-free alternatives.
- Chinese domestic glaze pigment suppliers may still use restricted heavy metals in traditional formulations — pre-qualification of the approved pigment supplier list is a critical gate before production.
- European suppliers (Ferro, Prince Minerals) provide certified lead-free, cadmium-free alternatives at a price premium but with full REACH and FDA compliance documentation.

## Compliance Risks
- **REACH** — lead (Pb) and cadmium (Cd) in glaze compounds are restricted substances under REACH Annex XVII; require full SDS and supplier declaration per pigment batch.
- **EN 1388 / ASTM C738/C927** — ceramic leaching test standards for food contact surfaces; migration levels of Pb and Cd must comply with EN 1388 (EU) or FDA CFR 21 (US); tested on fired finished product.
- **FDA CFR 21** — food contact compliance mandatory for any ceramicware intended for food/beverage use in the US; supplier test reports required per SKU.
- **CA Prop 65** — lead and cadmium require consumer-facing warning labels in California if above threshold levels; per Josephine: traditional glaze pigments may contain Pb/Cd — pre-qualify all suppliers against approved pigment list before production approval.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-02|CAT-HG-02 — Ceramic & Resin Artware]]
- [[CAT-HG-03|CAT-HG-03 — Kitchen & Dining (Ceramic Diningware)]]

### Sourced By Combos
- *(No specific combo mapped — applies across ceramic product suppliers)*

### Regulation References
- [[REG-REACH]]
- [[REG-GPSR]]

### Compliance / Pain Points
- [[PP-HG-005-reach-rohs-compliance|PP-HG-005 — REACH/RoHS Compliance]]
