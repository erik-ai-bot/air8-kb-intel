---
type: raw-material
id: RM-YARN-CASHMERE
domain: apparel
layer: 2
name: Cashmere Yarn
material_type: fiber
sourcing_countries: [MN, CN, IR, AF]
price_unit: kg
price_range: "80–200 USD/kg"
price_volatility: high
tariff_exposure: low
compliance_flags: [REACH, OEKO-TEX, mulesing-not-applicable]
---

# RM-YARN-CASHMERE — Cashmere Yarn

## Sourcing & Pricing
- Inner Mongolia (China) and Mongolia dominate global cashmere supply; raw cashmere is the dehaired undercoat of cashmere goats
- Dehairing and spinning operations concentrated in China and Italy for premium product
- Extreme price volatility driven by goat population cycles and severe weather events in Central Asia; demand spikes Oct–Dec creating factory machine capacity constraints
- Adulteration (blending with lower-grade wool) is a known industry risk — third-party fibre content testing (Woolmark or equivalent lab) required

## Compliance Risks
- **REACH** — Dyes and processing chemicals used during yarn finishing must comply with REACH substance restrictions
- **OEKO-TEX Standard 100** — Required for finished cashmere yarn entering premium and EU retail channels
- **Adulteration risk** — Cashmere/wool blending fraud is prevalent; require third-party fibre content certification (Woolmark or equivalent) for all shipments
- Note: Mulesing is not applicable for cashmere (goat-derived fibre); no animal welfare concern on this dimension

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-02|CAT-AP-02 — Knit Apparel — knitwear / sweater]]

### Sourced By Combos
- [[COMBO-001-south-asian-small-knit|COMBO-001 — South Asian Small Knit]]
- [[COMBO-007-indonesia-family-run|COMBO-007 — Indonesia Family Run]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-REG-REACH-001]]
