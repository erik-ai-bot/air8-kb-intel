---
type: raw-material
id: RM-TENCEL
domain: apparel
layer: 2
name: Tencel / Lyocell Fibre
material_type: fiber/cellulosic
sourcing_countries: [AT]
price_unit: kg
price_range: "3–5 USD/kg"
price_volatility: low
tariff_exposure: low
compliance_flags: [REACH, OEKO-TEX, EU-ECOLABEL, GOTS-eligible]
---

# RM-TENCEL — Tencel / Lyocell Fibre

## Sourcing & Pricing
- Tencel is Lenzing AG's registered brand for lyocell fibre; the closed-loop NMMO (N-Methylmorpholine N-oxide) solvent is recycled at >99% efficiency — the primary environmental credential
- Fibre is biodegradable; eligible for EU Ecolabel and increasingly used as a premium sustainable alternative to cotton in apparel
- Blends well with cotton and polyester; India (Grasim/Aditya Birla) produces generic lyocell as an accessible cost alternative to branded Tencel
- Low price volatility and low compliance burden make this one of the most accessible sustainable fibre options for suppliers transitioning toward ESG-aligned product lines

## Compliance Risks
- **REACH** — Minimal residual solvent concern (<0.1% NMMO in finished fibre); REACH compliance burden is substantially lower than for cotton (no pesticide residue) or synthetic fibres (dye/auxiliary chemicals)
- **OEKO-TEX Standard 100** — Standard certification for finished Tencel/lyocell fibre and fabric
- **EU Ecolabel** — Optional certification but valued by EU retail buyers; Tencel qualifies due to closed-loop production process
- **GOTS-eligible** — Can be incorporated into GOTS-certified production chains when processed in GOTS-certified facilities; low compliance risk and strong environmental narrative make this the primary selling point

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-05|CAT-AP-05 — Organic/Sustainable Textiles]]

### Sourced By Combos
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — India Large Vertical Integrator]]
- [[COMBO-008-india-organic-cotton-medium|COMBO-008 — India Organic Cotton Medium]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-REG-REACH-001]]
