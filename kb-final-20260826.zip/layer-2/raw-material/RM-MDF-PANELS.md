---
type: raw-material
id: RM-MDF-PANELS
domain: hardgoods
layer: 2
name: MDF / Composite Wood Panels (Indoor Furniture)
material_type: composite
sourcing_countries: [CN, MY, VN]
price_unit: m2
price_range: "8–20 USD/m2"
price_volatility: low
tariff_exposure: medium
compliance_flags: [CARB-PHASE2, EU-E1, JIS-F4, REACH]
---

# RM-MDF-PANELS — MDF / Composite Wood Panels (Indoor Furniture)

## Sourcing & Pricing
- MDF (medium-density fibreboard), particleboard, and plywood are primary panel materials for case goods including wardrobes, bookcases, dressers, and storage furniture.
- Urea-formaldehyde (UF) and melamine-formaldehyde (MF) resins used as binders — formaldehyde off-gassing is the primary health risk and regulatory focus.
- CARB Phase 2 is the strictest global formaldehyde emission standard; Chinese manufacturers are generally capable of CARB compliance, but certification verification is critical before financing.
- Vietnam and Malaysia emerging as competitive alternative supply to China; both markets have factories with CARB and EU E1 certifications targeting US and EU buyers.

## Compliance Risks
- **CARB Phase 2** — California Air Resources Board formaldehyde emission standard; mandatory for US market; requires 7–14 day pre-production emission test from CARB-approved lab; must be on finished panel, not resin alone.
- **EU E1 / JIS F★★★★** — European and Japanese equivalents to CARB; EU E1 (EN 717-1) required for EU-bound furniture; JIS F★★★★ for Japan; different test protocols from CARB — test reports are not interchangeable.
- **REACH** — formaldehyde is an SVHC; wood treatment chemicals and surface laminate adhesives must comply with REACH restricted substances.
- **Per Josephine**: FSC and CARB certificates can be fraudulent in Asian supply — verify FSC cert serial at fsc.org and CARB cert at CARB official database before production approval; do not accept photocopies without independent verification.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-04|CAT-HG-04 — Indoor Furniture]]

### Sourced By Combos
- *(No specific combo mapped — applies across indoor furniture suppliers)*

### Regulation References
- [[REG-REACH]]
- [[REG-UFLPA]]

### Compliance / Pain Points
- [[PP-REG-UFLPA-001]]
