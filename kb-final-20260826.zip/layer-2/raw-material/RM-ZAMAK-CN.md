---
type: raw-material
id: RM-ZAMAK-CN
domain: hardgoods
layer: 2
name: Zamak / Zinc Alloy (China)
material_type: metal
sourcing_countries: [CN]
price_unit: kg
price_range: "2–3.5 USD/kg"
price_volatility: medium
tariff_exposure: low
compliance_flags: [REACH]
---

# RM-ZAMAK-CN — Zamak / Zinc Alloy (China)

## Sourcing & Pricing
- Zinc alloy with <1% copper content; widely used in decorative hardware, picture frames, figurines, and ornamental castings.
- China dominates global zamak production; numerous domestic foundries and die-casting facilities with competitive pricing.
- Price tracks LME zinc (not copper) — significantly lower and less volatile than true brass inputs; typical cost advantage of 2–4× vs. copper-based alloys.
- Often commercially described as "brass" or "brass-finished" by suppliers — critical misidentification risk for tariff and compliance assessment.

## Compliance Risks
- **REACH** — zinc compounds and surface treatment chemicals (electroplating baths, lacquers) must comply with restricted substances; supplier SDS required.
- **CRITICAL — T1 TARIFF MISCLASSIFICATION**: Zamak has near-zero copper content; US Section 301 copper tariff exposure is near-zero for zamak-based products. Do NOT apply copper tariff signals to zamak products without confirming alloy spec.
- **Alloy verification** — suppliers may substitute zamak for brass without disclosure; XRF testing or mill certificates should be required for high-value orders.
- **Surface treatment** — nickel plating (common on zamak) triggers REACH SVHC disclosure obligations.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-02|CAT-HG-02 — Metal Décor & Brass Artware]]

### Sourced By Combos
- [[COMBO-HG-002-china-brass-artware|COMBO-HG-002 — China Brass Artware]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-HG-002-tariff-double-compress|PP-HG-002 — Tariff Double Compress]] *(signal does NOT apply to zamak — verify alloy spec first)*
