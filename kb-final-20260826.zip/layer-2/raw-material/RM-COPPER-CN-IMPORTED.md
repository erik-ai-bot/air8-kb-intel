---
type: raw-material
id: RM-COPPER-CN-IMPORTED
domain: hardgoods
layer: 2
name: Copper (China — Imported/Refined)
material_type: metal
sourcing_countries: [CN, CL, PE]
price_unit: kg
price_range: "7–9 USD/kg (LME-referenced)"
price_volatility: high
tariff_exposure: high
compliance_flags: [REACH, UFLPA, T1-COPPER-TARIFF]
---

# RM-COPPER-CN-IMPORTED — Copper (China — Imported/Refined)

## Sourcing & Pricing
- Primary input for true brass (60–70% copper content); refined copper price tracks LME copper daily with near-real-time price volatility.
- China is world's largest refined copper producer; ore is imported from Chile (Codelco) and Peru and refined domestically at scale.
- US Section 301 tariff (T1) applies to finished goods containing copper when manufactured in China — cost pressure compounds with LME price swings.
- Spot and forward purchasing strategies used by larger Chinese manufacturers; MSMEs typically absorb LME risk directly in cost.

## Compliance Risks
- **REACH** — copper compounds in surface treatments (patina, lacquer, electroplating baths) must comply with Annex XVII/SVHC restricted substances list; requires supplier declaration.
- **UFLPA** — Xinjiang copper smelting operations are under active traceability scrutiny; smelters with Xinjiang origins require full upstream chain-of-custody documentation for US entry.
- **T1 / Section 301** — US Section 301 tariff on China-origin finished goods; effective rate on brass artware typically 7.5–25% depending on HTS code.
- **"Albright/yellow lead" alloy** (lead-based brass substitute) = regulatory violation under REACH and CA Prop 65 — Air8 must NOT finance suppliers using this input.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-02|CAT-HG-02 — Metal Décor & Brass Artware]]

### Sourced By Combos
- [[COMBO-HG-002-china-brass-artware|COMBO-HG-002 — China Brass Artware]]

### Regulation References
- [[REG-REACH]]
- [[REG-UFLPA]]
- [[REG-TARIFF]]

### Compliance / Pain Points
- [[PP-HG-002-tariff-double-compress|PP-HG-002 — Tariff Double Compress]]
- [[PP-HG-005-reach-rohs-compliance|PP-HG-005 — REACH/RoHS Compliance]]
