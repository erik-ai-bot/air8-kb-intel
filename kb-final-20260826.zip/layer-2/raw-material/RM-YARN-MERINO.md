---
type: raw-material
id: RM-YARN-MERINO
domain: apparel
layer: 2
name: Merino Wool Yarn
material_type: fiber
sourcing_countries: [AU, NZ, AR, ZA]
price_unit: kg
price_range: "12–20 USD/kg (micron-dependent)"
price_volatility: medium
tariff_exposure: low
compliance_flags: [REACH, OEKO-TEX, WOOLMARK, mulesing-welfare]
---

# RM-YARN-MERINO — Merino Wool Yarn

## Sourcing & Pricing
- Australia and New Zealand are the primary global supply origins for Merino wool; micron count (16–21 μm) is the primary price driver — finer microns (superfine) command significant premium
- Woolmark certification provides quality assurance signal; ZQ Merino (New Zealand scheme) provides an additional welfare-assured traceability layer
- Mulesing (a surgical wound practice to prevent flystrike) is a major buyer ESG concern, particularly from EU premium buyers — mulesing-free declarations increasingly required
- EU premium buyers (H&M, Inditex) are among those requiring mulesing-free supply chain declarations as a procurement condition

## Compliance Risks
- **REACH** — Dye compliance for finished merino yarn; processing auxiliaries (scouring agents, moth-proofing chemicals) must comply with REACH restrictions
- **OEKO-TEX Standard 100** — Required for finished yarn in premium retail channels
- **Mulesing welfare declaration** — Increasingly mandated by EU buyers (H&M, Inditex, and others); ZQ Merino or equivalent welfare scheme preferred for EU-facing product lines
- **Woolmark** — Optional certification but strong premium market signal; required by some buyers as a quality prerequisite

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-02|CAT-AP-02 — Knit Apparel — knitwear / sweater]]

### Sourced By Combos
- [[COMBO-001-south-asian-small-knit|COMBO-001 — South Asian Small Knit]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-REG-REACH-001]]
