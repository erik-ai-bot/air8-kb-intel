---
type: raw-material
id: RM-COPPER-DOMESTIC-IND
domain: hardgoods
layer: 2
name: Copper (India — Domestic Primary)
material_type: metal
sourcing_countries: [IN]
price_unit: kg
price_range: "7–8.5 USD/kg"
price_volatility: high
tariff_exposure: none
compliance_flags: [REACH]
---

# RM-COPPER-DOMESTIC-IND — Copper (India — Domestic Primary)

## Sourcing & Pricing
- Hindalco Industries (Birla Group) and Vedanta are the primary Indian domestic copper producers operating integrated smelter-to-rod facilities.
- Domestic Indian supply provides significant cost and tariff advantage over China-origin copper for US-bound finished goods — removes Section 301 exposure.
- Price remains LME-linked (INR-denominated with FX risk) but is insulated from US T1 tariff surcharge on finished goods from China.
- **CRITICAL (Josephine Cheung, 2026-07-16)**: Per-factory verification required — Moradabad cluster heavily uses imported scrap (see RM-COPPER-SCRAP-IND), not domestic primary copper. Do NOT assume domestic primary sourcing without factory-level mill cert confirmation.

## Compliance Risks
- **REACH** — same restricted substances restrictions as CN copper; surface treatment chemicals must comply; SVHC disclosure required for EU buyers.
- **T1 benefit applies only when confirmed** — domestic Indian copper as primary input must be verified via mill certificate and COO documentation; scrap-heavy factories do NOT qualify for T1 benefit.
- **Factory-level due diligence** — Moradabad MSME cluster mixes scrap and primary copper inputs depending on availability and spot pricing; supplier-level declaration insufficient.
- **Traceability** — India does not have equivalent UFLPA scrutiny as Xinjiang, but general supply chain traceability documentation is still required by sophisticated buyers.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-02|CAT-HG-02 — Metal Décor & Brass Artware]]

### Sourced By Combos
- [[COMBO-HG-003-india-moradabad-brass-artware|COMBO-HG-003 — India Moradabad Brass Artware]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-HG-003-india-copper-hedge|PP-HG-003 — India Copper Hedge]]
