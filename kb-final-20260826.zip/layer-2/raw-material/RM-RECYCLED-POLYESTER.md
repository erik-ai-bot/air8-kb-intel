---
type: raw-material
id: RM-RECYCLED-POLYESTER
domain: apparel
layer: 2
name: Recycled Polyester (rPET)
material_type: fiber/synthetic
sourcing_countries: [CN, TW, KR, IN]
price_unit: kg
price_range: "2–4 USD/kg (5–15% premium vs virgin PET)"
price_volatility: medium
tariff_exposure: low
compliance_flags: [GRS, REACH, OEKO-TEX]
---

# RM-RECYCLED-POLYESTER — Recycled Polyester (rPET)

## Sourcing & Pricing
- Post-consumer PET bottles are the primary feedstock via a bottle-to-fibre conversion process; Taiwan and South Korea host premium producers (e.g. Repreve/Unifi); China dominates volume production
- GRS (Global Recycled Standard) certification is required by major international buyers for recycled content claims
- Growing demand as global brands target 2030 sustainability goals and recycled content commitments; blending with conventional polyester allows price management for cost-sensitive buyers
- Premium vs. virgin PET is 5–15%, making rPET an accessible sustainability step for cost-conscious suppliers

## Compliance Risks
- **GRS certification** — Full chain of custody from bottle collection through fibre production required; buyers increasingly require third-party content verification at point of purchase
- **REACH** — Same dye and auxiliary chemical restrictions as virgin polyester apply; rPET origin does not exempt from substance compliance
- **OEKO-TEX** — Standard 100 or Recycled Content Standard commonly required by EU and US buyers for finished goods containing rPET
- Content verification risk — blending of rPET with virgin PET without disclosure is a fraud exposure; third-party audit or test confirmation recommended

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-05|CAT-AP-05 — Organic/Sustainable Textiles]]
- [[CAT-AP-03|CAT-AP-03 — Woven Apparel — recycled blends]]

### Sourced By Combos
- [[COMBO-006-vietnam-fdi-knit|COMBO-006 — Vietnam Fdi Knit]]
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — India Large Vertical Integrator]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-REG-REACH-001]]
