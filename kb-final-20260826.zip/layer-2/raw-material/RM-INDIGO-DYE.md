---
type: raw-material
id: RM-INDIGO-DYE
domain: apparel
layer: 2
name: Indigo Dye (Synthetic / Natural)
material_type: chemical/dye
sourcing_countries: [DE, CN, IN]
price_unit: kg
price_range: "4–8 USD/kg (synthetic)"
price_volatility: low
tariff_exposure: low
compliance_flags: [REACH, ZDHC-MRSL]
---

# RM-INDIGO-DYE — Indigo Dye (Synthetic / Natural)

## Sourcing & Pricing
- Synthetic indigo (BASF the dominant global supplier) is the industry standard for commercial denim production
- Natural indigo sourced from India and El Salvador for premium and sustainable product lines; commands significant price premium
- Vat dyeing process requires reducing agents (sodium hydrosulfite) and alkalis — these auxiliaries represent the main REACH compliance exposure, not the indigo dye itself
- Laser finishing technology (vs. chemical distressing) reduces total indigo consumption by 80–90% and eliminates permanganate use

## Compliance Risks
- **REACH** — Reducing agents and auxiliaries used in the vat dyeing process are restricted substances; permanganate (used for vintage distressing effects) is restricted in the EU — laser alternative is the compliant route
- **ZDHC MRSL** — Indigo and associated vat auxiliaries must comply with ZDHC MRSL for buyers operating on the ZDHC Gateway platform
- Per Alice Wong (denim compliance expert): REACH is the primary compliance risk for denim finishing, particularly for EU-bound product with wet-process distressing

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-01|CAT-AP-01 — Denim]]

### Sourced By Combos
- [[COMBO-005-turkey-denim-specialist|COMBO-005 — Turkey Denim Specialist]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-REG-REACH-001]]
