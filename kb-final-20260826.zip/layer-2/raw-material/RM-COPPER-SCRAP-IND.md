---
type: raw-material
id: RM-COPPER-SCRAP-IND
domain: hardgoods
layer: 2
name: Copper Scrap (India — Imported Scrap)
material_type: metal
sourcing_countries: [IN]
price_unit: kg
price_range: "5–7 USD/kg (discount to LME)"
price_volatility: high
tariff_exposure: medium
compliance_flags: [REACH]
---

# RM-COPPER-SCRAP-IND — Copper Scrap (India — Imported Scrap)

## Sourcing & Pricing
- Predominant copper input for Moradabad brass artware cluster; scrap dealers aggregate mixed-origin copper scrap and supply to MSME manufacturing units.
- Purity and composition vary significantly by scrap grade (Birch/Cliff vs. Berry/Candy grades); batch-to-batch alloy composition inconsistency is a known quality risk.
- Priced at a discount to LME primary (typically 10–25% below), but retains LME price linkage and volatility; India levies import duties on scrap that add to landed cost.
- Does NOT provide the same US Section 301 (T1) tariff insulation as domestic primary copper; finished goods manufactured using imported scrap in India remain exposed to standard tariff classification by HTS content.

## Compliance Risks
- **REACH** — REACH restricted substances compliance requirements same as primary copper; alloy composition must be tested per batch due to scrap variability.
- **REACH Gate G4** — batch-level alloy composition testing required before production approval; scrap-derived brass may contain trace lead, tin, or other metals from mixed scrap streams.
- **T1 tariff clarity** — India-origin finished goods are NOT subject to US China Section 301 tariff, but scrap origin does not change India country-of-origin classification for T1 purposes; risk is product-level HTS classification, not origin.
- **Quality consistency** — MSME units using scrap may deliver inconsistent alloy quality affecting surface finish and plating adhesion; pre-production sampling recommended.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-02|CAT-HG-02 — Metal Décor & Brass Artware]]

### Sourced By Combos
- [[COMBO-HG-003-india-moradabad-brass-artware|COMBO-HG-003 — India Moradabad Brass Artware]]

### Regulation References
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-HG-003-india-copper-hedge|PP-HG-003 — India Copper Hedge]]
- [[PP-HG-005-reach-rohs-compliance|PP-HG-005 — REACH/RoHS Compliance]]
