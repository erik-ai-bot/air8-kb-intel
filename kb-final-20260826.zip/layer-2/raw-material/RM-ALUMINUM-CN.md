---
type: raw-material
id: RM-ALUMINUM-CN
domain: hardgoods
layer: 2
name: Aluminium Extrusions / Sheet (China)
material_type: metal
sourcing_countries: [CN]
price_unit: kg
price_range: "2.5–4 USD/kg (LME-referenced)"
price_volatility: medium
tariff_exposure: high
compliance_flags: [REACH, UFLPA, US-SECTION-232]
---

# RM-ALUMINUM-CN — Aluminium Extrusions / Sheet (China)

## Sourcing & Pricing
- Primary structural material for outdoor furniture (frames), decorative lighting (housing and heatsinks), and garden & outdoor products requiring lightweight corrosion resistance.
- China is the world's largest aluminium producer, with massive overcapacity enabling competitive pricing; Xinjiang holds significant smelting capacity (~10–15% of national output).
- LME aluminium price is the primary cost driver; Chinese domestic price may differ from LME due to export policy; extrusion die costs add one-time tooling charges.
- Section 232 (25% tariff on aluminium imports into the US) stacks on top of Section 301 on finished goods — creating a compounded tariff burden for aluminium-heavy products like outdoor furniture frames.

## Compliance Risks
- **REACH** — powder coat, anodizing, and chromate conversion coating surface treatments must comply with REACH Annex XVII; hexavalent chromium (Cr VI) restricted.
- **UFLPA** — Xinjiang aluminium smelting operations face active US Customs traceability scrutiny; smelters with Xinjiang-origin alumina or power require full upstream COC documentation for US entry.
- **US Section 232** — 25% tariff on aluminium imports adds to input cost for any aluminium-heavy finished goods; stacks with Section 301 rates on finished goods.
- **FSC not applicable** — metal inputs do not carry FSC certification obligation; however, responsible sourcing declarations may be required by some buyers.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-04|CAT-HG-04 — Outdoor Furniture]]
- [[CAT-HG-06|CAT-HG-06 — Lighting]]
- [[CAT-HG-10|CAT-HG-10 — Garden & Outdoor]]

### Sourced By Combos
- [[COMBO-HG-001-china-outdoor-furniture|COMBO-HG-001 — China Outdoor Furniture]]
- [[COMBO-HG-004-china-decorative-lighting|COMBO-HG-004 — China Decorative Lighting]]

### Regulation References
- [[REG-REACH]]
- [[REG-UFLPA]]
- [[REG-TARIFF]]

### Compliance / Pain Points
- [[PP-HG-002-tariff-double-compress|PP-HG-002 — Tariff Double Compress]]
