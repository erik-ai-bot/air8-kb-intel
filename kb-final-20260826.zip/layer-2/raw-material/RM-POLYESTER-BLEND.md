---
type: raw-material
id: RM-POLYESTER-BLEND
domain: apparel
layer: 2
name: Polyester/Cotton Woven Fabric (Blended)
material_type: fiber/woven
sourcing_countries: [CN, IN, VN]
price_unit: meter
price_range: "1.5–4 USD/m"
price_volatility: low
tariff_exposure: medium
compliance_flags: [UFLPA, REACH]
---

# RM-POLYESTER-BLEND — Polyester/Cotton Woven Fabric (Blended)

## Sourcing & Pricing
- Polyester/cotton blends (65/35, 50/50) are the dominant fabric in mass-market woven apparel globally; China and India lead production; Vietnam is a growing FOB origin
- Lower cost than equivalent 100% cotton fabrics; the polyester component provides stability while cotton provides comfort — the blend ratio drives both price and performance
- Blending ratio affects the UFLPA traceability burden (cotton component must be traced) and REACH finishing chemical compliance profile
- Vietnam increasingly used for FOB production to reduce US tariff exposure vs. China-origin fabric

## Compliance Risks
- **REACH** — Finishing chemicals including anti-wrinkle agents and water-repellent PFAS treatments are restricted substances in the EU; durable water repellency (DWR) PFAS treatments face increasing regulatory pressure
- **UFLPA** — Cotton component traceability to gin/farm level is still required for US-bound product, even in blended fabric; blended construction makes fibre-level traceability structurally more complex
- Blended fabric complicates fibre-level traceability — separate documentation chains for polyester and cotton components required for UFLPA compliance
- PFAS in finishing treatments face expanding regulatory restrictions across EU and select US states — non-PFAS alternatives should be specified in buyer tech packs

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-03|CAT-AP-03 — Woven Apparel]]

### Sourced By Combos
- [[COMBO-004-china-medium-woven|COMBO-004 — China Medium Woven]]
- [[COMBO-014-india-small-woven|COMBO-014 — India Small Woven]]

### Regulation References
- [[REG-REACH]]
- [[REG-UFLPA]]

### Compliance / Pain Points
- [[PP-REG-UFLPA-001]]
- [[PP-REG-REACH-001]]
