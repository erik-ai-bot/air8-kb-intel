---
type: raw-material
id: RM-ORGANIC-COTTON
domain: apparel
layer: 2
name: Organic Cotton (GOTS-Certified)
material_type: fiber
sourcing_countries: [IN, TR, TZ, US]
price_unit: kg
price_range: "4–8 USD/kg (20–40% premium vs conventional)"
price_volatility: high
tariff_exposure: medium
compliance_flags: [GOTS, UFLPA-advantaged, REACH, OEKO-TEX]
---

# RM-ORGANIC-COTTON — Organic Cotton (GOTS-Certified)

## Sourcing & Pricing
- India holds approximately 51% of global certified organic cotton production; Turkey, Tanzania, and USA are other significant origins
- GOTS (Global Organic Textile Standard) certification is required end-to-end — from farm through gin, spinning, fabric manufacturing, to finished garment
- Organic cotton procurement lead times are typically 2–4 weeks longer than conventional cotton due to limited availability and certification verification requirements
- Growing buyer demand from sustainability-committed brands (H&M Conscious, Patagonia, Pact) is tightening certified supply and maintaining price premium

## Compliance Risks
- **GOTS** — Mandatory full chain-of-custody documentation from farm → gin → spinning → fabric → garment; each stage must hold valid GOTS certification; a single uncertified link breaks the claim
- **UFLPA advantage** — Organic cotton inherently requires farm registration and gin certification, which satisfies a significant portion of UFLPA traceability requirements; represents a structural advantage over conventional cotton for US market
- **REACH** — Organic production excludes synthetic pesticides and many restricted chemicals, substantially reducing the chemical compliance burden vs. conventional cotton processing
- **OEKO-TEX Standard 100** — Complementary certification commonly required alongside GOTS for finished goods in EU retail

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-05|CAT-AP-05 — Organic/Sustainable Textiles]]
- [[CAT-AP-02|CAT-AP-02 — Knit Apparel — organic lines]]
- [[CAT-AP-04|CAT-AP-04 — Home Textiles — organic lines]]

### Sourced By Combos
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — India Large Vertical Integrator]]
- [[COMBO-008-india-organic-cotton-medium|COMBO-008 — India Organic Cotton Medium]]

### Regulation References
- [[REG-REACH]]
- [[REG-UFLPA]]

### Compliance / Pain Points
- [[PP-REG-UFLPA-001]] (advantaged position)
