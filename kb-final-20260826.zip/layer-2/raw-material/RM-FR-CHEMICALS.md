---
type: raw-material
id: RM-FR-CHEMICALS
domain: apparel
layer: 2
name: Fire Retardant (FR) Finishing Chemicals
material_type: chemical
sourcing_countries: [CN, DE, US]
price_unit: kg
price_range: "3–12 USD/kg"
price_volatility: low
tariff_exposure: low
compliance_flags: [REACH, ZDHC-MRSL, EU-FLAMMABILITY, BS5852, CA-TB117]
---

# RM-FR-CHEMICALS — Fire Retardant (FR) Finishing Chemicals

## Sourcing & Pricing
- Applied to home textiles (curtains, upholstery, contract bedding) where flammability certification is mandatory for hospitality and institutional markets
- Halogenated FR chemicals (brominated and chlorinated compounds) are largely phased out in the EU; phosphorus-based FR chemicals are the current industry standard for compliant finishing
- ZDHC compliance is required for buyers operating on the ZDHC Gateway platform — FR chemicals must appear on the MRSL-compliant list
- Incorrect application concentration or process deviation causes flammability test failure — classified as a critical product defect

## Compliance Risks
- **REACH** — Halogenated FR chemicals are restricted substances; phosphorus-based alternatives are the mandated route for EU-facing product; supplier formulation disclosure required
- **ZDHC MRSL** — FR chemicals must comply with ZDHC MRSL for buyers in the ZDHC Gateway ecosystem; non-compliant FR formulations block product certification
- **Flammability standards** — EN 13501 (EU), BS 5852 (UK), CA TB 117 (California) each specify different test methods and performance levels; product must be tested to the destination market standard
- Per Josephine (hardgoods expert): incorrect FR application is a critical safety defect — flammability failure at retail results in mandatory recall and significant liability exposure

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-04|CAT-AP-04 — Home Textiles — FR grade]]
- [[CAT-HG-02|CAT-HG-02 — Christmas Trees — FR mandatory]]

### Sourced By Combos
- [[COMBO-009-pakistan-home-textile|COMBO-009 — Pakistan Home Textile]]

### Regulation References
- [[REG-REACH]]
- [[REG-GPSR]]

### Compliance / Pain Points
- [[PP-REG-REACH-001]]
