---
type: raw-material
id: RM-LED-COMPONENTS-CN
domain: hardgoods
layer: 2
name: LED Components & Drivers (China)
material_type: composite
sourcing_countries: [CN]
price_unit: piece
price_range: "0.5–8 USD/driver (varies by wattage)"
price_volatility: medium
tariff_exposure: high
compliance_flags: [REACH, ROHS, CE-LVD-EMC, UL-1598, FCC-PART15]
---

# RM-LED-COMPONENTS-CN — LED Components & Drivers (China)

## Sourcing & Pricing
- LED BOM consists of: LED chip (COB or SMD), driver PCB with components, wiring harness, and socket/base; copper content in drivers and wiring typically 2–10% of BOM by product type.
- Chinese manufacturers (MeanWell, OSRAM Opto CN, and hundreds of generic OEMs) dominate global LED component supply with highly competitive pricing; quality tiers vary significantly.
- Certification (CE for EU, UL for US) is required per end market and is product-specific; certifications DO NOT transfer when changing manufacturing origin — re-certification required on any geo shift.
- Section 301 tariffs apply to LED luminaire finished goods from China; copper content in drivers also creates T1 tariff signal but at low BOM percentage.

## Compliance Risks
- **REACH + RoHS** — restricted substances apply to PCB substrate, lead-free solder, component coatings, and plastic housings; supplier DoC (Declaration of Conformity) and test reports required per component batch.
- **CE LVD + EMC (EU)** — CE marking requires Low Voltage Directive and EMC Directive compliance; type testing by notified body; CE test reports are product-specific and do NOT carry over on origin change.
- **UL 1598 + FCC Part 15 (US)** — UL listing requires physical product testing at UL-approved lab; FCC Part 15 for EMI/EMC; re-certification timeline is 2 weeks (CE) to 4 months (UL) — creates significant lead time risk on origin shift.
- **Per Josephine (PP-HG-007)**: CE/UL certification is a hard stop — financing luminaires without valid destination-market certification is not permitted; re-certification timelines must be factored into any supplier diversification plan.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-06|CAT-HG-06 — Lighting]]

### Sourced By Combos
- [[COMBO-HG-004-china-decorative-lighting|COMBO-HG-004 — China Decorative Lighting]]

### Regulation References
- [[REG-CE-LVD-EMC]]
- [[REG-FCC-PART15]]
- [[REG-UL-1598]]
- [[REG-REACH]]
- [[REG-TARIFF]]

### Compliance / Pain Points
- [[PP-HG-002-tariff-double-compress|PP-HG-002 — Tariff Double Compress]]
- [[PP-HG-007-ce-ul-certification-barrier|PP-HG-007 — CE/UL Certification Barrier]]
