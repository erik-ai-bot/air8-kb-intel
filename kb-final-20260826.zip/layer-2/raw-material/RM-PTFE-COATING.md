---
type: raw-material
id: RM-PTFE-COATING
domain: hardgoods
layer: 2
name: PTFE / Non-stick Coating Compound
material_type: chemical
sourcing_countries: [CN, US, DE]
price_unit: kg
price_range: "15–40 USD/kg"
price_volatility: low
tariff_exposure: low
compliance_flags: [PFAS, REACH, FDA-CFR21, EU-10-2011]
---

# RM-PTFE-COATING — PTFE / Non-stick Coating Compound

## Sourcing & Pricing
- PTFE (polytetrafluoroethylene) is the dominant non-stick coating for cookware; Chemours (Teflon brand), Whitford, and Daikin are the primary global suppliers with full compliance documentation.
- Ceramic sol-gel coatings (PFOA-free alternatives) are a growing segment, marketed as "natural" or "stone-effect"; these avoid PFAS chemistry entirely but carry different migration risk profiles.
- EU is progressively expanding PFAS restrictions under REACH Phase 2 — compounds previously considered compliant may fall under new restrictions; specific CAS number disclosure from supplier is now essential.
- Chinese suppliers offer lower-cost PTFE formulations but documentation quality varies; Chemours/Whitford licensed coaters have established compliance records.

## Compliance Risks
- **PFOA ban** — PFOA (C8 chemistry) is globally banned; generic "PFOA-free" supplier declaration is no longer sufficient — require specific compound CAS number and verification against EU REACH PFAS annex.
- **Broader PFAS / REACH Phase 2** — EU expanding PFAS restrictions to include C6 and shorter-chain fluorochemicals; supplier must disclose exact compound CAS number to assess ongoing compliance exposure.
- **FDA CFR 21 / EU 10/2011** — migration testing mandatory for food-contact non-stick coatings; test reports from accredited lab required per formulation; testing cannot be transferred across supplier changes.
- **Per Josephine**: generic "PFOA-free" claims on supplier declarations are insufficient for Air8 financing; require specific compound identification (CAS number) and current test reports before approval.

## 🔗 Edges / Links

### Used In Products
- [[CAT-HG-03|CAT-HG-03 — Kitchen & Dining (Cookware)]]

### Sourced By Combos
- *(No specific combo mapped — applies across cookware suppliers)*

### Regulation References
- [[REG-REACH]]
- [[REG-GPSR]]

### Compliance / Pain Points
- [[PP-HG-005-reach-rohs-compliance|PP-HG-005 — REACH/RoHS Compliance]]
