---
type: raw-material
id: RM-COTTON-YARN
domain: apparel
layer: 2
name: Cotton Yarn (Spun — Ring/OE)
material_type: fiber
sourcing_countries: [IN, PK, CN, BR, US]
price_unit: kg
price_range: "3–6 USD/kg (count-dependent)"
price_volatility: high
tariff_exposure: medium
compliance_flags: [UFLPA, GOTS-eligible, REACH, OEKO-TEX]
---

# RM-COTTON-YARN — Cotton Yarn (Spun — Ring/OE)

## Sourcing & Pricing
- Ring-spun preferred for quality fabrics; OE (open-end) used for commodity applications; India and Pakistan dominate South Asian spinning capacity
- Xinjiang cotton is under UFLPA rebuttable presumption — cotton from that origin is prohibited for US market without explicit evidence of non-forced-labour provenance
- Organic cotton yarn commands a 20–40% price premium over conventional equivalents
- Yarn count (Ne) drives price significantly — fine counts (Ne 40+) command meaningful premium over coarse counts

## Compliance Risks
- **UFLPA** — Cotton from Xinjiang prohibited for US market; traceability to gin/farm level required throughout the supply chain
- **GOTS** — Organic cotton yarn must be GOTS-certified at the spinning stage; chain-of-custody documentation required from farm to garment
- **REACH** — Dyes and processing chemicals used during spinning and finishing must comply with REACH restrictions
- **OEKO-TEX Standard 100** — Required for finished yarn entering premium/retail channels; covers harmful substance limits

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-02|CAT-AP-02 — Knit Apparel]]
- [[CAT-AP-04|CAT-AP-04 — Home Textiles]]
- [[CAT-HG-01|CAT-HG-01 — Home Textile & Bedding]]

### Sourced By Combos
- [[COMBO-001-south-asian-small-knit|COMBO-001 — South Asian Small Knit]]
- [[COMBO-009-pakistan-home-textile|COMBO-009 — Pakistan Home Textile]]

### Regulation References
- [[REG-UFLPA]]
- [[REG-REACH]]

### Compliance / Pain Points
- [[PP-REG-UFLPA-001]]
- [[PP-REG-REACH-001]]
