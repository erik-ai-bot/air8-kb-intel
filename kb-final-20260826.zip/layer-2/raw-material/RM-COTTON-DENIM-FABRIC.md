---
type: raw-material
id: RM-COTTON-DENIM-FABRIC
domain: apparel
layer: 2
name: Cotton Denim Fabric (Indigo-dyed)
material_type: fiber/woven
sourcing_countries: [CN, TR, PK, IN, BD]
price_unit: meter
price_range: "2.5–6 USD/m (weight/finish-dependent)"
price_volatility: medium
tariff_exposure: medium
compliance_flags: [UFLPA, REACH, ZDHC-MRSL]
---

# RM-COTTON-DENIM-FABRIC — Cotton Denim Fabric (Indigo-dyed)

## Sourcing & Pricing
- 3/1 or 2/1 twill weave construction; ring-dyed with indigo as the dominant denim colour process
- Turkey is the preferred source for premium stretch denim; China dominates volume production; Pakistan and India serve mid-tier buyers
- Fabric weight (6–14 oz) determines the end-use product category — lightweight for shirts, heavyweight for jeans
- Stretch denim (with elastane content) commands a price premium and introduces additional fibre-level compliance tracking

## Compliance Risks
- **REACH** — Indigo dye in some formulations is restricted; permanganate finishing chemicals (used for vintage distressing effects) are restricted in the EU; laser finishing is the preferred compliant alternative
- **UFLPA** — Xinjiang cotton feedstock risk applies to US-bound denim; full traceability to cotton gin and farm required
- **ZDHC MRSL** — Wet process chemical compliance required for buyers operating under ZDHC Gateway commitments; indigo vat auxiliaries (sodium hydrosulfite) are a primary concern

## 🔗 Edges / Links

### Used In Products
- [[CAT-AP-01|CAT-AP-01 — Denim]]

### Sourced By Combos
- [[COMBO-005-turkey-denim-specialist|COMBO-005 — Turkey Denim Specialist]]
- [[COMBO-004-china-medium-woven|COMBO-004 — China Medium Woven]]

### Regulation References
- [[REG-REACH]]
- [[REG-UFLPA]]

### Compliance / Pain Points
- [[PP-REG-UFLPA-001]]
- [[PP-REG-REACH-001]]
