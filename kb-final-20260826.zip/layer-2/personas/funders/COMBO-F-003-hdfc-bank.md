---
type: persona
subtype: funder
id: COMBO-F-003
layer: 2
name: HDFC Bank
country: IN
funder_type: bank
products:
  - bank_OD
  - bank_LC
  - export_credit
typical_rate: "12–16%"
collateral_required: true
personal_guarantee: true
coverage_region:
  - South Asia
air8_competitive_position: competing
---

# COMBO-F-003 — HDFC Bank

## Identity
- id: COMBO-F-003
- country: India (IN)
- type: bank
- products_offered: bank_OD, bank_LC, export_credit
- typical_rate: 12–16%
- collateral_required: yes
- personal_guarantee: yes
- coverage_region: South Asia

## Key Limitations (Why Suppliers Suffer)
- **OD rates destroy margins:** 12–18% overdraft rate consumes 75–150% of the typical 8–12% export margin, making bank OD mathematically unprofitable for many suppliers
- **Personal guarantee traps owner assets:** Proprietors and partners must pledge personal assets, creating catastrophic downside if orders are delayed or cancelled
- **Slow LC processing:** 30–60 day LC issuance/processing creates working capital voids during production ramp-up
- **INR depreciation double-hit:** INR-denominated financing gets more expensive in USD terms as INR depreciates, squeezing USD revenue further
- **Export credit complexity:** Bank export credit schemes involve bureaucratic eligibility checks and disbursement delays

## Air8 Advantage vs This Funder
- **SOFR+4% vs 12–18% OD:** Air8 rate is 6–10 percentage points lower — directly recoverable margin for the supplier
- **No personal guarantee:** Owner's personal assets are never at risk under Air8 products
- **T+1 vs 30–60 day LC:** Near-instant disbursement eliminates the production financing gap
- **USD-denominated financing:** Provides a natural hedge against INR depreciation — Air8 cost stays flat in INR/USD cross terms
- **No collateral:** ARP is priced on buyer credit quality, not supplier asset base

## 🔗 Edges / Links

### Supplier Combos Financed (Incumbent)
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — India Large Vertical Integrator]]
- [[COMBO-008-india-organic-cotton-medium|COMBO-008 — India Organic Cotton Medium Supplier]]
- [[COMBO-HG-003-india-moradabad-brass-artware|COMBO-HG-003 — India Moradabad Brass Artware Supplier]]

### Air8 Products That Compete
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase (replaces bank OD/LC)]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment RT2C (replaces export credit)]]
- [[PROD-PRESHIP-OBF|PROD-PRESHIP-OBF — Pre-Shipment OBF (order-based financing)]]

### Country References
- [[IN|Country — India]]

### Compliance / Pain Points Created
- [[PP-001-cashflow-gap|PP-001 — Cash Flow Gap from LC/OD processing delays]]
- [[PP-002-financing-cost|PP-002 — High Financing Cost consuming export margins]]
- [[PP-IN-001-india-msme-credit-gap|PP-IN-001 — India MSME Credit Gap]]
- [[PP-IN-003-inr-depreciation|PP-IN-003 — INR Depreciation compounding financing cost]]
