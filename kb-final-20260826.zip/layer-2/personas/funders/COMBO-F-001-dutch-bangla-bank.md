---
type: persona
subtype: funder
id: COMBO-F-001
layer: 2
name: Dutch-Bangla Bank
country: BD
funder_type: bank
products:
  - bank_LC
  - bank_OD
typical_rate: "10–16%"
collateral_required: true
personal_guarantee: true
coverage_region:
  - South Asia
air8_competitive_position: competing
---

# COMBO-F-001 — Dutch-Bangla Bank

## Identity
- id: COMBO-F-001
- country: Bangladesh (BD)
- type: bank
- products_offered: bank_LC, bank_OD
- typical_rate: 10–16%
- collateral_required: yes
- personal_guarantee: yes
- coverage_region: South Asia

## Key Limitations (Why Suppliers Suffer)
- **Slow LC processing:** 45–60 day LC turnaround creates critical cash flow gaps between order confirmation and shipment
- **Collateral-heavy:** Physical assets required as security, locking up supplier capital in illiquid form
- **Personal guarantee required:** Owner's personal assets exposed, creating existential risk for sole proprietors and family businesses
- **Micro/small supplier exclusion:** Limited appetite for suppliers below a certain revenue threshold, leaving the largest segment of BD garment suppliers underserved
- **High INR-equivalent financing cost:** 10–16% BDT rate erodes thin 8–12% export margins, especially for competitive FOB pricing

## Air8 Advantage vs This Funder
- **No collateral required:** Air8 ARP is buyer-risk priced, not asset-backed — suppliers don't need to pledge property
- **No personal guarantee:** Owner assets remain protected at all times
- **T+1 disbursement vs 45–60 day LC:** Air8 disburses within 1 business day of invoice approval, eliminating the processing gap entirely
- **SOFR+4% vs 10–16%:** At current SOFR levels, Air8 rate is materially lower, preserving more margin per shipment
- **USD-denominated financing:** Protects against BDT depreciation risk that compounds local bank financing costs

## 🔗 Edges / Links

### Supplier Combos Financed (Incumbent)
- [[COMBO-001-south-asian-small-knit|COMBO-001 — South Asian Small Knit Supplier]]
- [[COMBO-002-bangladesh-bank-lc|COMBO-002 — Bangladesh Bank LC Supplier]]

### Air8 Products That Compete
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase (replaces bank LC/OD)]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment RT2C (replaces pre-shipment bank credit)]]
- [[PROD-PAYGUARD|PROD-PAYGUARD — PayGuard (payment protection layer)]]

### Country References
- [[BD|Country — Bangladesh]]

### Compliance / Pain Points Created
- [[PP-001-cashflow-gap|PP-001 — Cash Flow Gap from slow LC processing]]
- [[PP-002-financing-cost|PP-002 — High Financing Cost consuming export margins]]
- [[PP-BD-002-political-instability|PP-BD-002 — Bangladesh Political Instability amplifying bank risk]]
