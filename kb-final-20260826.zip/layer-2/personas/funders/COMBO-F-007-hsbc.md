---
type: persona
subtype: funder
id: COMBO-F-007
layer: 2
name: HSBC
country: HK
funder_type: trade_finance_house
products:
  - bank_LC
  - supply_chain_finance
  - factoring
  - FX_hedging
typical_rate: "5–10% USD/EUR; 8–14% local currency"
collateral_required: true
personal_guarantee: false
coverage_region:
  - APAC
  - Europe
  - MEA
air8_competitive_position: competing
---

# COMBO-F-007 — HSBC

## Identity
- id: COMBO-F-007
- country: Hong Kong (HK)
- type: trade_finance_house
- products_offered: bank_LC, supply_chain_finance, factoring, FX_hedging
- typical_rate: 5–10% (USD/EUR trade finance); 8–14% (local currency)
- collateral_required: yes
- personal_guarantee: corporate guarantee for large FDI/listed clients only
- coverage_region: APAC, Europe, MEA

## Key Limitations (Why Suppliers Suffer)
- **$5M+ minimum ticket:** HSBC trade finance is only accessible for suppliers with significant ticket sizes — micro and small suppliers under $5M revenue are systematically excluded
- **VN FDI parent HQ approval bottleneck:** Vietnam FDI factories (Chinese or other foreign-owned) require parent company HQ approval before HSBC can extend facilities — a 4–8 week delay that makes HSBC impractical for fast-moving production cycles
- **Collateral requirement for smaller clients:** Even within eligible tiers, collateral is standard for non-flagship clients
- **Relationship-dependent access:** HSBC's best trade finance terms are reserved for large, listed, or FDI multinationals — independent mid-sized suppliers get second-tier treatment
- **Complexity and paperwork:** HSBC's LC and SCF products involve extensive documentation, KYC, and compliance processes that impose significant operational burden on smaller suppliers

## Air8 Advantage vs This Funder
- **T+1 for smaller suppliers ($1M+ revenue):** Air8 ARP is accessible from $1M revenue upward — a dramatically lower threshold than HSBC's $5M+ minimum
- **VN FDI: no parent HQ requirement:** Air8 approves VN FDI factories directly based on buyer relationships and invoice quality — no parent company sign-off, no 4–8 week wait
- **Accessible for all revenue tiers:** Air8's buyer-risk pricing model means a $2M revenue Vietnam FDI factory gets the same quality of service and speed as a $50M multinational
- **Comparable or lower USD rate:** At SOFR+4%, Air8 is competitive with HSBC's 5–10% USD trade finance rate for eligible suppliers — without the minimum ticket and access barriers
- **Simplified onboarding:** Air8 product activation is streamlined vs HSBC's full KYC/compliance journey

## 🔗 Edges / Links

### Supplier Combos Financed (Incumbent)
- [[COMBO-004-china-medium-woven|COMBO-004 — China Medium Woven Supplier]]
- [[COMBO-006-vietnam-fdi-knit|COMBO-006 — Vietnam FDI Knit Supplier]]
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — India Large Vertical Integrator]]

### Air8 Products That Compete
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase (replaces supply chain finance/LC)]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment RT2C (replaces pre-shipment financing)]]
- [[PROD-POOL|PROD-POOL — Pool Financing (replaces working capital/SCF facility)]]

### Country References
- [[HK|Country — Hong Kong]]

### Compliance / Pain Points Created
- [[PP-001-cashflow-gap|PP-001 — Cash Flow Gap from HQ approval delays and minimum ticket exclusion]]
- [[PP-004-scalability-constraint|PP-004 — Scalability Constraint: minimum ticket locks out growing suppliers]]
