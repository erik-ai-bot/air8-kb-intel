---
type: persona
subtype: funder
id: COMBO-F-005
layer: 2
name: HBL Bank
country: PK
funder_type: bank
products:
  - bank_LC
  - bank_OD
  - export_finance
typical_rate: "15–20%"
collateral_required: true
personal_guarantee: true
coverage_region:
  - South Asia
air8_competitive_position: competing
---

# COMBO-F-005 — HBL Bank

## Identity
- id: COMBO-F-005
- country: Pakistan (PK)
- type: bank
- products_offered: bank_LC, bank_OD, export_finance
- typical_rate: 15–20%
- collateral_required: yes
- personal_guarantee: yes
- coverage_region: South Asia

## Key Limitations (Why Suppliers Suffer)
- **Among the highest bank rates globally:** 15–22% total effective bank rate (including all charges) — one of the most expensive formal credit environments for exporters worldwide
- **Power crisis multiplier:** Pakistan's energy crisis adds 10–20% to production costs; when combined with 15–22% financing costs, total cost burden can exceed supplier margin entirely
- **Collateral and PG required:** Standard physical collateral plus personal guarantee required, tying up supplier assets and exposing owner liability
- **Political instability risk:** Pakistan's political environment creates sudden policy shifts, forex controls, and banking system disruptions that can freeze credit lines without notice
- **PKR depreciation risk:** PKR-denominated facilities become more expensive in USD revenue terms as PKR weakens — amplifying the already-high nominal rate

## Air8 Advantage vs This Funder
- **Offshore USD at SOFR+4% vs 15–22%:** Air8 rate is 9–16 percentage points lower — the single largest margin recovery opportunity for any PK supplier
- **No collateral, no personal guarantee:** Owner and factory assets are fully protected under all Air8 products
- **Cash flow improvement offsets power cost burden:** Faster, cheaper financing improves working capital position, helping suppliers absorb energy cost shocks without cutting orders
- **Offshore structure immune to PKR/political risk:** Air8 facilities are offshore USD — not subject to Pakistan forex controls, SBP policy changes, or domestic banking disruptions
- **T+1 disbursement vs standard 30–60 day LC:** Near-instant funding closes production financing gaps that HBL's slow processing creates

## 🔗 Edges / Links

### Supplier Combos Financed (Incumbent)
- [[COMBO-009-pakistan-home-textile|COMBO-009 — Pakistan Home Textile Supplier]]
- [[COMBO-001-south-asian-small-knit|COMBO-001 — South Asian Small Knit Supplier]]

### Air8 Products That Compete
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase (replaces bank LC/OD)]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment RT2C (replaces export finance)]]
- [[PROD-POOL|PROD-POOL — Pool Financing (replaces working capital facility)]]

### Country References
- [[PK|Country — Pakistan]]

### Compliance / Pain Points Created
- [[PP-001-cashflow-gap|PP-001 — Cash Flow Gap from LC processing delays]]
- [[PP-002-financing-cost|PP-002 — High Financing Cost (among highest globally)]]
- [[PP-PK-001-energy-crisis|PP-PK-001 — Pakistan Energy Crisis adding production cost burden]]
