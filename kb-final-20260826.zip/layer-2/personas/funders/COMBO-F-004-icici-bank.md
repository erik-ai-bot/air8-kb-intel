---
type: persona
subtype: funder
id: COMBO-F-004
layer: 2
name: ICICI Bank
country: IN
funder_type: bank
products:
  - bank_OD
  - bank_LC
  - treasury_facilities
typical_rate: "11–16%"
collateral_required: true
personal_guarantee: true
coverage_region:
  - South Asia
air8_competitive_position: competing
---

# COMBO-F-004 — ICICI Bank

## Identity
- id: COMBO-F-004
- country: India (IN)
- type: bank
- products_offered: bank_OD, bank_LC, treasury_facilities
- typical_rate: 11–16%
- collateral_required: yes
- personal_guarantee: yes
- coverage_region: South Asia

## Key Limitations (Why Suppliers Suffer)
- **Large-ticket bias:** ICICI's credit appetite favors large corporates and listed companies — smaller FOB exporters under $10M revenue are systematically underserved or declined
- **OD rates remain high for established clients:** Even long-standing clients with strong track records still face 11–16% OD pricing — rate does not meaningfully reward loyalty
- **Collateral and PG standard:** Physical collateral and personal guarantee requirements apply across the board, regardless of client history
- **30–60 day LC processing:** Standard bank processing timelines create financing gaps for suppliers managing tight production cycles
- **Relationship-dependent access:** Credit line increases often require relationship manager escalation, creating unpredictable access for growing suppliers

## Air8 Advantage vs This Funder
- **Serves $1M+ revenue suppliers equally:** Air8 ARP has no minimum revenue threshold that excludes small/medium exporters — buyer credit quality drives eligibility, not supplier size
- **Buyer-risk pricing model:** ARP uses the buyer's credit profile to price the facility, not the supplier's balance sheet or collateral — a fundamentally different and fairer model
- **T+1 vs 30–60 day LC processing:** Air8 disburses within 1 business day of invoice approval, removing the production financing gap
- **No collateral, no personal guarantee:** Owner assets are fully protected under all Air8 products
- **Predictable credit access:** Air8 credit lines are tied to buyer relationships, not subject to bank committee decisions or relationship manager availability

## 🔗 Edges / Links

### Supplier Combos Financed (Incumbent)
- [[COMBO-014-india-small-woven|COMBO-014 — India Small Woven Supplier]]
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — India Large Vertical Integrator]]

### Air8 Products That Compete
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase (replaces bank OD/LC)]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment RT2C (replaces export credit)]]

### Country References
- [[IN|Country — India]]

### Compliance / Pain Points Created
- [[PP-001-cashflow-gap|PP-001 — Cash Flow Gap from LC/OD processing delays]]
- [[PP-002-financing-cost|PP-002 — High Financing Cost vs export margins]]
- [[PP-IN-001-india-msme-credit-gap|PP-IN-001 — India MSME Credit Gap (small exporters excluded)]]
