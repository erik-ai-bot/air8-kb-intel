---
type: persona
subtype: funder
id: COMBO-F-006
layer: 2
name: Garanti BBVA
country: TR
funder_type: bank
products:
  - bank_LC
  - bank_OD
  - factoring
  - FX_hedging
typical_rate: "25–40% TRY effective"
collateral_required: true
personal_guarantee: true
coverage_region:
  - Europe
  - Middle East
air8_competitive_position: competing
---

# COMBO-F-006 — Garanti BBVA

## Identity
- id: COMBO-F-006
- country: Turkey (TR)
- type: bank
- products_offered: bank_LC, bank_OD, factoring, FX_hedging
- typical_rate: TRY 25–40% effective (hyperinflation-adjusted)
- collateral_required: yes
- personal_guarantee: yes
- coverage_region: Europe, Middle East

## Key Limitations (Why Suppliers Suffer)
- **TRY hyperinflation makes financing catastrophic:** TRY-denominated credit at 25–40% effective rate is toxic for EUR/USD revenue factories — the cost of financing in local currency exceeds revenue denomination, creating structural FX losses
- **TRY depreciation >300% since 2020:** Cumulative TRY depreciation has destroyed the real cost of any TRY-denominated obligation held by EUR/USD earners; banks offering TRY credit are offering a currency trap
- **Active credit line withdrawal since 2023:** Turkish banks including Garanti have been proactively reducing exposure to the textile sector since 2023, leaving suppliers with sudden, unexpected credit gaps at the worst possible moments
- **Factoring/FX hedging complexity:** While offered, FX hedging products add cost and complexity; factoring facilities still require collateral and have high minimum thresholds
- **Collateral and PG required:** Standard physical collateral plus personal guarantee, with TRY-denominated collateral valuations subject to inflation distortion

## Air8 Advantage vs This Funder
- **EUR/USD-denominated financing = natural hedge:** Air8 financing is USD-denominated, matching the revenue currency of Turkish textile exporters — eliminating TRY depreciation risk entirely
- **SOFR+4% vs 25–40% TRY effective:** The rate differential is the largest of any Air8 market — a supplier switching from Garanti TRY credit to Air8 ARP recovers 20–35 percentage points of financing cost
- **ARP replaces withdrawn bank credit lines:** As Garanti and other Turkish banks pull back from textile sector exposure, Air8 ARP provides a stable, buyer-backed alternative that doesn't depend on domestic bank appetite
- **No collateral, no personal guarantee:** Owner and factory assets fully protected — particularly important in Turkey's volatile macro environment
- **Offshore stability:** Air8 facilities are offshore and not subject to BDDK (Turkish banking regulator) policy changes, TRY deposit rate decisions, or domestic credit committee sentiment

## 🔗 Edges / Links

### Supplier Combos Financed (Incumbent)
- [[COMBO-005-turkey-denim-specialist|COMBO-005 — Turkey Denim Specialist Supplier]]

### Air8 Products That Compete
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase (replaces bank LC/OD and withdrawn credit lines)]]
- [[PROD-POOL|PROD-POOL — Pool Financing (replaces working capital facility)]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment RT2C (replaces pre-shipment bank credit)]]

### Country References
- [[TR|Country — Turkey]]

### Compliance / Pain Points Created
- [[PP-001-cashflow-gap|PP-001 — Cash Flow Gap from credit line withdrawal]]
- [[PP-002-financing-cost|PP-002 — High Financing Cost (TRY hyperinflation rate)]]
- [[PP-TR-001-lira-hyperinflation|PP-TR-001 — Turkish Lira Hyperinflation destroying financing economics]]
- [[PP-TR-002-bank-credit-contraction|PP-TR-002 — Turkish Bank Credit Contraction in textile sector since 2023]]
