---
type: persona
subtype: funder
id: COMBO-F-002
layer: 2
name: BRAC Bank
country: BD
funder_type: bank
products:
  - bank_LC
  - pre_shipment_credit
typical_rate: "11–15%"
collateral_required: true
personal_guarantee: true
coverage_region:
  - South Asia
air8_competitive_position: competing
---

# COMBO-F-002 — BRAC Bank

## Identity
- id: COMBO-F-002
- country: Bangladesh (BD)
- type: bank
- products_offered: bank_LC, pre_shipment_credit
- typical_rate: 11–15%
- collateral_required: yes
- personal_guarantee: yes
- coverage_region: South Asia

## Key Limitations (Why Suppliers Suffer)
- **Sector stress from NPL crisis:** Bangladesh banking sector NPL ratio hit 35.73% as of September 2025 — banks including BRAC are tightening credit availability and increasing scrutiny
- **Collateral-heavy despite RMG focus:** Even for established RMG suppliers, physical collateral and personal guarantees are standard requirements
- **Credit tightening:** As NPLs rise, banks proactively reduce or withdraw credit lines, leaving suppliers with sudden financing gaps mid-season
- **BDT depreciation risk:** BDT-denominated credit becomes more expensive in real terms as the currency weakens against USD
- **Personal guarantee exposure:** Owner's personal assets at risk in a high-NPL, politically unstable environment

## Air8 Advantage vs This Funder
- **Offshore USD financing:** Air8 financing is USD-denominated and offshore — completely insulated from Bangladesh banking sector stress and NPL contagion
- **No collateral required:** ARP is buyer-risk priced; suppliers with strong buyers qualify regardless of their own asset base
- **No personal guarantee:** No owner asset exposure under any Air8 product
- **SOFR+4% vs 11–15%:** Materially lower financing cost, improving net margin per shipment
- **Credit line stability:** Air8 credit lines are not subject to BD bank credit committee decisions or sector-wide tightening cycles

## 🔗 Edges / Links

### Supplier Combos Financed (Incumbent)
- [[COMBO-001-south-asian-small-knit|COMBO-001 — South Asian Small Knit Supplier]]
- [[COMBO-002-bangladesh-bank-lc|COMBO-002 — Bangladesh Bank LC Supplier]]

### Air8 Products That Compete
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase (replaces bank LC/OD)]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment RT2C (replaces pre-shipment bank credit)]]

### Country References
- [[BD|Country — Bangladesh]]

### Compliance / Pain Points Created
- [[PP-001-cashflow-gap|PP-001 — Cash Flow Gap from LC processing delays]]
- [[PP-002-financing-cost|PP-002 — High Financing Cost vs thin export margins]]
- [[PP-BD-002-political-instability|PP-BD-002 — Bangladesh Political Instability amplifying banking sector fragility]]
