---
type: persona
subtype: buyer
id: COMBO-B-002
layer: 2
name: US Premium Home Retailers
buyer_geo: US
channel: premium_home
payment_days: "60–90 OA"
compliance_standards: very_high
tariff_sensitivity: medium
origin_shift_risk: medium
key_buyers: [Pottery Barn, Restoration Hardware, Williams-Sonoma, CB2, West Elm, Arhaus]
---

# COMBO-B-002 — US Premium Home Retailers

## Identity
- id: COMBO-B-002
- buyer_geo: US
- channel: premium_home
- payment_terms: 60–90 days OA
- key_buyers: Pottery Barn, Restoration Hardware, Williams-Sonoma, CB2, West Elm, Arhaus
- compliance_standards: very_high — design QA, full compliance stack, supplier ethics, co-development requirements
- tariff_sensitivity: medium — willing to absorb tariff cost for quality and design differentiation; but now actively sourcing India for authentic brass
- origin_shift_risk: medium — shifts driven by quality, design authenticity, and ESG, not purely cost arbitrage

## Products Purchased
- Premium brass and metal artware (handcrafted, artisan)
- Premium outdoor furniture (teak, wrought iron, high-end aluminium)
- Home décor (artisan ceramics, stone, hand-finished metal)
- Premium home textiles (organic cotton, linen, GOTS-certified)

## Compliance Requirements Imposed on Suppliers
- REACH (chemical substances — full SVHC compliance)
- CARB Phase 2 (composite wood products with formaldehyde)
- FSC certification (for all wood components)
- CA Prop 65 (mandatory for California market)
- GOTS certification (for organic cotton product lines)
- Ethical sourcing audit (SA8000 or equivalent)
- Design IP protection agreements
- Co-development NDA requirements

## Air8 Relevance
SELLS_TO signal strongest for India Moradabad brass artware suppliers (T1 tariff benefit + authentic artisan positioning). Premium buyers are actively shifting from CN zamak to India brass for Pottery Barn/RH/WS lines. Longer OA terms of 60–90 days create high-value ARP opportunities; pre-shipment financing for longer production cycles (RT2C) also relevant.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-US-Premium-Home|BuyerType — US Premium Home]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-HG-003-india-moradabad-brass-artware|COMBO-HG-003 — India Brass Shifting to Fill US Premium Demand; Pottery Barn/RH/WS Actively Sourcing]] (weight: 0.85)
- [[COMBO-HG-001-china-outdoor-furniture|COMBO-HG-001 — CN Premium Outdoor; Declining on Tariff]] (weight: 0.30)
- [[COMBO-HG-002-china-brass-artware|COMBO-HG-002 — Zamak Décor Items; Stable]] (weight: 0.25)
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — Organic Cotton Home Textiles for Sustainable Premium Lines]] (weight: 0.60)

### Product Categories Purchased
- [[CAT-HG-02|CAT-HG-02 — Metal Artware & Décor]]
- [[CAT-HG-04|CAT-HG-04 — Outdoor Furniture]]
- [[CAT-HG-01|CAT-HG-01 — Seasonal & Holiday Décor]]
- [[CAT-HG-03|CAT-HG-03 — Ceramic & Glass Artware]]

### Regulation References
- [[REG-REACH]]
- [[REG-TARIFF]]
- [[REG-UFLPA]]
- [[REG-CSDDD]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment Financing RT2C]]
