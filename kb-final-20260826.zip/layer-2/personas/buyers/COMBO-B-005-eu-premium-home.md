---
type: persona
subtype: buyer
id: COMBO-B-005
layer: 2
name: EU Premium Home Retailers
buyer_geo: EU
channel: premium_home
payment_days: "60–90 OA"
compliance_standards: very_high
tariff_sensitivity: low
origin_shift_risk: medium
key_buyers: [John Lewis (UK), Crate & Barrel EU, Zara Home, H&M Home premium, Garden Trading UK]
---

# COMBO-B-005 — EU Premium Home Retailers

## Identity
- id: COMBO-B-005
- buyer_geo: EU
- channel: premium_home
- payment_terms: 60–90 days OA
- key_buyers: John Lewis (UK), Crate & Barrel EU, Zara Home, H&M Home premium, Garden Trading UK
- compliance_standards: very_high — FSC (wood), GOTS (organic textiles), CSDDD (due diligence), REACH, OEKO-TEX Standard 100; co-development design requirements
- tariff_sensitivity: low — EU-CN tariff pressure minimal; premium pricing absorbs landed cost increases
- origin_shift_risk: medium — shifts are ESG and design-led (India for artisan brass, Turkey/Portugal for organic textiles) rather than cost/tariff-driven

## Products Purchased
- Premium outdoor furniture (FSC-certified teak, powder-coated aluminium, premium rattan)
- Premium home textiles (organic cotton, linen, GOTS-certified ranges)
- Organic apparel and home (for integrated retail brands like Zara Home)
- Premium home décor (artisan brass, hand-finished ceramics, natural materials)

## Compliance Requirements Imposed on Suppliers
- FSC certification (mandatory for all wood and natural rattan components)
- GOTS certification (organic cotton and wool product lines)
- CSDDD compliance (EU supply chain due diligence — larger brands mandated 2026+)
- REACH (full SVHC compliance including candidate list)
- OEKO-TEX Standard 100 (all textile components)
- Ethical audit (SMETA or equivalent; some require B Corp alignment)
- Traceability documentation (fibre origin to finished product)

## Air8 Relevance
ESG-linked financing opportunity where GOTS/organic cotton certification investment creates financing need (PROD-ESG-FINANCING). OBF for premium cotton procurement supports India vertically integrated mills. Longer buyer relationships and repeat seasonal ranges deliver more stable ARP book than mass retail; lower churn and higher per-order values.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-EU-Premium-Home|BuyerType — EU Premium Home]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-HG-001-china-outdoor-furniture|COMBO-HG-001 — Premium EU Outdoor Furniture]] (weight: 0.60)
- [[COMBO-003-india-large-vertical-integrator|COMBO-003 — GOTS Organic for EU Premium]] (weight: 0.80)
- [[COMBO-008-india-organic-cotton-medium|COMBO-008 — Organic Cotton for EU Premium Home Textiles]] (weight: 0.70)
- [[COMBO-HG-003-india-moradabad-brass-artware|COMBO-HG-003 — Artisan Brass for EU Premium Home]] (weight: 0.60)

### Product Categories Purchased
- [[CAT-HG-04|CAT-HG-04 — Outdoor Furniture]]
- [[CAT-AP-05|CAT-AP-05 — Organic / Sustainable Textiles]]
- [[CAT-HG-01|CAT-HG-01 — Seasonal & Holiday Décor]]
- [[CAT-HG-02|CAT-HG-02 — Metal Artware & Décor]]

### Regulation References
- [[REG-REACH]]
- [[REG-CSDDD]]
- [[REG-UFLPA]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]]
- [[PROD-PRESHIP-OBF|PROD-PRESHIP-OBF — Pre-Shipment Open Buyer Financing]]
- [[PROD-ESG-FINANCING|PROD-ESG-FINANCING — ESG-Linked Supply Chain Financing]]
