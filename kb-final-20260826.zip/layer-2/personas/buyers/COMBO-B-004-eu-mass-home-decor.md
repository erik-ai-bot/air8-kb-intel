---
type: persona
subtype: buyer
id: COMBO-B-004
layer: 2
name: EU Mass Home Décor Retailers
buyer_geo: EU
channel: mass_home_decor
payment_days: "60–90 OA"
compliance_standards: medium
tariff_sensitivity: low
origin_shift_risk: low
key_buyers: [JYSK, Leroy Merlin, TK Maxx, Flying Tiger Copenhagen, Maisons du Monde, Amazon EU]
---

# COMBO-B-004 — EU Mass Home Décor Retailers

## Identity
- id: COMBO-B-004
- buyer_geo: EU
- channel: mass_home_decor
- payment_terms: 60–90 days OA
- key_buyers: JYSK, Leroy Merlin, TK Maxx, Flying Tiger Copenhagen, Maisons du Monde, Amazon EU
- compliance_standards: medium-high — REACH, GPSR, RoHS mandatory; CE marking required for electronics/lighting
- tariff_sensitivity: low — EU-CN tariffs significantly lower than US Section 301; CN remains cost-competitive for EU mass home décor
- origin_shift_risk: low — CN remains dominant; no material tariff incentive to shift origin for EU-destined goods

## Products Purchased
- Outdoor furniture (metal, rattan, mixed materials)
- Metal, glass, and ceramic artware
- Holiday and seasonal décor
- Home textiles (cushions, throws, rugs, basic bedding)
- Decorative and functional lighting
- Rugs and floor coverings

## Compliance Requirements Imposed on Suppliers
- REACH (chemical substances — SVHC, heavy metals, azo dyes)
- GPSR (EU General Product Safety Regulation — replaces GPSD from Dec 2024)
- RoHS Directive (restriction of hazardous substances in electrical/electronic equipment)
- CE marking (mandatory for all electrical, lighting, and electronic products)
- EN standards (EN 581 for outdoor furniture, EN 60598 for luminaires)
- CSDDD (emerging — mandatory due diligence for larger suppliers)

## Air8 Relevance
Largest EU buyer segment for CN hardgoods exporters; stable OA terms of 60–90 days make this the core ARP book for EU-destined CN goods. Lower tariff risk than US market means more stable supplier book with lower origin-shift disruption risk — predictable ARP utilisation and renewals.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-EU-Mass-Home-Decor|BuyerType — EU Mass Home Décor]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-HG-001-china-outdoor-furniture|COMBO-HG-001 — Primary EU Outdoor Furniture Supply]] (weight: 0.80)
- [[COMBO-HG-002-china-brass-artware|COMBO-HG-002 — EU Home Décor Metal Artware]] (weight: 0.70)
- [[COMBO-HG-004-china-decorative-lighting|COMBO-HG-004 — EU Decorative Lighting; CE Required]] (weight: 0.80)
- [[COMBO-009-pakistan-home-textile|COMBO-009 — PK Home Textiles for EU Mass]] (weight: 0.60)

### Product Categories Purchased
- [[CAT-HG-02|CAT-HG-02 — Metal Artware & Décor]]
- [[CAT-HG-04|CAT-HG-04 — Outdoor Furniture]]
- [[CAT-HG-06|CAT-HG-06 — Decorative Lighting]]
- [[CAT-HG-01|CAT-HG-01 — Seasonal & Holiday Décor]]
- [[CAT-HG-08|CAT-HG-08 — Rugs & Floor Coverings]]

### Regulation References
- [[REG-REACH]]
- [[REG-GPSR]]
- [[REG-CE-LVD-EMC]]
- [[REG-CSDDD]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]]
- [[PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C — Pre-Shipment Financing RT2C]]
