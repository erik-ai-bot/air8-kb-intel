---
type: persona
subtype: buyer
id: COMBO-B-006
layer: 2
name: EU Premium Lighting Retailers
buyer_geo: EU
channel: premium_lighting
payment_days: "60–90 OA"
compliance_standards: very_high
tariff_sensitivity: low
origin_shift_risk: low
key_buyers: [Nordlux (Denmark), Eglo (Austria), BHS (UK), Rowico (Sweden), Lighting Style (UK)]
---

# COMBO-B-006 — EU Premium Lighting Retailers

## Identity
- id: COMBO-B-006
- buyer_geo: EU
- channel: premium_lighting
- payment_terms: 60–90 days OA
- key_buyers: Nordlux (Denmark), Eglo (Austria), BHS (UK), Rowico (Sweden), Lighting Style (UK)
- compliance_standards: very_high — CE LVD + EMC mandatory for all products, CE RED for smart lighting, EN 60598 compliance, energy labelling regulation; design IP protection standard
- tariff_sensitivity: low — EU tariff exposure minimal for lighting; CN factories remain price-competitive even at EU import duty levels
- origin_shift_risk: low-medium — CE re-certification requirement (2–3 week re-test cycle per SKU) creates high switching barrier; most buyers stick with certified CN factories rather than re-qualify alternate origins

## Products Purchased
- LED chandeliers and pendant lights
- Table lamps and floor lamps
- Battery-operated and solar decorative lights
- Smart lighting (WiFi/Bluetooth enabled)
- Outdoor and garden lighting

## Compliance Requirements Imposed on Suppliers
- CE LVD (Low Voltage Directive — mandatory for all mains-powered lighting)
- CE EMC (Electromagnetic Compatibility Directive)
- EN 60598 (luminaires standard — photometric, thermal, mechanical safety)
- CE RED (Radio Equipment Directive — smart/wireless lighting products)
- EU Energy Labelling Regulation (A-rated LED efficiency requirements)
- RoHS (restriction of hazardous substances — mercury, lead, cadmium)
- REACH (chemical compliance for all materials)
- WEEE (waste electrical and electronic equipment take-back scheme)

## Air8 Relevance
Primary EU market for CN decorative lighting suppliers. CE certification acts as a natural factory loyalty mechanism — buyers rarely switch to uncertified alternatives. Rising copper costs (tariff-driven input price inflation) create cash flow stress in CN lighting factories = direct ARP opportunity. SMARTWALLET can monitor CE re-certification signals as an early indicator of buyer-supplier relationship changes.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-EU-Premium-Lighting|BuyerType — EU Premium Lighting]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-HG-004-china-decorative-lighting|COMBO-HG-004 — Primary EU Premium Lighting Supply; CE Required]] (weight: 0.90)

### Product Categories Purchased
- [[CAT-HG-06|CAT-HG-06 — Decorative Lighting]]

### Regulation References
- [[REG-CE-LVD-EMC]]
- [[REG-GPSR]]
- [[REG-REACH]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]]
- [[PROD-SMARTWALLET|PROD-SMARTWALLET — Smart Wallet Buyer-Mix Monitoring]] (monitor CE re-cert signals)
