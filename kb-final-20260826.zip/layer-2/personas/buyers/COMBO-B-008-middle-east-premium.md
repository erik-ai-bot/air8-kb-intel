---
type: persona
subtype: buyer
id: COMBO-B-008
layer: 2
name: Middle East Premium / Hospitality Buyers
buyer_geo: MiddleEast
channel: hospitality_premium
payment_days: "30–60 OA (first orders often LC)"
compliance_standards: medium
tariff_sensitivity: very_low
origin_shift_risk: very_low
key_buyers: [UAE luxury retail (Dubai Mall, Mall of Emirates), Saudi Vision 2030 hospitality, Qatar luxury homewares, UAE resort procurement]
---

# COMBO-B-008 — Middle East Premium / Hospitality Buyers

## Identity
- id: COMBO-B-008
- buyer_geo: MiddleEast
- channel: hospitality_premium
- payment_terms: 30–60 days OA (first orders often LC)
- key_buyers: UAE luxury retail (Dubai Mall, Mall of Emirates), Saudi Vision 2030 hospitality, Qatar luxury homewares, UAE resort procurement
- compliance_standards: medium — varies significantly by buyer; international luxury brands impose REACH for EU re-export legs; local buyers follow Gulf Standards Organisation (GSO) requirements; ESG requirements low compared to EU/US
- tariff_sensitivity: very_low — GCC import duties low (5% standard); no Section 301 or EU anti-dumping exposure; China remains dominant and preferred origin
- origin_shift_risk: very_low — no tariff incentive to shift; China dominant and accepted; India artisan brass valued for premium positioning (authentic craftsmanship narrative)

## Products Purchased
- Brass and metal artware (decorative, gift, interior)
- Metal décor (wall art, sculptures, ornamental pieces)
- Decorative lighting (chandeliers, pendant lights, statement pieces)
- Premium outdoor furniture (resort pools, hotel terraces, marina developments)
- Home textiles (luxury hospitality linen, towels, décor cushions)

## Compliance Requirements Imposed on Suppliers
- REACH (for brands that re-export to EU or operate EU-standard retail)
- GSO (Gulf Standards Organisation — electrical safety, product safety)
- Local safety standards (ESMA in UAE, SASO in Saudi Arabia)
- Halal certification (not typically required for homewares; relevant for food-contact items only)
- Country of origin documentation (CN and India both accepted)
- Quality inspections (typically pre-shipment inspection required for large hospitality orders)

## Air8 Relevance
Growing channel as EU and US mass retail declines — ME hospitality boom (Saudi Vision 2030 mega-projects, UAE luxury expansion, Qatar post-World Cup investment) drives incremental demand for both CN and India brass artware and decorative items. First orders often on LC providing natural PAYGUARD entry point; repeat orders shift to OA creating ARP follow-on. DDP delivery terms common for ME hospitality procurement.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-MiddleEast-Premium|BuyerType — Middle East Premium & Hospitality]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-HG-002-china-brass-artware|COMBO-HG-002 — CN Metal Artware Growing ME Channel]] (weight: 0.60)
- [[COMBO-HG-003-india-moradabad-brass-artware|COMBO-HG-003 — India Artisan Brass Premium for ME]] (weight: 0.70)
- [[COMBO-HG-001-china-outdoor-furniture|COMBO-HG-001 — Hospitality Outdoor Furniture]] (weight: 0.40)
- [[COMBO-HG-004-china-decorative-lighting|COMBO-HG-004 — Decorative Lighting for ME Hospitality]] (weight: 0.50)

### Product Categories Purchased
- [[CAT-HG-02|CAT-HG-02 — Metal Artware & Décor]]
- [[CAT-HG-06|CAT-HG-06 — Decorative Lighting]]
- [[CAT-HG-04|CAT-HG-04 — Outdoor Furniture]]

### Regulation References
- [[REG-REACH]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]]
- [[PROD-PAYGUARD|PROD-PAYGUARD — Payment Protection]]
- [[PROD-DDP|PROD-DDP — DDP Delivery Terms Financing]]
