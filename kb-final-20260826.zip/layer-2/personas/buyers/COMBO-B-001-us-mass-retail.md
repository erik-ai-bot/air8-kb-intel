---
type: persona
subtype: buyer
id: COMBO-B-001
layer: 2
name: US Mass Market Retailers
buyer_geo: US
channel: mass_retail
payment_days: "30–60 OA"
compliance_standards: high
tariff_sensitivity: very_high
origin_shift_risk: high
key_buyers: [Walmart, Target, Home Depot, Lowe's, Wayfair, Amazon US]
---

# COMBO-B-001 — US Mass Market Retailers

## Identity
- id: COMBO-B-001
- buyer_geo: US
- channel: mass_retail
- payment_terms: 30–60 days OA
- key_buyers: Walmart, Target, Home Depot, Lowe's, Wayfair, Amazon US
- compliance_standards: high — UL/ETL mandatory, FCC Part 15, CPSC (children's products), CA Prop 65
- tariff_sensitivity: very_high — actively shifting origin to escape Section 301
- origin_shift_risk: high — actively sourcing Vietnam, India, Mexico alternatives for CN categories

## Products Purchased
- Outdoor furniture (metal, wicker, teak)
- Decorative lighting (LED, battery-operated, string lights)
- Home décor (metal artware, ceramic, resin)
- Home textiles (cushions, throws, bedding)
- Seasonal / holiday décor
- Cookware and kitchenware
- Storage and organisation

## Compliance Requirements Imposed on Suppliers
- UL/ETL certification (mandatory for all electrical/lighting products)
- FCC Part 15 (wireless/electronic products)
- CPSC compliance (children's products — lead, phthalates, flammability)
- REACH (chemical substances — SVHCs, heavy metals)
- CA Prop 65 (California warning requirements)
- ASTM F1346 (furniture tipping), ASTM F963 (toys adjacent)
- Supplier Code of Conduct (ethics, labour, anti-bribery)

## Air8 Relevance
SELLS_TO signal for all major CN supplier combos — buyer-mix concentration monitoring via SMARTWALLET is critical as these accounts represent majority of CN hardgoods export revenue. Origin shift signals (Section 301 watch-list expansions, new exclusion expirations) trigger ARP conditional alerts for CN outdoor furniture and lighting suppliers.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-US-Mass-Retail|BuyerType — US Mass Retail]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-HG-001-china-outdoor-furniture|COMBO-HG-001 — CN Outdoor Furniture for Home Depot/Wayfair; declining under Section 301]] (weight: 0.50)
- [[COMBO-HG-002-china-brass-artware|COMBO-HG-002 — CN Metal Décor for Target/HomeGoods]] (weight: 0.40)
- [[COMBO-HG-004-china-decorative-lighting|COMBO-HG-004 — CN Lighting for Home Depot/Wayfair]] (weight: 0.40)
- [[COMBO-004-china-medium-woven|COMBO-004 — CN Woven Apparel for US Mass Retail; structural decline]] (weight: 0.80)
- [[COMBO-001-south-asian-small-knit|COMBO-001 — SA Knit Basics for Walmart/Target]] (weight: 0.50)

### Product Categories Purchased
- [[CAT-HG-02|CAT-HG-02 — Metal Artware & Décor]]
- [[CAT-HG-04|CAT-HG-04 — Outdoor Furniture]]
- [[CAT-HG-06|CAT-HG-06 — Decorative Lighting]]
- [[CAT-HG-01|CAT-HG-01 — Seasonal & Holiday Décor]]
- [[CAT-HG-03|CAT-HG-03 — Ceramic & Glass Artware]]
- [[CAT-HG-09|CAT-HG-09 — Storage & Organisation]]

### Regulation References
- [[REG-TARIFF]]
- [[REG-UFLPA]]
- [[REG-UL-1598]]
- [[REG-FCC-PART15]]
- [[REG-GPSR]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]] (conditional; CN origin watch)
- [[PROD-SMARTWALLET|PROD-SMARTWALLET — Smart Wallet Buyer-Mix Monitoring]] (critical for buyer-mix monitoring)
