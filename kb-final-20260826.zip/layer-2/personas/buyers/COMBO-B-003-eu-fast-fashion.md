---
type: persona
subtype: buyer
id: COMBO-B-003
layer: 2
name: EU Fast Fashion Brands
buyer_geo: EU
channel: fast_fashion
payment_days: "30–60 OA"
compliance_standards: high
tariff_sensitivity: low
origin_shift_risk: low
key_buyers: [Zara (Inditex), H&M, Primark, Mango, C&A]
---

# COMBO-B-003 — EU Fast Fashion Brands

## Identity
- id: COMBO-B-003
- buyer_geo: EU
- channel: fast_fashion
- payment_terms: 30–60 days OA
- key_buyers: Zara (Inditex), H&M, Primark, Mango, C&A
- compliance_standards: high — CSDDD, GOTS, Higg FEM, ZDHC MRSL; ESG compliance requirements escalating rapidly
- tariff_sensitivity: low — not directly tariff-exposed (EU-CN apparel duties lower); ESG compliance cost is the rising pressure
- origin_shift_risk: low — proximity and speed to market more important than tariff; nearshore (Turkey, Morocco) valued over distant alternatives

## Products Purchased
- Knit basics (T-shirts, polo, sweatshirts, underwear)
- Woven apparel (shirts, trousers, dresses)
- Denim (jeans, jackets, shorts)
- Home textiles (cushion covers, throws, basic bedding)

## Compliance Requirements Imposed on Suppliers
- CSDDD (EU Corporate Sustainability Due Diligence Directive — mandatory supply chain traceability)
- REACH (banned substances, SVHC list)
- OEKO-TEX Standard 100 (chemical safety for textiles)
- ZDHC MRSL (zero discharge of hazardous chemicals manufacturing restricted substances list)
- GOTS certification (for organic cotton product lines)
- Higg FEM (facility environmental module — water, energy, waste)
- EUDR (EU Deforestation Regulation — relevant for viscose/lyocell lines)
- Social audit (SMETA 4-pillar or equivalent)

## Air8 Relevance
Primary market for Turkey denim nearshore, Bangladesh knit, and Vietnam FDI knit suppliers. High OA usage (30–60 days) across large order volumes makes this the core ARP market. Escalating ESG compliance pressure creates demand for ESG-linked financing as suppliers invest in GOTS certification, Higg upgrades, and ZDHC compliance — PROD-ESG-FINANCING directly relevant.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-EU-Fast-Fashion|BuyerType — EU Fast Fashion]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-005-turkey-denim-specialist|COMBO-005 — Primary EU Fast Fashion Denim Supplier]] (weight: 0.95)
- [[COMBO-001-south-asian-small-knit|COMBO-001 — Bangladesh/SA Knit Basics for Primark/H&M]] (weight: 0.80)
- [[COMBO-002-bangladesh-bank-lc|COMBO-002 — BD RMG Core Fast Fashion Supply]] (weight: 0.80)
- [[COMBO-006-vietnam-fdi-knit|COMBO-006 — VN FDI Knit for EU Fast Fashion Diversification]] (weight: 0.70)
- [[COMBO-004-china-medium-woven|COMBO-004 — CN Woven; Stable for EU (Not Tariff-Hit vs US)]] (weight: 0.60)

### Product Categories Purchased
- [[CAT-AP-01|CAT-AP-01 — Knit Basics]]
- [[CAT-AP-02|CAT-AP-02 — Woven Apparel]]
- [[CAT-AP-03|CAT-AP-03 — Denim]]
- [[CAT-AP-04|CAT-AP-04 — Home Textiles]]

### Regulation References
- [[REG-REACH]]
- [[REG-CSDDD]]
- [[REG-UFLPA]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]]
- [[PROD-PAYGUARD|PROD-PAYGUARD — Payment Protection]]
- [[PROD-ESG-FINANCING|PROD-ESG-FINANCING — ESG-Linked Supply Chain Financing]]
