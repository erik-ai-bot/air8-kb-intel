---
type: persona
subtype: buyer
id: COMBO-B-007
layer: 2
name: EU Specialty / Independent Retailers
buyer_geo: EU
channel: specialty
payment_days: "30–60 OA"
compliance_standards: medium
tariff_sensitivity: low
origin_shift_risk: low
key_buyers: [Museum shops, gift boutiques, independent homewares stores, garden centres]
---

# COMBO-B-007 — EU Specialty / Independent Retailers

## Identity
- id: COMBO-B-007
- buyer_geo: EU
- channel: specialty
- payment_terms: 30–60 days OA
- key_buyers: Museum shops, gift boutiques, independent homewares stores, garden centres
- compliance_standards: medium — REACH and GPSR baseline compliance; EN 71 required for toy-adjacent items; smaller buyers often rely on supplier test reports rather than their own compliance programmes
- tariff_sensitivity: low — small order volumes; price sensitivity lower as niche products command margin
- origin_shift_risk: low — small volumes and personal supplier relationships make switching rare; buyers tend to be loyal to known suppliers

## Products Purchased
- Ceramic and resin artware (decorative figurines, vases, planters)
- Glass artware (hand-blown, decorative)
- Holiday and seasonal décor (Christmas, Easter, gift lines)
- Premium brass artware (artisan, handcrafted — museum and gallery gift shops)
- Candles and fragrance (scented, decorative)

## Compliance Requirements Imposed on Suppliers
- REACH (chemical substances — SVHC, heavy metals in ceramics and glazes)
- GPSR (EU General Product Safety Regulation — all consumer goods)
- CE marking (where applicable — electronic candles, illuminated décor)
- EN 71 (toy-adjacent items marketed near children — figures, plush, miniatures)
- Country of Origin labelling (EU consumer protection requirements)
- Test reports (typically accept supplier-provided third-party reports)

## Air8 Relevance
Residual buyer channel for artware suppliers; smaller order values and shorter OA terms mean lower ARP ticket size. However, specialty channel provides stable volume floor for CN and India artware suppliers during seasonal peaks. MINIARP product (smaller ticket, faster approval) most appropriate for this buyer channel.

## 🔗 Edges / Links

### Parent BuyerType
- [[BuyerType-EU-Specialty|BuyerType — EU Specialty & Independent]]

### Supplier Combos (SELLS_TO — suppliers selling to this buyer)
- [[COMBO-HG-002-china-brass-artware|COMBO-HG-002 — Artware for Specialty Retail]] (weight: 0.40)
- [[COMBO-HG-003-india-moradabad-brass-artware|COMBO-HG-003 — Artisan Brass for Specialty/Museum]] (weight: 0.60)

### Product Categories Purchased
- [[CAT-HG-02|CAT-HG-02 — Metal Artware & Décor]]
- [[CAT-HG-03|CAT-HG-03 — Ceramic & Glass Artware]]

### Regulation References
- [[REG-REACH]]
- [[REG-GPSR]]

### Air8 Products
- [[PROD-ARP|PROD-ARP — Accounts Receivable Purchase]]
- [[PROD-MINIARP|PROD-MINIARP — Mini ARP (Small Ticket)]]
