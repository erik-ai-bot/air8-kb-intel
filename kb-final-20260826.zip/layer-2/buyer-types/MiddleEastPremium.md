---
type: buyer-type
id: MiddleEastPremium
---
# BuyerType: Middle East Premium / Hospitality Buyers

## Profile
Middle East luxury retail, hospitality procurement, and project-based buyers. Key buyers include: UAE luxury retail (Dubai Mall brands, Mall of the Emirates), Saudi Vision 2030 hospitality projects, UAE resort procurement, Qatar luxury homewares, Jordan souvenir/premium. Characterized by: OA 30-60 days (first orders often LC), growing channel as EU/US mass retail declines, premium pricing, compliance standards vary by retailer, project-based ordering creates seasonality.

**GROWTH OPPORTUNITY:** Middle East is an offsetting channel for CN suppliers losing US mass retail under Section 301, and a growing premium channel for India artisan suppliers.

## Key Attributes
- payment_days: 30-60 days OA; LC for first orders
- concentration_risk: LOW-MEDIUM (project-based; multiple small buyers; no single buyer dominates)
- supplier_stickiness: MEDIUM (relationship-driven; quality matters; price secondary for luxury)
- compliance_standards: MEDIUM (varies by retailer; UAE has its own standards but EU/CE alignment common)
- tariff_sensitivity: LOW (Middle East buyers not subject to US/EU tariff dynamics)

## Related Suppliers
- [[../../personas/hardgoods/COMBO-HG-002-china-brass-artware]] (weight: 0.35) — CN brass artware for UAE luxury retail, Saudi home décor; growing channel
- [[../../personas/hardgoods/COMBO-HG-003-india-moradabad-brass-artware]] (weight: 0.50) — IN artisan brass for UAE luxury, religious/cultural decorative crossover; growing
- [[../../personas/hardgoods/COMBO-HG-004-china-decorative-lighting]] (weight: 0.30) — CN lighting for UAE hospitality procurement, chandeliers, premium pendant; growing
- [[../../personas/hardgoods/COMBO-HG-001-china-outdoor-furniture]] (weight: 0.40) — CN outdoor furniture for UAE resort projects, hospitality; growing

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — advance on confirmed Middle East buyer PO; OA terms typically 30-60 days
- [[../../../financing-products/PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C]] — LC-backed pre-shipment for first orders

## Compliance Exposure
- [[../../regulations/REG-REACH]] — REACH compliance for EU-origin materials in UAE-bound goods
- [[../../regulations/REG-CE-LVD-EMC]] — CE marking often required for electrical products in UAE
- [[../../regulations/REG-UL-1598]] — UL listing sometimes required for US-branded products sold in UAE
