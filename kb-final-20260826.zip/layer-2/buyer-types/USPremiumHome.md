---
type: buyer-type
id: USPremiumHome
---
# BuyerType: US Premium Home Retailers

## Profile
US premium home furnishings retailers selling design-led, higher-margin products. Key buyers include: Pottery Barn, Restoration Hardware, Williams-Sonoma, CB2, West Elm, Arhaus. Characterized by: moderate volume, higher unit prices, design co-development, OA 60-90 days, longer-term supplier relationships, compliance standards high but manageable.

**POSITIVE SIGNAL:** US premium home retailers are actively SHIFTING SOURCING FROM CN TO INDIA (Moradabad brass, India lighting) in 2026. This is a growth channel for India suppliers and a declining channel for CN.

## Key Attributes
- payment_days: 60-90 days OA
- concentration_risk: HIGH (premium suppliers often have 1-2 US premium buyers = 60-80% of revenue)
- supplier_stickiness: MEDIUM-HIGH (design differentiation, co-development; harder to replace than mass market)
- compliance_standards: HIGH (UL/ETL mandatory; stringent QC standards)
- tariff_sensitivity: MEDIUM (premium buyers absorb some; willing to pay for quality differentiation)

## Related Suppliers
- [[../../personas/hardgoods/COMBO-HG-003-india-moradabad-brass-artware]] (weight: 0.80) — IN artisan brass for Pottery Barn, Restoration Hardware, Williams-Sonoma, CB2; growing channel as CN declines
- [[../../personas/hardgoods/COMBO-HG-002-china-brass-artware]] (weight: 0.30) — CN brass artware for US premium; declining as buyers shift to India

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — primary advance vehicle for India suppliers; CONDITIONAL for CN suppliers
- [[../../../financing-products/PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C]] — pre-shipment for artisan production cycle

## Compliance Exposure
- [[../../regulations/REG-UL-1598]] — UL luminaire listing mandatory for US lighting
- [[../../regulations/REG-FCC-PART15]] — FCC Part 15 for smart/electronic products
- [[../../regulations/REG-REACH]] — REACH for products containing chemicals; EU-sourced materials in US-bound goods
- [[../../regulations/REG-TARIFF]] — Section 301 on CN-origin goods; BENEFIT for India as CN declines
