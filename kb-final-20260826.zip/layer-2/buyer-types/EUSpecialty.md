---
type: buyer-type
id: EUSpecialty
---
# BuyerType: EU Specialty / Independent Retailers

## Profile
European independent gift shops, homewares stores, museum shops, and specialty retailers. Characterized by: small order quantities, seasonal programs, higher unit prices, direct brand relationships, OA 30-60 days, flexible terms. Often the residual buyer channel when mass retail relationships are lost.

## Key Attributes
- payment_days: 30-60 days OA
- concentration_risk: LOW (many small buyers; no single buyer >10%)
- supplier_stickiness: LOW-MEDIUM (small buyers fold or switch; no formal contracts)
- compliance_standards: LOW-MEDIUM (retailer codes vary; generally less stringent than major retailers)
- tariff_sensitivity: MEDIUM (small buyers have limited ability to absorb tariffs)

## Related Suppliers
- [[../../personas/hardgoods/COMBO-HG-002-china-brass-artware]] (weight: 0.30) — CN brass artware for independent gift/homewares retailers; seasonal programs

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — advance on confirmed buyer PO
- [[../../../financing-products/PROD-MINIARP|PROD-MINIARP]] — for micro suppliers with small orders
