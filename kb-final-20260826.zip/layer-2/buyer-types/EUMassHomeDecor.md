---
type: buyer-type
id: EUMassHomeDecor
---
# BuyerType: EU Mass Home Décor Retailers

## Profile
European mass-market home décor retailers selling value-driven outdoor furniture, home accessories, and seasonal décor. Key buyers include: Leroy Merlin (France), JYSK (Denmark), TK Maxx, Flying Tiger Copenhagen, Maisons du Monde (mass range), Amazon EU. Characterized by: high volume, seasonal programs, OA 60-90 days, value-driven pricing, moderate compliance standards.

## Key Attributes
- payment_days: 60-90 days OA
- concentration_risk: MEDIUM (single buyer can be 40-60% of small supplier revenue)
- supplier_stickiness: MEDIUM (price + availability driven; private label suppliers more replaceable)
- compliance_standards: MEDIUM (EU safety regulations + retailer-specific codes)
- tariff_sensitivity: HIGH (buyers will shift origin to escape tariffs)

## Related Suppliers
- [[../../personas/hardgoods/COMBO-HG-001-china-outdoor-furniture]] (weight: 0.75) — CN outdoor furniture for Leroy Merlin, JYSK, TK Maxx
- [[../../personas/hardgoods/COMBO-HG-002-china-brass-artware]] (weight: 0.75) — CN brass artware for TK Maxx, Maisons du Monde, Flying Tiger
- [[../../personas/hardgoods/COMBO-HG-003-india-moradabad-brass-artware]] (weight: 0.30) — IN artisan brass for premium range only; mass volume rare

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — primary advance vehicle
- [[../../../financing-products/PROD-PRESHIP-RT2C|PROD-PRESHIP-RT2C]] — seasonal pre-shipment

## Compliance Exposure
- [[../../regulations/REG-REACH]] — surface coatings, metal treatments
- [[../../regulations/REG-TARIFF]] — Section 301 on CN-origin goods
- [[../../compliance/FSC-CoC]] — FSC Chain of Custody for timber components (John Lewis, Garden Trading require this)
- [[../../compliance/EUTR]] — EU Timber Regulation legal requirement for timber
