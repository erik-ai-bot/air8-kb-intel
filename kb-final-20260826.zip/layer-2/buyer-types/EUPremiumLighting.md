---
type: buyer-type
id: EUPremiumLighting
---
# BuyerType: EU Premium Lighting Retailers

## Profile
European design-led lighting retailers and distributors selling premium decorative luminaires. Key buyers include: BHS (UK), Nordlux (Denmark), Eglo (Austria), DC的目的 (France), Lighting Style, Rowico (Sweden). Characterized by: CE marking mandatory, design differentiation, moderate volumes, OA 60-90 days, supplier relationships built on design capability and quality.

## Key Attributes
- payment_days: 60-90 days OA
- concentration_risk: MEDIUM (design-led suppliers have 3-5 key buyers)
- supplier_stickiness: MEDIUM-HIGH (design co-development creates switching costs)
- compliance_standards: HIGH (CE mandatory; EN standards testing per SKU)
- tariff_sensitivity: MEDIUM (premium buyers absorb some; EU manufacturing base limits tariff arbitrage)

## Related Suppliers
- [[../../personas/hardgoods/COMBO-HG-004-china-decorative-lighting]] (weight: 0.55) — CN decorative lighting for BHS, Nordlux, Eglo (CE-marked, design-led)

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — primary advance vehicle
- [[../../../financing-products/PROD-SMARTWALLET|PROD-SMARTWALLET]] — buyer mix monitoring

## Compliance Exposure
- [[../../regulations/REG-CE-LVD-EMC]] — CE marking mandatory for all EU electrical lighting
- [[../../regulations/REG-REACH]] — chemical restrictions on metal finishes, coatings
- [[../../regulations/REG-CSDDD]] — CSDDD from 2026+ for large EU buyers
