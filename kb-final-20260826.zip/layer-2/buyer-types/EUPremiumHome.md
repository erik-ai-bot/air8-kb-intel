---
type: buyer-type
id: EUPremiumHome
---
# BuyerType: EU Premium Home Retailers

## Profile
European premium home furnishings retailers selling design-led, higher-margin products. Key buyers include: John Lewis (UK), Williams-Sonoma (EU), Crate & Barrel (EU), Zara Home, H&M Home (premium range), Garden Trading (UK outdoor). Characterized by: moderate volume, higher unit prices, design co-development, compliance standards, OA 60-90 days, longer-term supplier relationships.

## Key Attributes
- payment_days: 60-90 days OA
- concentration_risk: MEDIUM-HIGH (premium suppliers often have 2-4 premium buyers)
- supplier_stickiness: MEDIUM-HIGH (design differentiation, co-development relationship)
- compliance_standards: HIGH (EU regulations + retailer codes; FSC, REACH strict)
- tariff_sensitivity: LOW-MEDIUM (buyers absorb some; premium positioning allows price pass-through)

## Related Suppliers
- [[../../personas/hardgoods/COMBO-HG-003-india-moradabad-brass-artware]] (weight: 0.65) — IN artisan brass for Williams-Sonoma, Restoration Hardware, CB2
- [[../../personas/hardgoods/COMBO-HG-001-china-outdoor-furniture]] (weight: 0.35) — CN outdoor furniture for John Lewis, Garden Trading (FSC required)

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — primary advance vehicle
- [[../../../financing-products/PROD-SMARTWALLET|PROD-SMARTWALLET]] — multi-buyer visibility

## Compliance Exposure
- [[../../regulations/REG-REACH]] — strict REACH compliance for premium EU market
- [[../../regulations/REG-CSDDD]] — CSDDD from 2026+ for large EU buyers
- [[../../compliance/FSC-CoC]] — FSC Chain of Custody mandatory for timber
