---
type: buyer-type
id: USMassRetail
---
# BuyerType: US Mass Market Retailers

## Profile
US mass-market retailers and e-commerce platforms selling value-driven products. Key buyers include: Home Depot, Wayfair, Target, Lowe's, Walmart, Amazon US. Characterized by: high volume, OA 30-60 days, UL/ETL listing mandatory, aggressive pricing, private label focus, tariff pass-through pressure, declining CN share as buyers diversify origin.

**⚠️ CRITICAL:** US mass retail is actively reducing CN sourcing in 2026 due to Section 301 tariffs. Suppliers with >35% US mass retail revenue face structural decline risk.

## Key Attributes
- payment_days: 30-60 days OA
- concentration_risk: MEDIUM-HIGH (single US mass retail buyer can dominate small supplier revenue)
- supplier_stickiness: LOW (buyers switch origins easily; no long-term contracts)
- compliance_standards: HIGH (UL/ETL mandatory; FCC for electronics; CPSC regulations)
- tariff_sensitivity: VERY HIGH (buyers aggressively shift origin to escape tariffs)

## Related Suppliers
- [[../../personas/hardgoods/COMBO-HG-001-china-outdoor-furniture]] (weight: 0.50) — CN outdoor furniture for Home Depot, Wayfair; declining under Section 301
- [[../../personas/hardgoods/COMBO-HG-002-china-brass-artware]] (weight: 0.40) — CN brass artware for Target, HomeGoods; declining
- [[../../personas/hardgoods/COMBO-HG-004-china-decorative-lighting]] (weight: 0.40) — CN lighting for Home Depot, Wayfair, Target; declining
- [[../../personas/COMBO-004-china-medium-woven]] (weight: 0.80) — CN woven for US mass retail; structural decline

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — CONDITIONAL; only on confirmed book; watch for origin shift signals
- [[../../../financing-products/PROD-SMARTWALLET|PROD-SMARTWALLET]] — critical for buyer mix monitoring; detect origin shift early

## Compliance Exposure
- [[../../regulations/REG-UL-1598]] — UL luminaire listing mandatory for US lighting
- [[../../regulations/REG-FCC-PART15]] — FCC Part 15 for smart/electronic products
- [[../../regulations/REG-TARIFF]] — Section 301 tariffs on CN-origin goods; key driver of origin shift
- [[../../regulations/REG-UFLPA]] — cotton traceability for US-bound apparel/home textiles
