---
type: buyer-type
id: EUFastFashion
---
# BuyerType: EU Fast Fashion Brands

## Profile
European fast fashion brands sourcing garments from South and Southeast Asia. Key buyers include Zara (Inditex), H&M, Primark, Mango, C&A. Characterized by: high volume, short lead times, aggressive pricing, frequent style changes, OA payment terms 30-60 days, supply chain speed as competitive advantage.

## Key Attributes
- payment_days: 30-60 days OA
- concentration_risk: LOW-MEDIUM (buyer has many suppliers)
- supplier_stickiness: LOW (buyer switches easily based on price)
- compliance_standards: HIGH (EU due diligence laws, CSDDD 2026+)
- tariff_sensitivity: MEDIUM-HIGH (buyers absorb some tariff but push back on price)

## Related Suppliers
- [[../../personas/COMBO-001-south-asian-small-knit]] (weight: 0.90) — South Asian knit for Zara, H&M, Primark
- [[../../personas/COMBO-004-china-medium-woven]] (weight: 0.90) — CN woven for Zara, H&M fast fashion
- [[../../personas/COMBO-006-vietnam-fdi-knit]] (weight: 0.50) — Vietnam knit for fast fashion diversification

## Financed By
- [[../../../financing-products/PROD-ARP|PROD-ARP]] — advance on confirmed fast fashion buyer PO
- [[../../../financing-products/PROD-SMARTWALLET|PROD-SMARTWALLET]] — multi-buyer visibility

## Compliance Exposure
- [[../../regulations/REG-CSDDD]] — EU CSDDD mandatory from 2026 for large buyers; cascade down to suppliers
- [[../../regulations/REG-UFLPA]] — US-bound orders require cotton traceability
- [[../../regulations/REG-REACH]] — chemical restrictions on dyes and finishes
