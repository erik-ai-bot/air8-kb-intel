# Persona Auto-Synthesis Protocol

> Version: 1.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> Ported from air8-kb-v2/_reasoning/persona-synthesis.md — 2026-07-16
> Use when S2 Round 1 cannot match a supplier to an existing COMBO instance with confidence ≥ 0.7.
> Referenced from: S2-supplier-pain-bd.md (Step R1-1 fallback)

---

## Confidence Types — Explicit Distinction

```yaml
neighbor_similarity_score:
  definition: "Tag overlap score between client tags and a known combo's tags"
  range: 0.0-1.0
  purpose: "Determines whether synthesis is needed (score < 0.7 triggers synthesis)"
  example: "COMBO-006 neighbor_similarity_score = 0.65 means 65% tag overlap with client"

synthesized_field_confidence:
  definition: "Per-field quality confidence of the composed synthetic combo"
  range: 0.0-1.0
  purpose: "Flags which fields need S2 R1 verification before trusting"
  example: "identity field confidence = 0.85 means we're 85% confident this field is correct"

IMPORTANT: These are independent. A client with low neighbor_similarity_score (triggers synthesis)
can still produce high synthesized_field_confidence on specific fields where inheritance is clear.
Never conflate or compare these two numbers.
```

---

## When to Trigger Synthesis

Trigger persona synthesis when:
1. S2 Step R1-1 archetype match confidence < 0.7, OR
2. Supplier profile doesn't fit any existing COMBO instance (novel country/product/model combination), OR
3. Supplier explicitly describes a hybrid model (e.g., CMT for some buyers, FOB for others)

**Do NOT synthesise** if a direct COMBO match exists at confidence ≥ 0.7. Use the matched instance directly.

---

## Step 1 — Nearest Neighbor Identification

**Action:** Score all existing COMBO instances for overlap with the supplier's available tags.

**Scoring criteria (tag overlap):**
- country match: +3 points
- material match: +2 points
- company_type match: +3 points
- buyer_geo match: +2 points
- revenue_band match: +1 point

**Threshold:**
- Top-scoring neighbor: score must be ≥ 4 to be considered a neighbor
- Score < 4 on ALL instances → insufficient basis for synthesis; issue MONITOR signal; request more data

**Output:** Top-3 neighbors by overlap score + their scores

---

## Step 2 — Axis Inheritance

**Action:** For each assessment dimension relevant to this supplier, determine which neighbor is most representative.

**Per-dimension inheritance rule:**
- **Material dimension** → inherit from neighbor with matching material (country takes lower priority)
- **Country dimension** → inherit from neighbor with matching country (even if material differs)
- **Business model dimension** → inherit from archetype (CMT/FOB/Vertical) regardless of country
- **Buyer dimension** → inherit from neighbor with matching buyer_geo

---

## Step 3 — Synthesise Draft Instance

**Action:** Compose a synthesised COMBO draft using inherited axes and applying country-specific adjustments from layer-2-entities/countries/ files.

**Draft format:**
```yaml
id: SYNTH-[COUNTRY]-[TYPE]-[seq]
status: synthesised_draft
synthesis_basis: [COMBO-003 (0.4), COMBO-014 (0.35), COMBO-004 (0.25)]
country: [country]
material: [material]
company_type: [CMT|FOB|Vertical]
buyer_geo: [geo]

structural_nuances:
  - [inherited from source COMBO — label with source and confidence]
  - field_confidence: 0.85 | source: COMBO-003

assessment_dimensions:
  - dim: [name]
    inherited_from: [COMBO-XXX]
    confidence: 0.75
    note: "[why this inheritance is appropriate]"
```

**Per-field confidence:**
- Country match + material match: 0.90
- Country match only: 0.75
- Material match only: 0.70
- Archetype match only: 0.65
- No direct match (interpolated): 0.50

---

## Step 4 — Confidence Flags

Any synthesised field with confidence < 0.7 MUST appear in the S2 R1 qualifying questions to be verified with the client.

**Confidence flag format:**
```
⚠️ UNVERIFIED (confidence 0.65): buyer_nominated_pct inherited from CMT-LowMargin archetype.
   → R1 question required: "What % of your fabric/yarn is buyer-nominated vs own-sourced?"
```

---

## Step 5 — Learning from Verification

When R1 answers are received (S2 transitions to Round 2), update the synthesised draft:
- Confirmed value matches synthesised value (within 20%): promote confidence to 0.95
- Confirmed value diverges significantly: update value, flag for KB review
- After R3 completion: synthesised instance can be promoted to `draft_instance` for expert review

---

## Step 6 — Archetype Evolution

**Trigger:** 3+ synthetic combos share common axis-inheritance pattern (same country + company_type + buyer_geo)

```yaml
action_propose_new_archetype:
  when: "shared pattern represents a structurally distinct business model"
  output: "Draft new archetype with inherited axes from common pattern"
  route: "expert_review queue → Jerri + Alice sign-off"

action_propose_spanning_combo:
  when: "shared pattern is a geographic variant of existing archetype"
  output: "New COMBO instance extending existing archetype with country-specific overrides"
  route: "KB curator adds instance; no archetype change needed"

quarterly_review:
  action: "Review synthesis log for recurring patterns"
  threshold: "3+ synthetics in same quarter sharing pattern → trigger proposal"
  reviewer: "Jerri + Alice"
```

---

## Integration Notes

- **scenarios/S2-supplier-pain-bd.md** Step R1-1: "If archetype match confidence < 0.7 → trigger persona-synthesis protocol before proceeding"
- **PRIMITIVES.md**: If synthesis confidence is LOW across ALL dimensions → apply RP-INFORMATION-DEFICIT before emitting R1 card
- Synthesised drafts must conform to Persona Instance Node schema with `status: synthesised_draft` field added

## Related

- [PERSONA-PRINCIPLES.md](../principles/PERSONA-PRINCIPLES.md) — Persona synthesis reasoning principles
- [PRIMITIVES.md](../taxonomy/PRIMITIVES.md) — RP-INFORMATION-DEFICIT applied before emitting persona synthesis card
- [L1-reasoning-principles.md](../principles/L1-reasoning-principles.md) — Reasoning quality standards for synthesis
