# Decision log — where it lives now

`L1-decision-log.md` (copied unchanged) remains the human narrative: why each change happened.

**What changed in v2:** the *what and when* of every change is now carried by the rule nodes themselves — `valid_from` / `valid_to` on Band, TierRule, GateRule, CapRule. The log no longer needs to restate values; a log entry is one line of *why* plus the IDs of the nodes closed and opened, e.g.:

> 2026-09 · activity cut moved · Trigger A refit on Q3 FR export (gap peak moved, n=24) · closed `band:apparel-v1.1/activity/1`, opened `band:apparel-v1.2/activity/1`

Note the version bump: a threshold change is a new framework version (`fw:apparel-v1.2`), because verdicts cite the version that produced them. Cheap in the graph — new nodes, old ones keep `valid_to`.

## Related

- [L1-decision-log.md](L1-decision-log.md) — Machine-readable decision log this note refers to
- [L1-scoring-method.md](../methods/L1-scoring-method.md) — Version bump protocol for framework changes
- [NODE-scoring-framework.md](../../layer-2/frameworks/NODE-scoring-framework.md) — Where valid_from/valid_to live on rule nodes
