---
type: reasoning
id: SOLUTIONS
---

# Air8 Solution Playbooks — Layer 1

This file maps event types to financing product recommendations, organized by:
- Triggered event → matched persona archetypes → recommended Air8 product
- Rationale (linked to pain points)
- Urgency / timing
- Contraindications (what NOT to recommend)

All product names reference `layer-2-entities/financing-products/PROD-*.md`.
Pain point links reference `layer-1-reasoning/pain-points/`.
Persona–product fit sourced from `linkage/linkage-persona-full.md` and `linkage/linkage-product-reverse.md`.

---

## Playbook 1: EVT-TARIFF — Tariff / Duty Change

### Primary Pain Points Activated
- **PP-002** (financing cost increase — margins squeezed by duty increase)
- **PP-001** (cashflow gap — buyers may delay PO while tariff situation resolves)
- **PP-003** (buyer concentration — single buyer absorbing tariff shock = higher credit risk)

### Matched Personas → Product Recommendations

#### COMBO-004 (China Medium Woven) — EVT-TARIFF Section 301
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP (Hengqin)** | Offshore factoring preserves cashflow despite US buyer PO slowdown; Hengqin structure reduces cross-border restriction risk | HIGH — immediate |
| **SmartWallet** | Multi-buyer visibility helps identify which buyers are pausing POs vs. staying active | MEDIUM |
| **Pool Factoring** | If revenue >$20M + 5+ buyers, Pool offers better pricing than individual ARP in a squeezed-margin environment | MEDIUM |

**Contraindications:** Do NOT recommend PreShip-OBF (Section 301 creates buyer uncertainty — pre-shipment advance before confirmed PO is too risky). Do NOT recommend ESG Finance (not triggered by tariff event).

---

#### COMBO-014 (India Small Woven) — EVT-TARIFF (India 50% tariff)
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | Core cashflow bridge; India small woven suppliers have thin margins — T+1 disbursement is critical | HIGH |
| **RT2C** | Pre-shipment advance if supplier has existing ARP ≥6 months — helps fund fabric procurement when tariff creates buyer hesitation | MEDIUM |

**Contraindications:** Do NOT recommend Pool (revenue too small — $5-20M); Do NOT recommend ESG Finance.

---

#### COMBO-005 (Turkey Denim Specialist) — EVT-TARIFF (EU duty change or GSP)
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP (USD-denominated)** | USD invoicing protects against TRY depreciation compound effect on top of tariff squeeze | HIGH |
| **Pool Factoring** | Turkish denim exporters typically have multiple EU buyers — Pool pricing advantage at margin | MEDIUM |

---

#### COMBO-001, 002, 009 (South Asian Knit/BD/PK Home Textile) — EVT-TARIFF GSP/EBA graduation
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | GSP graduation causes buyer PO review period → cashflow gap bridged by ARP | HIGH |
| **RT2C** | Pre-shipment advance supports production continuation during buyer negotiation period | MEDIUM |
| **PayGuard** | GSP graduation sometimes causes buyer distress signals — PayGuard protects against buyer default | MEDIUM |

---

### Universal Tariff Playbook Rules
1. **Check buyer health first** — tariff events often cause buyer distress. If adverse_news = CRITICAL → ARP not available → lead with PayGuard conversation.
2. **Never recommend PreShip-OBF** for new tariff events — pre-shipment advance requires confirmed buyer PO, which tariff uncertainty disrupts.
3. **Timing:** ARP conversations should happen within 30 days of tariff announcement, before suppliers panic-discount to retain buyer POs.

---

## Playbook 2: EVT-REGULATION — Regulatory Compliance Event

### Primary Pain Points Activated
- **PP-REG-UFLPA-001** (UFLPA detention / traceability burden)
- **PP-REG-REACH-001** (chemical compliance re-testing cost)
- **PP-REG-CSDDD-001** (EU due diligence audit burden)
- **PP-002** (financing cost — compliance cost eats margin)

### Matched Personas → Product Recommendations

#### COMBO-004 (China Medium Woven) — EVT-REGULATION UFLPA Entity List add
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP (Hengqin)** | If supplier's buyer still wants to source from CN — offshore factoring structure helps separate risk | HIGH |
| **SmartWallet** | Multi-buyer visibility allows rapid identification of which buyers are pausing orders | MEDIUM |

**Note:** If supplier itself is added to UFLPA Entity List → ARP is NOT available. Lead with compliance advisory, not product.

---

#### COMBO-005 (Turkey Denim) — EVT-REGULATION REACH SVHC update
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | REACH re-testing creates 2-4 week shipment delay → cashflow gap → ARP bridges the gap | MEDIUM-HIGH |
| **Pool** | Multiple EU buyers means REACH compliance affects entire portfolio — Pool smooths revenue volatility | MEDIUM |

---

#### COMBO-003, 008 (India Large / India Organic) — EVT-REGULATION CSDDD scope expansion
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ESG Financing** | CSDDD compliance costs are substantial (audit + legal + reporting system) — ESG Finance offsets if IFC criteria met | HIGH |
| **ARP** | Core cashflow product; CSDDD audit period creates buyer payment review pause | HIGH |
| **OBF (PreShip)** | Large vertical integrators have massive pre-shipment needs — OBF frees capital for compliance investment | MEDIUM |

---

### Universal Regulation Playbook Rules
1. **Distinguish advice from product** — regulatory compliance advice first, product second. Suppliers need to understand the regulation before they need financing for it.
2. **PreShip is safe for EVT-REGULATION** (unlike tariff) — compliance timelines are known, so buyer POs are still confirmed.
3. **ESG Finance is exclusively triggered** by ESG-related regulatory events — not by import/duty regulations.

---

## Playbook 3: EVT-CURRENCY — FX / Currency Event

### Primary Pain Points Activated
- **PP-001** (cashflow gap — local currency depreciation inflates input costs in USD terms)
- **PP-002** (financing cost — FX adds unpredictability to cost of carry)
- **PP-CN/PK/BD-FX-001** (country-specific FX access restrictions)

### Matched Personas → Product Recommendations

#### COMBO-005 (Turkey Denim) — EVT-CURRENCY TRY devaluation
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP (USD-denominated)** | USD invoicing through Air8 provides natural FX hedge — supplier receives USD, not TRY-converted receivables | HIGH — immediate |
| **Pool** | Portfolio of EU/US buyers diversifies FX exposure across multiple receivable maturities | MEDIUM |

---

#### COMBO-009 (Pakistan Home Textile) — EVT-CURRENCY PKR devaluation
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | PKR depreciation inflates yarn input costs — ARP accelerates USD receivable collection to fund next procurement cycle | HIGH |
| **Pool** | PK home textile exporters often have multiple buyers — Pool pricing advantage | MEDIUM |

---

#### COMBO-001, 002 (South Asian Knit / BD) — EVT-CURRENCY BDT/INR volatility
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | Core liquidity bridge; USD-denominated disbursement protects against local depreciation | HIGH |
| **RT2C** | Pre-shipment advance in USD reduces local currency input cost burden | MEDIUM |

---

### Universal Currency Playbook Rules
1. **USD disbursement is the key pitch** — Air8 ARP always disburses in USD (T+1). This is the natural FX hedge for any supplier invoicing in USD.
2. **Timing is urgent** — FX events are fast-moving; BD conversations should happen within 1–2 weeks of major currency event.
3. **Check central bank restrictions** — Bangladesh Bank, Pakistan SBP, and China SAFE all have USD transfer restrictions. Hengqin structure or special documentation may be needed.

---

## Playbook 4: EVT-ESG-CERT — ESG Certification Event

### Primary Pain Points Activated
- **PP-ESG-001** (ESG certification cost and audit burden)
- **PP-002** (financing cost — cert fees eat margin)
- **PP-EXPAND-002** (ESG compliance as market access prerequisite)

### Matched Personas → Product Recommendations

#### COMBO-003 (India Large Vertical Integrator) — Buyer mandates GOTS
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ESG Financing** | If IFC criteria met (GOTS + FAIRTRADE + ≥3 certs) — ESG Finance directly funds certification infrastructure | HIGH |
| **ARP** | Core cashflow product regardless; GOTS certification timeline (2-4 weeks) creates buyer PO review pause | HIGH |
| **OBF (PreShip)** | Large vertical integrators' pre-shipment needs are amplified by organic cotton procurement | MEDIUM |
| **SmartWallet** | Multi-buyer setup to track which buyers require which cert levels | MEDIUM |

---

#### COMBO-008 (India Organic Cotton Medium) — Buyer mandates GOTS + IFC achievable
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ESG Financing** | UFLPA advantage (organic = inherent traceability) + GOTS = IFC criteria likely met | HIGH |
| **ARP / RT2C** | Core cashflow bridge; organic lead times are longer (90-120d + 2-4w organic cotton sourcing) | HIGH |

---

#### All COMBO with EU buyers — EVT-ESG-CERT buyer mandate for HIGG / ZDHC
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | Certification period creates buyer payment review → cashflow gap | MEDIUM |

**Contraindications:** Do NOT recommend ESG Finance unless ≥3 certs are held. Single-cert compliance does not meet IFC threshold.

---

### Universal ESG Playbook Rules
1. **ESG Finance has strict eligibility** — ≥3 ESG certs, IFC Performance Standards criteria met. Qualify before pitching.
2. **Organic suppliers are the ESG Finance primary target** — GOTS + FAIRTRADE + UFLPA advantage = near-automatic IFC eligibility.
3. **ESG events are relationship moments** — supplier achieving a new cert is a upsell trigger, not a risk flag.

---

## Playbook 5: EVT-MARKET-SHIFT — Buyer Sourcing Shift

### Primary Pain Points Activated
- **PP-003** (buyer concentration — losing a buyer is catastrophic if >30% revenue)
- **PP-004** (scalability constraint — new buyer requires rapid capacity scale-up)
- **PP-001** (cashflow gap — transition period between losing old buyer and onboarding new buyer)

### Matched Personas → Product Recommendations

#### COMBO-004 (China Medium Woven) — Buyer shifts POs to Vietnam
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **SmartWallet** | Multi-buyer management helps maximize wallet share with remaining buyers while buyer relationship is in flux | HIGH |
| **ARP** | Cashflow continuity during PO transition period | HIGH |
| **Pool** | If supplier retains 5+ buyers — Pool manages diversified portfolio through the shift | MEDIUM |

---

#### COMBO-006 (Vietnam FDI Knit) — Vietnam receives diverted POs
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP (parent pitch)** | Vietnamese FDI subsidiaries often need proof of Air8 relationship for parent company approval | HIGH |
| **PayGuard** | Rapid new buyer onboarding — new buyers carry higher payment risk | MEDIUM |

---

#### COMBO-001, 014 (South Asian) — Gaining POs diverted from China
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | New buyer onboarding → new financing line needed immediately | HIGH |
| **RT2C** | Pre-shipment advance for ramp-up production on new buyer POs | MEDIUM |
| **PayGuard** | New buyer = higher payment uncertainty | MEDIUM |

---

### Universal Market Shift Playbook Rules
1. **Market shifts create two types of opportunities:** (a) suppliers losing POs → defensive ARP + PayGuard; (b) suppliers gaining POs → offensive ARP + RT2C for capacity ramp.
2. **Timing matters:** Engage suppliers gaining POs within 60 days of buyer announcement — before competitor financing locks in the relationship.
3. **COMBO-006 (Vietnam FDI)** is unique — parent company must approve Air8 engagement. Lead with parent pitch, not supplier pitch.

---

## Playbook 6: EVT-SUPPLY-DISRUPTION — Supply Disruption

### Primary Pain Points Activated
- **PP-BD-002 / PP-PK-001** (country-specific production disruption)
- **PP-001** (cashflow gap — factory shutdown stops invoicing)
- **PP-003** (buyer concentration — buyers shift POs during disruption → revenue concentration risk)
- **PP-004** (scalability — surviving suppliers face sudden demand surge)

### Matched Personas → Product Recommendations

#### COMBO-002 (Bangladesh Bank LC) — Political crisis disruption
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | Factory shutdown delays invoice creation → ARP bridges the gap once production resumes | HIGH |
| **RT2C** | Pre-shipment advance enables production restart after disruption | HIGH |
| **PayGuard** | Political disruption often triggers buyer adverse_news signals — PayGuard protects receivables | MEDIUM |

---

#### COMBO-001 (South Asian Small Knit, not BD) — Gaining POs diverted from disrupted BD
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | Immediate new buyer POs → immediate ARP line needed | HIGH |
| **RT2C** | Pre-shipment advance for rapid capacity ramp | MEDIUM |

---

#### COMBO-009 (Pakistan Home Textile) — Energy crisis disruption
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP** | 8-hr load shedding → production delays → invoice delays → ARP bridges timing gap | HIGH |
| **Pool** | PK home textile typically has multiple buyers — Pool pricing advantage under stress | MEDIUM |

---

#### COMBO-013 (Multi-Country Group) — Logistics disruption (Red Sea)
| Product | Why it Fits | Urgency |
|---------|-------------|---------|
| **ARP (multi)** | 14-day extra transit time extends cash cycle by 14 days — ARP absorbs this extension | HIGH |
| **DDP Financing** | If any entities in group are on DDP/DDU terms — DDP Financing alleviates landed cost pressure | MEDIUM |
| **Pool / SmartWallet** | Multi-buyer management across group entities becomes critical during disruption | MEDIUM |

---

### Universal Supply Disruption Playbook Rules
1. **Disruption creates two distinct client pools:** disrupted suppliers (need liquidity bridge) and beneficiary suppliers (need capacity ramp financing). Engage both.
2. **OTD degradation is a lagging indicator** — if OTD drops below 90%, ARP eligibility for that facility may be at risk. Monitor scorecard before pitching.
3. **Logistics disruptions (Red Sea) affect ALL personas** — not just the disrupted country. Any supplier with extended transit time has an extended cash cycle that ARP can address.
4. **MiniARP** is the right product for very small disrupted suppliers (COMBO-007, 012, 015) who don't meet full ARP thresholds.

## Related

- [PRODUCT-PRINCIPLES.md](../principles/PRODUCT-PRINCIPLES.md) — Product selection logic and wallet share analysis
- [PRINCIPLES.md](../principles/PRINCIPLES.md) — Supply disruption reasoning principles
- [cliff-playbook.md](../playbooks/cliff-playbook.md) — Cliff playbook for disruption time-window management
- [PROD-ARP.md](../../layer-2/products/PROD-ARP.md) — ARP as primary disruption financing solution
- [PROD-MINIARP.md](../../layer-2/products/PROD-MINIARP.md) — MiniARP for small suppliers in disruption
