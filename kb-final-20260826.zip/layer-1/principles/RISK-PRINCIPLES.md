# L0 Risk Principles — Reasoning Frames

> Module: Risk | Count: 6 | Updated: 2026-07-01
> Ported from air8-kb-v2/L0-principles/risk-principles.md — 2026-07-16
> These are portfolio-level risk management frames applied alongside every S1 and S4 run.

---

## RP-RISK-CONC-01: Commodity Event → Concentration Exposure Check
**When applies:** event_type:Commodity
**Must consider:**
- Air8 book exposure to single commodity as % of total portfolio
- Alert threshold: single commodity > 30% of portfolio → alert
- Even when individual combo signal is EXPAND: max incremental lift is +20% without credit committee approval
- State this constraint explicitly in every S1 card action items — BD must not promise more
- After alert: any new positions must be offset by proportional reduction elsewhere
**LLM directive template:** N/A (this is internal portfolio data — credit team applies directly)
**Freshness:** stable

---

## RP-RISK-COUNTRY-01: Geopolitical or Policy Event → Country Concentration
**When applies:** event_type:Geopolitical OR event_type:Regulation/trade_agreement OR event_type:Buyer/sourcing_strategy_shift
**Must consider:**
- Air8 book exposure to affected source country as % of portfolio
- Country cap thresholds (internal risk policy)
- Contagion risk: disruption in one source country may benefit another (order diversion = surge exposure to second country)
- Disruption in one source country may also hurt another if they share upstream sourcing (e.g., BD depends on IN cotton → IN disruption hits BD factories too)
- Watch for second-order: does Air8 BENEFIT country exposure surge past cap while we focus on the hurt country?
**LLM directive template:** N/A (internal portfolio data — cross-reference with risk team)
**Freshness:** stable

---

## RP-RISK-POSTCLIFF-01: Cliff Event → Post-Cliff WC Stress Test
**When applies:** trigger.effective_window.has_cliff = true
**Must consider:**
- Factories that over-stockpile during the pre-cliff window face elevated WC needs in the quarter after cliff
- Air8 receivables book: are existing positions expiring before cliff? If not → risk rises
- New positions: ensure they do not mature into the post-cliff stress period
- Set cliff monitoring alert 30 days before cliff expiry for all active positions
- Over-commitment signal: if supplier procurement pace is 3-5x normal → flag for credit review
**LLM directive template:** N/A (this is portfolio monitoring logic — apply internally)
**Freshness:** stable

---

## RP-RISK-BUYER-ANCHOR-01: Buyer Anchor Deterioration → Facility Trigger Review
**When applies:** event_type:Financial/buyer_credit_event OR event_type:Buyer/ma_ownership OR buyer DSO deteriorating
**Must consider:**
- PreShip-OBF eligibility requires confirmed buyer PO anchor from investment-grade buyer
- If buyer anchor deteriorates → all PSF positions with that buyer require immediate credit review
- ARP positions: if buyer goes below minimum rating threshold → advance ratio reduction mandatory
- Portfolio exposure to single buyer type (fast fashion vs mass market vs DTC) — check concentration
- Replacement: can supplier switch to alternative buyer anchor within 30 days?
**LLM directive template:** "For [buyer] credit event: (1) Which Air8 positions have this buyer as receivable debtor or PSF anchor? (2) What is the aggregate exposure? (3) What is the timeline for any buyer payment disruption to hit Air8 positions?"
**Freshness:** stable

---

## RP-RISK-TRADER-01: Trader or Agent Detected → Third-Party Payment Check
**When applies:** client type = trader or sourcing agent (no factory assets)
**Must consider:**
- Third-party payment prohibition (OPS-KYC-002): Air8 cannot pay into accounts of unrelated third parties
- Trader-specific product: Back-to-Back / Trader TCS with recourse only
- Must verify and document the ultimate manufacturer before any disbursement
- Traders have no fixed assets as collateral → risk profile is fundamentally different from factory
- KYC requirement: document both the trader entity AND the ultimate manufacturing entity
**LLM directive template:** N/A (this is a compliance gate — apply before proceeding)
**Freshness:** stable

---

## RP-RISK-SIGNAL-DECAY-01: Active Event Cache → Signal Freshness Management
**When applies:** S4 Portfolio Monitoring runs and any reuse of S1 cache in S2
**Must consider:**
- All cached events have an expiry (cliff date or default TTL per event type)
- TTL defaults: Regulation=90d, Financial/FX=30d, Commodity=60d, Geopolitical=45d
- Expired events must be removed before running S4 — stale signals corrupt portfolio analysis
- A "Why Now" hook from an expired event is worse than no hook (damages BD credibility)
- Re-run S1 if the original event has evolved significantly (magnitude change, new cliff date announced)
**LLM directive template:** N/A (cache management logic — apply at S4 runtime)
**Freshness:** stable

## Related

- [EVENT-PRINCIPLES.md](EVENT-PRINCIPLES.md) — Event expiry and TTL logic shared with event reasoning
- [cliff-playbook.md](../playbooks/cliff-playbook.md) — Cliff event time-window management
- [NODE-risk-categories.md](../../layer-2/nodes/NODE-risk-categories.md) — Risk category taxonomy
