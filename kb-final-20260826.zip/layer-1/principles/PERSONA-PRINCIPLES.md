# L0 Persona Principles — Reasoning Frames

> Module: Persona | Count: 7 | Updated: 2026-07-01
> Ported from air8-kb-v2/L0-principles/persona-principles.md — 2026-07-16
> These are "what to think about" frames — not facts. LLM applies these to every event affecting a persona.

---

## RP-MATERIAL-01: Material Cost Event → Sourcing Dependency Analysis
**When applies:** event_type:Commodity OR event_type:Regulation/import_export_duty AND material is specified
**Must consider:**
- Actual sourcing origin breakdown (not just headline country — distinguish domestic vs imported blend)
- Whether factory controls sourcing (FOB/Vertical) or buyer controls it (CMT with buyer-nominated fabric)
- Domestic price floor mechanisms (MSP, government support prices) that cap downside even when global prices fall
- Substitutability of origin within a realistic 3–6 month sourcing window
- Second-order: is the saving captured by the factory, or does it flow through to the buyer?
**LLM directive template:** "For [combo] on [material] event: (1) Quantify sourcing origin breakdown by country %, cite source and year. (2) Determine domestic vs imported blend ratio for this combo. (3) Identify any government price floor/MSP in origin country and whether it caps downside. (4) Calculate blended cost impact = Δduty × imported_share × material_COGS_share. (5) Compare [combo country] vs peer origins on material cost parity post-event."
**Freshness:** stable

---

## RP-TARIFF-CLIFF-01: Event With Explicit Cliff Date → Window Optimization + Post-Cliff Risk
**When applies:** trigger.effective_window.has_cliff = true
**Must consider:**
- Days remaining in window from current date (not just cliff date in abstract)
- Pre-cliff: realistic order acceleration window and capacity to absorb higher volumes
- Post-cliff: over-stockpiling risk — factories that over-commit face elevated WC needs into the following quarter
- Tenor design: all Air8 disbursements must self-liquidate before cliff date
- Latest safe booking date = cliff_date − tenor_days − 5-day buffer
**LLM directive template:** "For event with cliff [date]: (1) Calculate days remaining from today. (2) What is a realistic pre-cliff order acceleration window given factory lead times? (3) What is the post-cliff over-stockpiling risk? Which combos most exposed? (4) What is the latest safe disbursement date for a [tenor]d Air8 facility?"
**Freshness:** stable

---

## RP-FX-01: FX Event → Currency Structure and Hedge Analysis
**When applies:** event_type:Financial/fx_rate
**Must consider:**
- Revenue currency mix (USD-denominated for most exporters; EUR for EU-focused)
- Cost currency mix (local currency for labor; USD/EUR for imported inputs)
- Natural hedge ratio: EUR revenue vs EUR-cost or TRY-cost creates different exposure
- Whether buyer contracts allow price adjustment for FX moves
- Whether Air8 EUR-denominated facility self-hedges local currency risk
**LLM directive template:** "For [combo] on FX event [currency_pair]: (1) Typical revenue/cost currency split for this combo type. (2) Estimated open FX exposure as % of annual revenue. (3) Does this combo have forward contracts or natural hedge? (4) Does Air8 EUR-denominated ARP reduce or increase FX exposure for this supplier?"
**Freshness:** stable

---

## RP-BUYER-FIN-01: Buyer Financial Event → Concentration and DSO Analysis
**When applies:** event_type:Financial/buyer_credit_event OR event_type:Buyer/ma_ownership OR event_type:Buyer/sourcing_strategy_shift
**Must consider:**
- Affected combos' revenue concentration in this buyer type (% from top buyer)
- DSO trend — has buyer been extending payment terms prior to event?
- Air8 receivables exposure to this buyer type across portfolio
- Replacement pipeline: can supplier redirect to other buyers within 6 months?
- PSF eligibility impact: if buyer anchor weakens, PreShip-OBF may become ineligible
**LLM directive template:** "For [buyer] event affecting [combos]: (1) What % of revenue do affected combos typically derive from this buyer type? (2) Recent DSO trend for this buyer type — any extension pattern? (3) What does this event mean for PSF/OBF eligibility with this buyer as anchor?"
**Freshness:** stable

---

## RP-COMPLIANCE-01: Regulation Event → Compliance Gap and Cert Cost Analysis
**When applies:** event_type:Regulation/environmental_compliance OR event_type:Regulation/traceability OR event_type:Regulation/product_safety OR event_type:Regulation/labor_standards
**Must consider:**
- Which combos are in scope (by buyer_geo and material — not all regulations apply to all markets)
- Existing certifications vs new requirement gap (BSCI ≠ GOTS ≠ CSDDD — each has different scope)
- Compliance timeline and cost to close gap (audit cost vs remediation cost are very different)
- Buyer pressure: is this mandatory for next season or voluntary signaling?
- Whether compliance gap creates Air8 credit risk (shipment detention = unpayable receivable)
**LLM directive template:** "For [regulation] event: (1) Which buyer geographies and material types are in scope? (2) Which combos have existing certifications that partially address this? (3) What is the timeline and typical cost to comply for a mid-size supplier? (4) What is the risk of shipment detention if non-compliant?"
**Freshness:** annual

---

## RP-COMPETITIVE-01: Cost/Price Event → Competitive Repositioning
**When applies:** event_type ∈ [Commodity, Regulation/import_export_duty, Financial/fx_rate]
**Must consider:**
- Does this event change [combo country]'s cost position vs peer sourcing countries?
- Are beneficiary combos likely to see PO inflow from shifted orders?
- Are disadvantaged combos likely to see PO outflow?
- Does shifting competitive position change Air8 book concentration risk (beneficiary combos may surge)?
- Second-order: does a competitor's cost advantage trigger nearshoring/consolidation decisions at buyers?
**LLM directive template:** "After event [trigger_id]: Compare [combo country] to BD, VN, CN, TR, PK on [material] input cost per unit. Who gains competitive advantage and over what timeframe? What order volume shift is realistic in 6–12 months?"
**Freshness:** stable

---

## RP-GRADUATION-01: Trade Preference Graduation → Structural Revenue Risk
**When applies:** event_type:Regulation/trade_agreement AND involves EBA, GSP+, or preferential access change
**Must consider:**
- Specific graduation timeline (announcement vs effective date vs transition period)
- Which combos are most exposed (EU-heavy revenue mix + no alternative trade advantage)
- Whether affected factories have a credible path to GSP+ or alternative certification
- Buyer pre-positioning signals — buyers typically start diversifying sourcing 18–24 months before effective date
- Air8 portfolio risk: graduation event may trigger gradual PO outflow starting years before effective date
**LLM directive template:** "For [country] trade preference change: (1) What is the exact effective date and any transition period? (2) What tariff rate applies post-graduation vs current zero-duty access? (3) Which buyer types are most likely to pre-position to alternative origins? (4) What is the realistic timeline for buyer RFQ/sourcing reviews to begin?"
**Freshness:** annual

## Related

- [PRINCIPLES.md](PRINCIPLES.md) — Master layer-1 principles this file extends
- [PERSONA-SYNTHESIS.md](../solutions/PERSONA-SYNTHESIS.md) — Persona synthesis method for novel personas
- [cliff-playbook.md](../playbooks/cliff-playbook.md) — Persona-specific cliff management (LDC graduation, tariff cliff)
