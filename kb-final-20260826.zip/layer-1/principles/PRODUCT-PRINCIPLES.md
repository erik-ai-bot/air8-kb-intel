# L0 Product Principles — Reasoning Frames

> Module: Products | Count: 5 | Updated: 2026-07-01
> Ported from air8-kb-v2/L0-principles/product-principles.md — 2026-07-16
> These are "what to think about" when mapping Air8 products to an event or BD situation.

---

## RP-PROD-SELFLIQ-01: Pre-Shipment Product → Verify Self-Liquidation Chain
**When applies:** product recommendation involves PROD-PRESHIP-OBF or PROD-PRESHIP-RT2C
**Must consider:**
- PSF self-liquidates: raw material → production → buyer receivable. State this explicitly in every card.
- Typical liquidation window vs event horizon (if cliff event: does tenor settle before cliff?)
- Self-liquidating = Low Air8 risk — always state this; it is a key differentiator vs bank WC
- Risk rises if: (a) buyer cancels PO post-disbursement, (b) cliff event forces over-commitment, (c) buyer anchor is not investment-grade
- PROD-PRESHIP-OBF requires confirmed buyer PO as anchor — without it, product is ineligible
- **Long-cycle category caution (CRITICAL):** For product categories with total operating cycle >9 months AND high seasonal order cancellation risk (outdoor furniture: 12-13 months; holiday décor: 12-13 months), pre-shipment OBF carries **elevated cancellation risk** — the longer the cycle, the greater the chance of order qty reduction or full cancellation before production completes. For these categories: **prefer ARP (post-shipment, on confirmed invoices) over OBF unless the buyer relationship is very well established and PO commitment is hard-confirmed.** Pre-shipment OBF for long-cycle categories = HIGH RISK default; requires explicit upgrade justification.
**LLM directive template:** "For PSF on this event: (1) What is the total operating cycle for [combo]? If >9 months, apply long-cycle caution — is buyer relationship established enough to justify pre-shipment OBF? (2) State the self-liquidation chain and timeline. (3) Does the tenor settle before any cliff date? (4) What is the buyer anchor quality? (5) Identify specific risk scenarios where self-liquidation fails for this specific combo."
**Correction source:** Josephine Cheung 2026-07-16 — pre-shipment finance for outdoor furniture (12-13 month cycle) confirmed high risk due to cancellation; post-shipment ARP preferred.
**Freshness:** stable

---

## RP-PROD-TENOR-01: Any Event With Time Window → Tenor Design
**When applies:** trigger.effective_window is specified AND contains cliff date
**Must consider:**
- Latest safe booking date = cliff_date − tenor_days − 5-day buffer. Calculate this explicitly.
- All disbursements must settle before cliff — do not allow tenor to cross cliff date
- If tenor unavoidably crosses cliff → escalate to CAUTION signal; buyer risk must be very low to proceed
- Front-load disbursements during early window; taper in final 30-45 days before cliff
- Post-cliff positions: must account for WC stress on supplier in quarter following cliff
**LLM directive template:** "For event with cliff [date] and recommended tenor [X]d: (1) Calculate latest safe booking date. (2) Is front-loading vs tapering appropriate? (3) What is the Air8 exposure if supplier over-commits pre-cliff?"
**Freshness:** stable

---

## RP-PROD-ELIGIB-01: New Combo → Eligibility Pre-Check Before Product Recommendation
**When applies:** any S2 Round 2 or S3 assessment; any new facility request
**Must consider:**
- ARP: Revenue >$1M (MiniARP) or >$3M (standard ARP); operations >2yr; buyer relationship >2yr
- PRESHIP-OBF: Revenue >$10M; must be existing ARP client; LF vendor preferred
- PRESHIP-RT2C: Revenue >$1M; must be existing ARP client with 6mo+ good track record
- POOL: Revenue >$20M; 5+ active buyer pairs; good overall scorecard
- ESG-FINANCING: Verifiable certifications (GOTS, FAIRTRADE, C2C, ROC); IFC eligibility
- If not eligible → flag explicitly; offer advisory/monitoring only; do not recommend
**LLM directive template:** N/A (eligibility is stored data — no LLM retrieval needed; apply gates directly)
**Freshness:** stable (updates only when A8 product terms change — quarterly review)

---

## RP-PROD-RISK-NARR-01: Any Product Recommendation → Risk Narrative Is Mandatory
**When applies:** any S1 or S2 card that recommends an Air8 product
**Must consider:**
- Every product recommendation must include WHY Air8 risk is low/medium/high
- Use the risk_reduction_narrative from the product node (self-liquidating chain, collateral, buyer quality)
- Without the risk narrative, BD cannot justify the product internally or to clients
- Risk narrative for ARP: buyer credit insurance + invoice purchase (not a loan)
- Risk narrative for PSF: self-liquidating, buyer PO as anchor
- Risk narrative for PayGuard: insurance-backed, limits set by buyer credit quality
**LLM directive template:** N/A (use product node risk_reduction_narrative field directly)
**Freshness:** stable

---

## RP-PROD-WALLET-01: Existing Client → Wallet Share Expansion
**When applies:** scenario = S2 AND client is already Air8 (COMBO-010 pattern)
**Must consider:**
- Wallet share: what % of client's total AR/WC needs flow through Air8 currently?
- Product gaps: if ARP only → always explore PRESHIP, SmartWallet, PayGuard
- Buyer pair gaps: if not all buyers covered → uncovered pairs = immediate expansion opportunity
- Limit lift: current advance ratio + whether an active event justifies higher limit
- Product cross-sell sequencing: ARP → RT2C → OBF → POOL → ESG (in order of eligibility thresholds)
**LLM directive template:** N/A (wallet share and product coverage are internal facility data)
**Freshness:** quarterly (review with each client touch)

## Related

- [NODE-product-trend.md](../../layer-2/nodes/NODE-product-trend.md) — Product trend reasoning
- [PP-EXPAND-001-low-wallet-share.md](../pain-points/expansion/PP-EXPAND-001-low-wallet-share.md) — Wallet share as product expansion trigger
- [PP-EXPAND-002-missing-product-coverage.md](../pain-points/expansion/PP-EXPAND-002-missing-product-coverage.md) — Product gap detection
