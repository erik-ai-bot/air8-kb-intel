# L1 · SHI Reasoning Principles

How to reason about SHI exceptions. This file contains thinking logic only —
no step-by-step flow (that is in the skill), no specific rule conditions (those are in layer2).

---

## What SHI is and why it exists

SHI (Special Handling Instruction) is a pre-approved standing exception for a specific
supplier-buyer pair. Trade documents routinely contain anomalies — non-standard payment terms,
partial shipments, unsigned POs, forwarder-issued BLs — that are commercially normal for a
given buyer relationship but technically deviate from Air8 standard requirements.

SHI exists so Ops does not need to escalate the same exception repeatedly for the same pair.
Once an exception is understood and approved, it becomes a standing instruction.

The agent's reasoning job is to determine: does this anomaly have a pre-approved resolution,
or does it need human judgment before release?

---

## Reasoning hierarchy — apply in this order

When an anomaly is detected, reason through these layers in sequence:

1. **Is this a hard stop?**
   Hard stops are absolute blockers regardless of any other evidence or precedent.
   Check `NODE-hard-stops` first. If matched, stop — do not continue reasoning.

2. **Does a buyer standing rule cover this?**
   Some buyers have pre-negotiated structural arrangements that override general rules.
   Check `NODE-buyer-standing`. If the buyer has a standing rule covering this anomaly,
   apply it — it takes priority over general auto-pass rules.

3. **Is there an auto-pass condition that matches?**
   Auto-pass conditions are derived from approved historical cases with documented evidence.
   Check `NODE-auto-pass-rules`. If a condition matches AND the required evidence is present,
   the anomaly is resolved without escalation.

4. **No rule matched — determine the approval path.**
   Fall back to the exception's risk node — check `NODE-risk-categories` for the applicable risk level and approval path defined there.

---

## How to reason about anomalies in documents

### Classification before judgment
Before deciding anything, classify the anomaly to its correct risk node (R1–R9).
The same phrase can map to different risk nodes depending on context — see `NODE-terminology`
for disambiguation. Do not apply rules from the wrong node.

### When an anomaly might not be an anomaly
Some phrases appear in trade documents and look like exceptions but are not.
Common patterns: standard trade references (SLAC, NRA, IEC), or equivalent terms with different
surface wording — see `NODE-terminology` Part B for the documented equivalences.
Before flagging, check `NODE-terminology` for known equivalences.

### When the same node has multiple sub-conditions
An FR may have multiple exceptions under the same risk node (e.g. both late shipment AND
partial shipment under R3). Reason through each sub-condition separately.
Apply the most restrictive outcome across all exceptions on the FR.

### When terms are not in the KB
Apply trading domain knowledge to infer the most likely risk concept.
State the inference and confidence level. Let the Ops expert confirm before proceeding.
Add confirmed mappings to `NODE-terminology` via the proposal process — do not self-modify.

---

## How to reason about evidence

Evidence is not binary. Rank it by strength — stronger evidence reduces the need for escalation.
Refer to `L1-evidence-discipline.md` for the full hierarchy.

Key principle: **a rule without evidence is not resolved.**
Even auto-pass conditions require the supporting evidence to be present and retained.
Auto-pass is a pre-approved path, not an evidence waiver.

---

## How to reason about escalation

Escalate when:
- A hard stop condition is present
- No auto-pass rule matches and risk level is HIGH
- Evidence is required but not available and cannot be collected at FR stage
- A new structure appears that has never been approved before

Do not escalate when:
- An auto-pass condition matches and evidence is present
- A buyer standing rule covers the exception
- The "anomaly" is a known equivalent term (not a real deviation)

When uncertain: flag for Ops expert confirmation rather than guessing. A wrong classification
costs more than a brief pause for confirmation.

---

## Governance principle

Rules in layer2 are the single source of truth. When a rule changes:
- The change happens only in the relevant layer2 node
- This file does not change
- The skill does not change
- Log the change in `ops/decision-log.md`

This file should remain stable over time. If you find yourself wanting to add
specific rule conditions here, put them in layer2 instead.

## Related

- [PRINCIPLES.md](PRINCIPLES.md) — Master principles file; this is the reasoning-layer sub-component
- [L1-scoring-method.md](../methods/L1-scoring-method.md) — Scoring reasoning method
- [L1-adverse-news-method.md](../methods/L1-adverse-news-method.md) — Adverse news reasoning method
- [L1-trend-method.md](../methods/L1-trend-method.md) — Trend assessment reasoning
