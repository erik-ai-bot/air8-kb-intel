# L1 · Pipeline and ordering

The run order and the list-construction policy. Rule *values* (which gate at what threshold) are Layer 2 nodes; this file is why the sequence is what it is.

## Sequence

1. **Load & map** (L1-db-field-contract) — derive indicators from the DB; trailing-12 window; nulls stay null
2. **Identity** (L1-evidence-discipline §3) — de-duplicate, resolve entities, apply relationship TAGS (never inputs)
3. **Route** (edges/E-routing) — product type → vertical → framework. Unroutable → Enrichment
4. **Score** (L1-scoring-method + edges/E-pattern-*) — points, tier, caps, gates. Scores freeze here
5. **Order** (below) — gates first, then sort. Cheap stages 1-5 run on everything
6. **Enrich the shortlist only** — adverse, need, contacts, buyers. Expensive; ~top 20
7. **Re-gate** — enrichment surfaces MATERIAL findings that were NOT SCREENED at step 5; the one loop in the flow
8. **Interpret** (layer2/N-*-types + edges/E-type-implications) — same score, different type, different call

## Gate policy

Gates remove or park; they never re-rank. Order: adverse (MATERIAL+) → hard default → entity unresolved (parked, not scored). `NOT SCREENED` is a valid, labelled state — the pipeline proceeds and the re-gate at step 7 catches what enrichment finds. An undisclosed allegation is itself a finding.

## Sort policy

Score is primary. Region breaks ties only (India/Pakistan preferred within equal scores); financing need is the tertiary tie-breaker and **never deletes a lead**. Floor (published evidence of *no* need) and Gated-out stay visible with their evidence — a reviewer's first question is always "why isn't the biggest one here?". Bench = one band lower with better evidence, promotable by exception, exception written down.

## Already-financed names

Stay ranked in place, labelled. The overlap between the pattern's top picks and the existing book **is** the validation a reviewer wants; backfill around them, never swap them out.

## Churn attribution

Before any churn is read as a scoring miss, attribute it: most churn in the calibration book was the buyer's programme dying, not the supplier failing. Check the buyer's `programme_status` (DB) first.

## Related

- [L1-scoring-method.md](../methods/L1-scoring-method.md) — Scoring method governed by pipeline gates
- [L1-performance-coverage.md](../methods/L1-performance-coverage.md) — CP1 coverage gate; pass/fail thresholds
- [L1-vertical-routing.md](../principles/L1-vertical-routing.md) — Vertical routing decision that pipeline gates
- [L1-ordering-and-gates.md](../principles/L1-ordering-and-gates.md) — Gate ordering and dependency logic
