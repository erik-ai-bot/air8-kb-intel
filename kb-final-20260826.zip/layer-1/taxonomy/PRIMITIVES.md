# Reasoning Primitives — LLM Fallback Library

> Version: 1.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> Ported from air8-kb-v2/_reasoning/primitives.md — 2026-07-16
> Use these primitives when an event does not match a known event_type in the tag_dictionary,
> OR when S1 Step 4 does not find a matching L0 principle for the event_type.
> Referenced from: S1-event-insights.md (Step 4 fallback), signal-decision-rules.md (MONITOR signal)

---

## When to Use Primitives

**Condition 1:** S1 Step 4 loads L0 principles → no principle matches the specific event_type
→ Fall back to primitives: identify which primitives apply, compose reasoning from scratch

**Condition 2:** MONITOR signal triggered (signal uncertainty, insufficient data)
→ Apply RP-INFORMATION-DEFICIT before emitting any recommendation

**Condition 3:** Novel event not in taxonomy (no event_type match in tag_dictionary.md)
→ Apply ALL relevant primitives and compose a first-principles analysis

**Condition 4:** STEP 0 produces `[KB-GAP]` items with no Layer 2 entity match
→ Apply RP-BEYOND-KB before falling through to other primitives

---

## RP-BEYOND-KB — Beyond-KB Signal Handling

**id:** RP-BEYOND-KB
**name:** Beyond-KB Signal Reasoning and Expansion Flagging
**when:** STEP 0 web enrichment surfaces a `[KB-GAP]` signal — a real-world finding with no matching KB principle, entity, or taxonomy entry. The brain still needs to reason about it and flag the KB gap for expansion.
**trigger:** `[KB-GAP]` tag in ENRICHMENT BLOCK from STEP 0

**ask:**
- Can the gap signal be mapped to an existing Layer 2 entity even without a principle path? (proximity match)
- If no Layer 2 match: which primitives can reason about this from first principles?
- What is the worst-case impact if the gap is ignored?
- What specific KB addition (new principle, entity update, new entity file) would resolve this gap?
- What data or expert input would be needed to validate the missing element?

**four-phase execution:**

**Phase 1 — Proximity Match**
Check Layer 2 entities (countries/, product-categories/, personas/) for entities implied by the gap signal, even if no principle activated them.
- Match found → include with source=`BEYOND-KB`, relevance capped at 0.15, all claims labeled `[HYPOTHESIS]`
- No match → use Phase 2 primitives on first-principles basis

**Phase 2 — First-Principles Reasoning (to build the analysis foundation)**
Apply the relevant primitive from this file:
- Input/upstream gap → RP-DEPENDENCY
- Cost pass-through uncertainty → RP-PASSTHROUGH
- Time-window gap → RP-WINDOW
- Unknown structural vs cyclical → RP-STRUCTURAL-CHANGE
- General uncertainty → RP-INFORMATION-DEFICIT
Label all output `[HYPOTHESIS]` or `[PENDING DATA]`. State the 2-3 data points that would resolve to [VERIFIED].

**Phase 3 — Analytical Synthesis (the required output — not optional)**
This is the phase that produces the actual value. After Phase 1 or 2, the brain must explicitly synthesize:

```
BEYOND-KB SYNTHESIS:
  gap_signal:              {the outside-KB finding from STEP 0}
  kb_would_have_said:      {what the principle chain alone would have concluded}
  analytical_dimension_added:
    {the reasoning dimension, mechanism, or risk that the KB doesn’t model —
     described in 1-2 sentences as a clear analytical insight, not a data point}
  how_it_changes_output:
    - {specific change to Step 2 question / Step 4 entity / Step 5 signal intensity /
       IMMEDIATE / COMMERCIAL / COMPETITIVE / WC+AIR8 block}
    - {another specific change if applicable}
  signal_impact: DIRECTION_REVISED | INTENSITY_DOWNGRADED | INTENSITY_UPGRADED |
                 CONDITION_ADDED | ANGLE_ADDED | QUESTION_ADDED
```

**If signal_impact = NO_CHANGE — the synthesis failed.** The finding was cataloged, not used.
Re-examine: does this finding change the timing? the recommendation? the persona priority? the question asked?
At least one element of the output card must change, or the beyond-KB signal is not being used.

**Phase 4 — KB Expansion Flag (mandatory)**
For every gap, generate a flag that captures not just what’s missing but what it would unlock:
```
[KB-EXPANSION-FLAG]
type:         NEW-PRINCIPLE | NEW-ENTITY | UPDATE-ENTITY
description:  {what is missing}
evidence:     {specific STEP 0 finding that revealed the gap}
would_enable: {what better or more accurate analysis would be possible if this gap were filled}
priority:
  HIGH   → gap materially changes signal direction; label signal [PENDING DATA]
  MEDIUM → gap enriches signal but doesn’t flip it; label [HYPOTHESIS]
  LOW    → context only; no signal impact
route_to:     Josephine Cheung expert review queue
```

**applies_to:** any event where STEP 0 open-world search surfaces findings outside the KB taxonomy

**how LLM uses for novel events:** When searching a new commodity policy (e.g., India cotton GST exemption) reveals that government price floors (MSP) can absorb the impact — but the KB has no principle for government price floors — apply RP-BEYOND-KB: Phase 1 → check if countries/IN.md has MSP data (partial match, score 0.10). Phase 2 → apply RP-PASSTHROUGH to estimate how much of the exemption benefit reaches factories vs is absorbed by MSP. Phase 3 → flag [KB-EXPANSION-FLAG] type=NEW-PRINCIPLE: "PRIN-GOVT-FLOOR — government price floors that neutralize commodity policy signals", priority=HIGH.

**Example:** India cotton GST exemption — STEP 0 finds MSP floor at INR 6,620/quintal. No KB principle covers MSP interaction.
```
Phase 1: countries/IN.md exists → BEYOND-KB entity included, score 0.10
  Claim: "MSP may absorb 30-50% of exemption benefit" | [HYPOTHESIS]
Phase 2: RP-PASSTHROUGH applied
  → Exemption at factory/mill level; MSP is a floor not a ceiling
  → If market price > MSP (current case): exemption fully passes through to mill
  → If market price drops to MSP: floor kicks in, buyer captures benefit instead
  Resolving data needed: current India cotton spot price vs MSP spread
Phase 3: [KB-EXPANSION-FLAG]
  type=UPDATE-ENTITY | entity=countries/IN.md | gap="MSP level and market price spread" | priority=MEDIUM
  type=NEW-PRINCIPLE | proposed=PRIN-GOVT-FLOOR | priority=HIGH → Josephine review
```

---

## RP-DEPENDENCY — Dependency Chain Analysis

**id:** RP-DEPENDENCY
**name:** Dependency Chain Analysis
**when:** Any event affecting a raw material, input, or upstream supplier that feeds into a combo's production
**ask:**
- Who in the chain (farm / spinner / mill / factory / buyer) captures this event's impact?
- At what stage does the impact attenuate or reverse?
- Does the factory own or control the affected input, or does a third party?
- What is the lag time between the upstream event and factory-level impact?
**applies_to:** commodity events, supply disruptions, duty changes affecting inputs
**how LLM uses for novel events:** When a new type of input event appears (e.g., rare earth shortage affecting dye chemistry), apply RP-DEPENDENCY to trace: who buys the affected input? Does the factory buy it directly or via a mill? What is the contract structure (spot vs forward)? What is the factory's switching cost to alternatives?

**Example:** A new synthetic dye shortage is reported. Apply RP-DEPENDENCY: Do apparel factories buy dye directly? No — dye is embedded in the fabric price from mills. Impact attenuates at mill level. Factory impact = indirect and lagged (1 season). Low direct risk for Air8 positions.

---

## RP-PASSTHROUGH — Cost/Benefit Passthrough Analysis

**id:** RP-PASSTHROUGH
**name:** Benefit/Cost Passthrough Analysis
**when:** Any event that creates a cost saving or cost increase that must travel through multiple parties before reaching the factory
**ask:**
- What % of the benefit/cost actually reaches the factory (vs absorbed by buyer or upstream supplier)?
- Is there a contract mechanism (cost-plus vs fixed price) that governs passthrough?
- Does the buyer nominate inputs (CMT model = zero passthrough for raw material events)?
- Is there a lag before passthrough materialises?
**applies_to:** commodity price events, duty changes, FX moves, energy price events
**how LLM uses for novel events:** When a new type of policy creates a cost saving (e.g., carbon tax exemption), apply RP-PASSTHROUGH: Does the exemption apply at raw material, mill, or factory level? Who holds the contract that determines whether the saving is kept or shared with buyer?

**Example:** Carbon tax exemption is granted to textile manufacturers. Apply RP-PASSTHROUGH: Exemption applies at factory level, not mill or raw material level. Factory keeps saving IF fixed-price contracts with buyers. If cost-plus, buyer captures it. Factory passthrough = high for fixed-price models; low for cost-plus.

---

## RP-WINDOW — Effective Window Analysis

**id:** RP-WINDOW
**name:** Time Window and Cliff Analysis
**when:** Any event with a defined start date, end date, or cliff date
**ask:**
- What is the effective window (start to end)?
- Is there a cliff date after which conditions reverse or disappear?
- What is the latest safe disbursement date given Air8's typical tenor?
- What is the risk of over-stockpiling in anticipation of the cliff?
- Does the opportunity repeat (seasonal) or is it one-time?
**applies_to:** duty windows, regulatory deadlines, seasonal sourcing, LDC graduation, policy sunsets
**how LLM uses for novel events:** When a new time-limited policy is announced (e.g., temporary import suspension), apply RP-WINDOW: When does it start? When does it end? Is there a cliff? What is the stockpile incentive? What is Air8's latest disbursement date to remain inside the window?

→ See layer-1-reasoning/playbooks/cliff-playbook.md for full protocol on cliff event management

---

## RP-CONCENTRATION — Concentration Risk

**id:** RP-CONCENTRATION
**name:** Concentration Risk Assessment
**when:** Any event that increases exposure to a single buyer, country, material, or event type across the Air8 portfolio
**ask:**
- Does this event increase single-buyer revenue concentration above 60%?
- Does this event increase single-country exposure above Air8's country cap?
- Does this event increase single-commodity exposure above 30%?
- Would expanding based on this event create correlated risk across multiple combos?
**applies_to:** buyer events, country events, commodity events; applies to portfolio-level analysis
**how LLM uses for novel events:** When a major sourcing shift event occurs (e.g., EU mass shift to a new low-cost country), apply RP-CONCENTRATION: If Air8 expands all combos in that country simultaneously, what is the portfolio-level country concentration? Is correlated risk created?

**Example:** Vietnam becomes the dominant EU sourcing country overnight. Apply RP-CONCENTRATION: If Air8 expands all VN combos to maximum, Vietnam concentration in portfolio rises sharply. RP-CONCENTRATION flags: expand selectively, not across all VN combos simultaneously.

---

## RP-CASCADE — Cross-Module Cascade

**id:** RP-CASCADE
**name:** Second-Order Cross-Module Effects
**when:** An event that affects one module (e.g., commodity) but has secondary effects in a different module (e.g., buyer behavior, regulation)
**ask:**
- What second-order effects does this event create in OTHER modules?
- Does a commodity event trigger a buyer sourcing shift? A regulatory change trigger a financial impact?
- Which combos are affected INDIRECTLY (2-hop edge walk) that are not directly affected?
- Does the event reinforce or undermine an existing Air8 position in a different module?
**applies_to:** complex multi-domain events; geopolitical events; regulatory overhauls
**how LLM uses for novel events:** When a novel event crosses domains (e.g., a geopolitical event affects commodity prices AND sourcing strategy AND buyer compliance requirements simultaneously), apply RP-CASCADE: Step through each affected module, then identify 2-hop effects in connected modules.

**Example:** US sanctions a key cotton-producing country. Apply RP-CASCADE: Module 1 = commodity (cotton supply reduced); Module 2 = compliance (OFAC sanctions triggers UFLPA risk check for all US buyers); Module 3 = buyer behavior (buyers scramble to qualify new origins); Module 4 = financial (Air8 positions in sanctioned-country combos must be reviewed for compliance). Four distinct cascades from one event.

---

## RP-INFORMATION-DEFICIT — Uncertainty Handling

**id:** RP-INFORMATION-DEFICIT
**name:** Uncertainty and Missing Information Protocol
**when:** Signal confidence is low; key facts are unknown or contradictory; novel event with no historical precedent
**ask:**
- What specific information is missing that would resolve the signal uncertainty?
- What is the worst-case and best-case interpretation of the available signal?
- Can a conservative recommendation be made that is safe under BOTH interpretations?
- What watch list criteria would trigger an upgrade or downgrade of the signal?
**applies_to:** novel events; early-stage signals; contradictory data; WhatsApp rumors; unconfirmed reports
**how LLM uses for novel events:** When a genuinely novel event type appears with no historical analogue, apply RP-INFORMATION-DEFICIT: Identify what is known, what is unknown. Issue MONITOR signal. State the 3 specific data points that, when confirmed, would resolve to a clear signal. Add to watch list with stated criteria.

**Triggered by:** MONITOR signal in signal-decision-rules.md

---

## RP-STRUCTURAL-CHANGE — Structural Break Detection

**id:** RP-STRUCTURAL-CHANGE
**name:** Structural Break vs Cyclical Event Assessment
**when:** An event that may represent a permanent structural shift rather than a temporary cyclical fluctuation
**ask:**
- Is this event part of a recurring pattern (cyclical) or a one-time shift (structural)?
- Does this event permanently alter the competitive dynamics of a sourcing country?
- Would prior scoring/weights for this combo be materially wrong after this event?
- Does this event trigger a KB update requirement (flag for expert review)?
**applies_to:** LDC graduation, country export policy changes, major buyer de-sourcing announcements, technology disruption
**how LLM uses for novel events:** When an event could be structural (e.g., a country announces permanent currency peg removal), apply RP-STRUCTURAL-CHANGE: Is this reversible? Will prior assessments of this combo still be valid? Flag the relevant COMBO nodes for KB update if the structural change is confirmed.

**Example:** Bangladesh permanently graduates from LDC status. Apply RP-STRUCTURAL-CHANGE: This is irreversible. All COMBO nodes referencing EBA duty advantage (COMBO-002, COMBO-012) need re-assessment. Prior EXPAND signals based on EBA advantage are no longer valid. Flag for expert review and KB update cycle.

---

## RP-PEER-FAILURE — Survivor Bias Correction

**id:** RP-PEER-FAILURE
**name:** Peer Failure → Survivor Bias Correction
**when:** Any event where peer factories, competitors, or market participants fail or exit, creating an apparent benefit signal for the surviving party
**core insight:** Peer failure does not automatically mean the survivor benefits. The survivor may face the exact same structural forces that caused the peer failure — just not yet triggered. A factory gaining orders from a closed competitor may be a "not-yet-failed" factory, not a genuine winner.

**ask:**
- Why exactly did the peer fail? What structural forces caused it — wage escalation, compliance failure, buyer exit, margin squeeze, overcapacity?
- Does the survivor face the same structural causes — even if they have not yet triggered?
- Is the new inflow (orders, customers, market share) at better or worse economics than the survivor's existing book?
- Is the inflow commitment durable (multi-season contract) or temporary (buyer testing the survivor before committing)?
- Is the survivor's margin per unit improving or declining despite higher volume?

**applies_to:** factory closures, competitor bankruptcies, market consolidation, supplier exits, country-level export decline where some factories survive

**signal correction rule:**
```
IF peer_failure_detected → default signal = EXPAND (naive assumption)

CORRECTION:
  IF survivor_faces_same_structural_cause = true:
    → signal = CONDITIONAL (at best)
    → label: "not-yet-failed — structural risk deferred, not resolved"
    → required: specific evidence of genuine structural differentiation before EXPAND approved

  IF survivor_faces_same_structural_cause = false:
    → signal = EXPAND confirmed
    → required: name the specific structural advantage that peers lacked

  IF new_inflow_economics < existing_book_economics:
    → signal = CAUTION regardless of volume
    → reason: volume growth masking margin deterioration = distress pattern
```

**four key assessment questions (always ask in order):**
1. "What specifically caused the peer closures — structural (permanent) or cyclical (temporary)?"
2. "Does this factory face the same root cause — wage trajectory, compliance gap, buyer concentration, margin squeeze?"
3. "Is the new PO inflow confirmed multi-season, or is it a buyer testing the factory temporarily?"
4. "What is the factory's margin per unit now vs 12 months ago — improving or declining?"

**how LLM uses for novel events:** When any event involves competitor exits or peer failures (in any industry, country, or segment), automatically fire RP-PEER-FAILURE before generating an EXPAND signal for survivors. The burden of proof is on the EXPAND signal — it requires demonstrated structural differentiation. CONDITIONAL or CAUTION is the default until differentiation is confirmed.

**example (BD factory closures 2026):**
```
Event: Multiple BD CMT factories closing (wage escalation + LDC risk + EU demand contraction)
Naive: Surviving BD factory gains new PO inflow → EXPAND
RP-PEER-FAILURE check:
  Q1: Closures caused by wage escalation + LDC graduation + EU demand contraction (structural)
  Q2: Does survivor face same forces? YES — same wage schedule, same LDC risk, same EU buyer base
  Q3: New POs — temporary buyer test (2-season), not long-term commitment
  Q4: Margin per unit declining 8% YoY despite higher volume
Corrected signal: CONDITIONAL → "not-yet-failed — structural risk deferred"
NOT EXPAND until factory demonstrates: (a) lower cost base than closed peers, OR (b) buyer commitment confirmed multi-season, OR (c) margin improving not declining
```

**cross-reference:** RP-STRUCTURAL-CHANGE, RP-CONCENTRATION, scenarios/S4 P0-4b (cluster stress check)

## Related

- [PRINCIPLES.md](../principles/PRINCIPLES.md) — RP-EVT-CORRELATED-PAIR, RP-CONCENTRATION, RP-PEER-FAILURE primitives
- [EVENT-PRINCIPLES.md](../principles/EVENT-PRINCIPLES.md) — Event reasoning primitives embedded in event workflow
- [BRAIN-CHAIN.md](../flows/BRAIN-CHAIN.md) — Brain chain that uses primitives for novel event classification
- [EVENT-CLUSTERS.md](EVENT-CLUSTERS.md) — Correlated pair logic that primitives govern
