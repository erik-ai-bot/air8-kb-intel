---
type: reasoning
id: EVENT-CLUSTERS
---

# Air8 Event Clusters — Combined Event Analysis

Some events share a common root cause and should be analysed together.
Running them combined produces richer signals: the two policy levers of the same underlying force interact, and the affected combos overlap significantly.

**Rule:** When two or more clustered events are simultaneously active, run a combined analysis pass rather than separate independent analyses. The combined pass produces:
- A single root-cause framing
- Cross-lever persona scoring (persona must be scored against both mechanisms)
- Financing recommendations that address both levers

---

## CLUSTER-US-DECOUPLING

**Root cause:** US strategic decoupling from Chinese supply chains

**Member events:**
- EVT-TARIFF (subtype: `section_301`, `ieepa_decree`, `forced_labor_tariff`)
- EVT-REGULATION (subtype: `forced_labor_uflpa`, `traceability_enforcement`)

**Two policy levers — different mechanisms, same root:**

| Lever | Mechanism | What it blocks |
|---|---|---|
| IEEPA / Section 301 | Cost penalty — tariff on goods | Makes China-origin goods price-uncompetitive |
| UFLPA | Access denial — import ban | Blocks goods with China-linked forced labour inputs, regardless of price |

**Why combine:**
A supplier can be fully UFLPA-compliant (clean traceability) and still face Section 301 cost penalties — or vice versa. Analysing them separately misses the compounding effect on suppliers and buyers who must navigate both mechanisms simultaneously.

**Primary affected combos:**
- COMBO-004 (China Medium Woven) — directly hit by both levers
- COMBO-006 (Vietnam FDI) — S301 tariff risk + UFLPA if cotton chain traced to Xinjiang
- COMBO-002 (Bangladesh CMT) — UFLPA traceability advantage (Indian cotton) + S301 secondary
- COMBO-009 (Pakistan Home Textile) — UFLPA advantage (non-Xinjiang cotton) + lower S301 exposure
- COMBO-012 (Cambodia) — dual threat: S301 + EU EBA graduation risk (cross-cluster)

**Combined reasoning paths:**
1. Score persona against BOTH mechanisms simultaneously
2. For each persona: assess UFLPA traceability status independently from tariff exposure — they are not correlated
3. Key nuance: UFLPA requires FACTORY-level documentation of cotton origin to gin/raw material level. Brand compliance certifications (Nike/Adidas programmes) do NOT substitute for factory-level UFLPA documentation
4. S301 is structural once published in Federal Register (5-10+ year duration). IEEPA is reversible by executive order. Treat differently in signal horizon
5. Run RP-STRUCTURAL-CHANGE on each lever: S301 = structural, IEEPA = potentially cyclical

**Combined financing signal:**
- If UFLPA exposure: ARP advance ratio review + documentation assessment before any US-bound advance
- If S301 confirmed: reduce advance ratio on US-buyer-facing receivables; pre-position beneficiary combos (COMBO-003 IN, COMBO-009 PK) for diverted US buyer spend

---

## CLUSTER-EU-MARKET-ACCESS

**Root cause:** EU market access differential shifting across source countries

**Member events:**
- EVT-REGULATION (subtype: `csddd_scope_expand`, `reach_update`, `gpsr_enforcement`)
- EVT-TARIFF (subtype: `new_fta`, `gsp_graduation`, `gsp_suspension`)
- EVT-MARKET-SHIFT (subtype: `tariff_driven_diversion`, `buyer_country_shift`)

**Scope — Alice's recommended expansion:**
This cluster should explicitly include Bangladesh EU trade (LDC graduation, EBA status) alongside the India-UK FTA and Cambodia CSDDD exposure. Analysing only the India FTA misses the observable sourcing shift dynamic where BD's EU duty-free access is simultaneously under pressure.

**Three dimensions of EU market access:**

| Dimension | Events | Key question |
|---|---|---|
| Regulatory access | CSDDD, REACH, GPSR | Can the supplier's product enter EU market compliantly? |
| Tariff access | FTA, GSP, EBA | What duty rate applies to the supplier's goods? |
| Buyer preference | Market shift, sourcing diversion | Is the buyer actively reallocating EU PO spend? |

**Why combine:**
A sourcing shift from BD → India for EU buyers is NOT just about the India-UK FTA. It's driven simultaneously by: BD's LDC graduation risk (EBA ending), India's FTA duty reduction, and CSDDD compliance capability differentials. Running each event separately produces fragmented signals. Combined, the full sourcing reallocation logic is visible.

**Compare across:**
- **Bangladesh** — EU EBA duty-free at risk post-LDC graduation; CSDDD compliance moderate
- **India** — FTA removes 8-12% duty disadvantage; GOTS/organic = CSDDD documentation head start
- **Cambodia** — EU EBA dependent; CSDDD compliance low; dual-market risk (EU + US)
- **Turkey** — Already at 0% EU duty (Customs Union); CSDDD exposure varies by buyer

**Primary affected combos:**
- COMBO-002 (Bangladesh CMT) — EBA graduation risk + CSDDD compliance gap
- COMBO-003 (India Large Vertical) — FTA beneficiary + CSDDD advantage (GOTS)
- COMBO-005 (Turkey Denim) — CSDDD pressure from direct EU buyers
- COMBO-012 (Cambodia) — Highest EU market access risk (EBA dependent, low compliance)
- COMBO-006 (Vietnam FDI) — EU secondary; FTA may not benefit VN as much as India

**Combined reasoning paths:**
1. Score each combo against ALL three dimensions of EU access simultaneously
2. A combo that is strong on tariff access but weak on regulatory compliance = fragile EXPAND signal
3. Buyer behaviour question is essential: buyer drives timeline, not regulation. Ask: "Have any EU buyers communicated new programme requirements for the next 24 months?"
4. Apply RP-STRUCTURAL-CHANGE: EBA graduation = structural (irreversible once enacted); individual buyer questionnaire = cyclical (buyer can change requirements)
5. Apply RP-SOURCSHIFT-01: buyer reallocation takes 12-24 months regardless of tariff change — pre-position accordingly

**Important correction (Alice — Event B):**
- "Asian competitors cannot provide ESPR sustainability data" → NOT a valid KB assertion. ASEAN + China + BD suppliers already report to HIGG FEM, HIGG FSLM, ZDHC, and Carbon metrics for major buyers. The data capability gap, if any, must be verified at runtime, not assumed.
- "Factory HIGG/GOTS certification → GSP+ pathway" → **LOGICAL ERROR.** GSP+ is a country-level trade preference scheme dependent on government ratification of international conventions. Individual factory certifications (HIGG FEM, GOTS, Better Work) do NOT create a GSP+ pathway. Remove from any BD materials.
- "CSDDD 2029 extension = false relief window" → treat as reasoning HYPOTHESIS to test, not as established fact. Depends entirely on buyer requirements and timeline. Ask buyers directly.
- "24-month head start for factories maintaining compliance investment" → no evidence for specific figure. Remove from KB; use open question format instead.

**Buyer-driven question (Alice's addition — mandatory for this cluster):**
> "Have any of your major EU buyers indicated that future business allocation, supplier ranking, or programme participation will depend on traceability, environmental reporting, or sustainability-performance improvements over the next 24 months?"

**Combined financing signal:**
- Regulatory compliance cost → PRIN-COMPLIANCE-COST → ESG Finance eligibility check
- Tariff duty removal → PRIN-PRODUCT-TARIFF → ARP + OBF pre-positioning for volume acceleration
- Sourcing shift → PRIN-SUPPLIER-RESILIENCE → identify winning vs losing combos; pre-position winners

---

## How to Run a Combined Cluster Analysis

When both cluster events are simultaneously active:

```
STEP 1: Identify which cluster(s) are active
  → Check event types against CLUSTER-US-DECOUPLING and CLUSTER-EU-MARKET-ACCESS

STEP 2: Score personas against ALL member event types
  → Run entity location and tag overlap for each event in the cluster
  → Union the matched personas across all events
  → For each persona: record which events produced a match and at what overlap score

STEP 3: Compute combined relevance
  → Sum relevance scores across member events per persona
  → Persona appearing in multiple cluster events = higher combined impact

STEP 4: Apply cluster-level reasoning paths
  → See "Combined reasoning paths" sections above
  → Apply relevant overlay rules (RP-STRUCTURAL-CHANGE, RP-WINDOW, RP-PEER-FAILURE as applicable)

STEP 5: Generate combined questions + insights
  → Questions must address ALL levers, not just one
  → Insight must frame the root cause, not just each individual event
  → Runtime web search provides actual figures (volumes, rates, timelines)

STEP 6: Match solutions
  → See SOLUTIONS.md for financing product recommendations
  → Combined cluster may activate multiple products across levers
```

---

## Pending Combined Analyses (POC)

| Cluster | Status | Notes |
|---|---|---|
| CLUSTER-US-DECOUPLING (D+F) | ⏳ PENDING | Alice: combine Event D (UFLPA) + Event F (IEEPA/S301) — generate combined questions + insights |
| CLUSTER-EU-MARKET-ACCESS (B+C+BD EU Trade) | ⏳ PENDING | Alice: combine Event B (CSDDD) + Event C (India-UK FTA) + BD EBA graduation — compare with Cambodia |

---

## Reviewed Correlated Pairs

> Source: correlated-event-combinations.md | Purpose: Documents expert-reviewed event pairs/triples that must run as combined analyses under RP-EVT-CORRELATED-PAIR
> Created: 2026-07-15 | Source: Alice expert review (Jerri relay 2026-07-15)

---

#### Combination 1: India-UK FTA + BD EU Duty-Free

**Status:** PENDING — needs formal S1 run
**Recommended by:** Alice (expert review, 2026-07-15)

#### Event Pair
- India-UK FTA: India gains preferential UK market access
- BD EU Duty-Free: Bangladesh EU duty-free access under EBA/GSP

#### Why Combine?
Alice: "combine to look at the duty free to EU out from BD instead of only focus in India. Reason — this gives more insight on observable sourcing shifts, buyer behavior, and financing demand."

Both are EU buyer sourcing diversification policy signals — they affect which origins gain preferential EU/UK access and therefore which face displacement.

#### Combined Read Approach
1. Run as ONE event: "EU/UK Buyer Sourcing Policy Shifts — which origins gain access, which lose it, what is the financing demand signal?"
2. Compare COMBO-003 (India woven) and COMBO-002 (BD CMT) simultaneously
3. Reference Cambodia CSDDD as counterpoint (KH losing EBA preferential access = negative comparator)
4. Apply RP-EVT-SEGMENT-BIFURCATE — verify same segment or bifurcation

#### Relationship Type: AMPLIFYING
- India gains UK market access + BD retains EU duty-free → both push EU buyer diversification from CN
- Combined = faster buyer sourcing shift away from CN toward alternatives
- Air8 signal: China apparel (COMBO-004, COMBO-005) face accelerated EU buyer off-shoring pressure

---

#### Combination 2: Event D (UFLPA) + Event F (IEEPA/Section 301)

**Status:** PENDING — needs combined S1 run + combined questions
**Recommended by:** Alice (expert review, 2026-07-15)

#### Event Pair
- Event D: UFLPA — US import ban on goods with China-linked forced labor inputs
- Event F: IEEPA/Section 301 — US tariff on China-origin goods as cost penalty

#### Why Combine?
Alice: "Both UFLPA and IEEPA/Section 301 have the same root cause: US decoupling from Chinese supply chains, just through two different policy levers."
- IEEPA/Section 301 = cost penalty (tariff)
- UFLPA = access denial (import ban)

#### Combined Read: "US Decoupling — Dual Policy Lever (Tariff + Import Ban)"

Combined questions set (per Alice):
- Q1: For US-bound CN factories — have buyers signaled origin shift intent, or locked in by certification barriers?
- Q2: For BD/VN/KH factories with US exposure — are buyers using both levers simultaneously to pressure sourcing shift?
- Q3: For US buyers — are S301 and UFLPA treated as SEPARATE compliance tracks requiring separate documentation?
- Q4: For Air8 — does UFLPA detention create disputed/unpayable receivable? What is the advance risk protocol?

#### Relationship Type: AMPLIFYING
- S301 raises cost: CN factories lose price competitiveness
- UFLPA creates access risk: CN factories face border detention even for compliant production
- Combined = no rebuttal available — tariff cannot be absorbed AND ban cannot be cleared if documentation gaps exist

#### Key Difference from Standalone
- Standalone S301: cost problem only
- Standalone UFLPA: access problem only
- Combined: cost + access simultaneously

### Air8 Protocol (from COMBO-002 nuances)
> "US Section 301 and UFLPA operate as SEPARATE legal tracks — a shipment can face both simultaneously. BD/VN/KH factories must have SEPARATE documentation for each. Air8 must NOT advance on US-bound shipments without both clearances confirmed."

---

#### Combination 3: Event B (CSDDD) + Event C + BD EU Trade

**Status:** PENDING — needs combined S1 run
**Recommended by:** Alice (expert review, 2026-07-15)

#### Event Triple
- Event B: CSDDD — EU buyer compliance demands on supply chain
- Event C: [EU regulatory — to be confirmed from KB event taxonomy]
- BD EU Trade: Bangladesh EU duty-free access

#### Why Combine?
Alice: "Event B + C + BD EU Trade — these all affect EU apparel sourcing policy; combined shows cumulative compliance + trade access effect."

All three create stacked EU buyer sourcing policy environment: CSDDD + Event C = regulatory burden stack; BD EU Trade = competitive advantage for BD. Combined: EU buyers face increased regulatory burden while BD retains market access advantage.

#### Relationship Type: AMPLIFYING (stacked regulatory + trade policy)
- CSDDD + Event C = regulatory burden increase
- BD EU Trade = competitive advantage retention
- Net: EU buyer reliance on BD increases despite compliance cost

---

### Correlated Pair Metadata

| Combination | Relationship | Status | Priority |
|---|---|---|---|
| India-UK FTA + BD EU Duty-Free | AMPLIFYING | PENDING | HIGH |
| Event D (UFLPA) + Event F (IEEPA/S301) | AMPLIFYING | PENDING | HIGH |
| Event B (CSDDD) + Event C + BD EU Trade | AMPLIFYING (stacked) | PENDING | MEDIUM |

## Related

- [EVENT-TYPES.md](EVENT-TYPES.md) — Event taxonomy; correlated pair vocabulary
- [EVENT-PRINCIPLES.md](../principles/EVENT-PRINCIPLES.md) — RP-EVT-CORRELATED-PAIR principle
- [BRAIN-CHAIN.md](../flows/BRAIN-CHAIN.md) — Brain chain step 3b for correlated event detection
- [REASONING-FLOW.md](../flows/REASONING-FLOW.md) — Reasoning flow step 3b for correlated event check
