---
type: pain-point
id: PP-ESG-002
---
# PP-ESG-002: Buyer ESG Requirements Escalating

## Description
EU and US buyers demanding more ESG data each year — Higg Index, ZDHC, SLCP, Sedex, etc. Compliance cost grows while financing terms don't improve.

## Trigger
`buyer = [fast_fashion_EU] AND year >= 2025`

## Cascading Impacts
- → Supplier diverts cash from production to compliance → [[universal/PP-001-cashflow-gap]] amplified
- → Smaller suppliers may fail to meet requirements → lose buyer

## ESG References
- [[../esg-standards/ESG-HIGG]]
- [[../esg-standards/ESG-ZDHC]]

## Regulation Reference
- [[../regulations/REG-CSDDD]]

## Related

- [NODE-compliance-social.md](../../layer-2/nodes/NODE-compliance-social.md) — Buyer ESG code of conduct requirements
- [PP-ESG-001-credentials-not-monetized.md](PP-ESG-001-credentials-not-monetized.md) — Supplier credential gap driving the escalation risk
- [ESG-C2C.md](../../layer-2/esg-standards/ESG-C2C.md) — C2C certification as premium ESG credential
- [ESG-ZDHC.md](../../layer-2/esg-standards/ESG-ZDHC.md) — ZDHC as buyer-required chemical management standard
