---
type: pain-point
id: PP-ESG-001
---
# PP-ESG-001: ESG Credentials Not Monetized

## Description
Supplier has strong ESG profile (GOTS, C2C, ROC, solar, women employment) but financing terms don't reflect this. Missing opportunity for IFC-eligible or ESG-linked pricing.

## Trigger
`supplier.certifications >= 3 AND financing ≠ ESG_linked`

## Cascading Impacts
- → No financial incentive to invest further in ESG
- → Competitive gap widens vs peers who do get ESG pricing

## Products That Help
- [[layer-2-entities/financing-products/PROD-ESG-FINANCING]] — 10–25 bps discount if IFC criteria met

## ESG Reference
- [[../esg-standards/ESG-IFC]]
- [[../esg-standards/ESG-GOTS]]

## Affected Combos
- [[../personas/COMBO-003-india-large-vertical-integrator]]
- [[../personas/COMBO-008-india-organic-cotton-medium]]

## Related

- [NODE-compliance-social.md](../../layer-2/nodes/NODE-compliance-social.md) — ESG/social compliance credentials
- [PP-ESG-002-buyer-esg-escalating.md](../pain-points/esg/PP-ESG-002-buyer-esg-escalating.md) — Buyer ESG demand as driver of credential urgency
- [ESG-FAIRTRADE.md](../../layer-2/esg-standards/ESG-FAIRTRADE.md) — Fairtrade certification as monetizable credential
- [ESG-HIGG.md](../../layer-2/esg-standards/ESG-HIGG.md) — Higg Index as ESG measurement standard
