---
type: pain-point
id: PP-007
---

# PP-007: Dilution / Buyer Deductions

## Description
Buyer deducts amounts from invoice payment (chargebacks, markdown allowances, quality claims,
compliance penalties). Dilution rate = % of invoice not paid in full.

## Trigger Conditions
- buyer = [US_mass_market | US_department]

## Intensity Factors
- buyer = Walmart/Target → dilution 3-8%
- buyer = department_store (Macy's, Nordstrom) → dilution 5-10%
- buyer = fast_fashion EU → dilution 2-5% (lower)

## Cascading Impacts
→ Air8 advance ratio must account for dilution → lower advance = less cash to supplier
→ If persistent → supplier margin erodes → scorecard impacts
→ If spike → investigate quality issue or buyer policy change

## Affected Personas
[[personas/COMBO-001-south-asian-small-knit]], [[personas/COMBO-003-india-large-vertical-integrator]],
[[personas/COMBO-006-vietnam-fdi-knit]], [[personas/COMBO-009-pakistan-home-textile]]

## Data Entities
- [[data-entities/ENTITY-Buyer]] (dilution_ratio)
- [[data-entities/ENTITY-Invoice]] (deduction_history)
- [[data-entities/ENTITY-Facility]] (advance_ratio)

## Air8 Operational Impact
Dilution data feeds into advance ratio calculation. Persistent dilution signals
quality or relationship risk — monitor closely.

## Related

- [PRINCIPLES.md](../principles/PRINCIPLES.md) — Dilution risk reasoning; RP-DILUTION principle
- [NODE-buyer-standing.md](../../layer-2/nodes/NODE-buyer-standing.md) — Buyer financial health as dilution risk driver
- [PP-003-buyer-concentration.md](PP-003-buyer-concentration.md) — Buyer concentration as dilution amplifier
