---
type: pain-point
id: PP-002
---

# PP-002: Financing Cost Burden

## Description
Cost of current financing (bank LC, OD, informal loans) consumes a significant portion of
already-thin margins. For garment suppliers with 8-12% margins, a 3-5% financing cost is
25-60% of profit.

## Trigger Conditions
- financing = [bank_LC | bank_OD | informal_loans]
- Intensity increases with: higher rate, thinner margin, larger revenue

## Intensity Factors
- bank_rate > 10% AND margin < 10% → CRITICAL
- bank_rate > 15% (Pakistan, India OD) → CRITICAL
- collateral_required = TRUE → additional opportunity cost

## Quantification
`annual_finance_cost = outstanding_balance × rate × (avg_days_outstanding / 365)`
`savings_vs_air8 = annual_finance_cost − (outstanding_balance × air8_rate × same_period)`

Example: $30M revenue, 30% utilization, bank 12% vs Air8 ~6% → **saves $540K/year**

## Cascading Impacts
→ thin margins → no capex investment → aging equipment → quality drops
→ collateral trapped → can't use asset for other business investment
→ bank freezes credit line during macro downturn → sudden liquidity crisis

## Affected Personas
[[personas/COMBO-002-bangladesh-bank-lc]], [[personas/COMBO-004-china-medium-woven]],
[[personas/COMBO-005-turkey-denim-specialist]], [[personas/COMBO-007-indonesia-family-run]],
[[personas/COMBO-009-pakistan-home-textile]], [[personas/COMBO-014-india-small-woven]]

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-ARP]] (cheaper than bank LC/OD)
- [[layer-2-entities/financing-products/PROD-SMARTWALLET]] (visibility into cost)

## Country Pain Points Amplifying This
- [[pain-points/country/PP-IN-002-bank-od-cost]] (India 12-18%)
- [[pain-points/country/PP-TR-001-lira-hyperinflation]] (Turkey bank instability)
- [[pain-points/country/PP-PK-001-energy-crisis]] (Pakistan 15-22%)

## Data Entities
- [[data-entities/ENTITY-Supplier]] (bank_rate, margin)
- [[data-entities/ENTITY-Facility]] (pricing)

## Related

- [PP-001-cashflow-gap.md](PP-001-cashflow-gap.md) — Financing cost as a component of cashflow gap
- [PROD-DDP.md](../../layer-2/products/PROD-DDP.md) — DDP as cost-reduction financing product
- [PROD-ESG-FINANCING.md](../../layer-2/products/PROD-ESG-FINANCING.md) — ESG financing as lower-cost alternative
