---
type: pain-point
id: PP-004
---

# PP-004: Scalability Constraint

## Description
Supplier has buyer demand exceeding their working capital capacity. They must reject orders
because bank won't increase credit limit fast enough.

## Trigger Conditions
- growth_stage = expanding
- AND bank_facility_utilization > 80%
- AND new_buyer_added OR existing_buyer_volume_increased

## Intensity Factors
- rejected_orders > 2 in past year → HIGH
- revenue_growth > 20% YoY but bank limit unchanged → HIGH

## Quantification
`lost_revenue = sum of rejected order values`
`opportunity_cost = lost_revenue × margin`

## Cascading Impacts
→ rejected orders → buyer finds alternative supplier → permanent revenue loss
→ repeated rejection → buyer de-lists supplier → relationship destroyed
→ supplier overstretches to accept orders → quality/delivery suffers → claims

## Affected Personas
[[personas/COMBO-001-south-asian-small-knit]], [[personas/COMBO-006-vietnam-fdi-knit]],
[[personas/COMBO-008-india-organic-cotton-medium]], [[personas/COMBO-014-india-small-woven]]

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-ARP]] (scalable facility — no fixed LC cap)
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]]

## Data Entities
- [[data-entities/ENTITY-Facility]] (utilization)
- [[data-entities/ENTITY-Order]] (declined_count)
- [[data-entities/ENTITY-Buyer]] (order_volume_trend)

## Related

- [PRINCIPLES.md](../principles/PRINCIPLES.md) — RP-SCALABILITY principle; scalability assessment method
- [PP-EXPAND-002-missing-product-coverage.md](../pain-points/expansion/PP-EXPAND-002-missing-product-coverage.md) — Product gap as scalability constraint
- [PROD-POOL.md](../../layer-2/products/PROD-POOL.md) — Pool financing to relieve scalability constraints
