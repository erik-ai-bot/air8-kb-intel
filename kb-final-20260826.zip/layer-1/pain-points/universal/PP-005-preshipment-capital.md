---
type: pain-point
id: PP-005
---

# PP-005: Pre-Shipment Capital Gap

## Description
Supplier needs cash BEFORE production to buy raw materials, pay workers, book logistics.
Bank LC covers post-shipment but not pre-shipment. Self-funding limits scale.

## Trigger Conditions
- type = [manufacturer_FOB | vertical_integrator]
- AND product = [woven | denim | organic] (longer production cycle)
- AND revenue > $10M (eligible for OBF)

## Intensity Factors
- vertical_integrator → CRITICAL (buying cotton from farmers = 60-90 days before production even starts)
- fabric_pre_payment > 30% of order value → HIGH
- multiple_orders_concurrent → compounds

## Quantification
`pre_shipment_need ≈ annual_revenue × (pre_production_days / 365) × 0.4`

## Cascading Impacts
→ can't buy fabric on time → production delayed → late shipment → OTD drops → scorecard drops
→ uses personal savings → personal financial stress → irrational business decisions
→ takes informal loan at 2-5% per month → margin destroyed

## Affected Personas
[[personas/COMBO-002-bangladesh-bank-lc]], [[personas/COMBO-003-india-large-vertical-integrator]],
[[personas/COMBO-008-india-organic-cotton-medium]], [[personas/COMBO-013-multi-country-group]],
[[personas/COMBO-014-india-small-woven]]

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-PRESHIP-OBF]] (>$10M revenue, existing ARP client)
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] (>$1M revenue, existing ARP client 6mo+)

## Data Entities
- [[data-entities/ENTITY-Order]] (raw_material_cost, advance_payment)
- [[data-entities/ENTITY-Commodity]] (cotton_price)

## Related

- [PROD-PRESHIP-RT2C.md](../../layer-2/products/PROD-PRESHIP-RT2C.md) — RT2C as preshipment financing product
- [PROD-PRESHIP-OBF.md](../../layer-2/products/PROD-PRESHIP-OBF.md) — OBF as preshipment alternative
- [PP-001-cashflow-gap.md](PP-001-cashflow-gap.md) — Preshipment capital need as cashflow gap component
