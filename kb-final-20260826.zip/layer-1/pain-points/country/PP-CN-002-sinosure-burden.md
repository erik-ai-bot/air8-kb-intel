---
type: pain-point
id: PP-CN-002
---

# PP-CN-002: China Sinosure Administration Burden

## Description
Monthly paper declaration by 15th. Miss deadline = coverage VOID for that month. CFO team
spends 3+ days/month on insurance paperwork alone.

## Trigger
country = CN AND insurance = Sinosure

## Cascading Impacts
→ missed declaration → lost coverage → Air8 cannot fund → supplier has cash gap
→ admin overhead = 3+ days/month per CN client

## Affected Personas
[[personas/COMBO-004-china-medium-woven]]

## Air8 Operational Note
Air8 Ops can manage Sinosure declaration on behalf of supplier — this is a service
differentiator. Deadline: 15th of each month. No exceptions.

## Related Compliance
- [COMP-SINOSURE.md](../pain-points/compliance/COMP-SINOSURE.md) — Sinosure premium burden
