---
type: pain-point
id: PP-IDN-001
---
# PP-IDN-001: Indonesia Rupiah Volatility

## Description
IDR/USD swings 5–10% per quarter. Supplier costs in IDR, revenue in USD. If IDR strengthens unexpectedly, margin is squeezed.

## Trigger
`country = ID`

## Linked Data
- fx.idr_usd

## Affected Combos
- [[../personas/COMBO-007-indonesia-family-run]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]]

## Related

- [Indonesia.md](../../layer-2/countries/Indonesia.md) — Indonesia country profile, rupiah dynamics, export dependency
- [PP-IN-002-bank-od-cost.md](PP-IN-002-bank-od-cost.md) — India bank credit contraction as parallel FX/cost pressure
- [NODE-compliance-trade.md](../../layer-2/nodes/NODE-compliance-trade.md) — FX volatility impact on trade finance pricing
