---
type: pain-point
id: PP-CN-003
---

# PP-CN-003: China Hengqin Capacity Constraints

## Description
Air8 Hengqin entity has regulatory caps: single company ≤40% portfolio, group ≤50%,
total balance ≤10× registered capital. Large CN clients may hit these caps.

## Trigger
country = CN AND facility_size_request > threshold

## Cascading Impacts
→ may limit facility size for large CN clients
→ need Air8 SG entity as supplement for overflow capacity

## Affected Personas
[[personas/COMBO-004-china-medium-woven]]

## Constraints Detail
- Single company: ≤40% of total Hengqin portfolio
- Group: ≤50% of total Hengqin portfolio
- Total factoring balance: ≤10× registered capital

## Data to Monitor
- hengqin.current_portfolio
- hengqin.registered_capital

## Related Compliance
- [COMP-SAFE.md](../pain-points/compliance/COMP-SAFE.md) — SAFE registration complexity
