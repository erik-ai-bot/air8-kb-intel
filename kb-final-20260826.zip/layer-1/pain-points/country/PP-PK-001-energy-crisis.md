---
type: pain-point
id: PP-PK-001
---
# PP-PK-001: Pakistan Energy Crisis

## Description
Frequent power outages increase production cost by 10–20% (generator fuel costs). Compounds already-high financing costs of 15–22% bank rate. Among the most severe operational pain points in Air8 target markets.

## Trigger
`country = PK`

## Cascading Impacts
- → Production cost rises → margin compressed
- → [[universal/PP-002-financing-cost]] amplified (double squeeze: energy + financing)
- → Factory may reduce production hours → capacity under-utilisation

## Affected Combos
- [[../personas/COMBO-009-pakistan-home-textile]]
- [[../personas/COMBO-001-south-asian-small-knit]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]] (offshore USD financing, far cheaper than local 15–22%)
- [[layer-2-entities/financing-products/PROD-POOL]]

## Related

- [Pakistan.md](../../layer-2/countries/Pakistan.md) — Pakistan country profile, energy infrastructure, textile competitiveness
- [PP-BD-001-wage-hike.md](PP-BD-001-wage-hike.md) — Bangladesh concurrent labour cost pressure; energy crisis differentiates PK
- [PP-TR-001-lira-hyperinflation.md](PP-TR-001-lira-hyperinflation.md) — Turkey concurrent FX instability
- [cliff-playbook.md](../playbooks/cliff-playbook.md) — Energy crisis as production continuity cliff event
