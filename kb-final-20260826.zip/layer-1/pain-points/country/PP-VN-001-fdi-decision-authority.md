---
type: pain-point
id: PP-VN-001
---
# PP-VN-001: Vietnam FDI Decision Authority

## Description
60%+ of VN garment factories are Korean or Taiwanese-owned. Local GM cannot sign financing agreement. Decision must go to parent HQ, adding 4–8 weeks to sales cycle.

## Trigger
`country = VN AND ownership = FDI`

## Cascading Impacts
- → Longer sales cycle
- → Air8 must identify and engage parent company, not local GM

## Affected Combos
- [[../personas/COMBO-006-vietnam-fdi-knit]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]] (pitched at parent HQ level)
- [[layer-2-entities/financing-products/PROD-PAYGUARD]]

## Related

- [Vietnam.md](../../layer-2/countries/Vietnam.md) — Vietnam country profile, FDI policy, decision authority structure
- [PP-BD-003-ldc-graduation.md](PP-BD-003-ldc-graduation.md) — Bangladesh graduation driving VN as FDI destination
- [PP-CN-001-safe-complexity.md](PP-CN-001-safe-complexity.md) — China SAFE complexity as alternative VN positioning driver
