---
type: pain-point
id: PP-TR-001
---
# PP-TR-001: Turkey Lira Hyperinflation

## Description
TRY depreciation >300% since 2020. Cost base in TRY explodes (wages, energy, raw materials) while revenues are in EUR/USD. Margin evaporates monthly.

## Trigger
`country = TR`

## Cascading Impacts
- → [[universal/PP-002-financing-cost]] amplified
- → Bank credit lines withdrawn
- → [[universal/PP-004-scalability-constraint]] — can't take new orders
- → Supplier may close or relocate

## Linked Data
- fx.try_usd, fx.try_eur

## Affected Combos
- [[../personas/COMBO-005-turkey-denim-specialist]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]] (USD-denominated — natural hedge)
- [[layer-2-entities/financing-products/PROD-POOL]]

## Related

- [Turkey.md](../../layer-2/countries/Turkey.md) — Turkey country profile, lira dynamics, inflation history
- [PP-TR-002-bank-credit-contraction.md](PP-TR-002-bank-credit-contraction.md) — Concurrent bank credit tightening
- [PP-IN-003-inr-depreciation.md](PP-IN-003-inr-depreciation.md) — EM FX depreciation as parallel pattern
- [cliff-playbook.md](../playbooks/cliff-playbook.md) — Lira crisis as disbursement timing cliff event
