---
type: pain-point
id: PP-BD-002
---

# PP-BD-002: Bangladesh Political Instability

## Description
Hartals (strikes), political protests disrupt 15-20 production days/year. Workers can't reach
factories. Raw material delivery blocked.

## Trigger
country = BD

## Cascading Impacts
→ production delays → OTD drops → scorecard drops → financing terms worsen → vicious cycle
→ buyers shift orders to Vietnam/India long-term → revenue at risk

## Affected Personas
[[personas/COMBO-002-bangladesh-bank-lc]], [[personas/COMBO-001-south-asian-small-knit]]

## Amplifies
- [[pain-points/universal/PP-001-cashflow-gap]] (delayed shipments delay payment)
- [[pain-points/universal/PP-004-scalability-constraint]]

## Bangladesh Banking Context (2025)
NPL ratio surged to 35.73% by Sep 2025. Banks tightening credit. Many factories can't get
credit line increase despite growing orders. This amplifies the political instability impact
on financing access.

## Related

- [Bangladesh.md](../../layer-2/countries/Bangladesh.md) — Bangladesh country profile, political risk assessment
- [PP-BD-001-wage-hike.md](PP-BD-001-wage-hike.md) — Wage pressure concurrent with political instability
- [PP-BD-003-ldc-graduation.md](PP-BD-003-ldc-graduation.md) — LDC graduation as political/economic cliff event
- [cliff-playbook.md](../playbooks/cliff-playbook.md) — Political instability as cliff event for disbursement timing
