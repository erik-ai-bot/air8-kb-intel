---
type: pain-point
id: PP-IN-002
---
# PP-IN-002: India Bank OD High Cost

## Description
Bank OD rates for garment manufacturers: 12–18% p.a., often with personal guarantee required. Among the highest financing costs in Air8 target markets.

## Trigger
`country = IN AND financing = bank_OD`

## Intensity
CRITICAL when margin < 10%

## Cascading Impacts
- → [[PP-002-financing-cost]] at severe intensity
- → High cost erodes margin → no capex investment → aging equipment → quality drops

## Linked Knowledge
- [[../dimensions/DIM-1-country]] (India section)
- [[../dimensions/DIM-7-current-financing]]

## Affected Combos
- [[../personas/COMBO-003-india-large-vertical-integrator]]
- [[../personas/COMBO-008-india-organic-cotton-medium]]
- [[../personas/COMBO-014-india-small-woven]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]] — SOFR+4% significantly cheaper than 12–18% OD

## Related

- [India.md](../../layer-2/countries/India.md) — India country profile, RBI policy, bank credit environment
- [PP-IN-001-gst-refund-delay.md](PP-IN-001-gst-refund-delay.md) — Concurrent working capital pressure from GST delays
- [PP-IN-003-inr-depreciation.md](PP-IN-003-inr-depreciation.md) — INR depreciation compounding credit cost
- [PP-IDN-001-rupiah-volatility.md](PP-IDN-001-rupiah-volatility.md) — EM FX volatility as parallel concern
