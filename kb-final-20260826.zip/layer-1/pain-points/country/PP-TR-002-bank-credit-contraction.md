---
type: pain-point
id: PP-TR-002
---
# PP-TR-002: Turkey Bank Credit Line Contraction

## Description
Turkish banks reducing credit exposure to textile sector amid macro instability. Factories losing existing facilities without replacement.

## Trigger
`country = TR AND year >= 2023`

## Cascading Impacts
- → [[universal/PP-004-scalability-constraint]] critical
- → Supplier may close or relocate production

## Affected Combos
- [[../personas/COMBO-005-turkey-denim-specialist]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]]

## Related

- [Turkey.md](../../layer-2/countries/Turkey.md) — Turkey country profile, BDDK banking regulation
- [PP-TR-001-lira-hyperinflation.md](PP-TR-001-lira-hyperinflation.md) — Lira instability as driver of credit contraction
- [NODE-compliance-trade.md](../../layer-2/nodes/NODE-compliance-trade.md) — Trade finance availability under credit contraction
