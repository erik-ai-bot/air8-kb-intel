---
type: pain-point
id: PP-HG-007
---
# PP-HG-007: CE/UL Certification Barrier — Origin Shift

## Description
CE/UL certification is the HIGHEST barrier to origin shift in the hardgoods space. Certification timelines: CE (EMC + LVD) = 2-3 weeks; UL listing = 2-4 months (fast-track 3-4 weeks with pre-certified components and identical design).

This is DOUBLE-EDGED:
1. **Sticky factories:** CN lighting factories are sticky — buyers cannot walk away without 6-month re-certification delay
2. **Slow recovery risk:** If a factory IS losing customers, the same 6-month delay applies before replacement volumes arrive from alternative origins

## Trigger Conditions
- Factory is CN-based decorative lighting
- T1 copper tariff or Section 301 event is active AND US-bound revenue >35%
- Buyer signals origin shift intent OR begins re-certification at alternative origin

## Certification Timeline Reference
| Certification | Market | Standard | Typical Timeline | Fast-Track |
|---|---|---|---|---|
| CE (EMC + LVD) | EU | Electromagnetic compatibility + Low Voltage Directive | 2-3 weeks | 2-3 weeks |
| UL listing | US | UL 1598 (luminaires) | 2-4 months | 3-4 weeks (pre-certified components) |
| FCC Part 15 | US (smart) | Radio emissions | +2-4 weeks on UL | — |
| CE RED | EU (smart) | Radio Equipment Directive | +2-4 weeks on CE | — |

## Signal Flip Conditions
- IF buyer has begun VN/IN CE/UL re-certification AND confirmed US book → finite tenure = DO NOT expand multi-year facilities
- IF confirmed US book + no re-cert signals → CONDITIONAL EXPAND (short tenor only)
- IF EU book >60% AND CE portfolio active → EXPAND on EU book

## Cascading Impacts
→ VN/CE/IN re-certification complete → CN US book declines 6-12 months later → Air8 US book shrinks
→ Air8 has 6-12 month window on confirmed US book → maximize short-term ARP utilization before decline

## Affected Personas
[[layer-2-entities/personas/hardgoods/COMBO-HG-004-china-decorative-lighting]] (primary)

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-ARP]] (short-tenor only on confirmed US book; DO NOT issue multi-year facilities)
- [[layer-2-entities/financing-products/PROD-SMARTWALLET]] (monitor certification status and buyer re-cert signals)
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] (pre-shipment on confirmed EU orders; EU book is the growth engine)

## Compliance Framework
- [[layer-2-entities/regulations/REG-CE-LVD-EMC]] (EU — CE marking)
- [[layer-2-entities/regulations/REG-UL-1598]] (US — UL luminaire listing)
- [[layer-2-entities/regulations/REG-FCC-PART15]] (US — smart lighting radio emissions)

## Data Entities
- [[data-entities/ENTITY-Buyer]] (buyer_geo, US_revenue_pct, re-cert_signals)
- [[data-entities/ENTITY-RawMaterial]] (copper_bom_pct — drives margin impact of tariff)

## Source
COMBO-HG-004-china-decorative-lighting.md | Expert verified: Josephine Cheung 2026-07-16

## Related

- [REG-CE-LVD-EMC.md](../../layer-2/regulations/REG-CE-LVD-EMC.md) — CE marking requirements for EU market
- [REG-FCC-PART15.md](../../layer-2/regulations/REG-FCC-PART15.md) — FCC Part 15 for US market
- [CAT-HG-06-lighting.md](../../layer-2/products/hardgoods/CAT-HG-06-lighting.md) — Lighting as primary CE/UL-exposure category
- [PP-HG-005-reach-rohs-compliance.md](PP-HG-005-reach-rohs-compliance.md) — Adjacent compliance barrier for same markets
