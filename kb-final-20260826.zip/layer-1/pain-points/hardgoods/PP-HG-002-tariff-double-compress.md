---
type: pain-point
id: PP-HG-002
---
# PP-HG-002: Copper Tariff Double Compression (US-bound CN metal artware)

## Description
Double compression for US-bound true brass artware factories: (1) T1-type copper tariff increases input cost directly — no lag, no pass-through buffer; (2) Section 301 25%+ duty on finished CN metal artware at US border. Both buying and selling at structural disadvantage vs India Moradabad.

**CRITICAL material distinction:** This ONLY applies to TRUE BRASS (60-70% copper). Zamak factories (<1% copper) are NOT exposed to copper tariff on the input side — misidentifying zamak as brass is a critical error.

## Trigger Conditions
- Factory produces true brass (confirmed copper content 60-70%) AND sells to US market
- T1 copper tariff event is active
- Commercial term: DDP (factory bears import duty) or FOB + confirmed US destination

## Signal Flip Conditions
- IF material = true_brass AND buyer_geo = US → signal = DO_NOT_EXPAND (double compression)
- IF material = zamak → copper tariff signal does NOT apply; reassess from zinc pricing only
- IF material = unconfirmed → suspend all event signals; verify material first

## Cascading Impacts
→ buyer starts origin shift review → confirmed US book finite → ARP tenor should not exceed re-cert timeline
→ CN brass vs India Moradabad margin gap widens → US buyers actively shifting → Air8 US book shrinks
→ US-bound true brass revenue becomes at-risk → do not expand facilities against at-risk revenue

## Air8 Risk Classification

| Supplier Profile | Risk Level | Action |
|---|---|---|
| True brass / China-only / concentrated premium buyers | 🔴 HIGH | Flag: India diversification active + T1 double squeeze; enhanced monitoring |
| True brass / diversified buyer mix | 🟡 MEDIUM | Monitor India allocation trend; assess margin buffer |
| Zamak/plated decor / mass market buyers | 🟢 LOW | Stable; T1 exposure minimal; no action needed |
| Lighting supplier / China-only | 🔴 HIGH | Double compression; no geo escape; assess cash flow vs fixed cost base immediately |
| Power tools / China-only | 🟡 MEDIUM | Monitor; slower-moving than lighting or artware |

## Financing Signal (T1 Hardgoods vs Outdoor Furniture)

> **Critical distinction for ARP decisions:**

| Scenario | Volume | Cash Flow | Air8 Action |
|---|---|---|---|
| **Outdoor furniture** (sourcing shift away from CN) | 📉 Declines as buyer shifts to VN | Deteriorates | Reduce exposure; ARP tenor should track geo-shift timeline |
| **Copper hardgoods** (true brass artware, lighting) | Flat or holds (cost absorption) | 📉 Deteriorates — margin compressed | **Financing demand spikes** — suppliers need WC to bridge cost squeeze; invoice values may stay the same or rise, but margins are thinner; suppliers are more fragile |

➡️ T1 copper categories = ARP demand increases while supplier resilience decreases. This is the highest-risk financing scenario: more deals offered, but more fragile counterparties. Screen harder, not looser.

## Key Questions for Supplier Assessment

1. What is the **actual copper/alloy content** of their products? (verify via REACH G4 report or mill cert — do not accept self-labelled "brass")
2. Which **buyer channel** are they selling into? (premium buyers → India shift risk; mass market → zamak holds, lower T1 impact)
3. Is the **buyer already qualifying India** or another alternative source?
4. What is the supplier's **margin buffer** before reaching cash-flow break-even?
5. Are they exploring **material substitution** (true brass → zamak) to reduce T1 input cost?

## WIP Gate Linkage

### Brass Artware & Metal Décor
- **G1 Material Spec Sign-off** → confirms alloy at intake. True brass vs zamak identified here. If zamak confirmed, T1 signal does NOT apply — reassess entire event signal.
- **G4 REACH Heavy Metal Test** → backup confirmation of alloy composition (zamak vs true brass). Also confirms Cr VI / Pb / Cd compliance (EU requirement).
- **Air8 action:** Add alloy verification as a pre-ARP requirement; request mill cert or G4 REACH report before signal is applied.

### Lighting
- **G1 Electrical Safety Sign-off** → driver/transformer spec confirms copper component intensity
- **G3 Safety Certification (UL/CE)** → does NOT transfer on geo shift; adds 2–4 weeks re-cert time; China factories are sticky due to cert lock-in; this slows their ability to escape double compression
- **Air8 action:** Lighting double compression is the most severe among all copper categories. Monitor cash flow quarterly; don’t expand facility financing against shrinking US book.

## Affected Personas
[[layer-2-entities/personas/hardgoods/COMBO-HG-002-china-brass-artware]] (primary)
[[layer-2-entities/personas/hardgoods/COMBO-HG-004-china-decorative-lighting]] (copper in LED drivers/wiring — partial exposure)

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-ARP]] (only viable on EU/non-tariff-hit book; do NOT advance on at-risk US book)
- [[layer-2-entities/financing-products/PROD-SMARTWALLET]] (monitor buyer mix shift signals)
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] (support pre-shipment against EU-bound orders)

## Compliance Note
Verify alloy type with factory before applying signal. Request: alloy material specification, mill certificates, or third-party test report. Albright/Yellow Lead metal = environmental violation — flag and do not finance.

## Data Entities
- [[data-entities/ENTITY-RawMaterial]] (copper_content_pct, tariff_risk)
- [[data-entities/ENTITY-Buyer]] (buyer_geo, payment_terms_days)
- [[layer-2-entities/regulations/REG-TARIFF]] (US copper tariff rates)
- [[layer-2-entities/regulations/REG-UFLPA]] (if origin trace is also flagged)

## Source
COMBO-HG-002-china-brass-artware.md | Expert verified: Josephine Cheung 2026-07-16

## Related

- [PP-REG-TARIFF-001.md](../pain-points/compliance/PP-REG-TARIFF-001.md) — Tariff classification as the underlying risk
- [CAT-HG-01-home-textile-bedding.md](../../layer-2/products/hardgoods/CAT-HG-01-home-textile-bedding.md) — Home textile product category most exposed to tariff compression
- [cliff-playbook.md](../playbooks/cliff-playbook.md) — Tariff cliff as time-window trigger for disbursement timing
