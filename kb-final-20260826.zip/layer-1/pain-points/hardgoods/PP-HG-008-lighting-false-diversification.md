---
type: pain-point
id: PP-HG-008
---
# PP-HG-008: Lighting False Diversification — No Copper Geo Escape

## Description
China decorative lighting factories (and some buyers) believe moving assembly to Vietnam or India escapes the T1 copper tariff double compression. This is FALSE: LED drivers, chips, and PCBs — the copper-intensive components — remain China-sourced even when T1 assembly moves. The input cost rise travels with the component supply chain, not the assembly location.

**Result:** Geo-shifted lighting assembly provides Section 301 relief on the finished goods side only. T1 input cost pressure persists. Net relief is partial at best.

This is the highest-risk financing scenario for lighting: suppliers face cash-flow deterioration regardless of geo-shift strategy. Air8 should NOT expand exposure based solely on a supplier's claim of "we're moving to Vietnam."

## Trigger Conditions
- Lighting supplier announces production move to Vietnam or India
- Buyer approves Vietnam/India origin to "escape tariffs"
- Air8 evaluating ARP expansion for a lighting supplier citing geo-diversification as de-risking measure

## Why the Escape Fails

| Component | China-sourced? | T1 exposure | Can geo shift fix it? |
|---|---|---|---|
| LED drivers / transformers | Yes (dominant) | High | ❌ No — components still manufactured in China |
| PCB / circuit boards | Yes (dominant) | High | ❌ No — same source |
| Copper wiring / heat sinks | Yes (dominant) | High | ❌ No — same source |
| Housing / shade (aluminium, resin) | Partially shiftable | Low | ✅ Yes — these CAN move |

The housing/shade can shift, but the electrical core cannot at current supply chain maturity. Gross margin does not improve proportionally.

## Compounding Factor: Safety Cert Lock-in
UL/CE certification does NOT transfer on origin shift:
- CE re-test: 2–3 weeks
- UL re-test: up to 4 months

Buyers cannot easily switch China-certified lighting suppliers without a prolonged re-cert cycle. This creates a "trapped" dynamic: the supplier is financially stressed but the buyer cannot exit quickly. Air8 is exposed during this interim period.

## Cascading Impacts
→ Supplier claims "lower risk due to VN move" → Air8 grants expanded ARP → component cost still rising → margin still compressed → supplier cash flow deteriorates → ARP becomes stressed receivable

## Affected Personas
[[layer-2-entities/personas/hardgoods/COMBO-HG-004-china-decorative-lighting]] (primary)

## Products
- [[layer-2-entities/financing-products/PROD-ARP]] — apply with caution; do not use geo-shift as sole de-risk rationale for lighting
- [[layer-2-entities/financing-products/PROD-SMARTWALLET]] — monitor supplier cash flow vs fixed cost base quarterly

## Air8 Action
- When a lighting supplier claims Vietnam origin as T1 mitigation: verify which components are actually sourced locally vs still sourced from China
- Request BOM breakdown with component origin by value
- Do NOT expand ARP limits based solely on assembly-location shift without confirming component-level sourcing change

## Compliance Notes
- Safety cert re-validation required for any origin shift — factor into timeline risk assessment
- No REACH/UFLPA shortcut on geo shift — full compliance documentation needed for new origin

## Source
`skills/hardgoods-analytics/references/copper-tariff-market-intelligence.md` | Expert validated: Josephine Cheung 2026-07-15

## Related

- [CAT-HG-06-lighting.md](../../layer-2/products/hardgoods/CAT-HG-06-lighting.md) — Lighting product category assessment
- [COMBO-HG-004-china-decorative-lighting.md](../../layer-2/personas/hardgoods/COMBO-HG-004-china-decorative-lighting.md) — China decorative lighting persona most exposed
- [NODE-product-trend.md](../../layer-2/nodes/NODE-product-trend.md) — Product trend assessment for false diversification detection
