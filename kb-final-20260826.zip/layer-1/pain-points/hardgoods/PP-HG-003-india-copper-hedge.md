---
type: pain-point
id: PP-HG-003
---
# PP-HG-003: India Copper Hedge (T1 Tariff BENEFIT Signal)

## Description
T1 copper tariff BENEFIT signal for India Moradabad brass artware. Mechanism: US T1 copper tariff insulates Indian domestic copper producers from import competition, while simultaneously raising CN input costs — widening the cost gap between India Moradabad and CN brass in the US market.

**CRITICAL correction (Josephine 2026-07-16):** Moradabad units import copper heavily via scrap dealers — domestic Indian copper does NOT hold at scale for the cluster. The "domestic copper insulation" advantage requires per-factory verification. Do NOT assume the full cluster is insulated.

## Trigger Conditions
- T1 copper tariff event is active
- Factory is confirmed sourcing domestic Indian copper (Hindalco, Vedanta primary supply)
- Target market: US (the tariff benefit applies to US-bound goods; EU-bound goods don't get the CN-input-cost disadvantage but also don't benefit from US tariff on CN)

## Signal Application
| Factory Type | Signal | Action |
|---|---|---|
| 100% domestic Indian copper confirmed | EXPAND (US market) | Apply full T1 BENEFIT — US tariff insulation + lower US duty vs CN |
| Significant imported scrap share | CAUTION | Quantify import share; downgrade BENEFIT to partial |
| Majority imported scrap | Treat like CN | No insulation; apply standard copper tariff signal |

## Cascading Impacts
→ US buyers actively shifting from CN to India (confirmed 2026 for: metal lighting, planters, furniture bases, decorative trays, candle stands) → India book growing → ARP opportunity growing
→ Moradabad premium positioning: artisan quality tier vs CN machine-finished → sticky buyer relationships if quality confirmed

## Why Vietnam Is NOT an Effective Copper Tariff Hedge

> A common misconception: moving copper hardgoods production from China → Vietnam escapes T1.

Vietnam imports most of its copper — it does NOT have a domestic copper supply chain comparable to India’s. Moving production to Vietnam for copper-intensive products:
- Still pays import tariff on copper inputs
- Only avoids Section 301 on the output side (finished goods)
- Net result: partial relief, NOT structural insulation

**India (Moradabad) is unique** because it has domestic copper processing (Hindalco, Vedanta) that can insulate from T1 on the input side — IF the factory sources domestically. This is the key reason India is the correct diversification destination for copper artware, not Vietnam.

| Geo | Copper source | Input-side T1 relief? | Output-side US duty? | Net position |
|---|---|---|---|---|
| China | Imported | ❌ Full T1 exposure | Section 301 25%+ | 🔴 Worst |
| Vietnam | Mostly imported | ❌ Still pays | Lower (~10–25%) | 🟡 Partial |
| India (domestic copper) | Domestic | ✅ Buffered | Lower | 🟢 Best (if verified) |
| India (scrap import) | Imported scrap | 🟡 Partial | Lower | 🟡 Partial |

## Confirmed Buyer Shift Products (2026)
US premium buyers actively shifting from CN to Moradabad in these specific product types:
- Metal lighting (decorative)
- Planters / cache-pots
- Structural furniture bases
- Decorative trays
- Candle stands

**China retains edge** on: machine-produced complexity, fast turnaround, mass-volume orders.

## Affected Personas
[[layer-2-entities/personas/hardgoods/COMBO-HG-003-india-moradabad-brass-artware]] (primary)

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-ARP]] (primary — advance on growing US book with tariff insulation)
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] (pre-shipment to support production for confirmed US orders)
- [[layer-2-entities/financing-products/PROD-POOL]] (if revenue >$20M + 5+ buyers in tariff environment)

## Data Entities
- [[data-entities/ENTITY-RawMaterial]] (RM-COPPER-DOMESTIC-IND — verification_required, tariff_exposure)
- [[data-entities/ENTITY-Buyer]] (buyer_geo, US_revenue_pct)
- [[layer-2-entities/regulations/REG-TARIFF]] (US copper tariff — applies to imported copper, not domestic Indian)

## Source
COMBO-HG-003-india-moradabad-brass-artware.md | Expert verified: Josephine Cheung 2026-07-16

## Related

- [India.md](../../layer-2/countries/India.md) — India copper market, Hindalco domestic supply, scrap import dependency
- [PP-HG-002-tariff-double-compress.md](PP-HG-002-tariff-double-compress.md) — Tariff double compression as adjacent hardgoods risk
- [RM-COPPER-DOMESTIC-IND.md](../../layer-2/raw-material/RM-COPPER-DOMESTIC-IND.md) — India domestic copper supply data
- [RM-COPPER-SCRAP-IND.md](../../layer-2/raw-material/RM-COPPER-SCRAP-IND.md) — India copper scrap import data
