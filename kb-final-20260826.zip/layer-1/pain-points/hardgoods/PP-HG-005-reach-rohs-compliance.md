---
type: pain-point
id: PP-HG-005
---
# PP-HG-005: REACH/RoHS Compliance Documentation Gap

## Description
REACH/RoHS compliance documentation gap is the most common compliance failure for hardgoods exporters to EU. Lead, Cadmium, Cr6 (hexavalent chromium) in plating, surface coatings, lacquers, and dyes — EU buyers require REACH SVHC declaration per SKU + test reports per batch.

**Surface treatment adhesion failure** is the highest WIP risk gate: failures are discovered at QC stage after full production cost is sunk. A factory without a formal surface treatment approval process carries elevated advance ratio risk.

**⚠️ Albright/Yellow Lead metal** (lead-based alloy) = HIGH RISK — environmental regulatory violation. Do not finance factories using this alloy.

## Trigger Conditions
- Factory sells to EU market (REACH applies)
- Factory lacks in-house REACH testing workflow
- No proactive third-party lab relationship (SGS, Intertek, BV)

## Cascading Impacts
→ EU customs detention or buyer rejection → advance against detained shipment → working capital gap → production delay
→ Adhesion failure at QC → 100% rejection post-production → full production cost lost → buyer relationship damaged

## Affected Personas
[[layer-2-entities/personas/hardgoods/COMBO-HG-002-china-brass-artware]] (primary — lead/cadmium in plating)
[[layer-2-entities/personas/hardgoods/COMBO-HG-003-india-moradabad-brass-artware]] (secondary — Moradabad units often rely on third-party labs without proactive testing)

## Assessment Questions
- Which compliance tests do you run for EU/US buyers — REACH, RoHS, lead/cadmium?
- Who certifies your compliance — in-house lab or third-party?
- Do you test per batch or per SKU? Which lab?
- Has any batch been rejected in the past 12 months for REACH failure?
- What surface treatment approval process do you have before mass production?

## Signal Flip Conditions
- IF reach_compliance_failure_recent = true → flag CRITICAL QC; suspend expansion until clean batch report
- IF in_house_test_workflow = true AND no_recent_failures → standard advance ratio
- IF albright_yellow_lead_detected → DO NOT FINANCE; environmental regulatory violation

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-ARP]] (viable only with clean compliance history; suspend if recent failure)
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] (pre-shipment advance supports production; compliance must be confirmed before disbursement)

## Compliance Framework
- [[layer-2-entities/regulations/REG-REACH]] (primary — EU chemicals regulation)
- [[layer-2-entities/regulations/REG-GPSR]] (General Product Safety — if non-compliant product reaches market)

## Data Entities
- [[data-entities/ENTITY-Buyer]] (buyer_geo, EU_revenue_pct)
- [[data-entities/ENTITY-RawMaterial]] (REACH-relevant materials in BOM)

## Source
COMBO-HG-002-china-brass-artware.md, COMBO-HG-003-india-moradabad-brass-artware.md | Expert verified: Josephine Cheung 2026-07-16

## Related

- [PP-REG-REACH-001.md](../pain-points/compliance/PP-REG-REACH-001.md) — REACH regulation as the underlying compliance trigger
- [PP-REG-CSDDD-001.md](../pain-points/compliance/PP-REG-CSDDD-001.md) — CSDDD chemical due diligence adjacent exposure
- [CAT-HG-03-kitchen-dining.md](../../layer-2/products/hardgoods/CAT-HG-03-kitchen-dining.md) — Kitchen/dining as highest-reach-exposure category
- [NODE-compliance-product-eu.md](../../layer-2/nodes/NODE-compliance-product-eu.md) — REACH/RoHS enforcement protocol
