---
type: compliance
id: COMP-SINOSURE
---
# COMP-SINOSURE: Sinosure Administration (China-specific)

China Export Credit Insurance Corporation — used for China-entity transactions.

## Key Rule
Monthly paper declaration must be submitted by **15th of each month**. Miss deadline = coverage VOID for that month.

## Process
Air8 Ops can manage Sinosure declaration on behalf of supplier.

## Risk
Missed deadline → no coverage → Air8 cannot fund → supplier cash gap that month.

## Trigger
`country = CN AND insurance = Sinosure`

## Related Pain Point
[PP-CN-002-sinosure-burden.md](../pain-points/country/PP-CN-002-sinosure-burden.md) — Sinosure country context
