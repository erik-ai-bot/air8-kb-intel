---
type: pain-point
id: PP-REG-REACH-001
---
# PP-REG-REACH-001: REACH Chemical Non-Compliance

## Description
EU-bound products must not contain SVHC >0.1% w/w. Failure = customs detention + potential recall. ECHA updates SVHC list twice per year.

## Trigger Conditions
`market = EU AND product = [denim | chemical_finish | dyed_fabric]`

## Intensity Factors
- product = denim → HIGH
- product = children's apparel → CRITICAL
- ECHA SVHC list updated bi-annually → new substances can surprise

## Impact Chain
```
EVENT: Product tests positive for SVHC above threshold
→ IMPACT-1: Shipment stopped at EU customs
→ IMPACT-2: Buyer rejects goods → invoice disputed → dilution
→ IMPACT-3: Supplier must re-process or destroy goods (cost)
→ IMPACT-4: If DDP incoterm → Air8 as importer bears compliance risk
→ IMPACT-5: Buyer may delist supplier
```

## Who Is Affected
- **Suppliers:** TR, CN, BD, IN selling denim/chemical-treated products to EU
- **Air8:** DDP transactions where Air8 entity is importer of record

## Regulation Reference
[[../regulations/REG-REACH]]

## Affected Combos
- [[../personas/COMBO-005-turkey-denim-specialist]]
- [[../personas/COMBO-004-china-medium-woven]]
- [[../personas/COMBO-009-pakistan-home-textile]]

## Related

- [REG-REACH.md](../../layer-2/regulations/REG-REACH.md) — Full REACH substance list, SVHC entries, Annex XVII restrictions
- [NODE-compliance-product-eu.md](../../layer-2/nodes/NODE-compliance-product-eu.md) — REACH product-level compliance enforcement
- [PP-HG-005-reach-rohs-compliance.md](../pain-points/hardgoods/PP-HG-005-reach-rohs-compliance.md) — Hardgoods-specific REACH/RoHS exposure
- [PP-REG-CSDDD-001.md](../pain-points/compliance/PP-REG-CSDDD-001.md) — Adjacent EU due diligence directive
