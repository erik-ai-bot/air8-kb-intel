---
type: pain-point
id: PP-REG-UFLPA-001
---
# PP-REG-UFLPA-001: UFLPA Cotton Traceability Failure

## Description
US-bound cotton products detained at CBP if traceability is insufficient. Apparel is the 2nd most targeted sector. Only 36% of detained apparel shipments are released (vs 58% all-sector average).

## Enforcement Data (2024)
- Total detentions: 4,619 shipments (+14.9% YoY)
- Apparel detentions: 876 (+11.6% YoY)
- Apparel clearance rate: **36%** (worst among major sectors)
- Apparel detained value: $90.42M
- China-origin denial rate: 61.6% (up from 44.6% in 2023)
- 37 new entities added Jan 2025 (26 in cotton sector)

## Trigger Conditions
`market = US AND product contains cotton`

## Intensity Factors
- cotton_origin = China → CRITICAL
- cotton_origin = India/Pakistan → HIGH
- cotton_origin = organic_certified → LOW (inherent traceability advantage)

## Impact Chain
```
EVENT: CBP detains shipment
→ IMPACT-1: Invoice cannot be paid until goods released
→ IMPACT-2: Air8 AR at risk (goods in limbo)
→ IMPACT-3: Buyer may cancel or re-source
→ IMPACT-4: Supplier OTD drops
→ IMPACT-5: Scorecard degrades
→ IMPACT-6: Insurance claim may trigger
→ IMPACT-7: Reputation damage → other buyers reduce orders
```

## Who Is Affected
- **Suppliers:** BD, IN, PK, CN, VN selling cotton to US market
- **Buyers:** All US retailers
- **Air8:** Receivable at risk for any financed invoice in detention
- **Products:** Any cotton-containing item (100% cotton AND blends)

## Regulation Reference
[[../regulations/REG-UFLPA]]

## Affected Combos
- [[../personas/COMBO-001-south-asian-small-knit]]
- [[../personas/COMBO-002-bangladesh-bank-lc]]
- [[../personas/COMBO-003-india-large-vertical-integrator]]
- [[../personas/COMBO-004-china-medium-woven]]
- [[../personas/COMBO-008-india-organic-cotton-medium]]
- [[../personas/COMBO-009-pakistan-home-textile]]
- [[../personas/COMBO-014-india-small-woven]]

## Related

- [REG-UFLPA.md](../../layer-2/regulations/REG-UFLPA.md) — UFLPA entity list, WRO scope, Xinjiang detention protocol
- [NODE-compliance-trade.md](../../layer-2/nodes/NODE-compliance-trade.md) — UFLPA enforcement as trade compliance trigger
- [COMP-SANCTIONS.md](../pain-points/compliance/COMP-SANCTIONS.md) — Sanctions/UFLPA intersection
- [PP-CN-001-safe-complexity.md](../pain-points/country/PP-CN-001-safe-complexity.md) — China/Xinjiang supply chain exposure
