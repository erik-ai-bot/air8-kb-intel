---
type: pain-point
id: PP-REG-CSDDD-001
---
# PP-REG-CSDDD-001: EU CSDDD Due Diligence Burden

## Description
EU CSDDD requires large companies to audit supply chains. Suppliers must provide granular ESG data to remain on buyer approved lists.

## Timeline (Omnibus amendment Feb 2026)
- Phase 1 (Jul 2028): >€1.5B + 5,000 employees
- Phase 2 (Jul 2029): >€900M + 3,000 employees
- Phase 3 (Jul 2029+): >€450M + 1,000 employees

## Impact Chain
```
EVENT: EU buyer begins CSDDD compliance program
→ IMPACT-1: Buyer sends DD questionnaire to ALL tier-1 suppliers
→ IMPACT-2: Suppliers without ESG data cannot respond → risk of being dropped
→ IMPACT-3: Compliance cost: $10-50K/year per supplier
→ IMPACT-4: Suppliers WITH ESG data = competitive advantage
→ IMPACT-5: Air8 ecosystem (T4S, VOICES, ESG Library) provides data → differentiation
```

## Who Is Affected
- **Suppliers:** ALL suppliers selling to large EU buyers
- **Buyers:** H&M, Zara/Inditex, Primark, C&A, M&S, Lidl, Zalando, ASOS
- **All combos** with market = EU

## Regulation Reference
[[../regulations/REG-CSDDD]]

## Affected Combos
All combos with EU market exposure.

## Related

- [REG-CSDDD.md](../../layer-2/regulations/REG-CSDDD.md) — The directive itself; applicability determination workflow
- [NODE-compliance-product-eu.md](../../layer-2/nodes/NODE-compliance-product-eu.md) — CSDDD corporate due diligence requirements
- [L1-compliance-interpretation.md](../principles/L1-compliance-interpretation.md) — EU regulation applicability determination method
- [PP-REG-REACH-001.md](../pain-points/compliance/PP-REG-REACH-001.md) — Adjacent EU product compliance obligation
