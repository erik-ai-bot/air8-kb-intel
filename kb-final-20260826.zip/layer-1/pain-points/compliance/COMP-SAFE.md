---
type: compliance
id: COMP-SAFE
---
# COMP-SAFE: SAFE Regulations (China Cross-Border)

State Administration of Foreign Exchange — controls on offshore receivable assignment.

## Key Rule
Assignment of receivables to foreign entity must be registered with SAFE.

## Air8 Solution
Air8 Hengqin (CN domestic entity) handles SAFE compliance.

## Constraints
- Single company ≤40% of Hengqin portfolio
- Group ≤50% of Hengqin portfolio
- Total factoring balance ≤10× registered capital

## Related Pain Point
[PP-CN-001-safe-complexity.md](../pain-points/country/PP-CN-001-safe-complexity.md) — SAFE complexity country context
