---
type: compliance
id: COMP-THREE-LINES
---
# COMP-THREE-LINES: Three Lines of Defence Model

| Line | Owner | Role |
|------|-------|------|
| **1st Line** | Business / Operations | KYC screening, due diligence, transaction monitoring |
| **2nd Line** | Risk + Compliance | Policies, risk assessment, regulatory oversight |
| **3rd Line** | Internal Audit | Independent process checks |

## Related

- [COMP-KYC.md](../pain-points/compliance/COMP-KYC.md) — First vs second line of defense in KYC context
- [NODE-risk-categories.md](../../layer-2/nodes/NODE-risk-categories.md) — Risk taxonomy for second-line classification
- [COMP-SAFE.md](../pain-points/compliance/COMP-SAFE.md) — Three-lines model applied to SAFE compliance
