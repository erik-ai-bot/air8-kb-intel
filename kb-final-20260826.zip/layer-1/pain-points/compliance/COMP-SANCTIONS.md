---
type: compliance
id: COMP-SANCTIONS
---
# COMP-SANCTIONS: Sanctions & AML Screening

Refinitiv World-Check screening for ALL parties on every transaction.

## Applies
ALL transactions — non-negotiable, ongoing monitoring.

## Key Checks
- Entity name screening (PEP, sanctions, adverse media)
- Vessel name screening (AML — Iran, North Korea, Russia routes)
- Port of loading/discharge (sanctioned country check)
- UBO (Ultimate Beneficial Owner) screening

## Linked Data
supplier.sanctions_check · bl.vessel_name · bl.port_of_loading

## Related

- [COMP-KYC.md](../pain-points/compliance/COMP-KYC.md) — KYC account restrictions and third-party payment prohibition overlap
- [NODE-compliance-trade.md](../../layer-2/nodes/NODE-compliance-trade.md) — OFAC, BIS, UFLPA entity screening as part of sanctions compliance
- [PP-REG-UFLPA-001.md](../pain-points/compliance/PP-REG-UFLPA-001.md) — UFLPA enforcement as sanctions-adjacent compliance trigger
