---
type: pain-point
id: PP-EXPAND-003
---
# PP-EXPAND-003: Operational Friction

## Description
Client experiences document matching errors, FR holds, slow OCR, or unclear portal UX. Friction reduces invoice submission rate and facility utilisation.

## Trigger
`financing = already_Air8 AND (fr_hold_count > 0 OR ocr_error_rate > 5%)`

## Cascading Impacts
- → Client stops submitting all invoices → opportunity cost for both parties
- → Negative perception of Air8 platform

## Affected Combos
- [[../personas/COMBO-010-existing-client-expansion]]

## Related

- [L1-db-field-contract.md](../methods/L1-db-field-contract.md) — Data quality and field mapping for operational friction detection
- [NODE-buyer-indicator.md](../../layer-2/nodes/NODE-buyer-indicator.md) — Buyer engagement indicators for operational friction signals
