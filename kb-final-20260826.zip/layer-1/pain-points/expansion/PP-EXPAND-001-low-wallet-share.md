---
type: pain-point
id: PP-EXPAND-001
---
# PP-EXPAND-001: Low Wallet Share

## Description
Client uses Air8 but only for a fraction of their total revenue. Remaining buyers are unfunded or funded by expensive bank alternatives.

## Trigger
`financing = already_Air8 AND wallet_share < 50%`

## Opportunity
Each % of wallet share gained = direct revenue for Air8 + cheaper financing for supplier.

## Affected Combos
- [[../personas/COMBO-010-existing-client-expansion]]

## Products That Help
- Add more buyer pairs to existing facility

## Related

- [PRODUCT-PRINCIPLES.md](../principles/PRODUCT-PRINCIPLES.md) — Wallet share analysis method and product cross-sell logic
- [NODE-outreach-profile.md](../../layer-2/nodes/NODE-outreach-profile.md) — Outreach angle for expansion conversations
- [PROD-ARP.md](../../layer-2/products/PROD-ARP.md) — ARP as primary product for wallet share expansion
- [PROD-PRESHIP-RT2C.md](../../layer-2/products/PROD-PRESHIP-RT2C.md) — RT2C as secondary product for buyer pair gaps
