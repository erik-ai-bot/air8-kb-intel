---
type: reasoning
id: BRAIN-CHAIN
version: 1.0
---

# Air8 KB — Brain Chain

**This is the single authoritative guide for how the KB brain processes any event.**

Read this first. Every other file in `layer-1-reasoning/` is referenced below at the exact step where it is used.

---

## Layer 1 File Map — When Each File Is Used

| File | Step | Role |
|------|------|------|
| **BRAIN-CHAIN.md** (this file) | — | Master navigation guide |
| *(web search — no file)* | Step 0 | Open-world + principle-guided event enrichment |
| **EVENT-TYPES.md** | Step 1 | Event → principle activation + weights |
| **EVENT-PRINCIPLES.md** | Step 2 | Subtype → RP-EVT-* reasoning directive |
| **PRINCIPLES.md** | Step 3 | Principle → Layer 2 entity fetch spec |
| **EVENT-CLUSTERS.md** | Step 3b | Correlated event check + combined card logic |
| **runtime/active_event_cache_schema.md** | Step 3b | Cache schema for correlated event lookup |
| **PERSONA-PRINCIPLES.md** | Step 5a | Per-persona reasoning frames (RP-MATERIAL, RP-FX, RP-BUYER-FIN, RP-TARIFF-CLIFF) |
| **PRODUCT-PRINCIPLES.md** | Step 5a | Per-product reasoning frames (RP-PROD-SELFLIQ, RP-PROD-TENOR, RP-PROD-ELIGIB) |
| **RISK-PRINCIPLES.md** | Step 5b | Risk overlays (concentration, cliff, peer-failure, signal decay) |
| **PRIMITIVES.md** | Step 5c | Fallback constructs when entity data is insufficient |
| **SOLUTIONS.md** | Step 6 | Event × persona → Air8 product match + contraindications |
| **PERSONA-SYNTHESIS.md** | Step 7 | Synthesize draft persona when no direct COMBO match (confidence < 0.7) |
| **pain-points/\*.md** | Referenced by Step 5 | Pain point definitions pulled when principle fetches a persona's `pain_points[]` |
| **compliance/\*.md** | Referenced by Step 5 | Compliance program details pulled when EVT-REGULATION activates PRIN-COMPLIANCE-COST |
| **playbooks/\*.md** | Referenced by Step 6 | Scenario-specific playbooks (cliff, China operations) |

---

## The Chain — Step by Step

```
INPUT EVENT
  └─ fields: type, subtype, supplier_country, buyer_geo,
             product_category, material, supplier_tier, company_type
```

---

### STEP 0 → Event Understanding & Enrichment (web search — runs before KB chain)
**Question:** What actually happened, and what context do we need before reasoning through KB principles?

**Mandatory for every event. Run before Step 1.**

Two directions run in parallel:

#### Direction 1 — Open-World Enrichment (outside-in)
Search the event broadly to surface real-world context, expert commentary, and market reactions — including signals that may fall **outside** KB principles.

**Search queries to generate:**
- `"{event description}" pricing impact supply textile factory`
- `"{event description}" expert commentary market reaction 2025`
- `"{country} {commodity} {policy type}" domestic pricing spinning mill`
- `"{event}" farmer / manufacturer / buyer response`

**Example (India cotton tax exemption):**
```
→ "India cotton GST exemption 2025 domestic price impact"
→ "India cotton tax exemption spinning mill margin reaction"
→ "India cotton MSP 2025 farmer planting incentive"
→ "India textile export competitiveness cotton exemption"
```

**Capture as `[OPEN-SIGNAL]` blocks.** If a finding has no matching KB principle → tag it `[KB-GAP]` and route to Beyond-KB handling (see below).

#### Direction 2 — Principle-Guided Search (inside-out)
Use the KB principles (from Step 1 preview) as targeted search lenses. Each activated principle defines a specific angle to search for.

| Principle (example: EVT-TARIFF/IN cotton) | Search lens |
|---|---|
| PRIN-COUNTRY-EXPOSURE | `"India cotton production capacity export trends 2025"` |
| PRIN-PRODUCT-TARIFF | `"India cotton domestic price floor MSP 2025 spinning"` |
| PRIN-SUPPLIER-RESILIENCE | `"India textile mill margin squeeze cost pass-through 2025"` |

**Note:** Direction 2 requires a rough Step 1 pre-read to know which principles will activate. Run Direction 1 first (no KB needed), then a quick Step 1 scan, then Direction 2 targeted searches.

**Output — ENRICHMENT BLOCK (feeds into Step 1 as enriched context):**
```
ENRICHMENT BLOCK:
  event_summary: [1-2 sentence factual description of what happened]
  open_signals:
    - [OPEN-SIGNAL] {finding} | source: {url} | confidence: [VERIFIED/HYPOTHESIS]
    - [KB-GAP] {signal outside KB taxonomy} | suggests: {what KB expansion may be needed}
  principle_enrichment:
    - principle: PRIN-COUNTRY-EXPOSURE
      search: "India cotton production capacity 2025"
      finding: "..."
      confidence: [VERIFIED/HYPOTHESIS]
  kb_expansion_flags:         ← populated if any [KB-GAP] items found
    - type: NEW-PRINCIPLE | description: {gap} | priority: HIGH/MEDIUM/LOW
    - type: UPDATE-ENTITY | entity_id: {existing entity} | gap: {what's missing or stale}
```

#### Synthesis Mandate — Enrichment Must Improve Analysis, Not Just Catalog It

**This is the most important rule in STEP 0.** Searching and tagging findings is NOT the goal. The goal is to emerge from STEP 0 with a sharper, more accurate analytical lens than you would have had from the KB alone.

After collecting the ENRICHMENT BLOCK, the brain must complete a **Synthesis Statement** for each significant finding:

```
SYNTHESIS:
  finding: "MSP floor at INR 6,620/quintal — below current market price"
  without_this: "I would apply RP-PASSTHROUGH assuming full exemption benefit reaches factories"
  with_this:    "Pass-through is conditional — if market price drops toward MSP floor,
                 benefit shifts to buyers, not factories. Need current spot vs MSP spread."
  analytical_upgrade:
    - Adds a conditional branch to the RP-PASSTHROUGH reasoning
    - Changes signal from HIGH to CONDITIONAL until spot/MSP spread is confirmed
    - Adds a specific watch condition: 'if spot < MSP + 5%, factory benefit = near zero'
  signal_impact: DIRECTION_REVISED | INTENSITY_DOWNGRADED | CONDITION_ADDED | NO_CHANGE
```

**Mandatory check before leaving STEP 0:**
- Did any finding change what question I ask in Step 2 (RP-EVT-* directive)? → Revise the question.
- Did any finding change which Layer 2 entity is most relevant? → Adjust Step 4 priority.
- Did any finding reveal a risk the KB would have missed entirely? → Add as explicit IMMEDIATE block item.
- Did any finding sharpen the timing or urgency? → Adjust intensity band in Step 5b.

If all synthesis statements say `signal_impact: NO_CHANGE` — the enrichment was too surface-level. Search deeper or from a different angle before proceeding.

**Output:** ENRICHMENT BLOCK + SYNTHESIS statements → fed as enriched, revised analytical context into Steps 1–8. KB-GAP flags → routed to Beyond-KB handling.

#### Enrichment-Triggered Event Discovery — The Fork

Every item found during STEP 0 search hits a single fork:

```
STEP 0 搜索发现的每条信息
  └─ 判断：如果没有 Event A，这条信息本身算不算一个独立的重要事件？
      ├─ 不算 → Enrichment context
      │           → 进入 SYNTHESIS statement
      │           → 改变对 Event A 的推论，体现在 Event A 的信号卡里
      │           → 不进 cache，不走 Phase A-E
      │
      └─ 算   → Distinct related event
                  → 走完整 Phase A-E 解析（和直接到达的 event 完全相同）
                  → 查 active_event_cache，写入 state=draft, sourced_by=[current_trigger_id]
                  → Step 3b 进行关联检查，产生 combined read
```

**"算不算独立事件" 的具体判断标准（三个条件同时满足）：**
- 有自己独立的触发机制（不同的政策、行为主体、生效日期）
- 经过 Phase B 评分可激活至少一个 event family STRONG 或 MODERATE
- 与当前事件至少共享一个字段（country / material / buyer_geo）

**设计原则：** 所有通过判断的 event 走同一个入口——不管是直接到达还是 enrichment 时发现的， Phase A-E 解析流程完全一致。唯一区别：`sourced_by` 被设置，初始 `state=draft`。

---

### STEP 1 → EVENT-TYPES.md
**Question:** Which event families apply, and what subtype/principles does each activate?

**How the brain navigates (important):**
> Parent event family = data container (weights + mandatory checks). NOT a navigation step.
> Map **directly to the subtype**. Family weights and mandatory checks inherit automatically.

**Action:**
1. Run **Phase A** (field extraction) + **Phase B** (family association scoring) from `EVENT-TYPES.md` on raw event text
2. Activate all families rated STRONG or MODERATE. Each runs its own independent chain.
3. For each activated family: match directly to best-fit **subtype** → inherit family’s principle weights and mandatory checks automatically
4. If no subtype fits: use CANONICAL parent subtype + flag `[KB-GAP]` + mark `[APPROX]`
5. Carry activation level (STRONG / MODERATE) forward to Step 6 for output ranking

**Output:** per-family (subtype + `(principle_id, weight)` list + `RP-EVT-*` rule + activation level)

**Example (EVT-TARIFF):**
```
→ PRIN-COUNTRY-EXPOSURE: 0.5
→ PRIN-PRODUCT-TARIFF:   0.3
→ PRIN-SUPPLIER-RESILIENCE: 0.2
→ RP-EVT rule: RP-EVT-DUTY-01
```

---

### STEP 2 → EVENT-PRINCIPLES.md
**Question:** For this event subtype, what must the brain specifically think about?

**Action:**
1. Look up the `RP-EVT-*` rule from Step 1 in `EVENT-PRINCIPLES.md`
2. Read the `Must consider:` list — these are the specific reasoning questions for this subtype
3. Read the `LLM directive template:` — this is the exact reasoning template to execute
4. Note the `Freshness:` field — if `annual`, flag for web validation before use

**Output:** Filled reasoning template with event-specific answers to each bullet

**Example (RP-EVT-DUTY-01 for tariff event):**
```
→ Who purchases the input — factory or buyer?
→ Domestic vs imported blend ratio?
→ Government price floor (MSP)?
→ Existing supply contracts fixed or floating?
→ Lag before new pricing takes effect?
```

> **Special checks always fired alongside RP-EVT-* rules:**
> - Any EVT-TARIFF → also check RP-EVT-DOUBLE-COMPRESS (co-occurring input+output tariff)
> - Any EVT with overlapping country+material → also check RP-EVT-CORRELATED-PAIR (Step 3b)
> - Any EVT-MARKET-SHIFT → also check RP-EVT-SEGMENT-BIFURCATE (mass vs premium split)
> - Any EVT with cliff date → also check RP-EVT-SEASONAL-LOCK (seasonal lock constraints)

---

### STEP 3 → PRINCIPLES.md
**Question:** For each activated principle, what Layer 2 data must be fetched?

**Action:**
For each `(principle_id, weight)` from Step 1, look up the principle in `PRINCIPLES.md`:
1. Read `entity_focus` → which entity type to fetch (country / product_category / persona)
2. Read the principle definition → what attributes to pull from each entity
3. Compute `type_weight` per entity type = sum of weights of all principles with that `entity_focus`

| Principle (EVT-TARIFF example) | entity_focus | weight | → Layer 2 target |
|-------------------------------|-------------|--------|-------------------|
| PRIN-COUNTRY-EXPOSURE | country | 0.5 | → countries/{supplier_country}.md + countries/{buyer_geo}.md |
| PRIN-PRODUCT-TARIFF | product_category | 0.3 | → product-categories/{product_category}.md |
| PRIN-SUPPLIER-RESILIENCE | persona | 0.2 | → personas/COMBO-*.md (via tag overlap — see Step 4B) |

**Output:** fetch targets for Step 4 + type_weight per entity type

---

### STEP 3b → EVENT-CLUSTERS.md + runtime/active_event_cache_schema.md
**Question:** Is this event part of a cluster or correlated with an active event?

**Action (mandatory — do not skip):**
1. Check `EVENT-CLUSTERS.md` — does this event type/subtype belong to a named cluster (e.g., CLUSTER-US-DECOUPLING, CLUSTER-EU-MARKET-ACCESS)?
   - If yes → run the combined analysis protocol for that cluster instead of standalone
2. Query the `active_event_cache` (schema in `runtime/active_event_cache_schema.md`) for events with ≥ 2 overlapping tags (country, material, buyer_geo, subtype)
3. Classify relationship:
   - **AMPLIFYING** → both events push same direction → generate COMBINED card, increase urgency
   - **REFRAMES** → new event changes interpretation of cached event → revise cached signal
   - **OFFSETS** → events partially cancel → muted net signal
   - **INDEPENDENT** → same geography, different mechanism → emit separately
4. Output must explicitly state: `Correlated event check: [result] — [rationale]`

**Output:** COMBINED card (if cluster/correlated) OR standalone confirmation

---

### STEP 4 → Layer 2 Entities (direct lookup)
**Question:** Which real-world entities are affected by this event?

Two paths run in parallel:

#### Path A — Country + Product (Direct Match)
```
event.supplier_country → layer-2-entities/countries/{code}.md  (role: supplier_origin)
event.buyer_geo        → layer-2-entities/countries/{code}.md  (role: buyer_geo)
event.product_category → layer-2-entities/product-categories/{category}.md
event.material         → within product-categories file (material-level section)
```
Match quality = 1.0 (direct match, no scoring needed)

#### Path B — Persona (Tag Overlap Scoring)
1. Build event tag set from: `[supplier_country, supplier_tier, product_category, material, buyer_geo, company_type]`
2. Score ALL persona files in `layer-2-entities/personas/`:
   - Count tag overlap with each COMBO's `tags:` frontmatter
   - Keep all personas with overlap ≥ 2
3. If no COMBO matches at confidence ≥ 0.7 → trigger **PERSONA-SYNTHESIS.md** (Step 7)

| Overlap | Impact Band | What to fetch |
|---------|-------------|---------------|
| ≥ 4 tags | HIGH | Full context block — all attributes, pain_points[], linked products |
| 2–3 tags | MEDIUM | Summary block — key risk factors, top 3 pain points |
| < 2 tags | Noise | Dropped |

**Key rule:** Return ALL personas with overlap ≥ 2. One event can affect multiple personas simultaneously. Each gets its own signal block — do NOT merge.

---

### BEYOND-KB SIGNAL HANDLING (triggered when STEP 0 produces `[KB-GAP]` items)
**Question:** STEP 0 found signals outside the KB principle taxonomy — how do we use them to produce better analysis, and how do we ensure the KB learns from them?

This runs **alongside Steps 4–5**, not as a replacement. The goal is not just to handle gaps — it is to **actively upgrade the analytical output** using insights the KB didn't know to ask about.

#### Phase 1 — Attempt Layer 2 Entity Proximity Match
Even without a principle path, check if the `[KB-GAP]` signal implies a country, product, or persona that **already exists** in Layer 2 but was not activated by the principle chain.

- If a Layer 2 entity is implied → include it in Step 4 with source tag `BEYOND-KB` (not principle-activated)
- Relevance score = `0.10 × signal_strength` (capped at 0.15 — does not override principle-activated entities)
- Label all claims from this entity as `[HYPOTHESIS]` unless a web source confirms

**Example:** STEP 0 surfaces that India cotton exemption is boosting yarn exports to Bangladesh — not triggered by any activated principle. Check: does `countries/BD.md` exist? Yes → include as `BEYOND-KB` entity with BRIEF block (score ≈ 0.10). Then synthesize: does BD yarn availability change the sourcing calculus for any matched persona? If yes → add to COMMERCIAL block.

#### Phase 2 — Analytical Synthesis (the core of Beyond-KB value)
**This is not a fallback step. This is where outside-KB insight upgrades the analysis.**

For every `[KB-GAP]` signal — whether or not a Layer 2 entity was found — the brain must explicitly synthesize what the outside finding means for the analysis:

```
BEYOND-KB SYNTHESIS:
  gap_signal: "MSP floor at INR 6,620/quintal may absorb exemption benefit"
  analytical_dimension_added:
    "Government price floor creates a conditional ceiling on factory cost reduction.
     KB principle (RP-PASSTHROUGH) asks who bears cost — but doesn't model government
     mechanisms that cap how much benefit reaches any party."
  how_it_changes_reasoning:
    - Step 2 RP-EVT directive: add question → 'Is the current spot price above or below MSP?'
    - Step 5 signal intensity: downgrade from HIGH to CONDITIONAL (benefit not guaranteed)
    - IMMEDIATE block: add action → 'verify current India cotton spot vs MSP before pitching'
    - COMMERCIAL block: add angle → 'if spot > MSP, full benefit to mill = ARP pitch now'
  primitives_applied: [RP-PASSTHROUGH, RP-INFORMATION-DEFICIT]
  signal_impact: DIRECTION_REVISED | INTENSITY_DOWNGRADED | CONDITION_ADDED | ANGLE_ADDED
```

**The test:** If the beyond-KB signal doesn't change at least one element of the signal card (direction, intensity, timing, recommendation, or a specific question), it wasn't synthesized — it was just cataloged. Catalog is not enough.

#### Phase 3 — KB Expansion Flag (mandatory for every `[KB-GAP]`)
Generate a structured flag for each gap, capturing not just what's missing but **what the missing piece would have enabled**:

```
[KB-EXPANSION-FLAG]
type:           NEW-PRINCIPLE | NEW-ENTITY | UPDATE-ENTITY
description:    {what is missing from the KB}
evidence:       {what STEP 0 found that revealed the gap}
would_enable:   {what better analysis would be possible if this gap were filled}
priority:       HIGH (blocks signal accuracy) | MEDIUM (enriches signal) | LOW (nice to have)
route_to:       expert_review_queue → Josephine Cheung
```

All `KB-EXPANSION-FLAGS` are collected in the final output's `KB_EXPANSION_FLAGS` section. HIGH priority flags must be flagged for expert review before the signal is treated as VERIFIED.

| Priority | What it means | Action |
|---|---|---|
| HIGH | Missing data materially changes the signal direction | Label signal [PENDING DATA]; route to Josephine immediately |
| MEDIUM | Missing data enriches but doesn't flip the signal | Include [HYPOTHESIS] label; flag for next KB update cycle |
| LOW | Nice-to-have context | Flag only; no signal impact |

---

### STEP 5 → Score + Apply Reasoning Frames

#### 5.0 — Score Each Entity
```
relevance_score = type_weight × role_weight × match_quality
```

| entity | type_weight | role_weight | match_quality | relevance_score |
|--------|------------|------------|--------------|----------------|
| Country:CN (supplier) | 0.50 | 0.70 | 1.0 | **0.350** |
| Country:US (buyer) | 0.50 | 0.30 | 1.0 | **0.150** |
| Product:WovenApparel | 0.30 | 1.0 | 1.0 | **0.300** |
| Persona:COMBO-004 | 0.20 | 1.0 | 5/7=0.71 | **0.142** |

Noise floor: drop entities below 0.05

| Score Range | Block Type |
|------------|------------|
| ≥ 0.20 | FULL — all attributes |
| 0.10–0.19 | SUMMARY — key risks + top 3 pain points |
| 0.05–0.09 | BRIEF — name + one risk sentence |
| < 0.05 | Dropped |

#### 5a → PERSONA-PRINCIPLES.md + PRODUCT-PRINCIPLES.md
**Question:** For each matched persona/product, what specific reasoning frames apply?

**Action:**
For each matched persona, check `PERSONA-PRINCIPLES.md`:
- If event involves material/commodity → apply **RP-MATERIAL-01** (sourcing dependency analysis)
- If event involves FX → apply **RP-FX-01** (currency structure + hedge)
- If event involves buyer financial event → apply **RP-BUYER-FIN-01** (concentration + DSO)
- If event has cliff date → apply **RP-TARIFF-CLIFF-01** (window optimization + post-cliff risk)

For each product recommendation forming, check `PRODUCT-PRINCIPLES.md`:
- If recommending PSF/OBF → apply **RP-PROD-SELFLIQ-01** (verify self-liquidation chain)
- If event has time window → apply **RP-PROD-TENOR-01** (tenor design vs cliff date)
- If new combo or new facility → apply **RP-PROD-ELIGIB-01** (eligibility pre-check)
- If Air8 wallet share context → apply **RP-PROD-WALLET-01**

**Output:** Per-persona answered directive templates + per-product eligibility check

#### 5b → RISK-PRINCIPLES.md
**Question:** Are there risk overlays that qualify or flip the primary signal?

Apply these risk overlays to the assembled signal context:

| Overlay Rule | Apply When |
|-------------|-----------|
| **RP-STRUCTURAL-CHANGE** | Always — is the change permanent or cyclical? Structural → confirm signal; cyclical → downgrade to MONITOR |
| **RP-WINDOW** | Event has cliff date → time-slice signal (before cliff vs after) |
| **RP-PEER-FAILURE** | Event involves competitor closure/exit → check if survivor faces same structural causes |
| **RP-CONCENTRATION** | Affected country/category → check Air8 portfolio concentration (>30% = elevated flag) |
| **RP-CASCADE** | Supply disruption, factory closure, port congestion → trace downstream cascade chain |

**Output:** Signal direction confirmed/downgraded/qualified by risk overlay

#### 5c → PRIMITIVES.md
**Question:** Is there insufficient entity data? Fall back to first-principles reasoning.

**Trigger:** Use PRIMITIVES.md when:
- Entity data is unavailable, stale, or marked `[PENDING DATA]`
- The event is a novel type without direct precedent in entity files
- A principle's entity_focus resolves to NO matched entities

Apply the relevant primitive:
- **RP-DEPENDENCY** — Identify upstream/downstream dependencies when entity data is missing
- **RP-PASSTHROUGH** — Determine who bears the cost when margin data is absent
- **RP-WINDOW** — Estimate time horizon from event mechanics alone
- **RP-CONCENTRATION** — Estimate portfolio exposure without direct data
- **RP-CASCADE** — Trace downstream effects via supply chain logic
- **RP-INFORMATION-DEFICIT** — When data is absent, flag as [PENDING DATA] and state what is needed
- **RP-STRUCTURAL-CHANGE** — Classify event as structural vs cyclical from event mechanics
- **RP-PEER-FAILURE** — When no entity file exists for a competitor, reason from failure pattern

---

### STEP 6 → SOLUTIONS.md + playbooks/
**Question:** For each matched persona, what does Air8 recommend?

**Action:**
1. Look up each matched persona in `SOLUTIONS.md` → find the event × persona → product cell
2. Check `applies_when:` conditions — do they match the assembled signal context?
3. Check `contraindications:` — are there flags that block this product?
4. Check urgency level → HIGH / MEDIUM / LOW → drives IMMEDIATE vs COMMERCIAL block placement
5. If playbook scenario applies (cliff scenario → `playbooks/cliff-playbook.md`; China operations → `playbooks/china-operations.md`) → apply playbook overlay

**Output:** Product recommendation per persona with contraindication check + urgency

---

### STEP 7 → PERSONA-SYNTHESIS.md (conditional)
**Trigger:** Only if Step 4B found no COMBO match at confidence ≥ 0.7

**Action:**
1. Follow `PERSONA-SYNTHESIS.md` → build a synthetic COMBO from the best-match neighbor + client-specific overrides
2. Document which fields are inherited vs synthesized
3. Apply `synthesized_field_confidence` per field
4. Flag synthesized fields for S2 Round 1 verification before trusting

**Output:** Draft synthetic persona with per-field confidence labels

---

### STEP 8 — Mandatory Output Gates (P0 Checks)

Before finalizing any signal card:

**P0-6: Competitive Dynamics** — Who gained, who lost?
> Format: "Because of this event: [Persona A] gains [X] via [mechanism]. [Persona B] loses [Y] via [mechanism]. Air8 positioning: [action for gainers] / [action for losers]."

**P0-7: Claim Confidence Labels** — Tag every WHY claim
| Label | Meaning |
|-------|---------|
| `[VERIFIED]` | Confirmed by official source |
| `[EXPERT]` | Josephine Cheung review or specialist input |
| `[HYPOTHESIS]` | Reasonable inference, not confirmed |
| `[PENDING DATA]` | Depends on unavailable data |

**P0-8: Correlated Event Cache Check** — Confirm Step 3b was run
> State explicitly: `Correlated event check: [result] — [rationale]`

---

## Output Structure — 4-Block Format

Every final signal card uses this structure:

```
IMMEDIATE       → What to do in the next 30 days (time-sensitive actions)
COMMERCIAL      → BD angles, product pitches, supplier conversations
COMPETITIVE     → Who gained, who lost (P0-6 answer goes here)
WC + AIR8       → Working capital implications + which Air8 products apply
```

---

## Quick Lookup: Which File Answers Which Question

| Question | Go to |
|---------|-------|
| "What type is this event?" | EVENT-TYPES.md → Summary Table |
| "Which principles activate?" | EVENT-TYPES.md → Activated Principles block |
| "What must I specifically think about for this subtype?" | EVENT-PRINCIPLES.md → RP-EVT-* rule |
| "What does each principle actually DO?" | PRINCIPLES.md → principle definition |
| "What are the entity weights?" | PRINCIPLES.md + REASONING-FLOW.md → formula |
| "Is this event part of a cluster?" | EVENT-CLUSTERS.md |
| "Is there a correlated active event?" | runtime/active_event_cache_schema.md |
| "Which personas are affected?" | Layer 2: personas/COMBO-*.md (tag overlap) |
| "What are this country's risks?" | Layer 2: countries/{code}.md |
| "What are this persona's pain points?" | pain-points/*.md (linked from COMBO file) |
| "FX / material / buyer-fin reasoning for this persona?" | PERSONA-PRINCIPLES.md |
| "Is this product eligible? Does tenor work?" | PRODUCT-PRINCIPLES.md |
| "What risk overlays apply?" | RISK-PRINCIPLES.md |
| "No entity data — what to do?" | PRIMITIVES.md |
| "Which Air8 product to recommend?" | SOLUTIONS.md |
| "How to synthesize a new persona?" | PERSONA-SYNTHESIS.md |
| "Cliff scenario details?" | playbooks/cliff-playbook.md |
| "China SAFE/operations details?" | playbooks/china-operations.md |

---

## Web Lookup Directives — Master List

> All `web_lookup` directives across KB files.
> DATA_FIGURE claims are never hardcoded in KB — they resolve via these directives at runtime.
> Updated: 2026-07-13

---

### PP-BD-003 — LDC Graduation

| Field | Query | Freshness | Fallback |
|-------|-------|-----------|---------|
| `eu_mfn_tariff_rate` | EU MFN tariff rate HS 6105 6109 T-shirts knit garments Bangladesh post-LDC [year] | annual | 9.6–12% (as of 2024 EU tariff schedule) |
| `gsp_plus_convention_count` | EU GSP+ required conventions count updated regulation 2024 2025 | annual | 32 conventions (updated EU GSP regulation 2023) |
| `bd_ratification_status` | Bangladesh ILO UN convention ratification progress GSP+ status [current year] | quarterly | Active progress — cleared major milestone November 2025 (first in Asia) |
| `buyer_preposition_signals` | EU buyers Bangladesh sourcing shift RFQ changes LDC graduation 2025 2026 | quarterly | Monitor buyer RFQ patterns as leading indicator |

---

### COMBO-002 — Bangladesh CMT LLM Directives

| Field | Query | Freshness | Fallback |
|-------|-------|-----------|---------|
| `bd_bank_od_rate` | current Bangladesh garment factory bank overdraft interest rate [year] | quarterly | 13.5–18% (as of 2024) |
| `air8_pricing_vs_bank` | Air8 SCF receivable purchase pricing SOFR spread vs Bangladesh bank OD rate | quarterly | Air8 ~SOFR+4% vs bank OD 13.5–18% |
| `bd_minimum_wage` | Bangladesh garment worker minimum wage current Taka per month [year] | annual | BDT 12,500/mo (Dec 2023 hike, +56% from BDT 8,000) |
| `wage_fob_share` | Bangladesh garment factory labour cost as percentage of FOB price CMT basics [year] | annual | ~12% of FOB (CMT basics, as of 2024) |
| `buyer_fob_wage_adjustment` | EU buyers FOB price adjustment Bangladesh wage hike sharing 2024 2025 2026 | quarterly | No confirmed FOB adjustment; factory absorbs full increase (verify with expert) |
| `india_yarn_price` | India cotton yarn price current USD per kg [year] | quarterly | See latest commodity data |

---

### How to Add New Directives

When a hardcoded DATA_FIGURE is found in any KB file during expert review:
1. Remove the hardcoded value from the KB file
2. Add a `web_lookup` block in the relevant KB file's "Live Data" section
3. Add a row to this master list
4. Set a fallback value (last known good value with date)
5. Log the change in `meta/kb-change-log.md`

## Related

- [REASONING-FLOW.md](REASONING-FLOW.md) — Detailed step-by-step reasoning flow; this file is the conceptual map
- [PRIMITIVES.md](../taxonomy/PRIMITIVES.md) — Reasoning primitives used in brain chain
- [EVENT-PRINCIPLES.md](../principles/EVENT-PRINCIPLES.md) — Event reasoning principles embedded in brain chain
- [EVENT-CLUSTERS.md](../taxonomy/EVENT-CLUSTERS.md) — Cluster detection logic in brain chain step 3b
