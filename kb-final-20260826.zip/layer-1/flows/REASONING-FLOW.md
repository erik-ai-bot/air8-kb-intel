---
type: reasoning
id: REASONING-FLOW
---

# Air8 KB - Reasoning Flow (Weight Formulas & Scoring Detail)

> **Navigation note:** For the complete step-by-step chain of which file to read at each step, see `BRAIN-CHAIN.md` first.
> This file provides the detailed weight calculation formulas, Cypher queries, scoring bands, and overlay rule detail.
> Use BRAIN-CHAIN.md for navigation; use this file for formula depth.

---

## The 9-Step Reasoning Pipeline

```
STEP 0:  Event understanding - open-world + principle-guided web enrichment → ENRICHMENT BLOCK
STEP 1:  Event arrives - read routing keys (enriched by STEP 0)
STEP 2:  Event type → activate principles (get weights)
STEP 3:  Compute entity type weights
STEP 3b: Correlated Event Check - query active_event_cache (P0-8 gate)
STEP 4:  Locate entities (two paths: direct match + tag overlap)
         [BEYOND-KB path]: KB-GAP signals → proximity match + primitives fallback
STEP 5:  Calculate relevance scores
STEP 5b: Intensity Scoring - CRITICAL/HIGH/MEDIUM/LOW per persona
STEP 6:  Assemble signal context → match solutions
STEP 7:  Mandatory Output Gates - P0-6 (competitive dynamics) + P0-7 (confidence labels)
         + KB_EXPANSION_FLAGS section (all [KB-GAP] items from STEP 0)
```

---

## STEP 0: Event Understanding & Enrichment

> Mandatory before Step 1. Grounds KB reasoning in real-world context.

### Direction 1 - Open-World Enrichment (outside-in)

Search the event broadly before touching any KB file. Goal: surface what is actually happening in the market, including signals the KB taxonomy may not yet cover.

**Query pattern:**
```
"{event description}" {country} {commodity} pricing domestic market impact 2025
"{event description}" expert commentary spinning mill factory buyer reaction
```

**Capture findings as:**
- `[OPEN-SIGNAL]` - signal with a KB principle match (feeds into Step 1 context)
- `[KB-GAP]` - signal with no KB principle match → route to BEYOND-KB handling at Step 4

> **Critical:** Every finding must be synthesized into an analytical change, not just logged. See Synthesis Mandate below.

### Direction 2 - Principle-Guided Search (inside-out)

After a quick Step 1 pre-read to identify activated principles, run targeted searches for each principle's specific angle.

**Query pattern per principle:**
| Activated Principle | Search Lens |
|---|---|
| PRIN-COUNTRY-EXPOSURE | `"{country} {commodity} production export capacity {year}"` |
| PRIN-PRODUCT-TARIFF | `"{country} {commodity} domestic price floor MSP {year}"` |
| PRIN-SUPPLIER-RESILIENCE | `"{country} {product} factory margin cost pass-through {year}"` |
| PRIN-COMPLIANCE-COST | `"{regulation} implementation timeline {country} {year}"` |

### ENRICHMENT BLOCK - Output Format

```yaml
event_summary: "India cotton GST exemption announced [date] - removes [X]% tax on raw cotton..."
open_signals:
  - signal: "India spinning mills seeing 8-12% input cost reduction"
    source: "https://..."
    confidence: "[VERIFIED]"
    kb_match: "PRIN-PRODUCT-TARIFF"
  - signal: "MSP floor may offset price benefit for buyers - govt may raise MSP in response"
    source: "https://..."
    confidence: "[HYPOTHESIS]"
    kb_match: null
    flag: "[KB-GAP] → MSP interaction not modeled in PRIN-PRODUCT-TARIFF"
principle_enrichment:
  - principle: PRIN-COUNTRY-EXPOSURE
    query: "India cotton production export capacity 2025"
    finding: "India cotton output projected at 32.5M bales; export quota unchanged"
    confidence: "[VERIFIED]"
  - principle: PRIN-PRODUCT-TARIFF
    query: "India cotton domestic price floor MSP 2025"
    finding: "MSP set at INR 6,620/quintal; below current market price - floor not binding"
    confidence: "[VERIFIED]"
kb_expansion_flags:
  - type: UPDATE-ENTITY
    entity_id: countries/IN.md
    gap: "MSP floor interaction with GST exemptions not modeled"
    priority: MEDIUM
  - type: NEW-PRINCIPLE
    description: "PRIN-GOVT-FLOOR - government price floors that can absorb or negate commodity price signals"
    priority: HIGH
```

### Synthesis Mandate - Analytical Quality Gate

**Searching is not the deliverable. Improved analysis is the deliverable.**

After collecting all findings, for each significant one, the brain must explicitly state:

| Synthesis Question | Required Answer |
|---|---|
| What did I expect before this finding? | State the KB-only assumption |
| What does this finding change? | Identify the specific analytical revision |
| Which step of the chain does it affect? | Name the step + how it changes |
| What would I have gotten wrong without it? | State the error the enrichment prevents |

**Signal impact labels (at least one must apply per significant finding):**
- `DIRECTION_REVISED` - finding flips the signal conclusion
- `INTENSITY_DOWNGRADED / UPGRADED` - finding changes urgency level
- `CONDITION_ADDED` - finding adds a prerequisite before signal is actionable
- `ANGLE_ADDED` - finding adds a dimension the KB chain wouldn't have surfaced
- `QUESTION_ADDED` - finding generates a specific follow-up question for Step 2

**If every finding resolves to `NO_CHANGE` - the search was too shallow.** Go deeper on a different angle before proceeding to Step 1.

> **STEP 0 output feeds directly into Step 1** as enriched, analytically revised context. The brain does not start Step 1 cold.

---

## STEP 1: Event Parsing — Subtype Direct Match + Parent Inheritance

> The brain does NOT navigate parent type → subtype in two steps. It maps **directly to the subtype**. Parent type is a data-organisation container, not a reasoning step.

### 1a — Extract Structured Fields from Raw Text

Run EVENT-TYPES.md **Phase A** on raw event text to extract:

```yaml
subtype:          section_301          ← map directly here; parent (EVT-TARIFF) is inferred
supplier_country: CN
buyer_geo:        US
product_category: woven_apparel        ← include downstream trace if raw material
material:         cotton
supplier_tier:    tier_2
company_type:     FOB
```

**Downstream trace rule:** If event affects a raw material → trace forward and include all affected product_categories (comma-separated, ordered by directness of impact).

### 1b — Score All 6 Event Families (Phase B)

Run EVENT-TYPES.md **Phase B**: score every event family STRONG / MODERATE / WEAK / NONE based on Phase B decision criteria. Activate all STRONG and MODERATE families.

**Rule:** Do not force a single family. Most real events activate 2–3 simultaneously.

### 1c — For Each Activated Family: Direct Subtype Match

For each STRONG/MODERATE family activated:
1. Match raw event to the best-fit **subtype** within that family
2. The subtype automatically inherits its family’s **principle weights** and **mandatory checks** — no separate parent lookup needed
3. If no subtype fits: use CANONICAL parent subtype + flag `[KB-GAP]` + note `[APPROX]`

```
Activated families for "India cotton GST exemption":

  EVT-TARIFF [STRONG]
    subtype: import_export_duty [APPROX — actual: domestic_tax_exemption, KB-GAP flagged]
    inherits: principles (0.5/0.3/0.2) + mandatory check: RP-EVT-DOUBLE-COMPRESS
    RP-EVT rule: RP-EVT-DUTY-01

  EVT-MARKET-SHIFT [MODERATE]
    subtype: demand_shift
    inherits: principles (0.4/0.4/0.2) + mandatory checks: RP-EVT-SEGMENT-BIFURCATE
    RP-EVT rule: RP-EVT-PRODTREND-01
```

### 1d — Per-Family Output

Each activated family produces its own independent output:
- `(principle_id, weight)` list — sourced from family definition, not recalculated
- `RP-EVT-*` rule ID — from subtype
- Activation level: STRONG or MODERATE — carried forward to Step 6 for output ranking

**Each family’s chain runs fully independently through Steps 2–6. No weight merging between families.**

All other information (what happened, who it affects, why it matters) is derived by the pipeline — not stored on the Event node.

**Rule:** The Event node holds what happened + where to look. Nothing else.

---

## STEP 2: Event Type → Activate Principles

Look up `type` in EVENT-TYPES.md. Get the activated principles and their weights.

```cypher
MATCH (et:EventType {id: event.type})-[a:ACTIVATES]->(p:Principle)
RETURN p.id AS principle, a.weight AS weight
ORDER BY a.weight DESC
```

For EVT-TARIFF the result is:
- PRIN-COUNTRY-EXPOSURE → 0.50
- PRIN-PRODUCT-TARIFF → 0.30
- PRIN-SUPPLIER-RESILIENCE → 0.20

Weight sum = 1.0. These weights drive Step 3.

---

## STEP 3: Compute Entity Type Weights

Each activated principle has an `entity_focus` property. Sum the activation weights per entity_focus to get the type_weight for each entity type.

```cypher
WITH principles,
  reduce(s = 0.0, x IN [p IN principles WHERE p.entity_focus CONTAINS 'country'] | s + p.weight) AS country_type_weight,
  reduce(s = 0.0, x IN [p IN principles WHERE p.entity_focus = 'product_category'] | s + p.weight) AS product_type_weight,
  reduce(s = 0.0, x IN [p IN principles WHERE p.entity_focus = 'persona'] | s + p.weight) AS persona_type_weight
```

For EVT-TARIFF:
- `country` type_weight = 0.50 (PRIN-COUNTRY-EXPOSURE is the only principle with country focus)
- `product_category` type_weight = 0.30
- `persona` type_weight = 0.20

These type_weights are the first multiplier in the scoring formula.

**Also from EVENT-TYPES.md: get role weights for this event type.**

Every EventType defines how much each entity role matters within that event type:

| EventType | supplier_origin weight | buyer_geo weight |
|---|---|---|
| EVT-TARIFF | 0.7 | 0.3 |
| EVT-REGULATION | 0.3 | 0.7 |
| EVT-CURRENCY | 0.8 | 0.2 |
| EVT-ESG-CERT | 0.4 | 0.6 |
| EVT-MARKET-SHIFT | 0.5 | 0.5 |
| EVT-SUPPLY-DISRUPTION | 0.8 | 0.2 |

Why the variation? Because different events affect different sides of the trade relationship:
- **Tariff** → hits supplier's cost competitiveness (supplier country matters more)
- **Regulation** → regulation applies in buyer's market jurisdiction (buyer country matters more)
- **Currency** → supplier's home currency is the input (supplier country dominates)

---

## STEP 4: Locate Entities (Two Paths + BEYOND-KB Path)

Both paths run in parallel from the same event. They find the Layer 2 entities to feed into the signal.

### Path A - Country + Product (Direct Match)

```
Event.supplier_country → Country node (role: supplier_origin, role_weight from EventType)
Event.buyer_geo → Country node (role: buyer_geo, role_weight from EventType)
Event.product_category + Event.material → ProductCategory node (role_weight: 1.0)
```

Direct match means: the entity code in the event field exactly matches the entity `id` in the graph. No scoring needed - match quality = 1.0.

### Path C - BEYOND-KB (triggered by `[KB-GAP]` items from STEP 0)

When STEP 0 flags a `[KB-GAP]` signal (no matching principle), run this path alongside Paths A and B:

1. **Proximity match** - Does the signal imply a country, product, or persona that exists in Layer 2 but wasn't principle-activated?
   - If yes → include entity with source tag `BEYOND-KB`, relevance capped at 0.15
   - All claims labeled `[HYPOTHESIS]` unless web-confirmed
2. **Analytical synthesis (mandatory)** - Apply RP-BEYOND-KB from PRIMITIVES.md. State explicitly:
   - What analytical dimension does this add that the principle chain wouldn't cover?
   - How does it change the signal direction, intensity, or recommendation?
   - What specific element of the output card (IMMEDIATE / COMMERCIAL / COMPETITIVE / WC+AIR8) changes?
3. **Generate KB-EXPANSION-FLAG** for every gap, including `would_enable` field (see BRAIN-CHAIN.md Beyond-KB section)

---

### Path B - Persona (Tag Overlap Scoring)

Persona lookup is NOT a direct match. It finds ALL personas that are significantly impacted by the event, using tag overlap scoring.

**Step 4B-i: Build the event tag set**

At ingestion, the event's context fields are normalized into a tag set:

```
eventTags = [
  supplier_country iso code,      → "CN"
  supplier_tier,                  → "tier_2"
  product_category,               → "woven_apparel"
  material,                       → "cotton"
  buyer_geo,                      → "US"
  company_type                     → "FOB"
]
```

**Step 4B-ii: Score all Persona nodes**

```cypher
MATCH (p:Persona)
WITH p,
  size([t IN p.tags WHERE t IN $eventTags]) AS overlap,
  size(p.tags) AS total_tags
WHERE overlap >= 2
RETURN p.id, overlap, total_tags,
  toFloat(overlap) / toFloat(total_tags) AS match_quality
ORDER BY overlap DESC
```

**Important: return ALL personas with overlap ≥ 2, not just the top 1.**
An event can significantly impact multiple personas simultaneously. Each gets its own signal block (Step 5).

**Step 4B-iii: Score bands**

| Overlap | Impact Band | Action |
|---|---|---|
| ≥ 4 tags | HIGH impact | Full context block |
| 2-3 tags | MEDIUM impact | Summary block |
| < 2 tags | Noise | Dropped |

---

## STEP 5: Calculate Relevance Scores

For each located entity, compute:

```
relevance_score = type_weight × role_weight × match_quality
```

| Entity | type_weight | role_weight | match_quality | relevance_score |
|---|---|---|---|---|
| Country:CN | 0.50 | 0.70 (supplier_origin) | 1.0 (direct) | **0.350** |
| Country:US | 0.50 | 0.30 (buyer_geo) | 1.0 (direct) | **0.150** |
| Product:WovenApparel | 0.30 | 1.0 | 1.0 (direct) | **0.300** |
| Persona:COMBO-004 | 0.20 | 1.0 | 5/7 = 0.71 | **0.142** |
| Persona:COMBO-014 | 0.20 | 1.0 | 4/7 = 0.57 | **0.114** |
| Persona:COMBO-001 | 0.20 | 1.0 | 3/7 = 0.43 | **0.086** |

**Noise floor: entities below 0.05 are dropped.**

Now map to context block type:

| Score Range | Block Type |
|---|---|
| ≥ 0.20 | FULL block - all entity attributes, pain points, linked products |
| 0.10-0.19 | SUMMARY block - key risk factors, top 3 pain points |
| 0.05-0.09 | BRIEF mention - name + one risk sentence |
| < 0.05 | Dropped (noise floor) |

**CRITICAL design point:** Each persona gets its OWN separate signal block. Do NOT merge them.
- Merged signals lose persona-level precision → generic advice that doesn't fit anyone
- Per-persona signals enable segment-specific BD advice → actionable for each archetype

```
[Signal: COMBO-004 - China Medium Woven FOB]       ← HIGH impact (0.142 ≥ 0.10)
  Pain points: PP-CN-001 (SAFE compliance), PP-002 (financing cost)
  Regulations: UFLPA (HIGH), REACH (MEDIUM)
  Recommended: ARP (Hengqin lane), SmartWallet, Pool

[Signal: COMBO-014 - India Small Woven]            ← MEDIUM impact (0.114 ≥ 0.10)
  Pain points: PP-IN-001 (GST delay), PP-002 (financing cost)
  Recommended: ARP, RT2C
```

---

## STEP 3b: Correlated Event Check - MANDATORY

> P0-8 gate. This step is mandatory for every event. Do NOT skip.

Before moving to Step 4, query the `active_event_cache` for any existing events with ≥2 overlapping tags (country, material, buyer_geo, event_subtype).

```
IF active_event_cache contains event(s) with overlap ≥ 2 tags:
  → CLASSIFY relationship type:
    AMPLIFYING:    both events push in same direction → urgency increases, window tightens
    REFRAMES:      new event changes interpretation of cached event → cached signal must be revised
    OFFSETS:       events partially cancel each other → net signal muted
    INDEPENDENT:   overlap in country but different mechanisms → emit separately
  → If AMPLIFYING or REFRAMES: generate COMBINED card (not standalone)
  → Mark correlated events with state=incorporated_in, relationship_type, combined_read_id
  → DEDUPLICATE: if this event was already incorporated into a combined card, emit link not new card
ELSE:
  → Proceed to Step 4 normally
```

**Example:** Event B (CSDDD compliance) + Event E (Turkey volume -17%) for COMBO-005 → AMPLIFYING → combined card: "double WC stress → ARP + compliance financing pitch".

**Example:** E7 (+20% order lift) + S1 (copper tariff) for COMBO-HG-001 → REFRAMES → E7 signal downgraded from EXPAND to CONDITIONAL.

See `EVENT-PRINCIPLES.md` → RP-EVT-CORRELATED-PAIR for full directive template.

---

## STEP 5b: Intensity Scoring

> After loading entity context (Step 5), before computing signal (Step 6).

Assign an impact level to each matched persona based on the magnitude of the event and the persona's exposure:

| Impact Level | Criteria |
|---|---|
| **CRITICAL** | Direct hit on primary revenue source; buyer concentration >50%; active cliff date within 60 days |
| **HIGH** | Direct hit on secondary revenue source; margin compression >15%; 30-60 day window |
| **MEDIUM** | Indirect exposure; margin compression 5-15%; window 60-120 days |
| **LOW** | Peripheral exposure; margin compression <5%; window >120 days |

For each persona, document: impact_level + which specific Assessment Dimensions drive the rating (buyer_concentration, margin_range, cash_cycle_days, etc.).

---

## STEP 6: Match Solutions + Multi-Family Convergence

### 6a — Per-Family Solution Match

For each activated family’s signal block, look up SOLUTIONS.md:
- Which event type × persona combinations trigger which products
- Contraindications (what NOT to recommend)
- Urgency level

Cross-reference the persona’s active pain points against the product’s `solves` and `applies_when` conditions.

### 6b — Multi-Family Convergence (when 2+ families activated)

After all family chains complete, check for product recommendations that appear across multiple families:

```
EVT-TARIFF chain     → recommends: ARP, SmartWallet
EVT-MARKET-SHIFT chain → recommends: ARP, RT2C

Convergence check:
  ARP appears in BOTH → [MULTI-SIGNAL] → highest confidence pitch
  SmartWallet: STRONG family only → standard confidence
  RT2C: MODERATE family only → secondary pitch
```

**Convergence output ranking rules:**

| Source | Label | Output Placement |
|---|---|---|
| Appears in 2+ activated families | `[MULTI-SIGNAL]` | Top of COMMERCIAL block; lead pitch |
| STRONG family only | `[STRONG]` | Standard position in COMMERCIAL block |
| MODERATE family only | `[MODERATE]` | After STRONG items; supplement section |
| BEYOND-KB only | `[HYPOTHESIS]` | Flagged separately; not a lead pitch |

**Rule:** Do not merge signal blocks from different families into one. Keep them labeled by source family. Convergence is a ranking signal, not a merge instruction — the distinct analytical angles (cost structure vs sourcing pattern) must both appear in the output.

---

## Overlay Rules - Run After Every Event

These rules are not event-type-specific. They overlay the primary signal and can flip or qualify it.

### RP-STRUCTURAL-CHANGE - Is the change permanent or cyclical?

Before accepting any signal at face value, ask:
- Is this event driven by forces that are structural (permanent, irreversible) or cyclical (temporary, reversible)?
- Structural events → long-horizon signal; cyclical events → short-horizon, monitor-only

**Example:** BD wage escalation is structural (government-mandated minimum wage schedule, politically locked). A one-quarter FX dip is cyclical. The same magnitude of impact triggers different Air8 product recommendations.

**How to apply:** After Steps 1-5 produce a raw signal, run RP-STRUCTURAL-CHANGE check before finalizing. If structural → CONFIRM signal. If cyclical → downgrade to MONITOR or CONDITIONAL.

---

### RP-WINDOW - Is there a time-sensitive action window?

**Question:** Does this event have an active cliff date, consultation deadline, ratification milestone, or contract renewal trigger that creates urgency?

If yes → the signal is only actionable within the window. Outside the window, the same underlying facts may produce a different or NEUTRAL signal.

**Example:** EU CSDDD consultation deadline July 24 → factories that pause compliance investment now face a compressed 2027-2028 timeline. The "false relief" window IS the action opportunity.

**How to apply:** After Steps 1-5, check if the event has an active cliff_date. If yes → flag the window, time-slice the signal: before the cliff vs after.

---

### RP-PEER-FAILURE - Did a competitor fail, and does the supplier face the same causes?

**Question:** When a competitor closes or fails, do NOT automatically upgrade the survivor's signal. Check whether the survivor faces the same structural causes that killed the competitor.

If the survivor faces the same structural forces → the survival is temporary, not a durable advantage. Volume growth without margin improvement = classic pre-failure pattern.

**How to apply:** Applied to any event involving competitor closure, factory shutdown, or market exit. Steps:
1. Why exactly did the peer fail? (structural cause or one-time event?)
2. Does the survivor face the same structural causes?
3. Is the survivor's new volume durable (multi-season written contracts) or temporary (buyer test)?
4. Is margin per unit on new inflow > or < existing book margin?

If structural causes are shared + new inflow margin < existing → CAUTION (not CONDITIONAL or EXPAND). The survivor may be a "not-yet-failed" factory.

---

### RP-CONCENTRATION - Is Air8's portfolio disproportionately exposed?

**Question:** If this event affects a country or product category, does Air8 have concentrated exposure that amplifies portfolio-level risk?

**How to apply:** After Steps 1-5, check:
- What % of Air8's active financed volume is in the affected country/category?
- Is this a single-buyer supplier or multi-buyer supplier in the affected zone?
- Concentration > 30% of portfolio in affected zone → elevated risk flag regardless of individual supplier signal.

---

### RP-CASCADE - Does the event create downstream effects on linked entities?

**Question:** Does this event cascade to affect entities beyond the directly implicated country/category?

**Example:** Factory closure in BD → fabric/yarn suppliers lose demand → ginners in India lose demand → cotton price softens → BD farmers plant less next season. Each step in the cascade maps to different Air8 clients.

**How to apply:** Used for supply disruption, factory closure, port congestion events. The primary signal is the direct effect. The cascade signal is secondary but may identify second-order Air8 exposure.

---

### RP-EVT-PRODTREND-01 - Is this a structural category shift or a cyclical demand blip?

**Question:** When demand declines for a product category, is this permanent (buyer taste shift, structural cost shift) or cyclical (seasonal, recession-driven)?

**Distinction matters:**
- Price stable + volume declining → CATEGORY BIFURCATION (some buyers leaving, others stable or growing). Treat as selective, not collapse.
- Volume declining + price declining → STRUCTURAL SHIFT. All players affected.
- Volume declining + price rising → PREMIUM SEGMENT SHIFT. Mass market exits; premium holds.

**How to apply:** Applied to EVT-MARKET-SHIFT events. After Steps 1-5, categorize the demand shift by price/volume behavior. Adjust signal direction accordingly.

---

## STEP 7: Mandatory Output Gates - P0 Checks

Before finalizing any event card, all of the following must be satisfied:

### KB_EXPANSION_FLAGS Section (mandatory if any `[KB-GAP]` found in STEP 0)
Append to every output card that had KB gaps:

```
KB_EXPANSION_FLAGS:
  [KB-EXPANSION-FLAG] type=UPDATE-ENTITY | entity=countries/IN.md
    gap: MSP floor interaction with commodity tax changes not modeled
    evidence: STEP 0 found MSP at INR 6,620/quintal absorbs ~40% of exemption benefit
    priority: MEDIUM → include in next KB update cycle
    route_to: Josephine Cheung expert review

  [KB-EXPANSION-FLAG] type=NEW-PRINCIPLE | proposed: PRIN-GOVT-FLOOR
    gap: No principle for government price floors that neutralize commodity signals
    evidence: STEP 0 found MSP prevents full pass-through of GST exemption
    priority: HIGH → flag signal as [PENDING DATA] until principle is validated
    route_to: Josephine Cheung expert review - IMMEDIATE
```

### P0-6: Competitive Dynamics - Who Gained, Who Lost?
> Every signal must answer: because of this event, did some Air8 clients gain PO volume or margin while others lost it?

If the event creates a sourcing shift, demand change, or capacity reallocation → the output MUST explicitly state which persona archetype(s) gained and which lost. Do not emit a generic "negative outlook for [country]" without specifying who wins and who loses within that geography.

**Template:** "Because of this event: [Persona A] likely gains [X] as [mechanism]. [Persona B] likely loses [Y] as [mechanism]. Air8 positioning: [action for gainers] / [action for losers]."

### P0-7: Claim Confidence Labels - All WHY Claims
> Every factual claim in the WHY section of the output must be tagged with a confidence label.

| Label | Meaning | When to use |
|---|---|---|
| `[VERIFIED]` | Confirmed by official source (customs data, government publication, buyer filing) | Active news, official announcements |
| `[EXPERT]` | Domain knowledge from Josephine Cheung review or validated specialist input | Hardgoods-specific, market dynamics |
| `[HYPOTHESIS]` | Reasonable inference from pattern but not confirmed | Logical extension of known facts |
| `[PENDING DATA]` | Claim depends on data not yet available | Tariff magnitude before official publication |

**Rule:** If a claim cannot be labeled, it must not appear as a confident assertion in the WHY section. Move it to QUALIFYING QUESTIONS instead.

### P0-8: Correlated Event Cache Check
> Done at Step 3b. Confirm the check was run and the result is reflected in the output.

Output must explicitly state: "Correlated event check: [none / AMPLIFYING / REFRAMES / OFFSETS / INDEPENDENT] - [brief rationale]." If AMPLIFYING or REFRAMES, the combined card supersedes individual cards.

---

## Summary: File Responsibility Map

| Step | Responsible File |
|---|---|
| Step 1 routing key | Event node (raw - no file) |
| Step 2 principle activation weights | EVENT-TYPES.md |
| Step 3 type_weight aggregation | This file + PRINCIPLES.md (entity_focus per principle) |
| Step 3b correlated event check | This file + EVENT-PRINCIPLES.md (RP-EVT-CORRELATED-PAIR) |
| Step 4a entity direct match | Layer 2 entity files (countries/, product-categories/) |
| Step 4b persona tag overlap | PRINCIPLES.md (PRIN-SUPPLIER-RESILIENCE reasoning logic) + COMBO-*.md (tags) |
| Step 5 weight formula | This file (formula + worked example) |
| Step 5b intensity scoring | This file (CRITICAL/HIGH/MEDIUM/LOW table) |
| Step 6 solutions | SOLUTIONS.md |
| Step 7 output gates (P0-6, P0-7, P0-8) | This file + EVENT-PRINCIPLES.md (per-principle directive templates) |
| Overlay rules | PRINCIPLES.md (each RP-* rule) + EVENT-PRINCIPLES.md (RP-EVT-* subtype principles) |

---

## Signal Decision Rules — Priority Hierarchy & Grammar

> Merged from signal-decision-rules.md | Version: 1.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> This file governs how conflicting signals are resolved and how composed signals are expressed.
> Cross-reference: PRIMITIVES.md (for RP-INFORMATION-DEFICIT when MONITOR signal is triggered)

---

### 1. Priority Hierarchy (4 Tiers)

When multiple signals are triggered by a single event, the hierarchy below governs which signal wins and what is surfaced to BD.

#### Tier 1 — Compliance (Always Overrides)
**Triggers that always override commercial or risk signals:**
- UFLPA / Xinjiang cotton detection in supply chain
- Active US or EU sanctions (OFAC, UK OFSI) affecting buyer or supplier entity
- Third-party payment prohibition triggered (trader/agent with no factory assets)

**Effect:** Tier 1 compliance signals HALT commercial recommendations. No commercial or risk signal (EXPAND, CONDITIONAL, CAUTION, DO_NOT_EXPAND, NEUTRAL, MONITOR, RESTRUCTURE, EXPAND_WITH_HEDGE, WATCH_HEDGE_GAP) can override a Tier 1 trigger. BD receives a compliance flag first; commercial discussion only after compliance is resolved.

#### Tier 2 — Risk (Overrides Commercial)
**Triggers that override any Tier 3 or Tier 4 commercial signal:**
- Single buyer revenue share > 60%
- Buyer distress signals: payment lengthening >15d, credit downgrade, M&A uncertainty
- Air8 bank facility utilisation > 90%
- Concentration cap breach (single commodity >30%, country cap exceeded)

**Effect:** Tier 2 risk signals suppress EXPAND signals. If Tier 2 is active, output CAUTION or DO_NOT_EXPAND regardless of commercial opportunity. Risk signal must appear in output WITH tier label.

#### Tier 3 — Structural (Overrides Fact-Based Commercial)
**Business model facts that override raw-data commercial signals:**
- Buyer-nominated input share > 80% (raw material event savings do NOT reach factory)
- All-organic sourcing with GOTS certification (import duty savings irrelevant to certified lines)
- No factory assets (trader/agent model — third-party payment prohibition risk)
- Country eligibility block (factory country not eligible for target buyer program)

**Effect:** Tier 3 structural conditions modify or reverse the default commercial signal before it reaches the output. These are permanent architectural facts — not event-dependent.

#### Tier 4 — Commercial (Lowest; No Override Authority)
**Pure commercial opportunity signals:**
- Buyer geography mix uplift (event improves factory's competitive position in a buyer geo)
- Margin improvement threshold (cost event directly benefits factory margin)
- Competitive repositioning opportunity (factory gains relative to peer origins)

**Effect:** Tier 4 signals are the "default" recommendation absent Tier 1-3 triggers. They are displayed but can be overridden by any higher tier.

---

### 2. Conflict Resolution Rule

> **"Most restrictive signal wins WITHIN the same tier. Higher tier always overrides lower tier."**

**Within-tier conflict example:**
- Tier 2 triggered by both: buyer_concentration >60% AND bank_utilisation >90%
- Resolution: Surface BOTH signals in output. The most restrictive output signal wins (DO_NOT_EXPAND beats CAUTION).

**Cross-tier conflict example:**
- Tier 3 structural: buyer_nominated >80% → NEUTRAL
- Tier 4 commercial: cotton duty cut → EXPAND
- Resolution: Tier 3 wins. Output: NEUTRAL. BUT: Tier 4 signal must still appear in output with tier label so BD understands the underlying opportunity for OTHER combos.

---

### 3. Visibility Rule

> **"All triggered signals must appear in output with tier label — not just the winner. BD must see the full picture."**

Format for output:
```
Tier 1 [COMPLIANCE]: UFLPA — Xinjiang exposure detected. All commercial signals suppressed.
Tier 3 [STRUCTURAL]: Buyer-nominated >80% → raw material savings do not reach factory.
Tier 4 [COMMERCIAL]: India cotton duty cut → EXPAND signal (suppressed by Tier 3).
FINAL SIGNAL: DO_NOT_EXPAND (Tier 3 structural override)
```

This visibility rule ensures BD can:
1. Understand why the commercial signal was suppressed
2. Identify which combos might benefit (where Tier 3 doesn't apply)
3. Correct structural assumptions if the client provides new information

---

### 4. Extended Signal Vocabulary

#### Primary Signals
| Signal | Meaning |
|---|---|
| `EXPAND` | Clear net benefit; recommend increasing exposure or new position |
| `CONDITIONAL` | Benefit exists but requires specific condition to be verified first |
| `CAUTION` | Risk factor present; maintain but monitor closely; no new expansion |
| `DO_NOT_EXPAND` | Net risk outweighs benefit; hold existing positions, no new |
| `NEUTRAL` | Event does not materially affect this combo |
| `MONITOR` | Signal uncertain; add to watch list; trigger RP-INFORMATION-DEFICIT check (see PRIMITIVES.md) |
| `RESTRUCTURE` | Current facility structure needs revision to fit changed conditions; maps to RP-STRUCTURAL-CHANGE primitive |
| `EXPAND_WITH_HEDGE` | Precondition: expand ONLY IF hedge confirmed in place (e.g., FX forward contract, buyer credit insurance). BD must confirm hedge exists before proceeding. |
| `WATCH_HEDGE_GAP` | Risk monitoring state: proceed with current exposure but flag active hedge gap to client and credit team. Does not block action. |
| `BUYER_SPLIT` | Buyer concentration risk; recommend splitting facility across 2+ buyers |

#### EXPAND_WITH_HEDGE vs WATCH_HEDGE_GAP — Usage Guidance
```
EXPAND_WITH_HEDGE — use when: hedge is required for the deal to be safe
  (e.g., EUR-denominated supplier needs FX confirmation for non-EUR markets,
  post-cliff stockpile needs WC plan confirmed)

WATCH_HEDGE_GAP — use when: existing position has unhedged exposure that should be
  monitored but doesn't block current action
  (e.g., TRY volatility on existing ARP position)

BD conversation difference:
- EXPAND_WITH_HEDGE: "We can proceed once we confirm [X hedge] is in place.
    What's your current FX/insurance coverage?"
- WATCH_HEDGE_GAP: "We can proceed. I want to flag that [X exposure] is unhedged —
    let's discuss whether that's intentional."
```

### 9-Signal Complete Vocabulary (reference)
Primary signals: EXPAND | CONDITIONAL | CAUTION | DO_NOT_EXPAND | NEUTRAL | MONITOR | RESTRUCTURE | EXPAND_WITH_HEDGE | WATCH_HEDGE_GAP
- MONITOR maps to RP-INFORMATION-DEFICIT primitive (see PRIMITIVES.md)
- RESTRUCTURE maps to RP-STRUCTURAL-CHANGE primitive (see PRIMITIVES.md)

#### Composition Operators
| Operator | Meaning | Example |
|---|---|---|
| `AND_IF` | Signal applies only if secondary condition is true | `EXPAND AND_IF buyer_PO_confirmed` |
| `OR` | Either condition triggers the signal | `CAUTION OR RESTRUCTURE` (use most restrictive) |
| `PER_AXIS` | Signal varies by dimension | `EXPAND (EU axis) | NEUTRAL (US axis)` |
| `TIME_SLICED` | Signal changes over time window | `EXPAND (Jun-Sep) | CAUTION (Oct)` |
| `PRECEDES` | Action must complete before secondary | `EXPAND PRECEDES cliff_date` |

#### Composed Signal Examples
```
# India cotton duty event — Turkey denim factory (COMBO-005)
CAUTION AND_IF india_denim_mills_upgrade_finishing (competitive threat, not direct benefit)

# Bangladesh CMT — India cotton event with buyer-nominated fabric
NEUTRAL (Tier 3 structural override: buyer_nominated >80%; savings stay with buyer)
Underlying Tier 4 signal: EXPAND (suppressed)

# India Vertical — cliff event approaching
EXPAND AND_IF buyer_PO_confirmed (Jun-Sep) | CAUTION AND_IF tenor > 90d (Sep-Oct) | RESTRUCTURE (Nov+)

# Pakistan home textile — India cotton duty cut
CAUTION PER_AXIS [competitive threat: Indian home textile mills gain cost advantage in US buyers]
```

#### Confidence Per Signal
Each emitted signal must include a confidence score. Confidence is assigned PER SIGNAL, not overall.

```
{
  "signal": "EXPAND",
  "confidence": 0.85,
  "tier": 4,
  "condition": "buyer_PO_confirmed",
  "operator": "AND_IF",
  "basis": "India cotton duty cut → direct benefit to domestic procurement blend"
}
```

---

### 5. Conflict Resolution Worked Examples

#### Example 1: BD CMT Factory — India Cotton Duty Cut
**Situation:** India reduces import cotton duty by 10%. BD CMT factory (COMBO-002) identified.

**Signals triggered:**
- Tier 4 [COMMERCIAL]: Cotton cost reduction → EXPAND (India yarn prices may fall)
- Tier 3 [STRUCTURAL]: Buyer-nominated fabric >90% → savings do not reach BD CMT factory

**Resolution:** Tier 3 overrides Tier 4.
**Output:** NEUTRAL. Tier 4 EXPAND signal shown with explanation: "Underlying EXPAND signal exists for India Vertical (COMBO-003) where sourcing is own-managed."

---

#### Example 2: India Vertical + Approaching Cliff Date
**Situation:** India cotton duty window ends Oct 31. Currently 18 days remaining.

**Signals triggered:**
- Tier 4 [COMMERCIAL]: Active duty benefit → EXPAND
- Tier 2 [RISK]: Tenor >18d → disbursements past cliff date risk
- Tier 1 [COMPLIANCE]: None triggered

**Resolution:** Tier 2 overrides Tier 4.
**Output:** DO_NOT_EXPAND for new positions. Existing positions flagged for cliff review.
**Formula applied:** latest_safe_disbursement = cliff_date - tenor - 5d = Oct 31 - 90d - 5d = Jul 27. Today is beyond that date.

---

#### Example 3: China FOB Factory — US Tariff Event
**Situation:** US announces additional 15% tariff on Chinese cotton apparel.

**Signals triggered:**
- Tier 4 [COMMERCIAL]: China cost competitiveness in US → negative commercial signal
- Tier 3 [STRUCTURAL]: EU revenue >70% for this factory → US tariff is LOW materiality
- Tier 4 [COMMERCIAL]: EU buyer demand for CN speed/complexity unaffected → EXPAND (EU axis)

**Resolution:** PER_AXIS resolution.
**Output:** `EXPAND PER_AXIS [EU: EXPAND] | DO_NOT_EXPAND [US: structural trend — shrinking book]`
**BD note:** "This factory has already de-emphasized US buyers by design. EU book benefits from CN speed advantage; US book should not be expanded further."


---

## Intensity Scoring Engine

> Merged from intensity-scoring-engine.md | Applies to: all Pain Points (PP-*.md) and all Event Triggers (S1 event taxonomy)
> Purpose: consistent, automated intensity computation at runtime from factory profile
> Updated: 2026-07-13

---

### Design Principle

Intensity is NOT a static label in the KB.
It is a score computed at runtime from two inputs:
1. **KB (static):** base_score + driver definitions per PP or event
2. **Factory profile (runtime):** assessment dimension answers from R1/R2

The KB stores WHEN a pain becomes critical.
The scenario determines IF it is critical for this specific factory.

---

### Score Scale

| Score Range | Intensity Level | Meaning |
|------------|----------------|---------|
| 80–100 | CRITICAL | Existential or near-term severe threat; lead opener |
| 60–79 | HIGH | Significant active pain; strong pitch material |
| 35–59 | MEDIUM | Present but manageable; qualifying question trigger |
| 15–34 | LOW | Watch only; not pitch material yet |
| 0–14 | INACTIVE | Dormant; skip in output |

---

### Scoring Formula

```
computed_score =
  base_score                    # inherent severity for this archetype (KB-defined)
  + exposure_score              # how exposed is this factory? (0–20)
  - capacity_discount           # does factory have capacity to absorb? (0–20)
  + urgency_bonus               # is there a near-term deadline? (0–15)
  + compound_bonus              # other high/critical PPs also active? (0–15 per co-active PP, max 30)

computed_score = min(100, max(0, computed_score))
intensity_level = map computed_score → scale above
```

---

### Driver Definitions

### exposure_score (0–20)
Measures how directly the factory intersects with the pain.
Each PP defines its primary exposure dimension and mapping:

| Exposure level | Score |
|---------------|-------|
| Factory is fully exposed (e.g., 100% EU revenue for an EU-tariff PP) | +20 |
| Highly exposed (e.g., >70% EU revenue) | +15 |
| Moderately exposed (e.g., 40–70%) | +10 |
| Low exposure (e.g., 20–40%) | +5 |
| Minimal / not exposed | 0 |

### capacity_discount (0–20)
Measures how well the factory can absorb or has already mitigated the pain.

| Capacity level | Discount |
|---------------|---------|
| Pain fully mitigated (e.g., factory already on GSP+ track, or using Air8 ARP) | -20 |
| Partially mitigated (e.g., some reserves, partial hedging) | -10 |
| No mitigation, but margin is healthy (>15%) | -5 |
| No mitigation, margin thin (<8%) | 0 |
| Pain actively worsening | +0 (use compound_bonus instead) |

### urgency_bonus (0–15)
Measures time pressure — is there a deadline driving action now?

| Urgency | Bonus |
|---------|-------|
| Deadline < 6 months | +15 |
| Deadline 6–18 months | +10 |
| Deadline 18–36 months | +5 |
| No specific deadline / structural pain | 0 |

### compound_bonus (0–30 max)
Each additional PP or event trigger that is simultaneously HIGH or CRITICAL for this factory:
- +15 per co-active PP that shares an exposure dimension (compound risk)
- Max cap: +30 (two or more co-active compounds)

Example: PP-BD-003 (LDC graduation) + PP-003 (buyer concentration) both HIGH for a 72% EU-revenue factory → compound_bonus = +15 each compound interaction = PP-BD-003 gets +15 compound bonus from PP-003 co-active

---

### PP File Standard Structure

Every PP-*.md file must use this structure (replacing the old static `intensity:` label):

```yaml
# PP-XXX — [Name]

### Identity
id: PP-XXX
type: pain_point | event_trigger
category: universal | country | esg | expansion
scope: [BD | IN | TR | VN | etc. | all]
updated: YYYY-MM-DD

### Angle / Logic / View (KB — static)
angle: [1–2 sentences: WHY this matters structurally]
logic: [the mechanism — HOW the pain works]
view:  [Air8's perspective — what this means for BD/credit/risk]

## Intensity Scoring (KB — static parameters)
base_score: [0–100]
# Rationale: [why this base score — what's the default severity for the target archetype]

primary_exposure_dimension: [field name from assessment dimensions]
exposure_mapping:
  high:   { condition: "[dimension] > [threshold]", score: 20 }
  medium: { condition: "[dimension] > [lower threshold]", score: 10 }
  low:    { condition: "[dimension] > [minimal]", score: 5 }
  none:   { condition: "default", score: 0 }

capacity_dimensions:
  - dimension: [field name]
    fully_mitigated:   { condition: "[state]", discount: 20 }
    partly_mitigated:  { condition: "[state]", discount: 10 }
    healthy_buffer:    { condition: "[state]", discount: 5 }

urgency_source: [what creates time pressure — deadline, event, regulatory cycle]
urgency_mapping:
  critical: { condition: "[e.g., deadline_months < 6]", bonus: 15 }
  high:     { condition: "[e.g., deadline_months 6–18]", bonus: 10 }
  medium:   { condition: "[e.g., deadline_months 18–36]", bonus: 5 }
  none:     { condition: "no deadline", bonus: 0 }

compound_triggers:
  - with: [PP-id or event type]
    condition: [when does this compound apply]
    bonus: 15

### Live Data (web_lookup — resolve at runtime)
# [Only for DATA_FIGURE fields — rates, counts, policy statuses, market figures]
# Structural ranges that define the archetype stay above as angles/logic
web_lookup:
  - field: [field_name]
    query: "[search query with [year] placeholder]"
    freshness: quarterly | annual | stable
    fallback: "[last known value with date]"

### Air8 Connection
products: [list of PROD-ids that address this pain]
bd_hook: [one-sentence opener for BD conversation]
qualifying_question: [the key question to surface this pain in R1/R2]
```

---

### What Stays in KB vs Web Lookup

### Stays in KB (structural — defines the archetype, does not expire quickly)
- gross_margin_band (e.g., 5–12%) — structural characteristic of archetype
- cash_cycle_days ranges — structural operational pattern
- revenue_band — segmentation characteristic
- concentration_pattern (e.g., top 2 buyers = 40–65%) — behavioral pattern
- eligibility thresholds (Air8 internal rules — $1M min, 2yr ops, 6mo ARP track record)
- dilution rates by buyer type — structural buyer behavior pattern
- GST/VAT refund cycle days — structural mechanics of tax system (changes rarely)

### Moves to web_lookup (live market data — changes periodically)
- Bank OD rates / financing rates (any country) — quarterly
- Minimum wage figures — annual
- Tariff rates — annual
- Convention counts (e.g., GSP+ requirements) — annual
- Government ratification status — quarterly
- Currency depreciation % — quarterly
- Commodity prices — quarterly

### Computed at runtime (never stored)
- Actual computed_score for a specific factory
- Actual intensity_level for a specific factory
- Compound_bonus values

---

### Event Trigger Scoring

Event triggers (S1 taxonomy: A–F + sub-types) use the same scoring model.
Additional driver: **relevance_score** instead of exposure_score.

```
event_computed_score =
  base_score                    # how severe is this event type for the archetype
  + relevance_score             # does this factory's supply chain intersect? (0–20)
  - capacity_discount           # factory's ability to absorb the event impact
  + urgency_bonus               # how soon does the event take effect?
  + compound_bonus              # other active events or PPs compounding?
```

relevance_mapping (event-specific):
- For supply-side events: intersection with factory's material sourcing
- For demand-side events: intersection with factory's buyer geo/type
- For regulatory events: intersection with factory's export market
- For cost events: intersection with factory's cost structure

---

### Runtime Computation Step

Added to S2 between R2-1 (instance match) and R2-2 (load data):

```
Step R2-1b: COMPUTE INTENSITY
  For each active PP for this archetype:
    1. Read base_score from PP file
    2. Read factory dimensions from R1/R2 answers
    3. Apply exposure_mapping → exposure_score
    4. Apply capacity_dimensions → capacity_discount
    5. Apply urgency_mapping → urgency_bonus (use web_lookup for deadline if needed)
    6. Check compound_triggers → compound_bonus
    7. computed_score = base + exposure - capacity + urgency + compound (cap 100)
    8. Map to intensity_level
  Sort PPs by computed_score descending
  → Output: ranked pain list with computed intensity (not KB base intensity)
```

Same step added to S1 for event impact scoring.

---

### Worked Example: PP-BD-003 for two factories

**Factory A:** eu_revenue_pct=72%, gsp_plus_preparedness=none, deadline=Nov 2026 (4mo away)
```
base_score:        55  (moderate default — not existential for all BD factories)
exposure_score:   +20  (eu_revenue_pct=72% > 50% → high)
capacity_discount:  0  (gsp_plus_preparedness=none → no mitigation)
urgency_bonus:    +15  (deadline_months=4 < 6 → critical urgency)
compound_bonus:   +15  (PP-003 buyer concentration also HIGH for this factory)
─────────────────────
computed_score:   105  → capped at 100 → CRITICAL
```

**Factory B:** eu_revenue_pct=25%, gsp_plus_preparedness=active_programme, deadline=Nov 2026
```
base_score:        55
exposure_score:    +5  (eu_revenue_pct=25% → low)
capacity_discount:-20  (gsp_plus_preparedness=active → fully mitigated)
urgency_bonus:    +15  (same deadline, but mitigation in progress)
compound_bonus:     0  (no co-active compound PPs)
─────────────────────
computed_score:    55  → MEDIUM
```

Same PP — CRITICAL vs MEDIUM — because the factory profile is different.

## Related

- [BRAIN-CHAIN.md](BRAIN-CHAIN.md) — Conceptual map for the reasoning flow; this file is the detailed version
- [EVENT-TYPES.md](../taxonomy/EVENT-TYPES.md) — Event type taxonomy used throughout reasoning flow
- [L1-adverse-news-method.md](../methods/L1-adverse-news-method.md) — Adverse news severity assessment in reasoning flow
- [L1-trend-method.md](../methods/L1-trend-method.md) — Trend assessment in reasoning flow
