# China Operations Playbook — Air8 Internal

> Version: 1.0 | Owner: Jerri Zhou + Risk Team | Created: 2026-07-01
> Internal operational rules only. Country structural facts are in `_country/CN.md`.

---

## Hengqin Entity Caps (Internal Rule)
- Single company: ≤40% of CN portfolio
- Group exposure: ≤50% of CN portfolio
- Total: ≤10x registered capital
- Action: credit team checks before any COMBO-004/COMBO-013 CN expansion
- Review: before each new CN client onboarding

---

## SAFE Cross-Border Compliance
- All cross-border payments must comply with SAFE (State Administration of Foreign Exchange)
- SSQ (上上签) e-signing required for contracts
- SAFE compliance requires specific documentation for cross-border trade finance flows; Air8 China structure uses Hengqin entity (Zhuhai Hengqin free trade zone)
- Action: ops team confirms SAFE compliance before deal close; BD must not proceed without ops sign-off

---

## Sinosure Monthly Declaration
- Sinosure (China Export Credit Insurance Corporation) requires monthly declaration of all insured receivables
- Declaration deadline: 15th of each month; miss = coverage void
- Factories using both Sinosure and Air8 must manage declaration requirements carefully to avoid double-counting or compliance gaps
- Action: ops team sets monthly reminder; BD must inform CN clients of Sinosure coordination requirement at onboarding

---

## Xinjiang Cotton Protocol
- Any detected Xinjiang cotton (XPCC-linked or origin-ambiguous) in US/EU-bound shipment = CRITICAL flag
- Immediate escalation to compliance team
- Do NOT proceed with ARP on that shipment until UFLPA compliance confirmed
- Per-order cotton traceability documentation must be in place BEFORE shipment

---

## Related

- [China.md](../../layer-2/countries/China.md) — China country profile; SAFE/NDRC/MOFCOM regulatory environment
- [PP-CN-001-safe-complexity.md](../pain-points/country/PP-CN-001-safe-complexity.md) — SAFE compliance complexity
- [PP-CN-002-sinosure-burden.md](../pain-points/country/PP-CN-002-sinosure-burden.md) — Sinosure burden
- [cliff-playbook.md](cliff-playbook.md) — Cliff playbook as companion for tariff/time-window events
- [COMBO-004-china-medium-woven.md](../../layer-2/personas/apparel/COMBO-004-china-medium-woven.md) — China medium woven apparel persona; primary CN playbook user
- [COMBO-013-multi-country-group.md](../../layer-2/personas/apparel/COMBO-013-multi-country-group.md) — Multi-country group using CN operations
- [REG-UFLPA.md](../../layer-2/regulations/REG-UFLPA.md) — UFLPA compliance protocol for Xinjiang cotton
