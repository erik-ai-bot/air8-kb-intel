# Cliff Playbook — Time-Window Management Protocol

> Version: 1.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> Use this playbook whenever an event has a cliff_date (hard deadline after which conditions reverse).
> Referenced from: S1-event-insights.md (P0-3), signal-decision-rules.md (Tier 2 risk)

---

## What is a Cliff Event?

A cliff event has a hard deadline — a date after which the opportunity disappears or conditions sharply reverse. Examples:
- Import duty exemption window ending (e.g., India cotton duty ends Oct 31)
- LDC graduation tariff change (Bangladesh EBA → post-GSP tariff)
- Seasonal sourcing deadline (H&M SS ordering close)
- Sanction effective date
- Regulatory compliance enforcement deadline

The cliff creates an asymmetric risk profile: **opportunity BEFORE the cliff, risk AFTER.**

---

## Latest Safe Disbursement Formula

```
latest_safe_disbursement_date = cliff_date - tenor_days - 5d_buffer

Example:
  cliff_date: Oct 31
  tenor: 90 days
  buffer: 5 days
  → latest_safe_disbursement_date = Oct 31 - 90 - 5 = Jul 27

Any disbursement after Jul 27 cannot self-liquidate before the cliff.
```

**Always calculate and display this date in every S1 card involving a cliff event.**

---

## 5-Phase Cliff Protocol

### Phase 1: Pre-Cliff Aggressive (>60 Days Remaining)
**When:** cliff_date - today > 60 days

**⚠️ CRITICAL — Calculate latest_safe_disbursement_date IMMEDIATELY even in Phase 1:**
```
latest_safe_OBF_date = cliff_date - OBF_tenor_days - 5d_buffer
Example: Oct 31 cliff - 90d tenor - 5d = July 27
```
Even in Phase 1, the OBF window may already be narrow if the event window started months ago.
Do NOT assume Phase 1 = unlimited time. Always compute the actual latest safe date first.

**Air8 stance:**
- Full EXPAND signal for eligible combos
- Standard tenor (up to 90d for OBF if cliff <120d remaining; 120d only if cliff >120d remaining)
- Full limit utilisation permitted
- Actively front-load disbursements to eligible clients — earlier is always safer
- Proactive BD outreach: send S1 event cards to relevant combo contacts

**Client guidance:**
- Encourage clients to plan cotton/material procurement within this window
- Lock forward contracts if possible to extend effective benefit past cliff
- Alert clients to the cliff date AND the latest safe disbursement date (not just cliff date)

**Alert:** Send T-60d notification to all relevant clients (see Alert Protocols below)

---

### Phase 2: Mid-Window (30–60 Days Remaining)
**When:** 30 < cliff_date - today ≤ 60 days

**Air8 stance:**
- Normal operations continue
- No new limit expansion — maintain existing positions
- Monitor client stockpile plans: are they ordering proportionally to expected demand?
- Watch for over-stockpiling indicators (orders >2x seasonal norm)

**Client guidance:**
- Verify client has placed fabric/material orders aligned with production calendar
- Check whether existing Air8 disbursements will self-liquidate before cliff date
- Begin identifying clients who will need post-cliff wind-down support

**Alert:** Send T-30d notification to active clients with open positions

---

### Phase 3: Late Window (15–30 Days Remaining)
**When:** 15 < cliff_date - today ≤ 30 days

**Air8 stance:**
- Tenor compression: cap new disbursements at 90-day tenor maximum
- Front-load any remaining approved disbursements before latest_safe_disbursement_date
- Warn existing clients with long-tenor positions: review maturity dates
- No new pre-shipment positions for clients who cannot self-liquidate by cliff

**Client guidance:**
- "Your latest safe disbursement date is [calculated date]. Any orders placed after this cannot be funded by Air8 under current structure."
- Identify clients who need post-cliff restructuring

**Alert:** Send T-15d notification with cliff countdown and latest disbursement date

---

### Phase 4: Final Window (<15 Days Remaining)
**When:** cliff_date - today ≤ 15 days

**Air8 stance:**
- NO new pre-shipment (OBF) positions — hard stop
- ARP only for existing buyers with confirmed receivables already en route
- All existing positions must have confirmed maturity dates before cliff
- Credit committee review required for any exception

**Client guidance:**
- "New pre-shipment financing not available within 15 days of tariff cliff. Existing positions being managed to maturity."
- Flag any client attempting to place last-minute oversize orders — over-stockpiling risk

**Alert:** Send T-7d notification to credit team + BD leadership

---

### Phase 5: Post-Cliff Wind-Down
**When:** cliff_date - today < 0 (cliff has passed)

**Air8 stance:**
- Monitor existing positions to maturity: all should self-liquidate per original schedule
- Watch for over-stockpiling WC stress: clients who ordered aggressively before cliff may face elevated WC needs in Q1 post-cliff (inventory financed but not yet sold)
- DO_NOT_EXPAND signal active until post-cliff inventory clears

**Post-cliff inventory stress indicators:**
- Buyer payment delays (over-stocked buyer is slow to reorder)
- Client requests for tenure extension on existing positions
- Client reporting slow factory utilisation (material in stock but no new POs)

**Rebound Assessment:** When does the opportunity re-open?
- Seasonal cliff (recurring): Opportunity re-opens next year's window. Note in active event cache.
- Structural change (one-time): Assess whether new equilibrium is higher or lower than pre-cliff.
- LDC graduation: Opportunity does not re-open. Permanent structural change.
- Tariff sunset: Watch for policy renewal or extension announcement.

**Alert:** Send T-0 closure notification to BD and credit teams

---

## Alert Protocol Summary

| Alert | Timing | Recipient | Content |
|---|---|---|---|
| T-60d | 60 days before cliff | BD team + affected clients | Cliff date, opportunity window, latest disbursement date |
| T-30d | 30 days before cliff | BD + Credit | Active position review, flag over-stockpiling |
| T-15d | 15 days before cliff | BD + Credit | Tenor compression in effect, final window |
| T-7d | 7 days before cliff | Credit committee | Final check: all positions maturing before cliff? |
| T-0 | Cliff date | BD + Credit + affected clients | Cliff passed, wind-down mode, rebound timeline |

---

## Rebound Assessment Template

After cliff passes, assess rebound timeline using:

```
1. Was this a recurring event? (Annual tariff window, seasonal sourcing)
   YES → next opportunity: [date of next cycle]
   NO → structural assessment required

2. Post-cliff equilibrium: 
   - Is the commodity price still elevated post-cliff? 
   - Has the competitive landscape shifted?
   - Are buyers reordering at normal pace or slow?

3. Rebound conditions (all must be met):
   - Existing over-stockpile inventory cleared (client WC stress resolved)
   - Buyer reorder cadence restored to normal
   - New duty/tariff/policy signal for next window confirmed

4. Expected rebound date: [estimate]
   Signal to upgrade from POST_CLIFF_MONITOR to PRE_CLIFF_AGGRESSIVE when T-60d of next cycle
```

---

## Integration Notes

- **S1-event-insights.md**: P0-3 references this playbook for cliff event calculations
- **signal-decision-rules.md**: Cliff events within 15 days trigger Tier 2 risk (DO_NOT_EXPAND for new PSF)
- **COMBO-003 (India Vertical)**: Primary cliff playbook user — annual cotton import duty window
- **COMBO-012 (Cambodia EBA)**: LDC graduation cliff — permanent, no rebound

**Rule:** Every S1 card involving a cliff event MUST cite this playbook and display the calculated latest_safe_disbursement_date.

## Related

- [PP-BD-003-ldc-graduation.md](../pain-points/country/PP-BD-003-ldc-graduation.md) — Bangladesh LDC graduation; primary cliff use case
- [PP-TR-001-lira-hyperinflation.md](../pain-points/country/PP-TR-001-lira-hyperinflation.md) — Lira crisis as disbursement cliff
- [PP-PK-001-energy-crisis.md](../pain-points/country/PP-PK-001-energy-crisis.md) — Energy crisis as production cliff
- [PP-REG-TARIFF-001.md](../pain-points/compliance/PP-REG-TARIFF-001.md) — Tariff cliff as disbursement timing trigger
- [RISK-PRINCIPLES.md](../principles/RISK-PRINCIPLES.md) — Risk TTL and expiry principles that govern cliff events
