# L1 · Performance Coverage (F2 CP1)

**What this is.** The coverage check that gates F2 scoring. Before any dimension in `NODE-performance-scorecard.md` is scored, CP1 confirms the required data is present and sufficient. This file is the reasoning for *what counts as sufficient* — the minimum thresholds live in the node.

**When it runs.** F2 CP1, immediately after CP0 data load. Nothing is scored before this check passes. Insufficient data → Enrichment. Do not award zero for missing data; zero asserts poor performance, null asserts nothing.

---

## 1 · Coverage gates by dimension

Three dimensions exist in the F2 scorecard (Performance · B/S Pair · QAQC). Check each independently. A dimension can be blocked while others proceed — report partial scores as `earned / available (dim_name pending)`.

### 1a · Performance dimension (trading docs / FR records)

| Check | Minimum required | If fails |
|---|---|---|
| FR count (completed, not cancelled) | ≥ 3 completed FRs on file | Label `INSUFFICIENT DATA — Performance (n = X of 3)`. Do not score. Do not award 0. Send to Enrichment. |
| FR recency | At least 1 FR in the trailing 24 months | Label `STALE DATA — last FR > 24m ago`. Score is provisional only; flag as `DATA-STALE`. |
| Document coverage | On-time delivery data AND document accuracy data both present | If either is missing: score from available fields only; label `PARTIAL — [missing field] not available`. |
| Discrepancy rate | FR records must include ≥ 1 invoice-level discrepancy record | If zero discrepancy records: assume 0 discrepancies (best case, not worst case), label `DISCREPANCY RATE: UNCONFIRMED (no records found)` |

**Minimum viable Performance score:** requires ≥ 3 completed FRs with recency ≤ 24m and at least on-time delivery data. Everything below this goes to Enrichment, not to a zero score.

### 1b · B/S Pair dimension (buyer-supplier pair quality)

| Check | Minimum required | If fails |
|---|---|---|
| Buyer identity resolved | Buyer name must resolve to a confirmed entity (CONFIRMED or CONFIRMED (our data)) — see L1-evidence-discipline §4 | Label `B/S PAIR UNRESOLVED — buyer identity not confirmed`. Do not score the B/S Pair dimension. |
| Buyer programme status | DB buyer table or `_to_db/buyer_programme_status.csv` must have a record for this buyer | If missing: check `NODE-market-trend.md` as a fallback signal. If still unknown, label `PROGRAMME STATUS: UNKNOWN` and apply −0 (neutral, not penalty). |
| Customs / PulseLink available | At least one of customs data or PulseLink data must be available for the pair | If neither: no B/S Pair score — send to Enrichment. Label `B/S PAIR: SOURCE UNAVAILABLE`. |
| If customs only (no PulseLink) | Score B/S Pair using MEDIUM-confidence proxy per `NODE-bs-proxy.md` | Label `B/S PROXY (MEDIUM confidence — customs only)` |
| If PulseLink only (no customs) | Score B/S Pair using MEDIUM-confidence proxy | Label `B/S PROXY (MEDIUM confidence — PulseLink only)` |
| Both available | Score direct B/S Pair; no proxy needed | Label `B/S PAIR (HIGH confidence)` |

**Minimum viable B/S Pair score:** buyer identity confirmed + at least one data source (customs OR PulseLink).

### 1c · QAQC dimension (inspection records)

> **Live as of 2026-08-25.** Thresholds supplied by Jerri Zhou — see `NODE-performance-scorecard.md` Dimension 3.

| Check | Minimum required | If fails |
|---|---|---|
| Inspection records exist | At least 1 completed inspection record on file | Label `QAQC: NO DATA`. Do not score. Revert to 2-dim scorecard. Label `SCORECARD: 2-DIM (QAQC pending)`. |
| Inspection recency | At least 1 inspection in the trailing 24 months | Label `QAQC: STALE (last inspection > 24m)`. Score provisionally; flag `DATA-STALE`. |
| Metric coverage | All 5 metrics ideally available | If partial: score available metrics, re-normalize weights to sum 1.0, label `QAQC: PARTIAL (n/5 metrics)`. |
| Vertical routing | Supplier must be routed to Apparel OR H&H before QAQC runs | Use Apparel bands for Apparel vertical; H&H bands for Hardgoods/Homewear. If vertical unresolved: `QAQC: VERTICAL UNROUTED — cannot score`. |

**QAQC never gets a zero for absent data.** QAQC: NO DATA ≠ QAQC score of 0. A 0 asserts poor quality; NO DATA asserts nothing.

---

## 2 · Buyer lookup at CP1

The B/S Pair dimension requires a resolved buyer. The lookup sequence at CP1:

1. **DB buyer table** — check `buyer_id` against the DB. If a match exists with `programme_status` populated, use it.
2. **FR records** — extract buyer name from the FR. Resolve via L1-evidence-discipline §3 (entity resolution) before attaching.
3. **`_to_db/buyer_programme_status.csv`** — fallback for programme status when DB entry exists but status is null.
4. **NODE-market-trend.md** — for buyer market-level signals when pair-level buyer data is unavailable.

**Buyer identity rules (from L1-evidence-discipline §4):**
- An intermediary (HK sourcing agent, vendor-of-record) is **not** the buyer. Name the end brand behind it.
- Two different suppliers may share a buyer name entry — confirm the buyer entity, not just the string.
- If buyer identity is `CONTRADICTED`, park the B/S Pair dimension. Do not score against an uncertain entity.

**If buyer lookup fails entirely:** remove the B/S Pair dimension from this run. Report `B/S PAIR: BUYER UNRESOLVED — see L1-evidence-discipline §3`. The scorecard runs on the Performance dimension only, partial.

---

## 3 · Coverage summary output format

At the end of CP1, output a coverage block before proceeding to CP2. One row per dimension:

```
COVERAGE CHECK — [Supplier Name]
  Performance:  READY (n=5 FRs, last=2026-04)
  B/S Pair:     READY — HIGH confidence (customs + PulseLink)
  QAQC:         DEFERRED — thresholds pending
  
  Buyer:        [Buyer name] — CONFIRMED (our data) — programme ACTIVE
  
  Proceeding to CP2 with 2-dim scorecard. Label all outputs: QAQC DEFERRED.
```

If any dimension is blocked:

```
COVERAGE CHECK — [Supplier Name]
  Performance:  ENRICHMENT — n=1 FR (minimum 3 required)
  B/S Pair:     READY — MEDIUM confidence (customs only, no PulseLink)
  QAQC:         DEFERRED — thresholds pending
  
  Buyer:        [Buyer name] — CONFIRMED (our data) — programme ACTIVE
  
  ⚠ Performance blocked. Scorecard will be partial: B/S Pair only.
    Report as: earned / available (Performance: INSUFFICIENT DATA, n=1).
```

---

## 4 · Enrichment vs. Stale vs. Insufficient — distinction

These three states are different and must be labelled correctly:

| State | Meaning | Action |
|---|---|---|
| `ENRICHMENT` | Data doesn't exist yet — we haven't collected it | Park. Do not score. Get the data. |
| `STALE` | Data exists but is older than the recency window | Score provisionally; label as `DATA-STALE`; flag for refresh |
| `INSUFFICIENT DATA` | Data exists but below minimum n for reliable scoring | Do not score. Record n. Queue for Enrichment. |

**Distinguish stale from insufficient.** A supplier with 8 FRs, all > 24m ago, has insufficient recency but not insufficient n. Score the on-time rate (n is fine) but flag `DATA-STALE` on all outputs. A supplier with 2 FRs from last month has sufficient recency but insufficient n → Enrichment, not stale.

---

## 5 · Links

- **—GATES→ [NODE-performance-scorecard]**: coverage check must pass before F2 CP2 scoring runs
- **—READS_CONTRACT_FROM→ [L1-db-field-contract]**: field mapping and null-handling rules for all data sourced at CP1
- **—READS→ [L1-evidence-discipline]**: entity resolution (§3), buyer evidence grades (§4)
- **—READS→ [NODE-bs-proxy]**: proxy rules when buyer pair data is partial (MEDIUM/LOW confidence fallback)
- **—READS→ [NODE-market-trend]**: fallback for buyer market-level signals when pair-level buyer data unavailable
- **—READS→ [DB / `_to_db/buyer_programme_status.csv`]**: buyer programme status lookup
- Decision log: `L1-decision-log.md`
- Decision log: `L1-decision-log.md`

## Related

- [NODE-performance-scorecard.md](../../layer-2/frameworks/NODE-performance-scorecard.md) — Coverage thresholds, minimum n, recency rules per dimension
- [L1-db-field-contract.md](L1-db-field-contract.md) — Field mapping and null-handling for data sourced at CP1
- [L1-evidence-discipline-ls.md](../protocols/L1-evidence-discipline-ls.md) — Entity resolution and buyer evidence grades
- [NODE-bs-proxy.md](../../layer-2/nodes/NODE-bs-proxy.md) — Proxy rules when buyer pair data is partial
- [NODE-market-trend.md](../../layer-2/nodes/NODE-market-trend.md) — Buyer market-level signals fallback
- [L1-decision-log.md](../solutions/L1-decision-log.md) — Decision log for coverage methodology changes
