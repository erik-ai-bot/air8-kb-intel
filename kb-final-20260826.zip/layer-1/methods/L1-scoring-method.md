# L1 · Scoring method

How scoring works, with no numbers in it. **Every weight, threshold, tier cut, gate and cap is a node in the tables in `../layer2/NODE-scoring-framework.md`** — the pattern is Layer 2 data, this file is the machine that runs it.

## The method

1. **Additive banded scoring.** A framework (`Framework` node) scores a set of signals (`Indicator` nodes). For each indicator, walk its band rows in order and award the first band whose condition the value meets. Sum the points; read the tier from the framework's `TierRule` nodes; apply `CapRule` then `GateRule` nodes.
2. **Only current rules apply.** Filter every rule node on `valid_to IS NULL`. Historical bands stay in the file so past runs remain explainable — a verdict cites the framework version that produced it, and re-scoring under a new pattern is a new verdict, not a correction.
3. **Missing input → no band → Enrichment.** A missing scored component sends the row to the Enrichment queue with the component named. Never award 0 for absence: a zero asserts something, a null asserts nothing. Report score as `earned / available` when components are missing.
4. **Cross-framework scores are not comparable.** Frameworks have different `max_points`. Rank within a vertical; if a merged view is unavoidable, use percent-of-max — and prefer tier.
5. **A pattern predicts retention, not appetite.** Calibration is on which financed relationships survived. A high scorer with no financing need is the system working, not a contradiction — need is assessed later and used only as a sort tie-breaker.
6. **What is never an input** is itself recorded in the graph (`ExcludedInput` nodes) with the reason, so the exclusion is as auditable as the inclusion.

## Changing a pattern (the whole point of this structure)

One file, three moves:

1. Set `valid_to` on the outgoing table row
2. Add the replacement node: `valid_from`, the new values, **the evidence and n that justify it**
3. One line in `L1-decision-log.md` saying why

Nothing in Layer 1 changes. The skill re-reads the edge file next run and picks up the new rule by the `valid_to IS NULL` filter. Preconditions for when a change is even permitted: `L1-update-protocol` section of the decision log (Triggers A / B / C).

## Evidence standard for any rule node

A Band without `evidence` + `n` is provisional and must say so. Thresholds sit at the measured stickiness-gap peak, not at round numbers. Measurement units matter: a cut derived on one unit (invoices per flow) must be percentile-remapped before use on another (shipments per supplier) — the remapping note travels on the Band node.

## Related

- [NODE-scoring-framework.md](../../layer-2/frameworks/NODE-scoring-framework.md) — The actual band thresholds, weights, tier cuts; this file is the machine that runs it
- [L1-db-field-contract.md](L1-db-field-contract.md) — DB field boundary; what the agent needs from the DB
- [L1-performance-coverage.md](L1-performance-coverage.md) — Coverage check that gates scoring
- [L1-decision-log.md](../solutions/L1-decision-log.md) — Decision log for framework changes
