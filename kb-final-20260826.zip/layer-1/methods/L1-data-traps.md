# L1 · Data traps — ten failures already paid for

Each of these has actually happened and cost a rebuild. The first two apply to both verticals.

**1. The trailing-12 window.** Months-active must be counted over 12 months, max 12. A 24-month window was used once and every threshold silently became meaningless — `≥10` only means something out of 12, in both frameworks. If you touch the aggregation, re-check the window and leave a comment saying why it is 12.

**2. US-only customs bias.** Customs feeds are US-import based. For UK and EU buyers (Primark, NEXT, M&S, Aldi) the UK-bound volume is invisible, so genuinely busy suppliers look dormant. Measured cost: 3 of 7 validatable existing clients scored C or Enrichment despite being sticky. **Directional rule: if book activity exceeds customs activity, the supplier is sticky and the customs record is the thing that is wrong.** Bulk-fix with HS-code enrichment; per-company global shipment counts can be researched manually for shortlist names (~10–15 min each — not a bulk feed).

**3. Duplicate entities.** The same company arrives twice under different supplier codes with punctuation variants (`CENTURY APPARELS LTD` vs `CENTURY APPARELS PRIVATE LIMITED,` with a trailing comma) and gets two different scores — 8 and 4. The scorer prints a warning; do not ignore it.

**4. Parenthetical names break tag matching.** `Crown Textile (Crown Tex / CT Group)` matches nothing unless bracketed aliases are expanded and split on `/` and `,`. Symptom: the top-10 tab shows zero relationship tags while the master list shows nineteen. Keys under 3 characters are dropped deliberately — after suffix-stripping, `CT Group` becomes `CT`, and two-character keys generate false positives.

**5. Scores from different frameworks are not comparable.** 11-point apparel, 15-point hardgoods v3.0, 11-point hardgoods v2.1. Compare tier or `score_pct`. In a mixed batch, rank within vertical and ship two lists.

**6. HS-based classifiers do not reproduce hand labels exactly.** One run matched 96 of 112 existing labels. Report the discrepancy rate; do not quietly overwrite the client's own classification.

**7. Use the lending file that has dates.** A supplier-buyer *pair list* looks like lending data and is not. Only an FR export carrying `actual_lending_date` **and** `product_desc` can tell you whether a client churned and which vertical it belongs to — five names were re-routed on product description alone.

**8. Growth is measured on shipment counts, not value.** Counts are what customs reliably gives. A supplier growing in value but shipping less often scores badly. Flag it if the batch has value data.

**9. Attribute churn before treating it as a scoring miss.** 21 of 33 churned apparel flows (64%) had `buyer_still_active = False` — the supplier did nothing wrong, the buyer's programme died. Check the buyer before blaming the model.

**10. Hardgoods-specific censoring.** The product-count field caps at 10, so breadth is censored at the top: 40 products and 10 products both read as 10. The ≥8 band is conservative by construction — do not rescale it. And monthly volume does **not** differentiate stickiness (~$58–66K in both durable and churned groups), so it is a within-tier tie-breaker only, never a promoter.

## Workflow hygiene

- **Never write over a file the user may have open.** `PermissionError` on save cost this project fourteen version bumps. Write a new version, then move superseded files into `_archive_old_versions/` — too many live versions is its own risk.
- **When asked to re-order, re-order.** A request to prioritise regions is not a request for more research.
- **Report the negative findings.** The duplicate entity, the discrepancy rate, the sticky client the customs data called dormant — these are the parts a reviewer cannot get anywhere else.

## Related

- [L1-db-field-contract.md](L1-db-field-contract.md) — DB field definitions and boundary conditions
- [L1-scoring-method.md](L1-scoring-method.md) — Scoring method that data feeds into
- [NODE-indicator.md](../../layer-2/nodes/NODE-indicator.md) — Indicator derivation logic that data traps affect
- [L1-decision-log.md](../solutions/L1-decision-log.md) — Where data trap discoveries are logged
