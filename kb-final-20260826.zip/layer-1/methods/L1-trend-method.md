# L1 · Trend method

How trend signals are assessed for suppliers. This file covers the reasoning and discipline; the exact band thresholds and point values live in `NODE-scoring-framework.md` (F1 hardgoods `trend` indicator) and in `NODE-product-trend.md` / `NODE-market-trend.md`.

## Trend is direction, not volume

Trend does not measure how big a supplier is. It measures the **direction** of the relationship over time — whether shipment activity, product range, or market conditions are moving up, sideways, or down. A high-volume supplier with a declining trend scores differently from a high-volume supplier with a stable trend. Both are valid findings; neither is a default.

## Two separate trend dimensions

These must not be conflated:

### 1. Product Trend
Used in: F1 hardgoods `trend` indicator; F2 product breadth dimension.

Measures: **whether a supplier's own shipment cadence and product range is growing, stable, or declining.** Sources and determination rules live in `NODE-product-trend.md`.

### 2. Market Trend
Used in: F2 market dimension; F3 buyer assessment context overlay.

Measures: **the trajectory of the buyer's end-market sector**, not the supplier's own business. A supplier may have stable personal metrics while selling into a structurally contracting sector — those are separate signals. Sources and determination rules live in `NODE-market-trend.md`.

## How to determine trend from data

### Source hierarchy (applies to both trend types)

Customs (shipment data) > trading documents > web research

When a higher-confidence source is available, do not supplement it with a lower-confidence source to change the direction — lower-confidence sources can confirm but not override.

### Calculation basis (product trend)

| Period | Definition |
|---|---|
| P1Y | Trailing 12 months from reference date |
| P2Y | The 12 months immediately before P1Y |

- Compare P1Y shipment count vs P2Y shipment count for **activity trend**
- Compare P1Y distinct product count vs P2Y distinct product count for **product breadth trend**

**Thresholds (applied to the percentage change):**

| Label | Condition |
|---|---|
| RISING | P1Y is +15% or more above P2Y |
| STABLE | P1Y is within −15% to +15% of P2Y |
| DECLINING | P1Y is more than −15% below P2Y |

These thresholds are the L1 reasoning standard. The F1 framework uses its own band assignment (RISING / STABLE / else), which maps to points in `NODE-scoring-framework.md`. The 15% cut is the reasoning guide; the Framework node is what gets scored.

## Thin-data handling

### Supplier with < 12 months of data

If P2Y is entirely empty (no prior-period data), **growth cannot be computed**. Do not default to STABLE — STABLE asserts something. Null means null.

- If P1Y exists but P2Y = 0 shipments: `yoy_growth = null` (see L1-db-field-contract)
- Trend label: do not assign a direction
- Action: Enrichment queue with component named `trend`

### Supplier with < 6 months in P1Y

Trend on fewer than 6 months of recent activity is unreliable. Label `INSUFFICIENT DATA`. Do not infer trend direction.

### Sparse customs data (present but thin)

If customs data is present but sparse (e.g. 2–3 shipment records in P1Y), default to **STABLE** rather than inferring a trend direction from a very small sample. A sparse signal can support a neutral label; it cannot support a directional one without a corroborating source.

## Trend for new suppliers (< 12 months total data)

Label `INSUFFICIENT DATA` and route to Enrichment. Never assign STABLE as a placeholder. A new supplier has no trend — absence of history is not evidence of stability.

## What trend predicts in the scoring model

In F1 (hardgoods): trend predicts **retention**, not absolute supplier size. A declining-trend supplier who still has high activity scores lower on the trend indicator but may still score well overall via the activity indicator. The indicators are independent — do not collapse them.

In F2 / F3: trend overlays the base assessment. A supplier with rising product variety and rising market demand scores better than one with stable individual metrics in a contracting sector.

## Trend and financing need

Product trend (rising receivables relative to revenue) is one of the six financing-need angles (see `NODE-financing-need.md` §Angle 2). When a supplier's receivables growth outpaces revenue growth, that is a working-capital signal. This is a separate calculation from the shipment-count trend used in scoring — report both if both are available, and do not merge them.

## What to record

| Field | Value |
|---|---|
| `trend` | RISING / STABLE / DECLINING / INSUFFICIENT DATA |
| `trend_basis` | `customs` / `trading_docs` / `web` |
| `trend_period` | e.g. `P1Y: 2025-08 – 2026-08 vs P2Y: 2024-08 – 2025-08` |
| `trend_note` | Required for INSUFFICIENT DATA; optional otherwise |

## Links

- **→ [NODE-product-trend]**: Product trend signal rules (F1 indicator, F2 breadth dimension)
- **→ [NODE-market-trend]**: Market trend signal rules (F2 market dimension, F3 overlay)
- **→ [NODE-scoring-framework]**: Band assignment and point values for the `trend` indicator in F1
- **→ [NODE-financing-need]**: Angle 2 — receivables growth vs revenue growth as a need signal
- **→ [NODE-indicator]**: `trend` derivation from the DB (`yoy` > +5% → RISING · < −5% → DECLINING · else → STABLE for indicator derivation; this L1 file sets the reasoning standard for the richer sourced assessment)

## Related

- [NODE-product-trend.md](../../layer-2/nodes/NODE-product-trend.md) — Product trend signal rules (F1 indicator, F2 breadth dimension)
- [NODE-market-trend.md](../../layer-2/nodes/NODE-market-trend.md) — Market trend signal rules (F2 market dimension)
- [NODE-scoring-framework.md](../../layer-2/frameworks/NODE-scoring-framework.md) — Band assignment and point values for trend indicator
- [NODE-financing-need.md](../../layer-2/nodes/NODE-financing-need.md) — Receivables growth vs revenue growth as a financing need angle
- [NODE-indicator.md](../../layer-2/nodes/NODE-indicator.md) — `trend` derivation from DB (yoy thresholds)
