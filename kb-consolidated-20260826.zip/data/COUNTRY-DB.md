---
type: country-database
id: COUNTRY-DB
last_updated: 2026-08-04
sources: USTR, BGMEA, WTO, TradingEconomics, TradeInt, FashionatingWorld, Vietnam Briefing, web-verified
refresh_cadence: monthly (or on major policy event)
countries: CN, IN, BD, VN, PK, TR, KH, ID
---

# Air8 Country Database
*Last updated: Aug 4, 2026*
*Used by: Validation Agent CP4a — country risk overlay on client COMBO signals*

---

## How to Read

Each entry: Export profile | Hardgoods | Currency vs USD | Key risks | Air8 signal | Freshness

---

## CN — China

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| Total textile/apparel exports | ~$260B | ~40% of global textile exports |
| US market share | ~32% (declining) | Tariff compression pushing buyer diversification |
| EU market share | ~20-22% | Full MFN 12% |

### Hardgoods
| Category | Notes |
|---|---|
| Furniture | Q1 2026 US-bound $4.39B (-2.2% YoY); US declined ~19.7% post-May 2026 (tariff shock) |
| Lighting | Dominant; LED driver/chip components remain CN-origin even if assembled elsewhere |
| Home Decor / Brass | Triple-stacked: S301 25% + S232 25% (copper) + FL301 12.5% = ~66-71% US total |
| Cookware | ~38-46% US total tariff burden |

### Currency vs USD (6-Month Trend)
- **CNY/USD**: ~6.76 (CNY at strongest since Jun 2026)
- **Trend**: CNY strengthening (USD weakening broadly)
- **Impact**: Mildly unfavorable for CN exporters — stronger CNY = less margin buffer

### Key Risks for Air8 Suppliers
1. Triple tariff stacking: S301 + S232 (copper/metals) + FL301 = 40–71% total burden
2. US buyer diversification accelerating: Cambodia +26.9%, VN penetration 100%
3. FL301 (12.5%) — CN in higher tariff group; legal challenge pending (25 states, Aug 3)
4. Furniture: US-bound exports down ~19.7% from major production regions
5. LED/lighting: component origin still CN regardless of assembly country

### Air8 Signal
> CN suppliers face maximum tariff compression (50–71% total). Priority: identify clients seeking EU/ME diversification or using CN as processing hub. Brass/hardgoods clients: verify S232 copper content threshold (≥15%).

**Freshness:** [VERIFIED Aug 4, 2026 — USTR, FurnitureDiscover, TradingEconomics, LME]

---

## IN — India

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| US apparel market share | 5.3% (up from 4%) | Growing — cotton-based, vertically integrated |
| Total US apparel exports | ~$4.07B to US (2025) | TradeInt Feb 2026 |
| Key products | Cotton apparel, home textiles (towels, bedding), rugs | |

### Hardgoods
| Category | Notes |
|---|---|
| Home Decor / Brass | Moradabad advantage: no S301, no FL301 stacking vs CN |
| Metal artware (true brass) | IN MFN + FL301(10%) = ~13-18% vs CN ~66-71% |
| Outdoor/metal furniture | Growing capacity |

### Currency vs USD (6-Month Trend)
- **INR/USD**: ~83–84 (mild depreciation 2026; RBI intervening)
- **Trend**: Slight INR weakness; contained
- **Impact**: Slightly favorable for exporters (more INR per USD earned)

### Key Risks for Air8 Suppliers
1. **FL301 +10%** (Jul 24, 2026): Erodes India's diversification advantage over CN
2. **Cotton import duty waiver EXPIRING**: Active Jun–Oct 31, 2026; reinstatement Nov 1 = +16% on raw cotton input
3. **13 weeks remaining** (as of Aug 4): mills face +8–12% input cost spike if they don't pre-buy
4. FL301 legal challenge: if voided, +10% drops; if sustained, permanent new layer
5. EU-India FTA stalled: standard GSP rate ~9.6% remains

### Air8 Signal
> India suppliers have 13-week window before cotton duty reinstatement (Nov 1). Pre-buy raw cotton opportunity. Brass/decor clients in Moradabad: highlight competitive advantage vs CN even with FL301. Monitor FL301 legal challenge outcome.

**Freshness:** [VERIFIED Aug 4, 2026 — TBSNews, USTR, India Budget 2026, TradeInt]

---

## BD — Bangladesh

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| US apparel exports (2025) | $8.20B (+11.71% YoY) | Second-highest annual figure on record |
| Global RMG total | ~$39–42B (FY2026) | BGMEA; Apr 2026 monthly 455.20 BDT Bn |
| Key products | Knit apparel (T-shirts, polos), woven (shirts, trousers) | CMT and FOB mix |
| EU access | EBA 0% (LDC status — at risk 2027+) | |

### Currency vs USD (6-Month Trend)
- **BDT/USD**: ~110-112 (mild depreciation pressure)
- **Trend**: Gradual depreciation; forex reserve concerns
- **Impact**: Favorable for export revenues; inflation import cost risk

### Key Risks for Air8 Suppliers
1. **FL301 +10%** (Jul 24, 2026): Immediate hit to US-bound volume
2. **Banking sector crisis**: Total bank exposure ~BDT 400,000 crore; systemic financing risk
3. **EBA eligibility at risk**: LDC graduation expected 2027; could lose EU 0% preferential
4. Political instability: post-2024 transition; lower regulatory predictability
5. Concentration risk: 85%+ of exports are RMG

### Air8 Signal
> BD clients face double pressure: FL301 on US + potential EBA loss on EU. Banking crisis makes early payment / ARP product highly attractive. Flag any BD client with >70% US concentration as high sensitivity.

**Freshness:** [VERIFIED Aug 4, 2026 — BGMEA, TextileToday, FashionatingWorld, TradingEconomics]

---

## VN — Vietnam

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| US apparel exports (2025) | $8.93B | TradeInt 2026 |
| US buyer penetration | 100% of major US buyers source from VN | Up from 90% — universal presence |
| EVFTA EU access | 0–12% (phased) | Strong EU growth path |
| Hardgoods | Furniture primary CN→VN shift destination | Growing |

### Currency vs USD (6-Month Trend)
- **VND/USD**: ~25,400-25,500
- **Trend**: Mild VND depreciation; SBV managing range
- **Impact**: Marginally favorable for exporters

### Key Risks for Air8 Suppliers
1. **FL301 +12.5%** (Jul 24, 2026): VN in HIGHER tariff group (vs BD/IN at 10%) — larger US penalty
2. **USTR S301 investigation open**: Jun 2, 2026 findings; potential additional tariffs on VN goods
3. **Priority Foreign Country** designation on IP (Jun 2026): US-VN bilateral tension
4. Origin-washing scrutiny: CN goods transshipped via VN; customs enforcement increasing
5. Furniture component supply chain: raw materials still largely CN-origin

### Air8 Signal
> VN faces steepest FL301 burden (12.5%) among Air8 key sourcing countries. Combined with S301 investigation risk, VN clients exporting to US face compounding uncertainty. Strong EU story via EVFTA. Flag US-heavy VN clients for EU diversification conversation.

**Freshness:** [VERIFIED Aug 4, 2026 — Vietnam Briefing, TradeInt, USTR, FashionatingWorld]

---

## PK — Pakistan

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| US apparel market share | 2.6% (up from 1.9%) | Cotton-based focus |
| US apparel exports | ~$1.37B to US (2025) | TradeInt 2026 |
| Key products | Home textiles (towels, bedding), cotton yarn, denim | Vertical integration |
| EU GSP+ | 0–3.5% preferential | Strong EU access |

### Currency vs USD (6-Month Trend)
- **PKR/USD**: ~278-285 (recovering from 2023-24 crisis lows)
- **Trend**: Stabilizing; IMF program supporting PKR
- **Impact**: Reduced forex risk; USD financing more stable

### Key Risks for Air8 Suppliers
1. **FL301 +10%** (Jul 24, 2026): Apparel and home textiles both affected
2. Macro instability history: PKR devalued 50%+ in 2022-2024; structural forex risk remains
3. IMF program dependency: fiscal adjustment could squeeze domestic credit
4. Cotton supply dependency: domestic crop recovery uneven after 2022 floods
5. Energy costs: industrial energy tariffs elevated; squeezes margins

### Air8 Signal
> PK strong in home textiles (towels, bedding) with EU GSP+ advantage. FL301 applies but PK net tariff still better than CN (~15-19% vs ~43-47%). Macro risk warrants tighter ARP structure. Flag PKR depreciation triggers in financing terms.

**Freshness:** [VERIFIED Aug 4, 2026 — TradeInt, TBSNews, TradingEconomics]

---

## TR — Turkey

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| Total textile+apparel exports | ~$26B (2025) | EU ~60-65% primary |
| EU access | Customs Union = 0% tariff | Proximity + fast replenishment (3-7 day transit) |
| Key products | Woven apparel, denim, knitwear, rugs/flooring | |
| Nearshoring advantage | Fast EU replenishment vs 30+ day Asian transit | |

### Currency vs USD (6-Month Trend)
- **TRY/USD**: ~32-34 (inflation-driven depreciation; TCMB rate hikes showing effect)
- **Trend**: Managed depreciation; high inflation environment
- **Impact**: High TRY-cost inflation; USD contracts favorable for TR manufacturers

### Key Risks for Air8 Suppliers
1. **FL301 +10%** on US exports (Jul 24, 2026): Limits US growth; EU remains primary
2. TRY inflation: domestic cost inflation ~40-50% pa squeezes TRY-cost exporters
3. EU Customs Union dependency: full EU access contingent on EU-Turkey relations
4. Rug/flooring competition: India competing hard on US market for HS57
5. Geopolitical positioning creates occasional trade friction

### Air8 Signal
> TR is the EU nearshoring play. EU clients sourcing from TR face near-zero tariff friction. For US-targeted TR clients, FL301 applies but volumes smaller. TRY inflation risk means USD-denominated supply chain financing is very attractive to TR manufacturers.

**Freshness:** [VERIFIED Aug 4, 2026 — BDExportWear, USTR, TradingEconomics]

---

## KH — Cambodia

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| US apparel exports (2025) | $2.79B (+26.93% growth) | Fastest growing among major sourcing countries |
| EU access | EBA 0% (LDC status) | At risk post-LDC graduation ~2027 |
| Key products | Knit apparel (T-shirts, activewear), woven basics | |

### Currency vs USD (6-Month Trend)
- **KHR/USD**: ~4,100-4,120 (essentially dollarized economy)
- **Trend**: Stable; minimal forex risk
- **Impact**: Low forex risk vs other sourcing countries

### Key Risks for Air8 Suppliers
1. **FL301 +10%** (Jul 24, 2026): Sudden tariff on fastest-growing sourcing country
2. EBA graduation risk: LDC graduation eliminates EU 0% preferential — timeline 2027+
3. Infrastructure constraints: port capacity, power reliability lagging rapid export growth
4. Origin-washing risk: scrutiny on CN fabric/component inputs into KH apparel
5. Shallow vendor base: limited supplier depth vs VN or BD

### Air8 Signal
> KH's fastest growth trajectory (+26.9%) now interrupted by FL301. Early indicator: will US buyers absorb +10% or redirect volume? Monitor KH client order books Q3 2026. EU business strong while EBA holds. ARP attractive given rapid revenue growth.

**Freshness:** [VERIFIED Aug 4, 2026 — FashionatingWorld, USTR, TradeInt]

---

## ID — Indonesia

### Export Profile (Apparel & Textile)
| Metric | Value | Notes |
|---|---|---|
| US buyer penetration | 77% (up from 75%) | Growing steadily |
| US apparel exports | ~$2.06B to US (2025) | TradeInt 2026 |
| Key products | Knitwear, sportswear, denim, rattan/timber furniture | |
| EU GSP rate | ~9% (standard GSP; not EBA) | |

### Currency vs USD (6-Month Trend)
- **IDR/USD**: ~16,000-16,200
- **Trend**: Mild IDR depreciation; Bank Indonesia managing
- **Impact**: Mildly favorable for exporters

### Key Risks for Air8 Suppliers
1. **FL301 +10%** (Jul 24, 2026): Applies to apparel and rattan/timber furniture
2. Commodity cost linkage: coal/CPO prices affect domestic energy costs
3. Bureaucratic friction: customs/regulatory environment can slow timelines
4. EU GSP moderate rate: ~9% (not 0% like BD/PK/KH); FTA in early stages
5. Furniture competition: VN/Malaysia competing hard on US market share

### Air8 Signal
> ID growing slowly but steady. FL301 +10% applies. Furniture segment interesting — ID has rattan/timber comparative advantage that VN lacks. EU path weaker than BD/PK (GSP 9% vs EBA 0%). Moderate risk profile; USD-sensitive.

**Freshness:** [VERIFIED Aug 4, 2026 — TradeInt, BDExportWear, USTR, TradingEconomics]

---

## Quick Reference Matrix

| Country | FL301 Rate | US Apparel | EU Access | Best Products | Air8 Signal |
|---|---|---|---|---|---|
| CN | +12.5% | #1 volume | MFN 12% | All; hardgoods esp. | Tariff compression; EU/ME pivot |
| VN | +12.5% | #2 | EVFTA 0-12% | Apparel, furniture | FL301 highest; EU diversification |
| IN | +10% | Growing #4 | GSP 9.6% | Cotton, brass, rugs | Cotton waiver Nov 1 deadline |
| BD | +10% | #3 apparel | EBA 0% | Knit, basics | Banking crisis; ARP fit |
| PK | +10% | Home textile | GSP+ 0-3.5% | Towels, bedding | Macro risk; USD financing attractive |
| TR | +10% | EU-primary | CU 0% | Woven, denim, rugs | EU nearshoring play |
| KH | +10% | Fastest growth | EBA 0% | Knit basics | FL301 growth interruption; watch Q3 |
| ID | +10% | Slow-grow | GSP 9% | Sportswear, rattan | Modest; furniture CN-alternative |

---

*Sources: USTR.gov (FL301 White House Jul 2026), BGMEA, TradeInt (Feb 2026), FashionatingWorld (Mar 2026), Vietnam Briefing (Jul 2026), TradingEconomics, Business-HumanRights.org*
*Next refresh: Sep 2026 or on any country-specific tariff/currency event*
