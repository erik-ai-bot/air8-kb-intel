---
type: tariff-database
id: TARIFF-DB
last_updated: 2026-08-04
sources: USTR, CBP, India Budget 2026, EC Trade, web-verified
refresh_cadence: monthly (or on any new tariff action)
---

# Air8 Tariff Database
*Last updated: Aug 4, 2026*
*⚠️ Forced Labor 301 legal challenge pending (25 states, Aug 3). Rates active until any injunction.*

---

## How to Read
```
US Total = MFN base + Section 301 (CN only) + Section 232 (metals, all origins) + Forced Labor 301 (Jul 24, 2026)
EU Total = MFN base OR preferential rate (GSP/EBA/FTA), whichever applies
```

---

## PART 1 — APPAREL

### 1A. Woven Apparel (HS 62) & Knit Apparel (HS 61)

**US Import:**

| Origin | MFN Base | S301 | FL301 (Jul 24) | **US Total** |
|---|---|---|---|---|
| China CN | 12–32% | +25% | +12.5% | **~50–70%** |
| India IN | 12–32% | — | +10% | **~26.5%** |
| Vietnam VN | 12–32% | — | +12.5% | **~28.5%** |
| Bangladesh BD | 12–32% | — | +10% | **~26.5%** |
| Pakistan PK | 12–32% | — | +10% | **~26.5%** |
| Turkey TR | 12–32% | — | +10% | **~26.5%** |
| Cambodia KH | 12–32% | — | +10% | **~26.5%** |
| Indonesia ID | 12–32% | — | +10% | **~26.5%** |

**EU Import:**

| Origin | MFN | Preferential | Scheme | Notes |
|---|---|---|---|---|
| Bangladesh BD | 12% | **0%** | EBA | ⚠️ At risk post-LDC graduation (2027+) |
| Pakistan PK | 12% | **0–3.5%** | GSP+ | |
| India IN | 12% | **9.6%** | Standard GSP | India-EU FTA in negotiation |
| Vietnam VN | 12% | **0–12%** | EVFTA | Phased schedule |
| Turkey TR | 12% | **0%** | Customs Union | |
| Cambodia KH | 12% | **0%** | EBA | ⚠️ At risk post-LDC graduation |
| China CN | 12% | 12% | None | Full MFN |
| Indonesia ID | 12% | ~9% | GSP | |

---

### 1B. Home Textiles — Towels, Bedding, Soft Furnishings (HS 63)

**US Import:**

| Origin | MFN Base | S301 | FL301 | **US Total** |
|---|---|---|---|---|
| China CN | 5–9% | +25% | +12.5% | **~43–47%** |
| Pakistan PK | 5–9% | — | +10% | **~15–19%** |
| India IN | 5–9% | — | +10% | **~15–19%** |
| Bangladesh BD | 5–9% | — | +10% | **~15–19%** |

**EU Import:**

| Origin | MFN | Preferential | Scheme |
|---|---|---|---|
| Pakistan PK | 9% | **0%** | GSP+ |
| Bangladesh BD | 9% | **0%** | EBA |
| India IN | 9% | ~6% | Standard GSP |
| China CN | 9% | 9% | None |

---

## PART 2 — HARDGOODS

### 2A. Furniture — Indoor & Outdoor (HS 9401, 9403)

**US Import:**

| Origin | MFN Base | S301 | FL301 | **US Total** | Notes |
|---|---|---|---|---|---|
| China CN | 0–3.7% | +25% | +12.5% | **~39–41%** | Supreme Court upheld S301 |
| Vietnam VN | 0–3.7% | — | +12.5% | **~12.5–16%** | Primary CN→VN shift destination |
| India IN | 0–3.7% | — | +10% | **~10–14%** | Growing for outdoor/metal furniture |
| Malaysia MY | 0–3.7% | — | +10% | **~10–14%** | Timber furniture |
| Indonesia ID | 0–3.7% | — | +10% | **~10–14%** | Rattan/timber |

**EU Import:**

| Origin | MFN | Notes |
|---|---|---|
| All origins | 0–5.7% | EU hardgoods MFN low; compliance (GPSR/REACH) is the main barrier |

---

### 2B. Lighting (HS 9405)

**US Import:**

| Origin | MFN Base | S301 | FL301 | **US Total** | Notes |
|---|---|---|---|---|---|
| China CN | 3.9% | +25% | +12.5% | **~41%** | ⚠️ No geo escape — LED drivers/chips still CN |
| Vietnam VN | 3.9% | — | +12.5% | **~16%** | Assembly only; components still CN-sourced |
| India IN | 3.9% | — | +10% | **~14%** | Limited capacity |

**EU Import:**

| Origin | MFN | Notes |
|---|---|---|
| China CN | 3.7% | CE/UL re-cert required on geo shift (2–4 weeks CE; up to 4 months UL) |
| Vietnam VN | 3.7% | EVFTA preferential available |

---

### 2C. Home Decor / Metal Artware / Brass (HS 83)

**US Import:**

| Origin | MFN Base | S301 | S232 Copper | FL301 | **US Total** | Notes |
|---|---|---|---|---|---|---|
| China CN (true brass) | 3–8% | +25% | +25% | +12.5% | **~66–71%** | Triple stack: S301 + S232 + FL301 |
| China CN (zamak/plated) | 3–8% | +25% | — | +12.5% | **~41–46%** | No copper content; S232 not applicable |
| India IN (true brass) | 3–8% | — | — | +10% | **~13–18%** | ✅ Moradabad advantage; no S301 |
| Vietnam VN | 3–8% | — | — | +12.5% | **~15.5–20.5%** | Still imports copper; only partial relief |

> ⚠️ Material bifurcation is critical: true brass vs zamak determines whether S232 applies. Verify via mill cert or REACH G4 test.

**EU Import:**

| Origin | MFN | Notes |
|---|---|---|
| All origins | 2.7–3.7% | REACH compliance is the main barrier; tariffs low |

---

### 2D. Kitchen & Dining — Cookware, Tableware (HS 73, 69, 76)

**US Import:**

| Origin | MFN Base | S301 | FL301 | **US Total** |
|---|---|---|---|---|
| China CN | 0–8% | +25% | +12.5% | **~38–46%** |
| Vietnam VN | 0–8% | — | +12.5% | **~12.5–20.5%** |
| India IN | 0–8% | — | +10% | **~10–18%** |
| Thailand TH | 0–8% | — | +10% | **~10–18%** |

---

### 2E. Consumer Electronics — Speakers, Clocks, Smart Goods (HS 85)

**US Import:**

| Origin | MFN Base | S301 | FL301 | **US Total** | Notes |
|---|---|---|---|---|---|
| China CN | 0–3.9% | +25% | +12.5% | **~39–41%** | List 3/4A covers most HS85 |
| Vietnam VN | 0–3.9% | — | +12.5% | **~12.5–16%** | |
| Mexico MX | 0–3.9% | — | EXEMPT | **~4%** | USMCA |

---

### 2F. Rugs & Flooring (HS 57)

**US Import:**

| Origin | MFN Base | S301 | FL301 | **US Total** |
|---|---|---|---|---|
| China CN | 3–9% | +25% | +12.5% | **~41–47%** |
| India IN | 3–9% | — | +10% | **~13–19%** |
| Turkey TR | 3–9% | — | +10% | **~13–19%** |

---

### 2G. Pet Supply (HS 42, 63, 39)

**US Import:**

| Origin | MFN Base | S301 | FL301 | **US Total** |
|---|---|---|---|---|
| China CN | 3–9% | +25% | +12.5% | **~41–47%** |
| Vietnam VN | 3–9% | — | +12.5% | **~15.5–21.5%** |
| India IN | 3–9% | — | +10% | **~13–19%** |

---

## PART 3 — RAW MATERIALS & INPUTS

### 3A. Section 232 Metals (US, ALL Origins — No Exemption)

| Material | HS | Rate | Effective | Notes |
|---|---|---|---|---|
| Copper articles & derivatives | 74 | **+25%** | Apr 6, 2026 | ≥15% copper content threshold |
| Steel articles | 73 | **+50%** | Apr 6, 2026 | |
| Aluminium articles | 76 | **+50%** | Apr 6, 2026 | |
| Products <15% metal content | Any | **Exempt** | Jun 1, 2026 | Removed from S232 scope |

> S232 does NOT stack with Forced Labor 301. If S232 applies, FL301 does not apply to same product.

---

### 3B. India Domestic Input Duties

**Raw Cotton (HS 5201):**

| Period | BCD | AIDC | **Total** | Status |
|---|---|---|---|---|
| Jun 1 – Oct 31, 2026 | 0% | 0% | **0%** | ✅ Waiver active |
| Nov 1, 2026 onwards | 11% | 5% | **~16%** | ⚠️ 13 weeks to reinstatement (from Aug 4) |

**Other Inputs (India):**

| Product | HS | BCD | AIDC | Total |
|---|---|---|---|---|
| Cotton yarn | 5205 | 10% | 5% | 15% |
| Cotton fabric | 5208 | 10% | 10% | 20% |
| Brass/copper scrap | 7404 | 2.5% | 5% | 7.5% |
| Copper wire rod | 7408 | 5% | 5% | 10% |
| Polyester staple fibre | 5503 | 5% | 5% | 10% |

---

## PART 4 — EVENT ID QUICK REFERENCE

| Event ID | Description | Rate | Effective | Expiry | Air8 Signal |
|---|---|---|---|---|---|
| S1 | Section 301 original — CN all goods | +25% | 2018–2019 | Ongoing | Base CN tariff layer |
| T1 | Section 232 Copper — all origins | +25% | Apr 6, 2026 | Ongoing | CN brass artware double compression |
| T2-CN | Forced Labor 301 — China | +12.5% | Jul 24, 2026 | Ongoing* | CN total burden ~37.5%+ |
| T2-IN | Forced Labor 301 — India | +10% | Jul 24, 2026 | Ongoing* | Erodes IN diversification advantage |
| T2-VN | Forced Labor 301 — Vietnam | +12.5% | Jul 24, 2026 | Ongoing* | Erodes VN diversification advantage |
| T2-BD | Forced Labor 301 — Bangladesh | +10% | Jul 24, 2026 | Ongoing* | BD apparel: +10% extra |
| T2-PK | Forced Labor 301 — Pakistan | +10% | Jul 24, 2026 | Ongoing* | PK home textile: +10% extra |
| T3 | India BCD+AIDC waiver — HS 5201 | 0% (from 16%) | Jun 1, 2026 | **Oct 31, 2026** | Window closing |
| T4 | India cotton duty reinstatement | ~16% | Nov 1, 2026 | Ongoing | Mills: +8–12% input cost |

*T2 legal challenge pending (25 states v. Trump admin, Aug 3, 2026)

---

## Usage in Validation Agent

When CP4a calls `[Tariff DB]`:
1. Match supplier_country + product_category (HS chapter) → pull relevant section above
2. Sum applicable layers: MFN + S301 (CN only) + S232 (metals) + FL301
3. Note S232 and FL301 do NOT stack on same product
4. Label output as `✅ VERIFIED` if in this table; note legal challenge on T2 items
5. Always verify 10-digit HTS code for exact MFN base — ranges above are indicative

*Sources: USTR.gov, CBP, India Budget 2026, EC Trade, tariffstool.com, chrobinson.com*
*Next refresh: Sep 2026 or on any new tariff action*
