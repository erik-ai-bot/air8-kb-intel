---
type: commodity-database
id: COMMODITY-DB
last_updated: 2026-08-04
sources: LME (westmetall.com), TradingEconomics, Barchart, Cbonds
refresh_cadence: weekly
---

# Air8 Commodity Database
*Last updated: Aug 4, 2026*
*Used by: Validation Agent CP4a — raw material cost and freight context for client signals*

---

## SECTION 1 — METALS

### LME Copper (Cash Settlement)
| Field | Value |
|---|---|
| **Spot Price** | **$13,945 USD/tonne** |
| As of | Aug 3, 2026 |
| 3-Month Forward | $13,876 USD/tonne |
| LME Stock | 244,025 tonnes |
| 1-Month Change | +2.3% (from ~$13,600 early July) |
| YoY Context | Elevated vs 2024-2025 range (~$8,500–$10,000) |

**Air8 Relevance:**
- Section 232 Copper tariff (+25% ALL origins) applies to goods with ≥15% copper content
- Brass artware (HS83) clients: raw material at record highs + 25% S232 import tariff
- India brass (Moradabad): cheaper domestic copper + no S301 vs CN = clear advantage

> ⚠️ Copper at $13,945 is historically very elevated. Brass-heavy clients face double compression: high raw material cost + S232 tariff.

**Tag:** [LIVE - web fetch Aug 4, 2026]

### LME Copper 30-Day Price History
| Date | Cash USD/t |
|---|---|
| Aug 3 | 13,945 |
| Jul 31 | 13,834 |
| Jul 27 | 13,810 |
| Jul 22 | 13,895 |
| Jul 17 | 13,374 |
| Jul 10 | 13,409 |

---

## SECTION 2 — AGRICULTURAL COMMODITIES

### ICE Cotton No. 2 Futures
| Field | Value |
|---|---|
| **Price** | **82.10 USc/lb** |
| As of | Aug 3, 2026 |
| 1-Day Change | +0.38% |
| 1-Month Change | +4.85% |
| YoY Change | **+27.38%** |
| Source | TradingEconomics / Barchart |

**Air8 Relevance:**
- Critical input for BD, IN, PK apparel and textile clients
- +27% YoY = significant input cost pressure for cotton-dependent suppliers
- India cotton waiver (Jun–Oct 31, 2026): expires Nov 1 — mills need to pre-buy NOW
- PK: domestic cotton crop recovery uneven; high global price + local production mix
- CN: uses mixed fiber (polyester blends reduce cotton exposure)

> ⚠️ Cotton at 82.10 USc/lb (+27% YoY). India mills must pre-buy before Nov 1 or face 16% import duty on top of elevated spot price.

**Tag:** [LIVE - web fetch Aug 4, 2026]

---

## SECTION 3 — FREIGHT INDICES

### SCFI — Shanghai Containerized Freight Index
| Field | Value |
|---|---|
| **Latest Available** | ~3,018 (Jun 2026 average) |
| Jun 2026 High | 3,239.64 |
| Jun 2026 Low | 2,726.48 |
| Jul-Aug 2026 Est. | ~3,000–3,200 range |
| YoY Context | Significantly higher than 2024 trough (~800–1,200) |
| Source | Cbonds / SSE Shanghai |

**Air8 Relevance:**
- High SCFI = higher logistics cost for CN exporters; squeezes already-compressed margins
- Air8 clients: freight cost spike increases invoice size → higher financing need

> Note: SCFI Jul/Aug 2026 exact reading unavailable. Use 3,000–3,200 as working range.

**Tag:** [ESTIMATED - based on Jun 2026 data, web fetch Aug 4, 2026]

---

### Baltic Dry Index (BDI)
| Field | Value |
|---|---|
| **BDI** | **2,843 index points** |
| As of | Aug 3, 2026 |
| 1-Day Change | +4.06% |
| 1-Month Change | +1.64% |
| YoY Change | **+44.31%** |
| Source | TradingEconomics / Baltic Exchange |

**Air8 Relevance:**
- BDI tracks bulk dry cargo (coal, grain, cotton, raw materials) — upstream cost signal
- +44% YoY indicates strong dry bulk demand; positive for Air8 export order demand backdrop
- High BDI also means higher raw material import costs (cotton, metals shipped in bulk)

**Tag:** [LIVE - web fetch Aug 4, 2026]

---

## SECTION 4 — ENERGY

### Brent Crude
| Field | Value |
|---|---|
| **Brent Crude** | **$83.82 USD/barrel** |
| As of | Aug 3, 2026 |
| 1-Day Change | -4.68% (sharp daily drop) |
| 1-Month Change | +16.43% |
| YoY Change | **+21.90%** |
| Source | TradingEconomics |

**Air8 Relevance:**
- Energy cost driver for textile/apparel manufacturing (dyeing, spinning, weaving energy-intensive)
- Polyester fiber price correlated with crude — CN/VN knit clients using blended fibers
- TR: elevated energy costs (TRY inflation + crude) squeezing TRY-cost manufacturers
- Container shipping bunker surcharges partially driven by crude

> Brent +22% YoY. Sharp -4.68% single-day drop Aug 3 — monitor for multi-day trend.

**Tag:** [LIVE - web fetch Aug 4, 2026]

---

## SECTION 5 — QUICK REFERENCE DASHBOARD

| Commodity | Value | Change (1M) | Change (YoY) | Air8 Impact |
|---|---|---|---|---|
| **LME Copper** | $13,945/t | +2.3% | Elevated | ⚠️ HIGH — S232 + raw cost on brass/hardgoods |
| **ICE Cotton No.2** | 82.10 USc/lb | +4.85% | **+27.4%** | ⚠️ HIGH — BD/IN/PK textile cost; India waiver closing |
| **SCFI** | ~3,000–3,200 | Stable | Significantly up | 🟡 MEDIUM — logistics cost; CN margin squeeze |
| **BDI** | 2,843 pts | +1.64% | **+44.3%** | 🟢 POSITIVE demand; ⚠️ raw material import cost |
| **Brent Crude** | $83.82/bbl | +16.4% | +21.9% | 🟡 MEDIUM — energy/polyester input; shipping surcharge |

---

## Usage in Validation Agent

When CP4a calls `[Commodity DB]`:
1. Match commodity to client product: brass/metal → LME Copper; cotton apparel → ICE Cotton; logistics → SCFI+BDI; energy/poly → Brent
2. Flag as `COMMODITY_SPIKE` if >10% MoM or >20% YoY
3. Layer onto DIM-4 (product) + DIM-1 (country) for composite risk score
4. LME Copper: check if HS code triggers S232 (≥15% copper content)

*Sources: LME via westmetall.com, TradingEconomics, Barchart, Cbonds*
*Next refresh: Week of Aug 11, 2026*
