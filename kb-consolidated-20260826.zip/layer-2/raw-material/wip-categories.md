# WIP Pre-Production Gate Knowledge — by Material Type

> Domain Owner: Josephine Cheung | Updated: 2026-07-01
> Key WIP gate knowledge for financing eligibility and quality risk assessment

---

## Why WIP Gates Matter for Air8

In hardgoods, the production process has multiple gates where defects are caught or created. Air8's exposure is highest AFTER financing is disbursed but BEFORE the goods clear the buyer's QC. Understanding WIP gate failure points:

- **Pre-production gate failure** (e.g., PP sample rejected) → production delayed → shipment delayed → Air8 tenor extends beyond plan
- **Mass production defect discovered** → buyer rejects shipment → invoice disputed → Air8 ARP at risk
- **Compliance failure** (e.g., lead content exceeds REACH limits) → customs detention → invoice unpayable

**Risk signal:** Factory that does NOT have formal PP sample approval process = higher QC risk = more conservative advance ratio.

---

## Material-by-Material WIP Gate Checklist

### Plastics (Injection Molded)
| WIP Gate | What's Checked | Failure Risk |
|---|---|---|
| Mold/Tool Approval | Dimensional accuracy, surface quality | Mold issue = all units wrong; costly rework |
| Color Swatch | Color match to Pantone/buyer standard | Batch inconsistency = buyer rejection |
| Restricted Substance (RS) Test | REACH SVHCs, phthalates, lead | RS failure = customs detention |
| PP Sample Approval | Full dimensional + aesthetic + compliance check | Customer sign-off REQUIRED before mass production |
| Production Monitoring | AQL inspection at 30%, 60%, 100% stages | Defect rate trend → early warning |

### Metal (Cast/Stamped/Welded)
| WIP Gate | What's Checked | Failure Risk |
|---|---|---|
| Raw Material Cert | Lead/cadmium content, grade specification | Bad material = all units non-compliant |
| Surface Treatment Approval | Plating thickness, coating adhesion | Adhesion failure discovered late = 100% rejection |
| RS Test | REACH SVHCs in coating/plating | EU customs detention |
| PP Sample | Structural + finish + compliance | REQUIRED before mass |

### Ceramic/Resin
| WIP Gate | What's Checked | Failure Risk |
|---|---|---|
| Glaze/Pigment Approval | Heavy metal content (lead, cadmium) | Leaching failure = recall risk |
| Firing Temperature Check | Consistency of kiln temperature | Inconsistency = color variation + structural weakness |
| PP Sample | Full check including leach test result | REQUIRED before mass |

### PTFE/Ceramic Coated Cookware
| WIP Gate | What's Checked | Failure Risk |
|---|---|---|
| Coating Spec Sign-off | Thickness, adhesion, PFOA-free declaration | Coating failure = product recall |
| Color Swatch | Coating color match | Batch variation |
| Adhesion Test | Fingernail scratch test (must not lift) | Critical defect |
| PP Sample | Full coated piece including cooking surface check | REQUIRED |

### Candles
| WIP Gate | What's Checked | Failure Risk |
|---|---|---|
| Fragrance Compliance | IFRA restricted substances list | Fragrance failure = EU/US market ban |
| Wick Centering Check | Position within 2mm of center | Fire safety risk |
| Container Integrity | Glass heat stress test, seam integrity | Safety hazard |
| Burn Test | Full burn in PP sample | REQUIRED |

### Seasonal/Holiday Decor
| WIP Gate | What's Checked | Failure Risk |
|---|---|---|
| Flammability Test | EN71-2 or applicable standard | Safety violation |
| RS Test | Lead, phthalates, restricted chemicals | Customs detention |
| Battery Compartment Check | Child safety (coin cell access) | CPSC/EN71 violation |
| Electrical Compliance | CE/UL marking if powered | Customs detention |
| PP Sample | Full aesthetic + compliance | REQUIRED |

---

## Air8 Operational Implication

**Ask at onboarding (hardgoods clients):**
1. "Do you have a formal PP sample approval process? Do you get written approval before mass production?"
2. "Which compliance tests do you run per SKU, and who certifies the results?"
3. "What is your AQL inspection protocol for final goods?"

**Factory without formal PP approval process → increase monitoring; consider lower advance ratio.**
**Factory with full WIP gate documentation → positive quality signal; supports standard advance ratio.**
