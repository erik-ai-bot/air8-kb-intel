# Hardgoods Defect Classification Guide

> Domain Owner: Josephine Cheung | Updated: 2026-07-01
> Source: hardgoods-defect-classification.md (Josephine's QC reference)

---

## Defect Severity Levels

| Level | Definition | AQL Tolerance |
|---|---|---|
| **Critical** | Safety risk, regulatory violation, renders product unusable, creates liability | Zero tolerance or AQL 1.0 |
| **Major** | Significant functional failure or high likelihood of complaint/return | AQL 1.0–2.5 |
| **Minor** | Cosmetic/aesthetic deviation; not safety-related; unlikely to cause complaint | AQL 2.5–4.0 |

**Rule:** Critical defects are NEVER negotiable. Major defects require customer notification. Minor defects may be accepted within AQL at customer discretion.

---

## WIP Pre-Production Approval Milestones (Universal)

**Applies to ALL hardgoods categories:**

1. **Material Certification** — food-safe grade / compliance-grade material confirmed via test report BEFORE production
2. **Color/Finish Swatch Approval** — surface finish/color standard confirmed; approved swatch retained as production reference
3. **Pre-Production (PP) Sample Approval** — full sample submitted to customer for written sign-off
4. 🚫 **MASS PRODUCTION MUST NOT COMMENCE until customer PP sample approval is received IN WRITING**

---

## Category-by-Category Defect Guide

### 1. COOKWARE — Uncoated (Stainless Steel, Cast Iron, Uncoated Aluminum)

**Critical:**
- Sharp edges or burrs on rims, handles, or base
- Handle detachment or instability under load
- Non-food-safe base materials (lead/cadmium exceeding limits)
- Cast iron: cracks, fractures, porous surface with embedded contaminants
- Missing/incorrect compliance markings (CA Prop 65, food contact)

**Minor:**
- Surface scratches/machining marks (non-structural)
- Slight color variation or uneven polishing
- Minor dents not affecting function

**WIP Gates:** Material Cert → Finish Swatch → PP Sample → Mass Production

---

### 2. COOKWARE — PTFE/Teflon Coating

**Critical:**
- Coating peeling, flaking, or blistering (ingestion risk)
- Coating adhesion failure (lifts when scratched with fingernail)
- PFOA or prohibited chemical content
- Exposed base metal on cooking surface
- Coating below minimum thickness standard

**Minor:**
- Cosmetic scratches not penetrating coating
- Slight color variation in coating finish
- Minor drips at rim area (non-cooking zone)

**WIP Gates:** Color Swatch → Coating Spec Sign-off (PFOA-free declaration, thickness, adhesion) → PP Sample

---

### 3. COOKWARE — Ceramic Coating (Sol-gel)

**Critical:**
- Coating chipping/cracking on cooking surface
- Heavy metal leaching (lead/cadmium above limits)
- Adhesion failure — coating separates from base
- Non-food-safe pigments or binders
- Surface porosity allowing bacterial harbor

**Minor:**
- Minor color variation or mottled appearance
- Faint surface marks in non-cooking zones
- Slight gloss variation

**WIP Gates:** Color Swatch → Ceramic Spec Sign-off (heavy metal compliance) → PP Sample

---

### 4. HOME DECOR — Plastic

**Critical:**
- Restricted substances: phthalates, lead, cadmium (REACH, RoHS, CPSIA)
- Sharp edges / protrusions
- Small detachable parts (choking hazard if child-facing product — ASTM F963, EN71)
- Structural failure under normal use load

**Minor:**
- Sink marks, weld lines, minor flash
- Color variation within batch
- Off-center logo

**Key compliance:** REACH SVHC, RoHS, CA Prop 65, CPSIA (US children's products)
**WIP Gates:** Material Cert (REACH/RoHS) → Color/Finish Swatch → PP Sample

---

### 5. HOME DECOR — Metal

**Critical:**
- Lead/cadmium surface coating content above limits
- Sharp edges / protrusions post-finishing
- Structural failure (weld or joint separation under load)
- Coating adhesion failure (electroplating lifting)

**Minor:**
- Minor surface scratches (non-structural)
- Slight finish variation
- Off-center decorative element

**Key compliance:** REACH, RoHS, CA Prop 65 (especially for decorative coatings)
**WIP Gates:** Material Cert → Surface Treatment Sign-off → PP Sample

---

### 6. HOME DECOR — Ceramic & Resin

**Critical:**
- Heavy metal leaching (lead, cadmium) above REACH/CPSIA limits
- Structural cracking creating sharp edges
- Non-food-safe glazes/pigments (for food-contact items)

**Minor:**
- Minor color variation between units
- Small surface imperfections in non-critical areas

**Key compliance:** REACH, food contact regulations (if applicable), CA Prop 65

---

### 7. SEASONAL + CANDLES

**Critical (Candles):**
- Wick not properly centered (fire risk)
- Non-compliant fragrance chemicals (IFRA restricted substances)
- Container integrity failure (glass cracking, seam leaking for container candles)

**Critical (Seasonal Decor):**
- Battery compartment accessible to children (small parts/battery ingestion risk)
- Electrical components without UL/CE certification (if battery-powered)
- Flammability: decorative materials must meet applicable standards (EN 71-2 for EU)

**Minor (Candles):**
- Minor color variation in wax
- Slight surface blemish (not affecting burn quality)

**WIP Gates:** Material Cert (IFRA compliance, flammability) → Sample Burn Test → PP Sample

---

### 8. FURNITURE (Indoor + Outdoor)

**Critical:**
- Structural failure under load (joints, legs, support mechanism)
- Sharp edges or protrusions on accessible surfaces
- Restricted substance content in wood treatments or coatings
- Outdoor: UV/weather treatment inadequate (claimed weather-resistant but not)

**Minor:**
- Minor finish variation
- Surface marks in non-critical areas
- Slight assembly tolerance variation (within spec)

**Key compliance:** REACH (upholstery chemicals), EN 12521/12520 (furniture strength), CARB (formaldehyde in wood panels — US)
**WIP Gates:** Material Cert → Structural Load Test → PP Sample

---

## AQL Reference

| AQL | Usage |
|---|---|
| 1.0 | Critical defect inspection (zero tolerance in practical terms) |
| 2.5 | Standard AQL for general hardgoods |
| 4.0 | Acceptable for purely cosmetic deviations |
