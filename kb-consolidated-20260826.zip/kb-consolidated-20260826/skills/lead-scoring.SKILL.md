---
name: "lead-scoring-agent"
description: "Run Air8 leads scoring pipeline (CP0-CP5). Scores suppliers using Apparel v1.1, Hardgoods v3.0/v2.1. Validates via Telegram. Writes to Notion."
status: proposal
version: "v2"
date: "2026-08-06T00:00:00.000Z"
user-invocable: true
---

# Lead Scoring Agent

## Scenario routing — always ask first

Before CP0, send this message and wait for reply:

```
🧭 Validation Agent — which scenario?

[📊 Leads Scoring]      ← score a supplier list, filter, export to Notion  
[🔍 Event Validation]  ← validate a specific supplier or event
```

- **Leads Scoring** — runs CP0–CP5 (this skill)
- **Event Validation** — different KB + flow; route to the event validation skill

Do not start CP0 until scenario is confirmed.

---

## When to use this skill

Triggered by: "score these leads", "run lead scoring", "filter supplier list",
"run CP0 leads", "score my leads", "leads filtering", "run the scoring agent", "📊 Leads Scoring" button

## ⚠️ Structural caveat — NEXT RETAIL / UK-EU buyers

US customs data (the scoring source) captures **US-bound volume only**.
UK-bound and EU-bound shipments are invisible.

For UK/EU retailers (NEXT, Primark, M&S, Aldi): suppliers shipping primarily to
UK/EU may score lower than their actual stickiness warrants. Cross-check against
book activity before concluding any supplier is dormant.

---

## Scripts (NEXT RETAIL pipeline)

| Script | Purpose | Run |
|---|---|---|
| `lead-scoring/score_next.py` | CP0–CP4: route + score all 670 suppliers, output `NEXT_scored.csv` | `python3 score_next.py` |
| `lead-scoring/filter_next.py` | CP3–CP4: apply gates, sort, build call list CSV | `python3 filter_next.py` |
| `lead-scoring/run_pipeline.py` | Run both scripts end-to-end in one command | `python3 run_pipeline.py` |

Outputs go to `lead-scoring/output/NEXT/`:
- `NEXT_scored.csv` — all 670 suppliers with scores, tiers, component detail
- `NEXT_call_list.csv` — call list / bench / pipeline with gate flags

---

## Inputs

| Input | How provided | Notes |
|---|---|---|
| Raw supplier data | File sent in chat (xlsx or csv) OR Notion database link | See §Raw data format below |
| Country filter (optional) | Natural language after CP4 | e.g. "India only", "focus Pakistan" |
| Run mode | `full` (all CPs unattended) or `step` (pause at each CP for Telegram confirmation) | Default: `step` |

### Raw data format

**Shape A — Buyer supplier list (minimal):**
Columns: Supplier Name, Supplier Code, Country, Product Family, Product Category,
No of shipments P1Y, Growth (P1Y/P2Y-1), Months with invoice P1Y,
Avg Invoice USD, Total Buyers, Buyer Names (pipe-separated), TOP_10 products (JSON array)

**Shape B — Air8 master list (full, 87 cols):**
The standard supplier_list.xlsx from the Air8 system. All indicators derive automatically.

If Shape A is provided and fields are missing, the agent notes which scoring components
cannot be computed and marks those suppliers for Enrichment rather than scoring them zero.

---

## KB structure (kb-v2/)

| Directory | Contains |
|---|---|
| `kb-v2/layer1/` | HOW to think — method, pipeline, evidence discipline, data traps, decision log. **No numbers.** |
| `kb-v2/layer2/` | WHAT things are — all weights, thresholds, tiers, gates live in versioned tables here. **All numbers.** |
| `kb-v2/_to_db/` | Seed data — dead buyer programmes, name collisions. DB content, not KB. |

**The only governance rule:** To change a number, fill in `valid_to` on the old table row,
add a new row with `valid_from`, evidence, and n. Increment the framework version.
One line in `L1-decision-log.md`. Nothing else changes.

Old → new file map: `kb-v2/layer2/CP-MAP.md` §Old file → new home

---

## KB files used per CP

| CP | L1 (method) | L2 (nodes) | Core logic |
|---|---|---|---|
| CP0 | `layer1/L1-db-field-contract.md` | `layer2/NODE-indicator.md` (locators) | Map columns→indicators; trailing-12; dedup on normalized name |
| CP1 | `layer1/L1-pipeline-and-gates.md` §3 | `layer2/NODE-scoring-framework.md` §ROUTED_FROM | HS chapter → framework; text = downgrade; none → Enrichment |
| CP2 | `layer1/L1-scoring-method.md` | **`layer2/NODE-scoring-framework.md` §USES_INDICATOR + Tier rules** | Banded additive; filter `valid_to = null`; missing → Enrichment not zero |
| CP3 | `layer1/L1-pipeline-and-gates.md` §gates | `layer2/NODE-scoring-framework.md` §Gates and caps | flow-stale / cny-domestic / kill-combo / furniture cap |
| CP4 | `layer1/L1-pipeline-and-gates.md` §sort | `layer2/NODE-scoring-framework.md` §TIEBREAK_BY | Score primary; region tie-break; need tertiary |
| CP4.5 | `layer1/L1-evidence-discipline.md` | **`layer2/NODE-adverse-screen.md` · `layer2/NODE-financing-need.md` · `layer2/NODE-outreach-profile.md` · `layer2/NODE-evidence-source.md`** | Adverse → re-gate loop; need band → Floor; buyers/contacts per source |
| CP5 | `layer1/L1-evidence-discipline.md` | — | All rows out; audit log cites framework instance versions |

Citation format (Telegram): `[KB: NODE-scoring-framework.md · fw:apparel-v1.1]`

---

## CP0 — Data Load & Field Mapping

**Read:** `kb-v2/layer1/L1-db-field-contract.md` + `kb-v2/layer2/NODE-indicator.md`

1. Load the raw file (xlsx or csv).
2. Map columns to indicator locators in NODE-indicator.md.
3. Deduplicate by SUPPLIER_CODE — one row per supplier. For multi-row suppliers
   (one row per buyer), aggregate: sum shipments, max months_active, max n_buyers,
   collect all buyer names, collect all TOP_10 items.
4. Flag any missing indicator columns.

**Telegram message format:**
```
📥 CP0 · Data Load
[KB: L1-db-field-contract.md · NODE-indicator.md]

✓ {n_rows} rows loaded → {n_suppliers} unique suppliers
✓ Columns mapped: {mapped_cols}/{total_cols}
{missing_cols_list if any}

{flag_count} suppliers missing key fields → Enrichment queue

Confirm to proceed to CP1 (Vertical Routing)?
[✅ Confirm] [⚠ Flag issue]
```

---

## CP1 — Vertical Routing

**Read:** `kb-v2/layer1/L1-pipeline-and-gates.md` §3 + `kb-v2/layer2/NODE-scoring-framework.md` §ROUTED_FROM

Route each supplier by HS chapter. Apparel chapters (61, 62) route to Apparel v1.1.
All other scoring chapters route to Hardgoods v3.0 (or v2.1 for thin data fallback).
Park: raw hides (41), raw yarn/fabric (50–53), chemicals (29–30), paper/books (48–49).

> ⚠️ Common mistake: ch63 (made-up textiles) looks like apparel but is hardgoods.
> ch64 (footwear) and ch42 (bags/leather) are hardgoods — do NOT park these.

**Telegram message format:**
```
🗺 CP1 · Vertical Routing
[KB: L1-pipeline-and-gates.md · NODE-scoring-framework.md §ROUTED_FROM]

Apparel v1.1:     {n_apparel} suppliers
Hardgoods v3.0:   {n_hg30} suppliers
Hardgoods v2.1:   {n_hg21} suppliers (thin data fallback)
Parked:           {n_parked} suppliers (raw material / mill — outside both funnels)
Enrichment:       {n_enrichment} suppliers (no HS codes, can't route)

Confirm to proceed to CP2 (Scoring)?
[✅ Confirm] [⚠ Reroute a supplier]
```

---

## CP2 — Component Scoring

**Read:** `kb-v2/layer1/L1-scoring-method.md` + `kb-v2/layer2/NODE-scoring-framework.md`

Score each supplier using the framework in NODE-scoring-framework.md for their vertical.
Only rows where `valid_to IS NULL` apply. Cite the framework instance in Telegram.

### Scoring bands — read from layer2, never duplicate here

**All thresholds, weights, tier cuts, and bands live in:**
`kb-v2/layer2/NODE-scoring-framework.md` — filter `valid_to IS NULL` for active rows only.

Do NOT reproduce numbers in this skill. If a threshold changes, only NODE-scoring-framework.md changes.
The CP2 Telegram message renders bands from that file at runtime — it always matches what executed.

### Score flags (exception handling — these are process rules, not thresholds)

| Flag | Source | Effect |
|---|---|---|
| flow-stale | `valid_to IS NULL` gate in NODE-scoring-framework.md §Gates | Demote 1 tier |
| furniture cap | §Gates — furniture category cap | Cap at Tier B max |
| own-book | `own_book = TRUE` in DB | Label only, not removed |
| missing component | null input → no band matched | Enrichment queue, not zero |

## ★ Message format standard (apply to ALL CPs)

Rule: one message per CP, four fixed sections, do not remove any section.

Section 1 — Header
  emoji  *CP{n} · Title*
  `[KB: file1 · file2]`

Section 2 — Core logic (blue code block)
  Use ``` fenced block for tables/rules/bands.
  This renders as blue monospace in Telegram. Keep columns clean.

Section 3 — Results
  emoji bullet per outcome. Short lines. No ASCII tables.

Section 4 — Output summary + buttons
  Short divider line, then next-step summary, then inline buttons.

──────────────────────────────────────────────
CP2 template:

📊 *CP2 · Scoring*
`[KB: NODE-scoring-framework.md · L1-scoring-method.md · L1-decision-log.md]`

```
Framework Check
fw:apparel-v1.1   calibrated {cal_date_app} · {days_app} days ago
fw:hardgoods-v3.0 calibrated {cal_date_hg}  · {days_hg} days ago

New financed pairs since cutoff: {n_pairs}  (threshold: 20) → not triggered
Calibration age: {days_app} / {days_hg} days (threshold: 90d) → not triggered
BD outcomes recorded: {n_outcomes}           (threshold: 30)  → not triggered
→ Using existing framework.
```

```
[Render scoring table at runtime from kb-v2/layer2/NODE-scoring-framework.md]
[Filter valid_to IS NULL — active rows only]
[Show: framework ID · max pts · each indicator with bands · tier cuts]
Single source of truth — never hardcode here.
```

Results:
📊 Apparel   A:{n_a} B:{n_b} C:{n_c} ({total} total)
📊 Hardgoods A:{n_a} B:{n_b} C:{n_c} ({total} total)

Top Apparel Tier A (excl. own-book): {list}
Top Hardgoods Tier A (excl. own-book): {list}

```
Exception Handling          [KB: kb-v2/layer2/NODE-scoring-framework.md §Gates]
Missing component  → Enrichment, not zero (null ≠ zero)
flow-stale >6m     → Demote 1 tier · {n} affected
own-book           → Label only, not removed · {n} suppliers
Category unknown   → Enrichment, not zero
```

──────────────────────────────────────────────

CP3 template:

🔍 *CP3 · Gate Checks*
`[KB: kb-v2/layer1/L1-pipeline-and-gates.md · kb-v2/layer2/NODE-scoring-framework.md §Gates]`

```
Gate          Condition                     Action
kill-combo    CN+≤1 buyer+ticket>pen+low cad Hard remove
CNY domestic  Only CNY domestic txns         Hard remove
furniture cap Category = furniture           Cap at Tier B
flow-stale    >6m since last target txn      Demote 1 tier
own-book      Already financed by Air8       Label only
Adverse       Not yet checked                NOT SCREENED
```

Results:
✅ kill-combo — {n} removed
✅ CNY domestic — {n} removed
✅ furniture cap — {n} affected
⚠️ flow-stale — {n} demoted · {examples}
🏷 own-book — {n} labelled · {names}
🔍 Adverse — NOT SCREENED (CP4.5 checks shortlist only)

Output to CP4:
  Tier A: {n_a}  (incl. {n_own} own-book — labelled at CP5, not called)
  Hard removed: {n_hard}
  Demoted by flow-stale: {n_stale}
  NOT SCREENED: all — CP4.5 checks shortlist only
  Total proceeding: {n_total} scored suppliers

[✅ Confirmed — go to CP4] [⚠️ Flag a supplier]

──────────────────────────────────────────────

Buttons rule: always [✅ Confirmed — go to CP{n+1}] + [⚠️ Flag a supplier] minimum.
CP4 also gets [🔧 Change filter].

Governance thresholds (fixed — do not query live data):
- New financed pairs since calibration cutoff **< 20** → no re-calibration
- Calibration age **< 90 days** → no re-calibration
- BD outcomes recorded **< 30** → no re-calibration
- Counter-examples observed **< 3** → no re-calibration
Count new pairs from leads_activity_monthly.csv rows with month > calibration cutoff month.
BD outcomes from Notion Status field (Closed Won / Closed Lost count).

Buttons: [✅ Confirm — go to CP3] [⚠️ Flag a supplier]

---

## CP3 — Gate Checks

**Read:** `kb-v2/layer1/L1-pipeline-and-gates.md` §gates + `kb-v2/layer2/NODE-scoring-framework.md` §Gates and caps

Apply gates in order: flow-stale → cny-domestic → kill-combo → furniture cap.
Adverse + default checks here expect `NOT SCREENED` — that is the honest normal state.

**Telegram message format:**
```
🔍 CP3 · Gate Checks
[KB: L1-pipeline-and-gates.md §gates]

{n_removed} suppliers removed from list. {n_proceed} proceed to CP4.

Confirm to proceed to CP4 (Sort & Call List)?
[✅ Confirm] [⚠ Flag a supplier]
```

---

## CP4 — Sort + Call List

**Read:** `kb-v2/layer1/L1-pipeline-and-gates.md` §sort + `kb-v2/layer2/NODE-scoring-framework.md` §TIEBREAK_BY

### Default region filter + sort:

**Default filter** (all regions in scope — user can narrow):
India · Pakistan · Bangladesh · China · Hong Kong · Vietnam · Indonesia · Sri Lanka

No priority between regions — they are a filter, not a ranking.
Modify the filter to focus on specific regions before finalising.

**Sort** (within filtered set):
1. Score descending
2. Financing need as tiebreaker only (never removes)

### List structure:
- **Call list:** top 20 (Tier A fills first; top Tier B added if Tier A < 20)
- **Bench:** next 5 Tier B suppliers — promote if a call list slot opens
- **Pipeline:** remaining scored suppliers — revisit next quarter
- **Floor:** suppliers with published evidence of no financing need — visible, not deleted
- **Gated out:** removed suppliers — visible with reason, never silently deleted

After generating the list, **pause and wait for a filter instruction** before finalising.

**Telegram message format:**
```
📋 CP4 · Call List Ready
[KB: L1-pipeline-and-gates.md §sort]

━━━ TOP 10 APPAREL ━━━
1. [A] {name} ({country}) — {score}/11
...

━━━ TOP 10 HARDGOODS ━━━
1. [A] {name} ({country}) — {score}/15
...

[✅ Approve & export to Notion]
```

Send buttons alongside the CP4 list:
```
[✅ Approve CP4 — run CP4.5]   ← PRIMARY: always next step
[🔧 Change filter]             ← re-filter without re-scoring
[⏭ Skip CP4.5 → Notion]       ← only if user explicitly says no research needed
```

CP4.5 is mandatory after CP4. Do NOT offer direct export to Notion as the primary action.
Only show [⏭ Skip CP4.5] as a secondary option — never as the default.

When [Change filter] is pressed:
- Ask: "Which filter? (e.g. India only, Tier A only, remove Vietnam)"
- Re-sort, re-present the full updated list with exclusions noted
- Do NOT re-score — scores are frozen at CP2
- Offer [Change filter] again until user hits Approve CP4

---

## CP4.5 — Top N Research (Background Check · Financing Need · Contacts)

**Resource-intensive. Default: top 20 per vertical. Confirm scope before running.**

**Read:** `kb-v2/layer1/L1-evidence-discipline.md` + all `kb-v2/layer2/NODE-*.md`

**Cache:** Check `lead-scoring/output/NEXT/NEXT_cp45_cache.json` before researching each supplier. The cache is empty by default for a clean run — only populated as research completes. If a supplier name (normalised to UPPERCASE) is already in `entries`, use the cached result and skip live research. Write each new result to the cache immediately after completion.

**Own-book skip:** Suppliers with `own_book = TRUE` are already financed — skip CP4.5 entirely for them. They get `Call Priority = 🔴 Already Financed` in Notion with `Shortlist = false`.

### Scope is confirmed at CP4 (not here)

CP4.5 uses the research count and region filter confirmed by the user at CP4.
No additional scope question at the start of CP4.5.
Own-book suppliers are always skipped.

### For each supplier in scope:

**0. Cache check first.** Normalise the name to UPPERCASE and look up in `NEXT_cp45_cache.json`. If found, load cached result. Only proceed with live research if not in cache.

**1. Background check** `KB: NODE-adverse-screen.md`
Search: `"{name}" lawsuit OR fraud OR default OR sanction OR investigation`
Verdict: CRITICAL / MATERIAL (remove) / MINOR (keep, flag) / CLEAN / NOT SCREENED

**2. Financing need** `KB: NODE-financing-need.md`
Check: rating agency action, receivables vs revenue growth, collateral exhaustion,
parent funding pattern, legal form.
Band: VERY HIGH / HIGH / MEDIUM / LOW / UNKNOWN.
LOW → Floor (visible, not deleted).

**3. Key buyers** `KB: NODE-outreach-profile.md`
List top 3 buyers by shipment volume. Flag if top buyer >80% concentration.
Apply supplier type logic (trading house → activity signal is misleading; etc.).

**4. Company info**
Founded year, HQ, employee count, key certifications (GOTS, OEKO-TEX, ISO, SEDEX).

**5. Contact details** `KB: NODE-evidence-source.md §Contact-Finding Hierarchy`
Work through the source hierarchy in order (internal records → annual report/prospectus → rating rationale → regulator filing → trade fair directory → certification DB → B2B profile → company site → IR adviser). For LF-tagged suppliers, check internal vendor records first. Search the person by name once identified (`"{name}" "{company}"` for LinkedIn). Use local-language search for China (`董秘 {name} 年报`) and Pakistan. `NOT FOUND` (with sources checked) ships — invented contacts do not.

**6. Write to cache.** After completing research on each supplier, append the result to `NEXT_cp45_cache.json` so the next run does not repeat the work.

### Telegram message format:
```
🔎 CP4.5 · Research done — {n_checked} suppliers
[KB: NODE-adverse-screen.md · NODE-financing-need.md · NODE-outreach-profile.md]

Background check:
  Clean:        {n_clean}
  Minor issues: {n_minor} (kept, flagged)
  Removed:      {n_removed}

Financing need:
  Likely needs: {n_need}
  Uncertain:   {n_unc}
  Already covered: {n_covered} → moved to Floor

{if removed > 0}
⚠ Removed:
  • {name} ({country}) — {reason}
```

---

## CP5 — Export to Notion

**Read:** `kb-v2/layer1/L1-evidence-discipline.md` + `kb-v2/layer2/CP-MAP.md` §Notion output schema

1. Write ALL scored suppliers to the Notion database.
2. BD-tracking fields (BD Owner, Status, Notes, Last Contacted) left empty for BD to fill.
3. Add a **Shortlist** checkbox (true for clean Tier A that are not own-book; false for flagged or already-financed).
4. Add a **Call Priority** select:
   - 🟢 Call Now — clean Tier A, not own-book
   - 🟡 Verify First — Tier A with unresolved adverse / entity concerns
   - 🔵 Floor — need assessed as LOW (already well-funded)
   - 🔴 Already Financed — `own_book = TRUE` (model validation only, do not call as new BD)
5. Generate audit log: run timestamp, input file hash, KB files used, filter instructions.

**Telegram message format:**
```
✅ CP5 · Export complete

{n_total} suppliers written to Notion
📊 Notion: {notion_url}

  Tier A (call this week):    {n_a}  ← {n_shortlist} shortlisted
  Tier B (call this quarter): {n_b}
  Tier C (not ready):         {n_c}
  Enrichment queue:            {n_enrichment}

Audit log: lead_scoring_audit_{timestamp}.json
Run ID: {run_id}
```

---

## Notion setup

Before first run, create the Notion database:
1. Say: "set up the Notion leads database for scoring"
2. Agent creates DB using `kb-v2/layer2/CP-MAP.md` §Notion output schema
3. Database ID saved to skill config

Notion API key: `~/.config/notion/api_key`

---

## Error handling

| Situation | Action |
|---|---|
| Missing key column (supplier name, product family) | Stop at CP0, report missing column |
| Supplier with no scoreable components | Move to Enrichment queue, not Tier C |
| Notion write fails | Save to CSV at `lead-scoring/output/` + notify via Telegram |
| User sends unrecognised filter | Ask for clarification, do not apply partial filter |
| KB file not found | Stop and report which file is missing |
| Chapter not in routing table | Log as "Enrichment — manual review needed", do not guess |
