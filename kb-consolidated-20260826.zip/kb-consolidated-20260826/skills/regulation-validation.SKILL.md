# regulation-validation — Skill v1.0

## Description

Regulation Validation Flow (RVF). Given a regulatory event (news, ECHA alert, DHS notice, etc.),
classify it, screen the igefile (supplier/BOM product data) for impacted suppliers/products,
then produce a per-supplier compliance analysis and combined HTML report.
Does NOT mix with lead-scoring — separate flow, separate KB.

## Triggers

Use this skill when:
- "run regulation validation" / "RVF" / "reg validation"
- "check this regulation" / "screen this regulatory change"
- "which clients are impacted by [regulation name]" / "impact screening"
- "substance [name] regulatory impact" / "SVHC [substance] alert"
- "REACH Annex XVII [entry] impact" / "new SVHC [CAS/name] alert"
- "regulation event: [text]" / "reg event: [text]"

## Substance Matching Priority

The igefile substance data has CAS numbers present for most records (use "-" or blank as no-CAS).
Screening uses a **CAS-first, name-fallback** approach:

Match logic priority (in order):
1. **CAS number exact match** — when `substanceCode` is non-null, match directly
   against the regulated substance's CAS. Most reliable; use as authoritative match.
2. **Substance name exact match** — case-insensitive exact string match against
   `substanceName` field when CAS is null.
3. **Substance name fuzzy/partial match** — keyword substring match when exact
   name fails (e.g. "hexane" hits "n-Hexane", "hexane solvent").

Confidence levels:
- CAS match → HIGH confidence (flag as CONFIRMED)
- Exact name match → MEDIUM confidence (flag as LIKELY)
- Fuzzy name match → LOW confidence (flag as POSSIBLE — needs human review)

## Files

```
IGEFILE:
  /Users/erikkwok/.openclaw/workspace/compliance-kb/igefile-substance-report-2026-08-25.csv
  (1.6MB flat CSV — 6228 substance rows, 11 suppliers, CAS + substance names per row)
  Key columns:
    Purchase order     — PO reference
    Supplier name      — supplier company name
    Product name       — product description
    Item number        — item ref (format: EAN-itemNo)
    EAN / EAN quantity / EAN ship year
    Material name      — material/formula name
    Material id        — UUID
    BOM weight (g)     — total BOM weight
    CAS                — substance CAS number ("-" or blank = no CAS)
    Substance name     — substance name
    Weight %           — weight % in material
    Actual weight (g)  — actual weight in grams
    REACH registration — REACH reg number if applicable
    BoS level          — 0=material level, 1=substance level

  FORMAT: Flat CSV, one substance per row. No JSON parsing needed.
  CAS matching: use "CAS" column directly (skip "-" or blank values).
  Group by "Supplier name" + "Item number" for per-supplier analysis.

  Suppliers in igefile (11):
    KORUMA TEMIZLIK ANONIM SIRKETI
    SAPRO TEMIZLIK URUNLERI SANAYI VE TICARET ANONIM SIRKETI
    NINGBO KWUNG'S HOME INTERIOR & GIFT CO.LTD
    NINGBO MASCUBE IMP.&EXP. CORP
    QINGDAO KINGKING APPLIED CHEMISTRY CO., LTD
    DALIAN TALENT GIFT CO., LTD.
    ARTMATE CO., LTD | BEST BASE II INTERNATIONAL CO., LTD
    HANGZHOU LIGHT INDUSTRIAL PRODUCTS | CONDA GROUP HONGKONG LIMITED
    PRIMACY INDUSTRIES PRIVATE LIMITED

KB BASE:
  /Users/erikkwok/.openclaw/workspace/compliance-kb/
  L1/L1-compliance-scope.md         ← routing
  L1/L1-compliance-interpretation.md ← interpretation chain
  L1/L1-compliance-response.md       ← playbook
  L1/L1-regulatory-intelligence.md   ← how to track regulations
  L2/NODE-compliance-product-eu.md   ← EU substance rules + SVHC list
  DT/DT-reach-svhc.md               ← SVHC substance data table (image)
  DT/DT-internal-data-map.md        ← data source map
```

## Flow: Step-by-Step

---

### STEP 1 — EVENT INTAKE

Input: raw event text (paragraph, article URL, ECHA alert, DHS notice, etc.)

Output: structured event record. Fill in all fields:

```
Event Record:
  Title: [event name]
  Source: [where it came from]
  Date: [effective date / publication date]
  Regulation: [REACH / GPSR / UFLPA / PPWR / Prop 65 / CPSIA / Other]
  Jurisdiction: [EU / US / UK / Multi]
  Substance(s) triggered: [CAS + name, or requirement description]
  Product scope: [HS codes / product categories affected]
  Market scope: [EU / US / both]
  Effective date: [date it came / will come into force]
  Deadline / enforcement: [date, or "already in force"]
  Severity: [Hard ban / Notification required / Upcoming / Ongoing]
  Description: [concise summary of what changed]
```

Ask clarification questions if event text is ambiguous.

---

### STEP 2 — REGULATION CLASSIFICATION

Question: Is this a compliance-relevant regulatory event?

Check:
- Does it relate to chemical substance restrictions? (REACH, SVHC, Annex XVII)
- Does it relate to product safety? (GPSR, CE, CPSC)
- Does it relate to forced labor / country of origin? (UFLPA, sanctions)
- Does it relate to labeling / packaging? (PPWR, Prop 65)
- Does it relate to import duties that affect compliance cost? (Section 301)

Routes:
```
YES → continue to Step 3
NO  → "This event is [type] — not a product compliance trigger.
       If you want a different analysis (trade policy, market, pricing),
       route to the appropriate flow."
UNCERTAIN → "I'm not sure if this qualifies. Could you confirm:
             - Is this about a legal requirement that affects product composition,
               labeling, import, or safety?
             If yes, I'll proceed. If it's about pricing, logistics, or general
             trade news, I'll route it differently."
```

---

### STEP 3 — RISK ANALYSIS OF EVENT

Load relevant KB nodes. Use L1-compliance-interpretation.md reasoning chain.

Answer these questions:

```
1. WHAT changed?
   → New substance added to SVHC candidate list?
   → New restriction threshold set in Annex XVII?
   → New enforcement date for existing regulation?
   → New product category in scope?

2. WHO is the regulator?
   → ECHA (EU chemical agency) for REACH/SVHC
   → European Commission for GPSR/PPWR
   → CBP/DHS (US) for UFLPA
   → CPSC/OEHHA for Prop 65 / CPSIA

3. What's the enforcement mechanism?
   → Notification to ECHA (SCIP) — non-compliance = importer liability
   → Market withdrawal — hard ban product from sale
   → Customs detention — UFLPA shipment hold
   → Buyer hold — retailer refuses shipment until doc provided

4. What's the deadline?
   → Past (already in force) → immediate exposure
   → Future → countdown, timeline to act
   → Rolling (SCIP notifications) → 6-month window from listing

5. What's the penalty for non-compliance?
   → EU: fines + market withdrawal + importer back-charge to supplier
   → US: CBP detention + Prop 65 private litigation + buyer claims
   → Reputation: buyer may delist supplier

6. Is this a recurring/ongoing regulation?
   → UFLPA: ongoing enforcement, entity list updates
   → GPSR: single appointment needed, then done
   → SVHC: new substances added ~2x per year, need re-screen each time
```

Output: Risk Brief with severity score (1–5), affected regulation, key deadlines.

---

### STEP 4 — IGEFILE SCREENING

Load igefile CSV (`igefile-substance-report-2026-08-25.csv`). Each row = one substance.
Flat CSV — no JSON parsing. Read rows directly.

**Substance Screening (CAS-first, name-fallback):**

Build a regulated substance lookup from the event (CAS + name + synonyms).
For each row in igefile:

```
For each row in igefile CSV:

  PASS 1 — CAS match (HIGH confidence / CONFIRMED):
    IF row["CAS"] is not blank / "-" / null AND looks like a valid CAS:
      IF row["CAS"] == regulated_CAS:
        → IMPACTED (CONFIRMED)
        → Record: Supplier name, Item number, Product name, Material name,
                  CAS, Substance name, Actual weight (g), Weight %
        → Tag row CONFIRMED — skip further passes for this row

  PASS 2 — Exact name match (MEDIUM confidence / LIKELY):
    IF row["Substance name"] (stripped, lowercase) == regulated_name (lowercase):
      → IMPACTED (LIKELY)
      → Record: as above, match type = EXACT NAME

  PASS 3 — Fuzzy/keyword match (LOW confidence / POSSIBLE):
    IF any keyword from regulated substance synonym list
       appears as substring of row["Substance name"] (case-insensitive):
      → IMPACTED (POSSIBLE — flag for human review)
      → Record: matched keyword, Substance name, Actual weight (g)

Group IMPACTED rows by "Supplier name" for Step 5 analysis.
Key output fields: Supplier name, Item number, Product name,
                   Material name, CAS, Substance name, Weight %, Actual weight (g)
```

**Additional product-category triggers:**
```
Candles / fragrance / diffuser products:
  → Fragrance compounds (paraffin wax, fragrance oils) — SVHC screening
  → Lead in wicks if metal-core wick used

Markers / paints / art supplies:
  → solvents (acetone, xylene, toluene, butyl acetate)
  → pigments (lead chromate, cadmium sulfide, barium sulfate)
  → monomers (styrene, acrylates, methacrylates)

Bubble guns / children's toys:
  → electrical safety (if battery/LED present)
  → small parts regulation
  → phthalates in plastic components
```

**Output: Three-tier impact list**

```
CONFIRMED IMPACTED   (CAS match):        show in 🔴 RED
LIKELY IMPACTED      (exact name match): show in 🟠 ORANGE
POSSIBLE IMPACTED    (fuzzy match):      show in 🟡 YELLOW + "needs review"
NOT IMPACTED:        no match in BOM     show in 🟢 GREEN

Each entry: SUPPLIER_CODE, SUPPLIER_NAME, ITEM_DESCRIPTION,
            matched substance, match type, actualWeight
```

Group by SUPPLIER_CODE for Step 5.

---

### STEP 5 — PER-SUPPLIER / PER-PRODUCT ANALYSIS

For each IMPACTED supplier (grouped by SUPPLIER_CODE):

```
For each impacted row belonging to this supplier:
  → CP2: Document gap check
      - Is there a GPSR EU AR on file? (production outside EU + EU destination)
      - Is there a REACH SVHC declaration? (any EU destination)
      - Is there a Prop 65 test? (US destination + California)
      - Is there a UFLPA Tier 1 traceability doc? (China production)
  
  → CP3: Risk scoring
      Use severity × urgency matrix from L1-compliance-response.md
      Score each gap:
        GPSR EU AR missing → 5×5 = 25 (CRITICAL if EU destination)
        SVHC substance confirmed → 4×4 = 16 (HIGH if EU destination)
        UFLPA docs missing → 4×4 = 16 (HIGH if China production)
        Prop 65 test missing → 4×4 = 16 (HIGH if US destination)

  → CP4: Currency check
      Has the regulation changed since last assessment?
      Any existing document on file for this supplier is now potentially stale.
```

Aggregate per supplier — one analysis record per supplier, not per row.

---

### STEP 6 — HTML OUTPUT

Generate a single combined HTML report.

**Required sections:**

1. **Header** — Event title, date, assessment timestamp, overall status banner
2. **Event Summary** — What changed, why it matters, enforcement mechanism, deadline
3. **Regulation Classification** — YES/NO/UNCERTAIN with reasoning
4. **Impact Heatmap** — table of all IMPACTED suppliers:
   - Supplier name
   - Country
   - Product types affected
   - Regulation triggered
   - Risk score
   - Status (CRITICAL / HIGH / MEDIUM)
5. **Per-Supplier Detail Cards** (expandable/collapsible):
   - Supplier name + code
   - Impacted products (ITEM_DESCRIPTION list)
   - Matched substance(s) found in BOM
   - Risk scores
   - Required actions
   - Data gaps (what's missing to confirm full impact)
6. **Not-Impacted Suppliers** — brief list of suppliers with no match
7. **Data Quality Notes** — BOM CAS null rate, substance name match confidence
8. **Next Steps** — Recommended immediate actions + follow-up schedule

**Color coding:**
- 🔴 CRITICAL (score 20–25): immediate action required
- 🟠 HIGH (score 15–19): important, deadline-driven
- 🟡 MEDIUM (score 8–14): monitor, plan ahead
- 🟢 LOW (score 1–7): minor / informational

**Design:** Dark theme, mobile-friendly, collapsible sections. Air8 orange (#f97316) accent.

**Filename:** `rvf-report-[event-slug]-[YYYYMMDD].html`

---

## Substance Name Matching Reference

Common regulated substance name keywords for fuzzy matching:

```
SVHC Feb 2026 additions:
  n-Hexane → "hexane", "n-hexane", "hexane-", "C6H14"
  BPAF     → "bisphenol AF", "BPAF", "hexafluoropropane"

REACH Annex XVII common entries:
  Lead compounds → "lead", "lead acetate", "lead oxide", "Pb"
  Cadmium → "cadmium", "cadmium sulfide", "Cd"
  DEHP / DBP / BBP → "phthalate", "DEHP", "DBP", "BBP", "plasticizer"
  Chromium VI → "chromium", "chromium trioxide", "Cr6"
  Formaldehyde → "formaldehyde", "CAS 50-00-0", "formalin"
  Azo dyes → "azo", "dye", "aromatic amine"
  PAH → " PAH", "polycyclic", "benzo[a]pyrene", "carcinogenic"

Common regulated solvents:
  Acetone → "acetone", "propan-2-one"
  Toluene → "toluene", "methylbenzene"
  Xylene → "xylene", "dimethylbenzene"
  Butyl acetate → "butyl acetate", "n-butyl acetate"
  n-Hexane → "hexane", "n-hexane" (common paint thinner)
  1,2-dichloroethane → "DCE", "ethylene dichloride"

Fragrance SVHC risk (candles/diffusers):
  Paraffin wax → not SVHC, but document composition
  Fragrance compounds → unknown SVHC risk without CAS
  Essential oils → d-limonene, linalool — not currently SVHC
```

## Output Format

Default: HTML report (dark theme, mobile-friendly)
Optional: Markdown summary with same structure if HTML not required

## Important Distinctions

- RVF = Regulation Validation Flow = event-driven, fan-out to many clients
- Compliance Assessment CP0–CP5 = client-driven, one client at a time
- These are separate skills with separate KBs
- RVF can call the Compliance Assessment CP logic for per-supplier analysis (Step 5)

---

*Skill version: 1.0 — 2026-08-26*
*KB path: /Users/erikkwok/.openclaw/workspace/compliance-kb/*
*igefile: /Users/erikkwok/.openclaw/workspace/compliance-kb/igefile-substance-report-2026-08-25.csv*
*Previous igefile archived: igefile-bom-39samples_backup_20260826.csv*
*Do not mix with lead-scoring flow*
