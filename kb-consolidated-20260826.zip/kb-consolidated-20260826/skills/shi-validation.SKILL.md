---
name: shi-validation
description: Run the SHI validation agent on raw trade documents. Detects exceptions, resolves via KB rules, outputs a structured decision.
version: v1.4
date: 2026-08-14
kb: air8-databases/SHI-KB/
---

# SHI Validation — SV0 to SV5

## Interaction pattern

Run one step at a time. After each step, send the output and wait for confirmation before proceeding.
Use inline buttons at the end of every step:
- **[✅ Confirmed — go to SV{n+1}]** → proceed
- **[⚠️ Adjust]** → user corrects; apply correction and re-present the same step before continuing

Do not proceed to the next step until the current step is confirmed. If the expert adjusts, acknowledge the change, update the output, and re-present with buttons again.

---

## Message format (apply to ALL steps)

Section 1 — Header: emoji + *SV{n} · Step name* + `[KB: files used]`
Section 2 — Core output (use code block for tables/structured data)
Section 3 — Summary line
Section 4 — Inline buttons: [✅ Confirmed — go to SV{n+1}] [⚠️ Adjust]

---

## SV0 — Intake

Collect: supplier, buyer, documents received. List each document with type and key ref.

Buttons: [✅ Confirmed — go to SV1] [⚠️ Adjust]

---

## SV1 — Parse

Load `layer2/NODE-terminology.md`

Use Part A to map document labels to canonical field names.
Use Part B to normalize values (especially payment terms cross-document).

Extract key fields from each document into a structured table. Mark `[NOT FOUND]` where missing.
Note any standard trade reference codes (Part B — for context only, no action).

Buttons: [✅ Confirmed — go to SV2] [⚠️ Adjust]

---

## SV2 — Detect

Load `layer2/NODE-risk-categories.md`

Run exception detection per the R1–R9 triggers defined there.
Compare extracted fields across documents.
Run hard stop pre-check (HS1–HS5) at the end of this step.

Output: confirmed exception list with R-category and raw values + hard stop status.

Buttons: [✅ Confirmed — go to SV3] [⚠️ Adjust]

---

## SV3 — Resolve

Load `layer1/L1-reasoning-principles.md` and follow the resolution hierarchy defined there.

Output: resolution per exception (AUTO-PASS / ESCALATE / HOLD) with rule cited.

Buttons: [✅ Confirmed — go to SV4] [⚠️ Adjust]

---

## SV4 — Evidence Check

Load `layer1/L1-evidence-discipline.md`

Cite evidence per decision with format `[Source type · Date · Person/System]`.
Flag insufficient evidence and state what is needed.

Buttons: [✅ Confirmed — go to SV5] [⚠️ Adjust]

---

## SV5 — Output

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SHI — [Supplier] → [Buyer]
Date: [today]  |  Docs: [list]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OVERALL: [AUTO-PASS ✅ / ESCALATE 🔴 / HOLD 🟡]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[For each exception:]
R[N] · [Category]
  Found:    [values]
  Decision: [AUTO-PASS ✅ / NOT AN EXCEPTION ✅ / ESCALATE 🔴 / HOLD 🟡]
  Rule:     [rule applied]
  Evidence: [citation]

─────────────────────────────────────

ACTIONS: [what is needed before release]
KB PROPOSALS: [new patterns — do not self-modify KB]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Buttons: [✅ Done — save report] [⚠️ Adjust]

---

## KB Update

Never edit KB directly. Confirmed new patterns → proposal file + decision log after Ops confirms.
