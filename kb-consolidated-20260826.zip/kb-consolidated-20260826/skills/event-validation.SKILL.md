---
type: skill
id: kb-validation-agent
version: 0.3
---

# KB Validation Agent — Master Skill

> A step-by-step reasoning validation agent that runs the Air8 KB event trigger flow
> with full transparency at each checkpoint. Each step is visible, labeled, and 
> human-validatable before proceeding to the next.

---

## When to Use This Skill

Trigger when:
- A new market event arrives and needs to be processed through the KB reasoning flow
- A human needs to validate KB reasoning step by step (demo / review mode)
- You want to expose which data sources were queried and why
- You want to surface KB gaps for expert review

---

## Flow Overview

```
CP0 → Event Enrichment     (web-first, pre-KB scan)
CP1 → Event Parse          (field extraction)
CP2 → Family Activation    (KB coverage check — event types)
CP3 → Entity Fetch Plan    (KB coverage check — COMBOs + principles)
CP3.5 → Client Mapping     (data query — client DB)
CP4 → Data Extract         (data queries — all sources)
CP5 → Insight Assembly     (KB coverage check — solutions)
       + KB-GAP routing
```

---

## How to Run

### Step 1 — Read this file first (you are here)
### Step 2 — Read each CP file in order as you execute that step

| Step | Read file | Then do |
|---|---|---|
| CP0 | `CP0-ENRICHMENT.md` | Run web enrichment, build ENRICHMENT BLOCK |
| CP1 | `CP1-EVENT-PARSE.md` | Extract event fields |
| CP2 | `CP2-FAMILY-ACTIVATION.md` | Run KB coverage checks, activate families |
| CP3 | `CP3-ENTITY-PLAN.md` | Build entity fetch queue |
| CP3.5 | `CP3.5-CLIENT-MAPPING.md` | Query client DB, return impacted clients |
| CP4a | `CP4-DATA-EXTRACT.md` | One-line data fetch trace per source — 8-step fetch sequence (Client DB → Tariff DB → Country DB → Commodity DB → KB COMBO → KB Country → Web Search → R1 queue); always follow order |
| CP4b | `CP4-DATA-EXTRACT.md` | Per-client insight card (the deliverable — MD → HTML) |
| CP5 | `CP5-INSIGHT-ASSEMBLY.md` | Assemble run summary + render HTML output (air8-kb-intel style) + KB-GAP routing |

---

## State Object

Carry this JSON state object across all checkpoints. Populate each field as you complete the corresponding CP:

```json
{
  "run_id": "[uuid]",
  "event_text": "[raw input]",
  "validator_id": "[who is validating]",
  "run_mode": "step",

  "cp0_enrichment": {
    "open_signals": [],
    "principle_enrichment": [],
    "kb_gaps": []
  },

  "cp1_parsed": {
    "supplier_country": "",
    "buyer_geo": [],
    "product_category": { "primary": "", "downstream": [] },
    "material": "",
    "supplier_tier": "",
    "company_type": "",
    "event_mechanism": ""
  },

  "cp2_families": {
    "activated": [],
    "cluster_match": null,
    "kb_gaps": []
  },

  "cp3_entities": {
    "fetch_queue": [],
    "principle_checks": [],
    "combo_checks": [],
    "kb_gaps": []
  },

  "cp3_5_clients": {
    "impacted": [],
    "total": 0,
    "data_source": ""
  },

  "cp4_data": {
    "extracted": [],
    "kb_gaps": []
  },

  "cp5_insights": {
    "signals": [],
    "multi_signal": [],
    "client_actions": [],
    "kb_expansion_flags": []
  },

  "kb_expansion_flags": []
}
```

---

## Validation Mode (run_mode: "step")

At each CP:
1. Execute the step fully
2. Format output as a Telegram message (see CP output formats)
3. Send message and WAIT for validator response
4. On ✅ confirm → proceed to next CP
5. On ✏️ adjust → accept correction, re-run current CP with correction injected
6. On ⏭️ skip → accept output as-is, proceed

Never proceed to the next CP without a validator confirmation (in step mode).

---

## Output Format Rules

Each CP message must include:
- `📥` input summary (one line)
- `🧠` reasoning / source check log
- `📤` structured output block
- Validation buttons: `✅ Confirm | ✏️ Adjust | ⏭️ Skip`

Label every data point clearly:
- `✅ HIT` — KB coverage found
- `❌ MISS` — KB coverage not found → [KB-GAP 🚩]
- `[VERIFIED ✅]` — data confirmed from source
- `[LIVE 🔄]` — live data, may change
- `[STALE ⚠️]` — data older than 90 days
- `[HYPOTHESIS 💭]` — inferred, not directly stated
- `[PROXY]` — closest available substitute used
- `[KB-GAP 🚩]` — gap flagged for KB Expand

---

## KB-GAP Routing (end of CP5)

After CP5 is confirmed:
1. Compile all `kb_expansion_flags` accumulated across all CPs
2. Group by priority: HIGH / MEDIUM / LOW
3. For HIGH priority: immediately trigger KB Expand flow → Expert Review
4. For MEDIUM: add to KB Expand queue
5. For LOW: log only

---

## Data Source Reference

See `DATA-SOURCE-MAP.md` for the full source priority chain per data point.
See `AGENT-REQUIREMENTS.md` for tool requirements and TBD source slots.

---

## KB Files Referenced (read access required)

| File | Used at |
|---|---|
| `layer-1-reasoning/EVENT-TYPES.md` | CP1, CP2 |
| `layer-1-reasoning/PRINCIPLES.md` | CP2, CP3, CP5 |
| `layer-1-reasoning/EVENT-CLUSTERS.md` | CP2 |
| `layer-1-reasoning/REASONING-FLOW.md` | CP3 |
| `layer-1-reasoning/SOLUTIONS.md` | CP5 |
| `layer-2-entities/personas/COMBO-*.md` | CP3 |
| `layer-1-reasoning/pain-points/compliance/*.md` | CP4 |
| `layer-1-reasoning/compliance/**/*.md` | CP4 |
| `layer-2-entities/countries/*.md` | CP4 |
| `layer-2-entities/product-categories/*.md` | CP4 |

---

*Skill version: 0.3*
*Last updated: 2026-08-03*
*Owner: Jerri / Air8 KB team*
