# L1-compliance-gap-method.md — KB Gap Identification and Filling Protocol

**Purpose:** The meta-layer. How to identify gaps in the compliance KB, classify them, and fill them systematically. This ensures the KB improves over time rather than accumulating silently wrong or missing assessments.

---

## Two Types of Gaps

Every gap encountered during a client assessment falls into one of two types. The distinction is critical because the remedy is entirely different.

### Type A — Missing Knowledge
**Definition:** The KB has no rule for a situation. The agent cannot determine whether a regulation applies because the rule itself is not encoded.
**Examples:**
- "Does REACH Annex XVII Entry 63 (nickel restriction) apply to metallic ink printed on a ceramic surface?"
- "Does the EU PFAS restriction apply to a polytetrafluoroethylene (PTFE) non-stick coating on a cast iron pan if it is sold as decorative cookware?"
- "Is a battery-powered LED candle an 'electrical and electronic equipment' under RoHS if the battery is removable and the circuit is sealed?"

**Root cause:** KB hasn't been updated to cover this substance/product-category intersection, or the regulation has changed since KB was last updated.
**Fix:** Identify authoritative source → draft rule → expert review → add to KB.

### Type B — Missing Data
**Definition:** The KB has the rule, but the agent cannot apply it because required data about the specific client/product is not available.
**Examples:**
- "REACH Article 33 applies to articles with >0.1% SVHC. Rule is clear. But we don't have the BOM for this client's product."
- "UFLPA supply chain check requires Tier 2 supplier list. Client has not provided it."
- "Buyer RSL test requires a physical sample. No sample has been submitted to lab."

**Root cause:** Data not yet collected, or not collectible without external input (client, lab, third party).
**Fix:** Identify who holds the data → request it → flag as pending → resume assessment when received.

---

## Gap Identification Process

Run this at every CP (compliance checkpoint) step during a client assessment.

### Step 1: Run CP0–CP4 for the Client
Complete each checkpoint in sequence per the compliance scope module (L1-compliance-scope.md) and interpretation module (L1-compliance-interpretation.md).

### Step 2: At Each CP, Document Every "Cannot Determine Because..."
When an assessment step stalls, do not skip it silently. Record the blocker explicitly:
```
Cannot determine [specific regulatory applicability] because:
  → [missing rule] (Type A) OR [missing data: what data, from whom] (Type B)
```

### Step 3: Classify the Gap

```
Is the rule for this situation encoded in the KB?
  NO  → Type A (knowledge gap)
  YES → Is the required data available to apply the rule?
          NO  → Type B (data gap)
          YES → NOT a gap — this is an assessment error; re-run the step
```

### Step 4: For Type A — Draft the Rule

1. Identify the authoritative source that resolves the ambiguity:
   - Regulatory text (EUR-Lex, ECHA guidance documents, CPSC guidelines)
   - ECHA technical guidance (e.g., "Guidance on requirements for substances in articles")
   - Case law / CJEU decisions relevant to scope
   - Expert interpretation (Jerri or designated compliance expert)

2. Draft the rule in the KB format:
   - Condition: [product/substance/market combination]
   - Rule: [regulation applies / does not apply] because [specific reasoning + citation]
   - Threshold: [if applicable]
   - Exception: [if applicable]
   - Source: [citation with URL or document reference]

3. Flag for expert review before adding to KB (see KB Update Protocol below).

### Step 5: For Type B — Identify Data Holder and Collect

```
Who holds this data?

Internal (Air8 systems)?
  → See DT/DT-internal-data-map.md for available data sources
  → Pull from Air8 financing records, inspection data, customs history
  → If available: pull and proceed

Client?
  → Draft data request to client (specific document name, format, what it must contain)
  → Flag assessment as PENDING until received
  → Set follow-up: 5 business days

External paid source?
  → Assess: what is the cost? What confidence improvement does it provide?
  → If cost > benefit: document rationale for not collecting and proceed with reduced confidence
  → If cost ≤ benefit: flag for human approval before purchasing
  → Human approval required before any paid external data source is added to KB or procured

Not collectible (no data exists)?
  → Document as structural data gap
  → Proceed with explicit uncertainty disclosure in assessment output
  → Do NOT fabricate or estimate without flagging
```

---

## Data Source Decision Tree

```
Q: Do we need this data for an accurate compliance assessment?
│
├─ NO → Document why it is not needed. Avoid data debt. STOP.
│
└─ YES
    Q: Is it available internally in Air8 systems?
    │  (See DT/DT-internal-data-map.md for available internal sources)
    │
    ├─ YES → Pull from Air8 data (financing records, inspection reports, customs filings, QC docs)
    │         Proceed with assessment.
    │
    └─ NO
        Q: Is it data that only the client can provide?
        │
        ├─ YES → Draft specific data request to client
        │         Request: [document name, what it must include, acceptable format]
        │         Set: 5 business day follow-up
        │         Flag assessment as: PENDING_CLIENT_DATA
        │         Do not estimate or assume — wait for actual data.
        │
        └─ NO — it's from a paid external source
            Q: What is the cost vs. accuracy improvement?
            │
            ├─ Cost is low AND accuracy improvement is significant → Flag for human approval
            │   (Human must authorize before any paid source is subscribed to or purchased)
            │
            └─ Cost is high OR accuracy improvement is marginal → Document rationale
                Proceed with explicit uncertainty disclosure
                Log as structural limitation in KB
```

---

## Gap Queue Format

Each gap identified during a client assessment must be logged. Use this exact format:

```
GAP-ID: [auto-assigned: GAP-YYYY-MM-DD-NNN]
Type: A (knowledge) / B (data)
Triggered by: [client name / project ID] at [CP step number and description]
Description: [Precisely what was missing — quote the "cannot determine because..." statement]
Impact: [Which assessment it affects; confidence drop; what decision was deferred]
Recommended fix:
  Type A: [Authoritative source URL or document; draft rule text if possible]
  Type B: [Who holds the data; how to request it; estimated collection time]
Status: pending_review / approved_pending_addition / rejected / added_to_kb
Approved by: [Name of reviewer]
Date logged: [YYYY-MM-DD]
Date resolved: [YYYY-MM-DD or blank]
```

**Example:**

```
GAP-ID: GAP-2026-08-26-001
Type: A (knowledge)
Triggered by: Yangzhou Decor Co. / CP2 REACH Annex XVII step
Description: Cannot determine whether metallic ink containing chromium compounds
  printed on ceramic substrate triggers Annex XVII Entry 27 (chromium VI) when
  the ink is fired at 800°C during manufacturing. Firing may convert Cr3+ to Cr6+
  or may not — KB has no rule for thermal treatment effect on chromium speciation.
Impact: Cannot complete REACH Annex XVII assessment for 3 product lines.
  Confidence drop from 85% to 40% on those lines.
Recommended fix: ECHA Guidance on Annex XVII restriction entries;
  specifically check Entry 27 scope + chromium speciation guidance.
  CIRS Group has published CN-language analysis: cirs-group.com/reach/chromium.
  Draft rule after reviewing both sources. Submit to Jerri for review.
Status: pending_review
Approved by: [blank]
Date logged: 2026-08-26
Date resolved: [blank]
```

---

## KB Update Protocol

Follow this exact sequence after a gap is filled. Do not shortcut steps.

### Step 1: Draft New Rule or Data Source Entry

- For Type A: Write the new rule in KB format (condition → rule → threshold → exception → source citation)
- For Type B: Document the new data source (what data it provides, how to access it, cost, reliability rating) in DT/DT-internal-data-map.md

### Step 2: Expert Review

- Route to: Jerri (primary compliance expert) or designated reviewer
- Provide: the draft rule/entry + the original gap + the sources consulted
- Expert must: (a) confirm the interpretation is correct, (b) confirm the source is authoritative, (c) approve or modify the draft
- Do NOT add to KB without expert sign-off on Type A gaps
- For Type B data source additions: Jerri reviews; human approval required for any paid source

### Step 3: Add to KB

- Type A knowledge rule → add to the relevant L2 node (e.g., L2/NODE-compliance-product-eu.md for EU product rules)
- Type B data source → add to DT/DT-internal-data-map.md under the appropriate data category
- Update the gap record: Status → "added_to_kb", Date resolved → today's date, Approved by → reviewer name
- Update cross-links in affected L1/L2 files if new rule changes the routing or interpretation logic

### Step 4: Re-Run Affected Client Assessments

- Identify all past client assessments that were flagged with this gap (search gap log by GAP-ID)
- Re-run the specific assessment step(s) using the new rule/data
- Update the client's compliance record with revised output and confidence score
- If the revised assessment changes a recommendation (e.g., from "cannot determine" to "non-compliant") → escalate to client per L1-compliance-response.md escalation rules

### Step 5: Note Confidence Improvement

- Log the before/after confidence score for the affected assessments
- If the gap was systemic (affected multiple clients), note the broader impact
- Use this to track KB quality improvement over time

---

## KB Quality Metrics (Track These)

| Metric | Description | Target |
|---|---|---|
| Open Type A gaps | Rules missing, pending expert review | < 5 at any time |
| Open Type B gaps | Data pending from client or external | Track per client; review weekly |
| Gap resolution time (Type A) | Days from logged to added_to_kb | < 14 days |
| Gap resolution time (Type B client) | Days from request to data received | < 10 business days |
| Re-assessment completion rate | % of affected assessments re-run after gap resolved | 100% (no exceptions) |
| False positive rate | Regulations flagged as applying that expert confirms don't | Track and minimize |
| False negative rate | Regulations missed that expert identifies post-assessment | Most critical — track closely |

---

## Cross-Reference Links

- [L1-compliance-interpretation.md](L1-compliance-interpretation.md) — Where gaps are most commonly discovered (Steps 1–4 of the reasoning chain)
- [DT/DT-internal-data-map.md](../DT/DT-internal-data-map.md) — Available internal data sources before requesting from client or external
- [L2/NODE-regulatory-intelligence.md](../L2/NODE-regulatory-intelligence.md) — When the gap is due to a new regulation not yet in KB (Type A from regulatory change)

---

*Last updated: 2026-08-26 | Owner: Compliance KB*
