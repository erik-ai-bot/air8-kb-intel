# L1-regulatory-intelligence.md — Systematic Regulatory Change Tracking

**Purpose:** How to know when something new is coming. Systematic monitoring of regulatory changes, classification of alerts, and determination of whether and when client action is required.

---

## Regulatory Lifecycle Model

Every regulation passes through a predictable lifecycle. The most common error is treating a Proposal as an enforceable obligation, or missing the gap between "in force" and "applying."

```
Proposal
    ↓
Public Consultation (typically 12 weeks)
    ↓
Committee Opinion (ECHA RAC/SEAC, EU Parliament, Council)
    ↓
Trialogue / Co-decision (EP + Council negotiation)
    ↓
Adoption (Political agreement)
    ↓
Publication in Official Journal (this is "enters into force")
    ↓
Entry into force date (usually 20 days after OJ publication)
    ↓
"Shall apply from" date (enforcement start — often 12–24 months after entry into force)
    ↓
Derogation / transition period end (specific exemptions sunset)
    ↓
Full enforcement
```

### CRITICAL DISTINCTION: "Enters into Force" ≠ "Shall Apply From"

These are two different legal events. Confusing them is one of the most common errors in compliance reporting.

| Event | Legal Meaning | Practical Meaning |
|---|---|---|
| "Enters into force" | Regulation legally exists. Cannot be changed without repeal procedure. | Obligated parties should begin preparing, but enforcement has not started |
| "Shall apply from" / "applies as of" | Enforcement begins. Non-compliance is actionable by market surveillance authorities | THIS is the compliance deadline for clients |
| "Derogation end" | A specific exemption within the regulation expires | Specific product/substance loses its exemption on this date |

**Example — GPSR:**
- GPSR (EU) 2023/988 published in Official Journal: **June 15, 2023** → entered into force
- GPSR applies from: **December 13, 2024** — 18-month gap between legal existence and enforcement
- Implication: Companies had 18 months to prepare. Shipments to EU after December 13, 2024 require full GPSR compliance.

**Example — PFAS restriction in textiles (Annex XVII):**
- Expected application date for textile PFAS restriction: **October 2026** (verify in current OJ)
- Entry into force was earlier; but products only need to comply from October 2026

**Always note both dates for every regulation in client files.**

---

## Source Registry

### Tier 1 — Official Primary Sources (Check Weekly)

These are authoritative. If a Tier 2/3 source contradicts Tier 1, Tier 1 wins.

| Source | URL | What to Monitor | Frequency |
|---|---|---|---|
| ECHA Candidate List | echa.europa.eu/candidate-list-table | New SVHC additions | Every 6 months (June + December) but check monthly for intention registry |
| ECHA SVHC Intention Registry | echa.europa.eu/registry-of-svhc-intentions | Substances under assessment before formal listing (6–12 months early warning) | Monthly |
| EUR-Lex Official Journal | eur-lex.europa.eu → OJ (L series) | All EU regulations: text, entry into force date, application date, corrigenda | Weekly (automated RSS available) |
| EU Safety Gate (RAPEX) | ec.europa.eu/safety-gate | Weekly product alerts by category; shows enforcement pattern and frequency of recalls | Weekly (subscribe to weekly digest) |
| DHS UFLPA Entity List | dhs.gov/uflpa-entity-list | New entity additions — can be sudden | Monthly minimum; subscribe to DHS alerts |
| CPSC Regulations & Laws | cpsc.gov/Regulations-Laws | New rules, recalls, proposed rules (NPRMs), final rules | Weekly |
| California OEHHA Prop 65 List | oehha.ca.gov/proposition-65/proposition-65-list | New substance listings, NSRL/MADL updates | Quarterly (major updates) but check monthly |
| UK REACH Candidate List | hse.gov.uk/reach/candidate-list.htm | UK-specific SVHC (diverges from EU post-Brexit) | Every 6 months |

**RSS/alert setup (recommended):**
- EUR-Lex: `https://eur-lex.europa.eu/oj/daily-view/L-series/browse.html` — subscribe to daily OJ alerts filtered by keyword (REACH, GPSR, RoHS, textiles)
- Safety Gate: weekly digest email subscription at ec.europa.eu/safety-gate
- CPSC: cpsc.gov/Newsroom → subscribe to recall alerts by product category

---

### Tier 2 — Curated Interpretation Services (Check on New Alerts)

Use these to understand what a Tier 1 development means for Chinese exporters. Do NOT use as primary source without verifying against Tier 1.

| Source | Strength | Access |
|---|---|---|
| CIRS Group (cirs-group.com) | China exporter perspective; bilingual EN+CN; strong on REACH, food contact, cosmetics | Free newsletter + paid reports |
| REACH24H (reach24h.com) | REACH specialist; detailed substance analyses; SVHC deep dives | Free newsletter + paid compliance reports |
| SGS Safeguards newsletter | Weekly; sorted by product category; strong on consumer products, toys, textiles | Free subscription at sgs.com |
| Eurofins regulatory news | Strong on PFAS, food contact, environmental; EU-centric | Free newsletter |
| TÜV SÜD compliance briefs | EU enforcement cases; useful for understanding how authorities interpret rules | Free; tuvsud.com/en/services/regulatory-compliance |
| Intertek regulatory news | US+EU combined; strong on CPSC, ASTM, EN standards | Free; intertek.com/regulatory |
| AAFA (American Apparel & Footwear Assoc) | Apparel-specific US trade + compliance; tariff + forced labor focus | Member-only for full access; some public summaries |
| AHFA (American Home Furnishings Alliance) | Home goods, furniture; TSCA, CARB, CPSC focus | Member-only |
| HPVA (Hardwood Plywood & Veneer Assoc) | Composite wood, formaldehyde, TSCA | Member-only |

**How to use Tier 2:**
1. Tier 1 alert comes in (e.g., new SVHC listed)
2. Search CIRS/REACH24H for analysis: "what does this mean for Chinese manufacturers?"
3. Cross-check their interpretation against Tier 1 text
4. If consistent → use their client-friendly explanation as basis for client communication
5. If inconsistent → flag for expert review; do NOT relay the Tier 2 interpretation without verification

---

### Tier 3 — Early Warning Sources (6–12 Months Ahead)

These provide advance notice of what WILL be regulated. Use to warn clients about upcoming requirements, not current ones.

| Source | What It Shows | Lag Before Formal Action |
|---|---|---|
| ECHA SVHC Intention Registry | Substances that member states or ECHA intend to propose for SVHC listing | 6–18 months before formal Candidate List addition |
| EU Commission "Have Your Say" portal (ec.europa.eu/info/law/better-regulation) | Open public consultations on proposed regulations | 12–24 months before final publication |
| MSC (Member State Committee) meeting minutes | Decisions on SVHC proposals, restriction proposals; published after each meeting | 3–6 months before formal listing |
| CARACAL meeting documents | Advisory committee on REACH/CLP; discusses upcoming restrictions before formal proposal | 6–18 months ahead |
| ECHA RAC/SEAC opinions | Scientific committee opinions after dossier review; signals likely restriction adoption | 6–12 months before OJ publication |
| European Parliament plenary agendas | Scheduled votes on pending regulations | 1–3 months before formal adoption |

**Practical use of Tier 3:**
- When a substance appears in SVHC Intention Registry: advise client to begin BOM screening NOW so they know exposure before the listing occurs. If substance is found in their products, they have time to reformulate before the listing triggers Article 33 obligations.
- When a new restriction proposal enters consultation: calculate likely application date (consultation → committee → OJ → application = typically 2–4 years). Flag to client if their product category is in scope.

---

## How to Judge a Regulatory Alert

When any alert comes in (news article, newsletter, Tier 2 source, client query), immediately classify it:

### Classification Framework

**STAGE 1 — Proposal/Consultation**
- Keywords: "proposed", "under review", "public consultation", "draft regulation", "Commission proposal", "ECHA dossier submitted"
- Action: Add to monitoring log. Note substance/product category and likely timeline. **No client action required yet.**
- Example: "ECHA proposes adding [substance] to SVHC Candidate List" → Stage 1

**STAGE 2 — Adopted (Not Yet Applying)**
- Keywords: "published in Official Journal", "Regulation (EU) XXXX/XXX of [date]", "entered into force", "signed into law"
- Action: Note BOTH the entry into force date AND the application date. Calculate time to compliance deadline. Flag to clients in scope with timeline. **Begin preparation, not enforcement compliance.**
- Example: "GPSR published in OJ June 2023, applies December 2024" → Stage 2 from June 2023 to December 2024

**STAGE 3 — In Force and Applying**
- Keywords: "has applied since", "shall apply from [past date]", "is now in effect", "enforcement has begun"
- Action: Immediate assessment. Identify clients whose products are in scope. For each: run compliance assessment, trigger response playbook (L1-compliance-response.md). **Full compliance required now.**
- Example: GPSR after December 13, 2024 → Stage 3

**STAGE 4 — Derogation/Transition Ending**
- Keywords: "derogation expires", "transitional period ends", "with the exception of... until [date]", "exemption lapses"
- Action: Calculate exact date. Identify clients relying on derogation. Plan reformulation/compliance before deadline. **Hard deadline — no grace after expiry.**

---

### Red Flags in Alert Text — Urgent Classification Triggers

When you see these phrases in any regulatory source, immediately escalate to Stage 3 assessment:

| Red Flag Phrase | Why It Matters |
|---|---|
| "enters into force immediately" / "with immediate effect" | No transition period; enforcement starts from OJ publication date |
| "without transitional period" | Products must comply instantly; no runway for existing stock |
| "applies to articles" | Product obligation, not just manufacturing process; entire supply chain affected |
| "presumption of non-compliance" | Burden of proof reversal (UFLPA model); importer must prove innocence |
| "total ban" / "prohibition on placing on the market" | Annex XVII-style hard ban; do NOT ship |
| "emergency measure" / "Article 13 GPSR" | Fast-track safety ban; can apply within days |
| "recalls ordered" | Enforcement already underway; CBP/MSA actively checking |

---

## Monitoring Cadence

### Weekly Tasks
- [ ] EU Safety Gate / RAPEX weekly digest — scan for product categories relevant to current client portfolio
- [ ] CPSC recall database — scan for product categories
- [ ] EUR-Lex OJ daily L-series — scan headlines for REACH, RoHS, GPSR, textiles, toys keywords
- [ ] SGS Safeguards newsletter — scan and flag relevant items

### Monthly Tasks
- [ ] ECHA SVHC Intention Registry — new intentions added since last check
- [ ] DHS UFLPA Entity List — new additions
- [ ] California OEHHA Prop 65 — quarterly major updates; monthly minor checks
- [ ] UK REACH Candidate List — check for UK-specific additions diverging from EU
- [ ] CPSC Federal Register notices — proposed rules, final rules

### Bi-Annually (June and December — Aligned with ECHA Update Cycle)
- [ ] Full ECHA Candidate List review — compare to previous version, identify all new SVHCs
- [ ] Cross-reference new SVHCs against active client product BOMs
- [ ] Update internal SVHC tracker for all clients with confirmed/suspected presence
- [ ] Check ECHA SVHC Annex XIV (authorization list) updates — substances approaching sunset date

### Ad Hoc Triggers
- Client requests compliance update for specific product/market → immediate full scan
- Breaking news about ban, recall, or enforcement action → immediate Stage 1/2/3 classification
- Air8 onboards new client in new product category → new category monitoring set up
- Buyer sends updated RSL → immediately compare to previous version, flag new substances

---

## Cross-Reference Links

- [L2/NODE-regulatory-intelligence.md](../L2/NODE-regulatory-intelligence.md) — Detailed source database with subscription details, specific URLs, historical alert archive
- [L1-compliance-gap-method.md](L1-compliance-gap-method.md) — When a regulatory alert reveals a knowledge gap in the KB

---

*Last updated: 2026-08-26 | Owner: Compliance KB*
