# L1 · Adverse news — severity ladder and protocol

## Search surface

Per name, search all five: the **entity**, its **parent or controlling shareholders**, its **named directors**, its **plant locations**, and any **brand or trading name** it operates under. A finding against a parent is a finding.

## Severity ladder

| Verdict | Includes |
|---|---|
| **CRITICAL** | Sanctions listings; forced-labour findings (UFLPA entity list, CBP WRO); fraud convictions; insolvency or winding-up filings; debarment by a development bank |
| **MATERIAL** | Criminal proceedings, **including ones resolved in the company's favour where the allegation itself is undisclosed**; tax or regulatory demands not provided for in the accounts; unscreened shareholders with adjacency to a distressed group; unresolved regulatory appellate files; ownership transfers pending competition clearance where the buyer is unscreened |
| **MINOR** | Resolved or historic matters; a single-site environmental fine; a labour report on a plant since closed; civil disputes in the ordinary course |
| **CLEAN** | Searched, nothing found. **State which sources you searched** — an unqualified "clean" is not auditable |
| `NOT SCREENED` | Not yet searched. Legitimate; blankness is not |

## Sources that have actually produced findings

- **National court records** — Lahore High Court writ petitions, Indian NCLT/NCLAT, provincial high courts
- **Provincial and municipal environmental decisions** — a Vietnamese People's Committee decision fined a plant VND 320mn for operating without an environmental permit and suspended the source for 4.5 months
- **Regulator appellate files** — SECP, SEBI; an unretrieved file is a MATERIAL flag, not a null
- **OpenSanctions** — mirrors the UFLPA dataset; plus CBP WRO and UFLPA entity lists directly
- **The company's own annual report contingencies note** — where unprovided-for demands hide. Read it before searching the press
- **The parent's material-events index** (HKEX / NEEQ filings) — a ticked "NO" against litigation, penalties, dishonesty listings, guarantees and pledges is auditable evidence of absence, which is stronger than silence
- **Labour-monitoring NGOs** — with a date check: a 19-year-old report on a plant that has since closed is MINOR, not MATERIAL
- **Accord / ITUC signatory lists** — presence is a positive, and tells you which brands audit the site

## Writing the finding

State what happened, when, the forum, the outcome, and what is still open. Then state what would change the verdict — "full disclosure of the FIR allegation plus provisioning for the pending demands" is actionable; "monitor" is not.

Record the **date of the search**. An adverse screen is perishable.
