# L1 · DB field contract — what the agent needs, and from where

The agent computes indicators **from the DB** and reads rules and judgements **from the KB**. This file is the boundary. If a field is derivable from the DB it must not be stored in the KB, or the two will disagree and nobody will know which is stale.

## Derived from the DB, never stored in the KB

| Indicator | DB source | Derivation |
|---|---|---|
| `act_months` | shipment / invoice rows | count of **distinct months with at least one row in the trailing 12** (max 12) |
| `shipments_12m` | shipment / invoice rows | row count, trailing 12 months |
| `shipments_prior_12m` | same | row count, months 13–24 back |
| `yoy_growth` | the two above | `(n12 − n24) / n24`; null when `n24 = 0`, never 0 |
| `n_buyers` | buyer field | distinct buyers in the trailing 12; floor of 1 |
| `density` (apparel) | above | `shipments_12m / n_buyers / act_months` |
| `cadence` (hardgoods v2.1) | above | `shipments_12m / act_months` |
| `product_count` (hardgoods v3.0) | product description | distinct descriptions in the flow. **Censored at 10 by the source field** |
| `avg_invoice_usd` | invoice value | mean over the trailing 12 |
| `hs_codes` | commodity code | distinct 4-digit prefixes |
| `last_txn_date` / `months_since_target` | shipment rows filtered to the target buyer | for the apparel flow-stale gate |
| `target_buyer_share` | shipment rows | that buyer's share of trailing-12 rows |

**The trailing-12 window is load-bearing.** Both frameworks band on months-out-of-12; a 24-month window makes `≥10` meaningless. Any query touching this must state its window in a comment.

## Held in the KB — reasoning and types only

| Field | Layer | Why it is not DB data |
|---|---|---|
| Thresholds, weights, tier cuts | L1 | Decisions, not observations |
| Severity ladders, need angles, evidence rules | L1 | Judgement protocols |
| Actor types and their features | L2 | Type-level knowledge: what a trading house *is*, what a dead programme *implies* |
| Relationships between types and what each edge implies | L2 | The reasoning that turns two facts into a finding |
| Category durability rates | L2 | Measured once on the book, then reused as knowledge about the type |

**Individual entities are never KB content.** A named buyer, supplier, factory or brand is a DB row. The KB says what *kind* of thing it is and what that kind implies.

## Enrichment the agent writes back to the DB

Research findings are per-entity, so they are **DB fields, not KB files**. The DB needs somewhere to put them:

| Field | On | Notes |
|---|---|---|
| `registration_no`, `lei`, `legal_form` | supplier | resolves ambiguous name strings; authoritative join key |
| `entity_status` | supplier | resolved / unresolved-parked / duplicate-of |
| `adverse_verdict`, `adverse_finding`, `adverse_reopen_if`, `adverse_search_date` | supplier | CRITICAL / MATERIAL / MINOR / CLEAN / NOT SCREENED — never blank |
| `need_band`, `need_evidence`, `need_as_of` | supplier | band is useless without the figures |
| `contact_name`, `contact_title`, `contact_email`, `contact_phone`, `contact_source_url`, `contact_date` | supplier | `NOT FOUND` where nothing is published |
| `supplier_type` | supplier | the L2 type this row was classified as |
| `relationship_tags` | supplier | own book / affiliate; never a scoring input |
| `buyer_confidence`, `action_tag` | supplier × buyer | CONFIRMED … CONTRADICTED; ANCHOR / LEAD WITH THIS / CROSS-SELL / WARNING |
| `programme_status`, `status_basis`, `status_as_of` | buyer | ALIVE / DYING / DEAD — the field that turns absence of rows into a real answer |

Seed data for the last two rows, from work already done, is staged in [../_to_db/](../_to_db/).

Every one of these fields carries a **date**, because all of them perish.

## Join keys

1. **Registration number** where available (CIN, NTN, USCC, company number, LEI). Authoritative
2. **Normalized name** otherwise: uppercase, strip punctuation, strip legal suffixes (`PRIVATE LIMITED`, `PVT LTD`, `CO LTD`, `INC`…) and industry words (`TEXTILE`, `GARMENTS`, `INDUSTRIES`, `GROUP`, `EXPORTS`…), collapse whitespace
3. **Bracketed aliases must be expanded** before matching — split on `(`, `/`, `,` and match each fragment. `Crown Textile (Crown Tex / CT Group)` matches nothing without this
4. Drop keys shorter than 3 characters. After suffix-stripping, `CT Group` becomes `CT`, and two-character keys generate false positives

Normalized-name joins are **probabilistic**. Two unrelated companies have already collided on a shared brand word and a shared postcode. Any join that carries a financial or adverse fact must be confirmed against a registration number first — see [L1-evidence-discipline.md](L1-evidence-discipline.md).

## Data-quality checks the agent runs before scoring

| Check | Action on failure |
|---|---|
| Duplicate entities after normalization | Report both rows and their scores; de-duplicate before ranking |
| No HS codes and no usable product text | **Enrichment queue, not a score of zero** |
| Missing any scored component | Enrichment queue, with the missing component named |
| `n24 = 0` | Growth is null, not 0 or Declining |
| Target buyer absent from the supplier's rows | Flag; the relationship may be a name collision |

Missing data is a to-do, not a verdict. A score of zero asserts something; a null asserts nothing, which is usually the truth.

## The filtering result the agent writes back

One row per supplier: `supplier_name`, `vertical`, `framework` (with version), each component's points, `score`, `score_out_of`, `score_pct`, `tier`, `queue`, gates applied, region, relationship tags, and the free-text `notes` that explains every deviation.

**`score` is not comparable across frameworks** — apparel is out of 11, hardgoods v3.0 out of 15, hardgoods v2.1 out of 11. Rank within a vertical, or compare `tier` / `score_pct`. A mixed-vertical batch ships as two lists.
