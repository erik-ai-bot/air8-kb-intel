# L1 · Evidence Standards

What counts as evidence, how to rank it, and how to retain it.
No specific triggers or rules — those are in layer2. No procedural steps — those are in the skill.
This file defines the principles the agent applies when evaluating proof at any point in the reasoning.

---

## Evidence Strength Ranking

When multiple evidence types are available, rank by strength. The highest-ranked evidence available governs the decision.

| Rank | Type | Notes |
|------|------|-------|
| 1 | Buyer written confirmation (email, portal export) | Direct — strongest proof of buyer intent |
| 2 | BD written confirmation (email or Teams message) | Internal — accepted as commercial relationship evidence |
| 3 | System-generated document (portal export, API record, Transcepta, Ariba) | Trusted system origin — equivalent to written confirmation for format exceptions |
| 4 | Carrier/forwarder verification | Third-party operational confirmation |
| 5 | Packing list / customs cross-reference | Documentary linkage — indirect but auditable |
| 6 | Supplier written confirmation | Lowest — self-asserted; always requires corroboration from Rank 1–4 |

> Supplier-only confirmation (Rank 6) is **never sufficient alone** for HIGH-risk nodes (R4–R9). Always require at least one corroborating source.

---

## Evidence Retention

All evidence must be:
- Stored in the **SHI folder** for the supplier-buyer pair
- Referenced by date and source in the FR record
- Retained for audit — not discarded after release

This applies even for AUTO-PASS decisions. Auto-pass is a pre-approved path, not an evidence waiver.

---

## Evidence Gaps

If required evidence is not available:

- For MEDIUM risk (R1–R3): hold the FR; request evidence from BD or buyer before releasing
- For HIGH risk (R4–R9): escalate to G4; G4 decides whether to release on partial evidence
- For HARD-STOP: do not release regardless of partial evidence

Do not approximate or infer evidence. If evidence is missing, say so explicitly and state what is needed.

---

## What Does Not Count as Evidence

- Verbal/phone confirmation (not on record)
- "Common practice" or "previous releases did this" without documented approval
- Agent's own judgment that the exception "looks reasonable"
- Prior FR approvals without an explicit SHI or approval on file for the current exception

---

## Citing Evidence in Output

When producing a decision, cite evidence as:
`[Source type · Date · Person/System]`

Example: `[BD email · 2026-08-01 · Pranav]` or `[Buyer portal export · Transcepta · 2026-07-15]`

This makes decisions auditable and rerunnable. A decision without a citation is provisional.
