# L1 · Evidence discipline

The rules that make every other file trustworthy. They are short, and they are not negotiable.

## 1 · Never invent a contact

Only what the company itself, an annual report, a regulator filing or a reputable directory publishes. **No email constructed from a name pattern**, however obvious the convention looks. No phone number assembled from a switchboard plus a guessed extension. No personal home addresses, no personal mobiles, no personal social accounts.

If the finance contact is not published, the record reads `NOT FOUND` and still ships. **A named CFO with no email is more useful than an invented address** — BD can find a route to a named person; they cannot recover from a mail that reaches a stranger.

Where nothing at all is published, name the route that would work instead: a warm introduction through an existing group relationship, the trade body that lists them, the buyer's own sourcing office, or a field visit already scheduled. *"No published finance contact — needs a warm introduction"* is actionable. A blank cell is not.

**Contact priority:** CFO / finance director / GM Finance → company secretary or authorised representative → published switchboard and general mailbox → IR adviser → legal representative or partner. Record for each: name, exact title, why them in one phrase, email, phone, source URL, date found. Note when the legal representative is the only named person, because that changes a call into an introduction.

## 2 · Absence of evidence is not evidence of absence

Write which one you have, every time. `NOT SCREENED` means nobody has looked. `CLEAN` means someone looked, and it must say **where** — an unqualified "clean" is not auditable. *"Every Chinese register blocked automated access"* is a real, reportable state and belongs in the deliverable.

## 3 · Resolve the entity before attaching anything to it

Three failure modes, all observed:

- **Different companies sharing a name.** Two Karachi textile firms shared a brand word and a postcode, were entirely unrelated, and a PKR 451mn FY25 loss was nearly attributed to the wrong one
- **The buyer's list names a third entity.** A buyer's tier list may name a similarly-named company from a different group. Where the buyer's list and the supplier's own disclosure disagree, flag `CONTRADICTED` and name the two conflicting sources — do not pick the more convenient one
- **The same company twice in one list.** Different supplier codes, punctuation variants (`CENTURY APPARELS LTD` vs `CENTURY APPARELS PRIVATE LIMITED,` with a trailing comma), two different scores — 8 and 4

**Resolution order:** registration number from a national register (MCA, SECP, Companies House, USCC, GLEIF LEI) → registered address against the shipping address → directors or controlling shareholders → the company's own site checked for its registration number. If two of the four disagree, the entity is **unresolved → parked, not scored.** A score on an unidentified company is false precision.

## 4 · Buyer evidence has grades, and they matter

| Label | Means |
|---|---|
| `CONFIRMED` | Audited disclosure or a buyer-side factory list |
| `CONFIRMED (self-disclosed)` | The company says so, unaudited or undated |
| `CONFIRMED (our data)` | Our own transaction records |
| `OUR DATA ONLY` | Customs or internal data, unconfirmed externally |
| `PARTIAL - may have lapsed` | Evidence exists but is stale |
| `NOT CONFIRMED` | The relationship we were told about cannot be found |
| `CONTRADICTED` | The supplier's own disclosure conflicts with the buyer's list — probable name collision |

Sources, best first: audited top-five-customer disclosure (exact percentages) → IPO prospectus → bills-of-lading counts (good for ranking, unreliable for share, blind outside the US) → the company's own client logos → buyer-published factory lists.

**Intermediaries are not brands.** A 26% "customer" that is a Hong Kong sourcing agent or vendor-of-record is not the brand you underwrite. Name the end brand behind it. Getting this wrong turns a diversified supplier into a concentrated one, or the reverse.

## 5 · The target buyer is often not the biggest

Check before writing any call opener. Observed cases where the real anchor was someone else: Carter's, American Eagle, AEO/Talbots, Aldi at 65%, M&S at 76%. Two consequences: the call opens on the **anchor**, not the buyer whose list you were handed; and some names are **cross-sell** candidates for a different programme entirely.

Action tags: `ANCHOR` (largest) · `LEAD WITH THIS` (most financeable, whether or not largest) · `CROSS-SELL` (belongs to another programme) · `WARNING`.

`WARNING` covers **related-party receivables**: a supplier whose largest counterparty is its own UK parent or a Singapore affiliate has intra-group receivables that may be unfinanceable. Three such cases appeared in one batch of twenty. This is a structural bar, not a pricing question, and it is invisible unless you look at the group.

## 6 · Date everything perishable

Ratings, adverse screens, contacts, buyer relationships. An adverse screen with no date cannot be relied on and cannot be refreshed intelligently.
