---
type: compliance
id: COMP-THREE-LINES
---
# COMP-THREE-LINES: Three Lines of Defence Model

| Line | Owner | Role |
|------|-------|------|
| **1st Line** | Business / Operations | KYC screening, due diligence, transaction monitoring |
| **2nd Line** | Risk + Compliance | Policies, risk assessment, regulatory oversight |
| **3rd Line** | Internal Audit | Independent process checks |
