---
type: compliance
id: COMP-KYC
---
# COMP-KYC: Know Your Customer Process

## Documents Required
- Certificate of incorporation
- Board resolution authorizing Air8 facility
- UBO declaration (>25% ownership)
- Bank account details (verified)
- Financial statements (2–3 years)
- Sanctions screening result
- Field survey report (for Lane B/C)

## Special Rules
- OPS-KYC-002: Third-party account prohibition — cannot pay to unrelated entities
- CN entities: SSQ (上上签) e-signature required
- Annual KYC refresh required

## Related
[[COMP-SANCTIONS]]
