---
type: pain-point
id: PP-REG-TARIFF-001
---
# PP-REG-TARIFF-001: US Tariff Escalation

## Description
US imposed 50% tariffs on Indian apparel (Aug 2025). China tariffs already high (25–50%). Bangladesh facing potential post-LDC EU tariff exposure.

## Impact Chain
```
EVENT: New tariff imposed on sourcing country
→ IMPACT-1: Buyer's landed cost increases → demands price reduction from supplier
→ IMPACT-2: Supplier margin compressed → PP-002 amplified
→ IMPACT-3: Buyer begins sourcing from alternative country → supplier loses orders
→ IMPACT-4: Industry-wide supply chain reconfiguration (China+1 shifts)
→ IMPACT-5: Air8 portfolio shifts geographically → insurance re-mapping needed
```

## Affected Combos
- [[../personas/COMBO-004-china-medium-woven]]
- [[../personas/COMBO-014-india-small-woven]]
- [[../personas/COMBO-003-india-large-vertical-integrator]]

## Regulation Reference
[[../regulations/REG-TARIFF]]
