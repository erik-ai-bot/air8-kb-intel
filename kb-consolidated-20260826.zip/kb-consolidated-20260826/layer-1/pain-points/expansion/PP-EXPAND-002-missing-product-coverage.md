---
type: pain-point
id: PP-EXPAND-002
---
# PP-EXPAND-002: Missing Product Coverage

## Description
Client only uses ARP (post-shipment) but has pre-shipment capital need, or no cash flow forecasting tool.

## Trigger
`financing = already_Air8 AND products_used = [ARP_only]`

## Products That Help
- [[layer-2-entities/financing-products/PROD-PRESHIP-OBF]] — if revenue >$10M
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] — if existing ARP track record >6 months
- [[layer-2-entities/financing-products/PROD-SMARTWALLET]] — if 3+ buyers and finance team exists

## Affected Combos
- [[../personas/COMBO-010-existing-client-expansion]]
