---
type: pain-point
id: PP-TR-002
---
# PP-TR-002: Turkey Bank Credit Line Contraction

## Description
Turkish banks reducing credit exposure to textile sector amid macro instability. Factories losing existing facilities without replacement.

## Trigger
`country = TR AND year >= 2023`

## Cascading Impacts
- → [[universal/PP-004-scalability-constraint]] critical
- → Supplier may close or relocate production

## Affected Combos
- [[../personas/COMBO-005-turkey-denim-specialist]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]]
