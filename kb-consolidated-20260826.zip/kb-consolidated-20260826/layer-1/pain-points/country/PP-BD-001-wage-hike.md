---
type: pain-point
id: PP-BD-001
---

# PP-BD-001: Bangladesh Minimum Wage Shock (2023)

## Description
56% wage hike in Dec 2023 (BDT 8,000 → BDT 12,500 = $113/month). Factory margins compressed
by 3-5% overnight. Many factories operating at breakeven or loss.

## Trigger
country = BD

## Intensity
CRITICAL for revenue < $20M (no scale to absorb)

## Cascading Impacts
→ margin compression → can't absorb LC cost → needs cheaper financing → Air8 opportunity
→ OR: quality cutting to restore margins → claims → buyer exit → existential

## Affected Personas
[[personas/COMBO-002-bangladesh-bank-lc]], [[personas/COMBO-001-south-asian-small-knit]]

## Amplifies
- [[pain-points/universal/PP-002-financing-cost]]
- [[pain-points/universal/PP-005-preshipment-capital]]

## Products
- [[layer-2-entities/financing-products/PROD-ARP]] (replace expensive LC with cheaper Air8)
