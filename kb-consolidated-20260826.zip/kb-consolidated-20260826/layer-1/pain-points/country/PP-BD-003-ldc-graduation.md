---
type: pain-point
id: PP-BD-003
---

# PP-BD-003: Bangladesh LDC Graduation Tariff Cliff

## Description
Bangladesh will lose EU EBA duty-free access post-2029 (LDC graduation). EU tariff on
garments: 9.6-12%. Vietnam has FTA with zero-duty → competitive disadvantage.

## Trigger
country = BD AND market = EU AND year >= 2027

## Cascading Impacts
→ buyer may preemptively shift orders starting 2027 → supplier revenue at risk → financing demand changes
→ suppliers with ESG/GOTS certification may survive (sustainability premium offsets tariff)
→ Air8 portfolio may shift geographically

## Affected Personas
[[personas/COMBO-002-bangladesh-bank-lc]], [[personas/COMBO-001-south-asian-small-knit]]

## Timeline
- 2027: Buyers begin sourcing reviews factoring in post-2029 tariffs
- 2029: EU tariff 9.6-12% kicks in
- Vietnam FTA: 0% → creates 9-12% cost advantage vs Bangladesh

## Strategic Note
Suppliers who diversify into US market or build ESG credentials (CSDDD compliance)
may retain EU buyer relationships despite tariff increase.
