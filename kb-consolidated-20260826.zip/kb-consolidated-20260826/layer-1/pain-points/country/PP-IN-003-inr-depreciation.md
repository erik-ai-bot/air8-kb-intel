---
type: pain-point
id: PP-IN-003
---
# PP-IN-003: India INR Depreciation

## Description
INR depreciates 3–8% annually vs USD. Costs in INR, revenue in USD. Creates margin illusion — revenue looks up in INR but real margin may be flat or declining.

## Trigger
`country = IN`

## Cascading Impacts
- → Apparent revenue growth masks real margin erosion
- → Supplier may under-price next season contracts

## Linked Data
- fx.inr_usd_trend

## Affected Combos
- [[../personas/COMBO-003-india-large-vertical-integrator]]
- [[../personas/COMBO-008-india-organic-cotton-medium]]
- [[../personas/COMBO-014-india-small-woven]]
