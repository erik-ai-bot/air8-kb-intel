---
type: pain-point
id: PP-CN-001
---

# PP-CN-001: China SAFE Cross-Border Complexity

## Description
SAFE (State Administration of Foreign Exchange) regulates offshore receivable assignment.
Assignment of receivables to foreign entity must be registered with SAFE. Complex paperwork,
delays, uncertainty.

## Trigger
country = CN AND Air8_entity = Hengqin

## Cascading Impacts
→ delays in setting up facility → supplier waits longer for financing access
→ ongoing admin burden for CN cross-border transactions

## Affected Personas
[[personas/COMBO-004-china-medium-woven]]

## Air8 Solution
- Air8 Hengqin (CN domestic entity) handles SAFE compliance
- Constraints: single company ≤40% portfolio, group ≤50%, balance ≤10x registered capital
- SSQ (上上签) e-signature required for CN entity contracts

## Related Compliance
- [[compliance/COMP-SAFE]]
