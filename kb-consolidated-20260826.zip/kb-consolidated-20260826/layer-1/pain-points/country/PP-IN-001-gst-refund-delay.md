---
type: pain-point
id: PP-IN-001
---

# PP-IN-001: India GST Refund Delay

## Description
Export goods are zero-rated for GST but 18% input GST must be claimed back. Refund
processing: 30-90 days. Result: 18% of input value trapped in tax receivables cycle.

## Trigger
country = IN AND type = manufacturer

## Quantification
`trapped_capital ≈ annual_input × 0.18 × (refund_days / 365)`

Example: $50M revenue, 60% RM → $30M RM spend × 18% × 60/365 = **~$890K trapped**

## Cascading Impacts
→ amplifies [[pain-points/universal/PP-001-cashflow-gap]] (total cash gap = AR gap + GST gap)
→ for a $20M supplier, GST trap alone = $350-500K frozen

## Affected Personas
[[personas/COMBO-003-india-large-vertical-integrator]], [[personas/COMBO-008-india-organic-cotton-medium]],
[[personas/COMBO-014-india-small-woven]]

## Air8 Relevance
Air8 financing frees up AR gap but cannot directly address GST trap.
However, reducing AR financing cost frees up cash buffer to absorb GST wait.
