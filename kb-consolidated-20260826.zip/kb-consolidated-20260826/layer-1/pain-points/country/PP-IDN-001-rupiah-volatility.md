---
type: pain-point
id: PP-IDN-001
---
# PP-IDN-001: Indonesia Rupiah Volatility

## Description
IDR/USD swings 5–10% per quarter. Supplier costs in IDR, revenue in USD. If IDR strengthens unexpectedly, margin is squeezed.

## Trigger
`country = ID`

## Linked Data
- fx.idr_usd

## Affected Combos
- [[../personas/COMBO-007-indonesia-family-run]]

## Products That Help
- [[layer-2-entities/financing-products/PROD-ARP]]
