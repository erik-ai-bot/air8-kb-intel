---
type: pain-point
id: PP-006
---

# PP-006: Trade Finance Literacy Gap

## Description
Supplier (especially micro/small, family-run, 1st-2nd generation) does not understand
factoring, receivable purchase, or alternatives to bank LC. They think "bank loan" is the
only option.

## Trigger Conditions
- revenue < $20M
- AND role = owner/CEO (no CFO)
- AND financing = [bank_LC | none]

## Intensity Factors
- family_business + 1st_generation → CRITICAL
- country = [BD | PK | KH | IDN] → amplified (less developed TF market)

## Cascading Impacts
→ continues paying 3-5% for LC when 1.5-2.5% alternatives exist
→ doesn't know they can free collateral
→ doesn't explore buyer-risk-based financing (only knows asset-based)
→ longer sales cycle for any financing provider

## Affected Personas
[[personas/COMBO-001-south-asian-small-knit]], [[personas/COMBO-007-indonesia-family-run]],
[[personas/COMBO-011-trader-sourcing-agent]], [[personas/COMBO-015-micro-first-time]]

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-MINIARP]] (simplified entry product)
- [[layer-2-entities/financing-products/PROD-ARP]] (after education)

## Sales Implication
Education = prerequisite to conversion. Agent should identify literacy gaps early and
explain receivable purchase concept before product pitch.
