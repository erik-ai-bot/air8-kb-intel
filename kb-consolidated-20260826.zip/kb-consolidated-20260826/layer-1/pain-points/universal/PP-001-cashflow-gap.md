---
type: pain-point
id: PP-001
---

# PP-001: Post-Shipment Cash Flow Gap

## Description
Supplier ships goods but waits 60-120 days for buyer payment. During this gap, cash is locked.
Supplier must simultaneously fund next order cycle (buy raw materials, pay workers) without
receiving revenue for the previous cycle.

## Trigger Conditions
- ANY supplier with OA payment terms
- Intensity increases with: longer payment_days, larger order_value, smaller revenue

## Intensity Factors
- payment_days > 90 → HIGH
- payment_days > 120 → CRITICAL
- revenue < $10M AND payment_days > 60 → CRITICAL
- multiple_buyers_all_OA → compounds (no staggering of cash inflows)

## Quantification
`locked_capital ≈ annual_revenue × (avg_payment_days / 365) × 0.7`

Example: $20M revenue × (90/365) × 0.7 = **$3.45M locked at any given time**

## Cascading Impacts
→ supplier cannot take new orders → revenue cap ([[pain-points/universal/PP-004-scalability-constraint]])
→ supplier delays fabric payment → fabric supplier stops credit → production halt
→ supplier takes high-interest informal loans → margin erosion ([[pain-points/universal/PP-002-financing-cost]])
→ repeated cash stress → quality cutting to reduce costs → claims → rating drop

## Affected Personas
[[personas/COMBO-001-south-asian-small-knit]], [[personas/COMBO-002-bangladesh-bank-lc]],
[[personas/COMBO-003-india-large-vertical-integrator]], [[personas/COMBO-004-china-medium-woven]],
[[personas/COMBO-005-turkey-denim-specialist]], [[personas/COMBO-006-vietnam-fdi-knit]],
[[personas/COMBO-007-indonesia-family-run]], [[personas/COMBO-008-india-organic-cotton-medium]],
[[personas/COMBO-009-pakistan-home-textile]], [[personas/COMBO-012-cambodia-eba-dependent]],
[[personas/COMBO-014-india-small-woven]], [[personas/COMBO-015-micro-first-time]]

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-ARP]] (primary solution — advance on receivables T+1)
- [[layer-2-entities/financing-products/PROD-MINIARP]] (for micro suppliers)

## Data Entities
- [[data-entities/ENTITY-Buyer]] (payment_days_avg)
- [[data-entities/ENTITY-Order]] (total_value)
- [[data-entities/ENTITY-Facility]] (advance_ratio)
