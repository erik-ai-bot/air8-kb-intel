---
type: pain-point
id: PP-003
---

# PP-003: Buyer Concentration Risk

## Description
Supplier depends on 1-3 buyers for >50% of revenue. Loss of any one buyer creates existential
crisis. Also gives buyer disproportionate negotiation leverage.

## Trigger Conditions
- buyer_concentration_top3 > 50%
- OR single_buyer > 30%

## Intensity Factors
- single_buyer > 50% → CRITICAL
- if that buyer is financially distressed (adverse_news, late payments) → CRITICAL
- revenue < $10M with 1 dominant buyer → existential

## Cascading Impacts
→ buyer reduces orders → revenue gap → can't cover fixed costs
→ buyer dictates longer payment terms → [[pain-points/universal/PP-001-cashflow-gap]] worsens
→ buyer demands price reduction → [[pain-points/universal/PP-002-financing-cost]] worsens (margin compression)
→ buyer imposes new compliance requirements → compliance cost spike

## Affected Personas
[[personas/COMBO-001-south-asian-small-knit]], [[personas/COMBO-005-turkey-denim-specialist]],
[[personas/COMBO-007-indonesia-family-run]], [[personas/COMBO-012-cambodia-eba-dependent]],
[[personas/COMBO-014-india-small-woven]], [[personas/COMBO-015-micro-first-time]]

## Products That Solve This
- [[layer-2-entities/financing-products/PROD-PAYGUARD]] (buyer credit protection)

## Data Entities
- [[data-entities/ENTITY-Supplier]] (buyer_concentration)
- [[data-entities/ENTITY-Buyer]] (financial_health, adverse_news)
