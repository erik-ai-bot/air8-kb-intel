---
type: reasoning
id: EVENT-TYPES
---

# Air8 Event Types - Reasoning Layer

This file defines all 6 event types recognized by the Air8 KB reasoning engine.
For each event type: subtypes, activated principles with weights (summing to 1.0), entity focus, and examples.

See `PRINCIPLES.md` for principle definitions. See `ARCHITECTURE.md` for the full engine logic.

---

## Event Parsing & Classification Protocol

> Run this before Step 1 field lookup. Takes raw event text → produces structured event fields + type activation list.

### Phase A - Field Extraction from Raw Text

From the raw event description, extract the following fields. If a field cannot be determined from the text, infer from context or mark as `[UNKNOWN]`.

| Field | How to extract | Example (India cotton GST exemption) |
|---|---|---|
| `supplier_country` | Who/where is the policy/event originating? | `IN` (India) |
| `buyer_geo` | Who buys from this origin? Infer from trade flows if not stated. | `[INFER]` - India cotton → EU/US/BD textile mills |
| `product_category` | What product or commodity is affected? | `cotton` / `yarn` / `woven_apparel` (trace downstream) |
| `material` | Specific material within category | `raw_cotton` |
| `supplier_tier` | Large/medium/small? Infer from event scope if not stated. | `[UNKNOWN]` - affects all tiers |
| `company_type` | FOB/CMT/DDP? Infer from product stage if not stated. | `[UNKNOWN]` |
| `event_mechanism` | What is the actual mechanism? (price change / compliance / FX / supply) | `domestic tax reduction → input cost change` |

**Downstream tracing rule:** If the event affects a raw material (e.g., cotton), trace forward to determine which product categories are affected:
```
cotton (raw) → yarn → fabric → woven_apparel / home_textiles / denim
```
Include all affected product categories in `product_category` field (comma-separated), weighted by directness.

---

### Phase B — Event Family Association Scoring

**Rule: Check ALL 6 event families. Include every family with STRONG or MODERATE association. Only exclude WEAK and NONE.**

Do not force a single family. Most real-world events touch 2–3 families simultaneously. Each activated family runs its own independent principle chain and produces its own signal block.

> **Key design:** Each family is a **data container** (principle weights + mandatory checks + subtypes), not a navigation step. The brain maps **directly to the subtype**, and the family’s weights + mandatory checks are inherited automatically. You do not need to identify the family first and then drill down — matching the subtype is sufficient.

| Association Level | Meaning | Action |
|---|---|---|
| **STRONG** | Core mechanism of this event family directly applies | Activate — subtype match + inherit weights + run full principle chain |
| **MODERATE** | Secondary effect clearly present; generates a distinct signal | Activate — subtype match + inherit weights + run full principle chain |
| **WEAK** | Tangential; would only add noise | Flag as `[NOTED]` but do not activate |
| **NONE** | No meaningful connection | Exclude entirely |

**Decision criteria per event type:**

| Event Type | Activate when the event involves... |
|---|---|
| **EVT-TARIFF** | Any change to duty, tax, levy, exemption, subsidy, GSP, FTA - whether cross-border OR domestic - that affects the cost structure of production or trade |
| **EVT-REGULATION** | New/amended mandatory compliance requirements (chemical, labor, reporting, traceability, safety) |
| **EVT-CURRENCY** | FX rate move, devaluation, inflation, currency restrictions that affect cost or receivable value |
| **EVT-ESG-CERT** | Buyer ESG mandate, certification standard change, greenwashing scrutiny, IFC eligibility change |
| **EVT-MARKET-SHIFT** | Sourcing allocation change, demand pattern shift, buyer entry/exit, pricing structure change in a market |
| **EVT-SUPPLY-DISRUPTION** | Physical disruption to production or logistics; buyer credit stress; raw material shortage or allocation constraint |

---

### Phase C - Worked Example: India Cotton GST Exemption

**Raw text:** "India removes GST on raw cotton - textile mills to benefit from lower input costs"

**Step 1 - Field extraction:**
```
supplier_country: IN
buyer_geo: [INFER] → EU, US, BD (India cotton exports)
product_category: raw_cotton → yarn → woven_apparel, home_textiles (downstream trace)
material: raw_cotton
supplier_tier: [UNKNOWN] - affects all tiers
event_mechanism: domestic tax reduction → mill input cost reduction → potential price pass-through to buyers
```

**Step 2 - Type association scoring:**

| Event Type | Association | Rationale |
|---|---|---|
| EVT-TARIFF | **STRONG** | GST exemption is a tax change that directly alters the cost structure of cotton production and trade. Mechanism is equivalent to a domestic duty reduction on inputs. Use subtype: `import_export_duty` (closest canonical); flag `[KB-GAP]` → suggest new subtype `domestic_tax_exemption`. |
| EVT-MARKET-SHIFT | **MODERATE** | If India cotton becomes cheaper, it may shift sourcing patterns: BD/Vietnam mills may increase India cotton sourcing; competing cotton origins (US, Brazil) lose price competitiveness. A distinct market-level signal emerges. |
| EVT-SUPPLY-DISRUPTION | **WEAK** | No physical disruption. Raw material availability unchanged. Flag `[NOTED]` only - do not activate. |
| EVT-REGULATION | **NONE** | Not a compliance event. Exclude. |
| EVT-CURRENCY | **NONE** | Not an FX event. Exclude. |
| EVT-ESG-CERT | **NONE** | No ESG dimension. Exclude. |

**Result: Activate EVT-TARIFF (primary) + EVT-MARKET-SHIFT (secondary)**

Each type runs its own principle chain in Step 2 → produces separate signal blocks → combined at Step 6 where signals converge.

---

### Phase D — Multi-Family Handling Rules

When 2+ event families are activated:

1. **Run each family’s principle chain independently** — no weight merging between families; each keeps its own `(principle_id, weight)` list. This avoids double-counting principles that appear in multiple families (e.g., PRIN-COUNTRY-EXPOSURE in both EVT-TARIFF and EVT-MARKET-SHIFT).
2. **Score entities separately per family** — an entity may score differently under EVT-TARIFF vs EVT-MARKET-SHIFT; keep scores independent
3. **At Step 6** — check where product recommendations converge across families → `[MULTI-SIGNAL]` = highest-confidence pitches; see REASONING-FLOW.md Step 6b for convergence ranking rules
4. **Output card structure:** label every finding by its source family; do not merge. STRONG family findings appear first, MODERATE findings follow as supplement.

**Multi-family output label format:**
```
[EVT-TARIFF • STRONG] India mills: input cost reduction ~8% if full pass-through confirmed
[EVT-MARKET-SHIFT • MODERATE] BD/Vietnam mills: India cotton sourcing share likely rises → spot prices may tighten
[MULTI-SIGNAL] ARP: indicated by both cost-structure and sourcing-shift signals → lead pitch
```

---

### Phase E - When Event Doesn't Fit Any Subtype

If no existing subtype matches the event mechanism:
1. Use the **CANONICAL parent subtype** of the closest event type (e.g., `import_export_duty` for any tax/duty-adjacent event)
2. Note the approximation explicitly: `subtype: import_export_duty [APPROX - closest fit; actual: domestic_tax_exemption]`
3. Generate a `[KB-GAP]` flag: `suggest new subtype: domestic_tax_exemption under EVT-TARIFF`
4. Do **not** block reasoning - proceed with canonical subtype and note the approximation

---

## Summary Table

| Event Type ID        | Name                  | Primary Entity Focus          | Weight Split                                     |
|----------------------|-----------------------|-------------------------------|--------------------------------------------------|
| EVT-TARIFF           | Tariff / Duty Change  | Country (0.5) + Product (0.3) | Country_Exposure(0.5), Product_Tariff(0.3), Supplier_Resilience(0.2) |
| EVT-REGULATION       | Regulatory Compliance | Product (0.3) + Country (0.2) | Compliance_Cost(0.5), Product_Tariff(0.3), Buyer_Geo_Exposure(0.2) |
| EVT-CURRENCY         | Currency / FX Event   | Country (0.6)                 | Country_Exposure(0.6), Supplier_Resilience(0.3), Financing_Match(0.1) |
| EVT-ESG-CERT         | ESG Certification     | Product (0.4) + Persona (0.3) | Compliance_Cost(0.4), Buyer_Geo_Exposure(0.3), Financing_Match(0.3) |
| EVT-MARKET-SHIFT     | Buyer / Market Shift  | Country (0.4) + Persona (0.2) | Buyer_Geo_Exposure(0.4), Country_Exposure(0.4), Supplier_Resilience(0.2) |
| EVT-SUPPLY-DISRUPTION| Supply Disruption     | Country (0.5) + Persona (0.4) | Country_Exposure(0.5), Supplier_Resilience(0.4), Financing_Match(0.1) |

---

## EVT-TARIFF - Tariff / Duty Change

**Description:** Any event involving changes to import/export duties, anti-dumping measures, safeguard tariffs, GSP status changes, or preferential trade agreement modifications.

### Subtypes
| Subtype ID                | Description                                              | RP-EVT-* rule fired |
|---------------------------|----------------------------------------------------------|---------------------|
| `import_export_duty`      | **CANONICAL** - any import or export duty change (parent of below) | RP-EVT-DUTY-01 |
| `section_301`             | US Section 301 tariffs on Chinese goods                  | RP-EVT-DUTY-01 |
| `anti_dumping`            | Anti-dumping duty investigation or imposition            | RP-EVT-DUTY-01 |
| `safeguard`               | WTO safeguard tariff on specific product category        | RP-EVT-DUTY-01 |
| `gsp_graduation`          | Country graduates out of GSP/EBA preference scheme       | RP-EVT-DUTY-01 |
| `gsp_suspension`          | GSP preferences suspended (e.g., Bangladesh post-LDC)   | RP-EVT-DUTY-01 |
| `new_fta`                 | New Free Trade Agreement comes into effect               | RP-EVT-DUTY-01 |
| `tariff_increase`         | General tariff rate increase on category                 | RP-EVT-DUTY-01 |

> **Routing note:** All EVT-TARIFF subtypes also trigger RP-EVT-DOUBLE-COMPRESS check (mandatory: query active_event_cache for co-occurring input+output tariff on same country×category).

### Activated Principles

| Principle                   | Weight | entity_focus       | Rationale                                              |
|-----------------------------|--------|--------------------|--------------------------------------------------------|
| PRIN-COUNTRY-EXPOSURE        | **0.5**| country            | Tariff hits are country-of-origin driven               |
| PRIN-PRODUCT-TARIFF          | **0.3**| product_category   | HS code / product classification determines duty rate  |
| PRIN-SUPPLIER-RESILIENCE     | **0.2**| persona            | Supplier's ability to absorb margin hit varies by size |
| **Total**                   | **1.0**|                    |                                                        |

### Entity Focus by Weight
- **Primary:** Country (supplier_origin role) - 0.5 × 0.7 = 0.35 effective
- **Secondary:** Product category - 0.3
- **Supporting:** Supplier persona - 0.2

### Example Events
- US imposes additional 25% tariff on CN woven apparel under Section 301
- India's GSP status partially suspended for EU textile exports (50% of HTS codes)
- Bangladesh scheduled to graduate from EU EBA in 2026 → standard GSP rates apply
- Anti-dumping duties imposed on Vietnamese knit products entering Canada

---

## EVT-REGULATION - Regulatory Compliance Event

**Description:** Any event involving new or amended mandatory regulations that require supplier action - chemical bans, forced labor compliance, safety standards, due diligence laws, supply chain reporting mandates.

### Subtypes
| Subtype ID              | Description                                                    |
|-------------------------|----------------------------------------------------------------|
| `environmental_compliance` | **CANONICAL** - any environmental/chemical compliance change (parent of below) | RP-EVT-ENVCOMP-01 |
| `traceability`          | **CANONICAL** - any chain-of-custody / traceability requirement | RP-EVT-TRACE-01 |
| `reach_update`          | ECHA adds new SVHC to REACH Candidate List                     | RP-EVT-ENVCOMP-01 |
| `uflpa_entity_add`      | New entity added to UFLPA Entity List                          | RP-EVT-TRACE-01 |
| `uflpa_detention`       | Shipment detained under UFLPA at US port                       | RP-EVT-TRACE-01 |
| `csddd_scope_expand`    | CSDDD scope expansion (lower revenue threshold)                | RP-EVT-ENVCOMP-01 |
| `gpsr_enforcement`      | EU GPSR enforcement action / market surveillance               | RP-EVT-ENVCOMP-01 |
| `s211_deadline`         | Canadian S-211 annual reporting deadline approaching           | RP-EVT-ENVCOMP-01 |
| `ny_fashion_act`        | NY Fashion Sustainability and Social Accountability Act update  | RP-EVT-ENVCOMP-01 |
| `food_contact_ban`      | PFAS/PFOA ban for food-contact materials (EU/US)               | RP-EVT-ENVCOMP-01 |
| `prop65_update`         | California Prop 65 new listing affecting product               | RP-EVT-ENVCOMP-01 |

### Activated Principles

| Principle                   | Weight | entity_focus                  | Rationale                                               |
|-----------------------------|--------|-------------------------------|----------------------------------------------------------|
| PRIN-COMPLIANCE-COST         | **0.5**| product_category + persona    | Compliance cost is product AND supplier-size dependent   |
| PRIN-PRODUCT-TARIFF          | **0.3**| product_category              | Regulation often maps to specific HS codes/materials     |
| PRIN-BUYER-GEO-EXPOSURE      | **0.2**| country (buyer side)          | Regulation jurisdiction determines which buyers are affected |
| **Total**                   | **1.0**|                               |                                                           |

### Entity Focus by Weight
- **Primary:** Product category + Persona (joint 0.5 - compliance cost straddles both)
- **Secondary:** Product category (HS code specificity) - 0.3
- **Supporting:** Buyer country (jurisdiction of regulation) - 0.2

### Example Events
- ECHA adds new brominated flame retardant to SVHC list → affects upholstery fabrics to EU
- UFLPA Entity List adds major Chinese cotton spinning mill → all cotton-chain suppliers face scrutiny
- CSDDD threshold drops to €150M → 40% more EU-selling suppliers in scope
- GPSR enforcement action at Rotterdam detains Chinese holiday décor shipments

---

## EVT-CURRENCY - Currency / FX Event

**Description:** Any event involving significant currency movements, devaluation, hyperinflation, or FX volatility affecting supplier production costs or receivable value.

### Subtypes
| Subtype ID            | Description                                                      |
|-----------------------|------------------------------------------------------------------|
| `fx_rate`             | **CANONICAL** - any FX rate move (parent of below) | RP-EVT-FX-01 |
| `devaluation`         | Deliberate currency devaluation by central bank     | RP-EVT-FX-01 |
| `hyperinflation`      | Inflation exceeds 50% monthly / economy in hyperinflation | RP-EVT-FX-01 |
| `fx_volatility`       | Elevated FX volatility (±15%+ in 30 days) without direction | RP-EVT-FX-01 |
| `usd_strengthening`   | USD strengthens - impacts USD-invoiced supplier margins | RP-EVT-FX-01 |
| `local_depreciation`  | Supplier's local currency depreciates vs USD (mixed effect) | RP-EVT-FX-01 |

### Activated Principles

| Principle                   | Weight | entity_focus       | Rationale                                              |
|-----------------------------|--------|--------------------|--------------------------------------------------------|
| PRIN-COUNTRY-EXPOSURE        | **0.6**| country            | FX events are fundamentally country-level              |
| PRIN-SUPPLIER-RESILIENCE     | **0.3**| persona            | Hedging ability, USD invoicing ratio vary by supplier size |
| PRIN-FINANCING-MATCH         | **0.1**| persona + financing_product | FX creates financing urgency - match product  |
| **Total**                   | **1.0**|                    |                                                        |

### Entity Focus by Weight
- **Primary:** Country - 0.6
- **Secondary:** Supplier persona - 0.3
- **Supporting:** Financing product match - 0.1

### Example Events
- Turkish lira depreciates 30% in Q3 - Turkish denim exporters gain cost competitiveness but face BOP risk
- Pakistan rupee devaluation → fabric import costs spike for PK home textile manufacturers
- Bangladesh Bank restricts USD transfers → LC opening delays for BD suppliers
- CNY appreciation vs USD narrows margins for China-based exporters

---

## EVT-ESG-CERT - ESG Certification / Sustainability Standard Event

**Description:** Any event where a buyer mandates new ESG certification, a certification body updates standards, or a supplier achieves/loses a key sustainability credential.

### Subtypes
| Subtype ID               | Description                                                    |
|--------------------------|----------------------------------------------------------------|
| `buyer_mandate`          | Buyer adds ESG cert as new supplier qualification requirement  |
| `standard_update`        | Certification body revises standard (e.g., GOTS 7.0)          |
| `cert_achieved`          | Supplier achieves new ESG certification (upsell opportunity)   |
| `cert_lapsed`            | Supplier's ESG cert lapses - buyer contract at risk            |
| `zdhc_gateway_add`       | Chemical added to ZDHC MRSL restricted list                    |
| `ifc_criteria_met`       | Supplier now meets IFC PS criteria (ESG Finance eligible)      |
| `greenwashing_scrutiny`  | Regulatory/media greenwashing scrutiny in buyer's market       |

### Activated Principles

| Principle                   | Weight | entity_focus                  | Rationale                                             |
|-----------------------------|--------|-------------------------------|-------------------------------------------------------|
| PRIN-COMPLIANCE-COST         | **0.4**| product_category + persona    | Cert costs (testing + audit + annual fee) are product/size-dependent |
| PRIN-BUYER-GEO-EXPOSURE      | **0.3**| country (buyer side)          | ESG mandate origin is buyer geography (EU vs US vs UK) |
| PRIN-FINANCING-MATCH         | **0.3**| persona + financing_product   | ESG Finance product available if IFC criteria met      |
| **Total**                   | **1.0**|                               |                                                        |

### Entity Focus by Weight
- **Primary:** Persona (cost absorption ability) and Buyer country (mandate jurisdiction) - co-primary
- **Secondary:** Financing product (ESG Finance eligibility)

### Example Events
- H&M adds GOTS certification requirement for all organic cotton suppliers from 2027
- ZDHC updates MRSL version 3.1 - 12 new chemicals restricted, affecting denim wet processing
- India large vertical integrator achieves IFC PS certification → ESG Finance product now eligible
- EU greenwashing regulation (Green Claims Directive) requires third-party verification for "sustainable" labels

---

## EVT-MARKET-SHIFT - Buyer Sourcing Shift / Market Exit

**Description:** Any event where buyer sourcing allocation changes, demand patterns shift, or a buyer exits / significantly reduces from a country or supplier base.

### Subtypes
| Subtype ID                 | Description                                                   |
|----------------------------|---------------------------------------------------------------|
| `sourcing_strategy_shift`  | **CANONICAL** - any buyer sourcing strategy change (parent of below) | RP-EVT-SOURCSHIFT-01 |
| `market_entry_exit`        | **CANONICAL** - buyer entering or exiting a market/geography  | RP-EVT-MKTENTRY-01 |
| `supplier_consolidation`   | **CANONICAL** - buyer reducing vendor count / consolidating supply base | RP-EVT-SUPCONSOLIDATE-01 |
| `product_trend_change`     | **CANONICAL** - structural shift in product category demand   | RP-EVT-PRODTREND-01 |
| `product_technology_disruption` | **CANONICAL** - new tech disrupts production method    | RP-EVT-PRODTECH-01 |
| `demand_shift`             | General demand shift in a market or category                  | RP-EVT-PRODTREND-01 |
| `buyer_country_shift`      | Buyer reallocates sourcing from Country A to Country B        | RP-EVT-SOURCSHIFT-01 + RP-EVT-SEGMENT-BIFURCATE |
| `buyer_category_exit`      | Buyer stops sourcing a product category entirely              | RP-EVT-MKTENTRY-01 |
| `demand_collapse`          | End-market demand collapses (recession, consumer shift)       | RP-EVT-PRODTREND-01 |
| `tariff_driven_diversion`  | Tariff triggers buyer to redirect PO allocation               | RP-EVT-SOURCSHIFT-01 + RP-EVT-SEASONAL-LOCK |
| `nearshoring`              | Buyer shifts to nearshore supply base (e.g., Mexico, Morocco) | RP-EVT-SOURCSHIFT-01 |
| `fdi_attraction`           | FDI-driven capacity build in new country attracts buyer POs   | RP-EVT-SOURCSHIFT-01 |

> **Routing note:** All EVT-MARKET-SHIFT sourcing subtypes also trigger RP-EVT-SEGMENT-BIFURCATE (verify segment overlap before calling substitution) and RP-EVT-SEASONAL-LOCK check (if category has annual purchase cycle).

### Activated Principles

| Principle                   | Weight | entity_focus       | Rationale                                               |
|-----------------------------|--------|--------------------|----------------------------------------------------------|
| PRIN-BUYER-GEO-EXPOSURE      | **0.4**| country (buyer)    | Shift originates from buyer side - buyer geo is key     |
| PRIN-COUNTRY-EXPOSURE        | **0.4**| country (supplier) | Origin country losing/gaining PO allocation             |
| PRIN-SUPPLIER-RESILIENCE     | **0.2**| persona            | Supplier's revenue concentration determines shock severity |
| **Total**                   | **1.0**|                    |                                                         |

### Entity Focus by Weight
- **Co-primary:** Buyer country + Supplier country - equal 0.4 each
- **Supporting:** Supplier persona (concentration risk) - 0.2

### Example Events
- US buyers shift 20% of outdoor furniture POs from China to Vietnam (tariff-driven hedge)
- EU fast fashion buyers pivot from Bangladesh to Morocco (lead time / nearshoring)
- End-market demand for denim collapses 15% YoY - Turkey denim exporters revenue falls
- Vietnam FDI attracts Nike/Adidas full package relocation - knit ecosystem follows

---

## EVT-SUPPLY-DISRUPTION - Political / Operational Supply Disruption

**Description:** Any event causing physical disruption to production or logistics - political instability, energy crisis, factory disaster, port congestion, pandemic-level disruption.

### Subtypes
| Subtype ID              | Description                                                     |
|-------------------------|-----------------------------------------------------------------|
| `political_instability`    | Government crisis, civil unrest, coup, mass strikes            | RP-EVT-POLINSTAB-01 |
| `buyer_credit_event`       | **CANONICAL** - buyer distress, downgrade, DSO extension, covenant breach | RP-EVT-BUYERCREDIT-01 |
| `raw_material_shortage`    | **CANONICAL** - shortage/allocation constraint on input material | RP-EVT-CMDTYSHORT-01 |
| `allocation_constraint`    | Specific material allocation rationing by supplier             | RP-EVT-CMDTYSHORT-01 |
| `lead_time_change`         | **CANONICAL** - material change in production/shipping lead time | RP-EVT-SUPCHAIN-01 |
| `factory_capacity_change`  | **CANONICAL** - competitor or own factory capacity shift       | RP-EVT-SUPCHAIN-01 |
| `energy_crisis`            | Power rationing, energy price spike affecting factory ops       | RP-EVT-POLINSTAB-01 |
| `factory_disaster`         | Factory fire, collapse, or major safety incident               | RP-EVT-SUPCHAIN-01 |
| `port_congestion`          | Major port congestion / shipping delay                         | RP-EVT-SUPCHAIN-01 |
| `logistics_disruption`     | Shipping route disruption (Red Sea, Panama Canal, etc.)        | RP-EVT-SUPCHAIN-01 |
| `natural_disaster`         | Flood, earthquake, typhoon affecting production region         | RP-EVT-POLINSTAB-01 |
| `pandemic_response`        | Government COVID/pandemic-level factory shutdown orders        | RP-EVT-POLINSTAB-01 |

### Activated Principles

| Principle                   | Weight | entity_focus                  | Rationale                                              |
|-----------------------------|--------|-------------------------------|--------------------------------------------------------|
| PRIN-COUNTRY-EXPOSURE        | **0.5**| country                       | Disruption is country/region-specific                  |
| PRIN-SUPPLIER-RESILIENCE     | **0.4**| persona                       | Supplier's ability to absorb / reroute depends on size/type |
| PRIN-FINANCING-MATCH         | **0.1**| persona + financing_product   | Emergency liquidity needs arise - financing match needed |
| **Total**                   | **1.0**|                               |                                                         |

### Entity Focus by Weight
- **Primary:** Country (location of disruption) - 0.5
- **Secondary:** Supplier persona (resilience + liquidity need) - 0.4
- **Supporting:** Financing product (emergency liquidity match) - 0.1

### Example Events
- Bangladesh political crisis escalates - factory shutdowns, OTD degrades → Air8 AR at risk
- Pakistan energy crisis: 8-hr load shedding daily → production output drops 25%
- Rana Plaza-type factory collapse → entire sourcing category under scrutiny
- Red Sea shipping disruption → 14-day extra lead time → cash cycle extends → PP-001 intensifies

---

## Tag Dictionary — Controlled Vocabulary

> Merged from tag_dictionary.md | Version: 2.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> All tags must be registered here before use. No synonyms. Lowercase with underscores.

---

### Event Type Tags (2-Level Taxonomy)

#### Regulation
| Sub-type | Description |
|---|---|
| `import_export_duty` | Tariff changes, customs duty revisions |
| `environmental_compliance` | REACH, ZDHC, chemical bans |
| `traceability` | UFLPA, Digital Product Passport, chain of custody |
| `labor_standards` | Minimum wage, CSDDD social clauses, factory audits |
| `trade_agreement` | FTA, EBA/GSP+ changes, preferential access |
| `product_safety` | GPSR, flammability, ESPR, REACH SVHC |

#### Financial
| Sub-type | Description |
|---|---|
| `fx_rate` | Currency pair moves (TRY/EUR, INR/USD, etc.) |
| `interest_rate` | Central bank rate changes, credit market shifts |
| `buyer_credit_event` | Buyer downgrade, insolvency, payment term extension |
| `buyer_payment_term` | Buyer extending OA days unilaterally |
| `supplier_distress` | Supplier cash crisis, over-leverage, bank freeze |

#### Market
| Sub-type | Description |
|---|---|
| `product_trend_change` | Product category growing or declining structurally in buyer demand (athleisure rising, formal declining, sustainability premium growing) |
| `product_technology_disruption` | New production technology changes competitive landscape (3D knitting, laser finishing, automation disrupting cut-and-sew) |
| `demand_shift` | General consumer demand shifting across geographies or segments |
| `new_trade_flow_pattern` | New sourcing or trade flow patterns emerging between countries |
| `competitor_capacity_change` | Competitor entering or exiting a product/country segment |

#### Commodity
| Sub-type | Description |
|---|---|
| `raw_material_price` | Cotton, yarn, indigo, cashmere, wool price moves |
| `raw_material_shortage` | Supply disruption, allocation constraints |
| `energy_price` | Electricity, gas, diesel — production cost impact |
| `freight_rate` | Ocean freight rate spikes or drops |

#### Geopolitical
| Sub-type | Description |
|---|---|
| `sanctions` | OFAC, EU sanctions, country/entity designations |
| `trade_war` | Tariff escalation, retaliatory measures |
| `political_instability` | Country-level disruption (hartal, coup, election chaos) |
| `route_disruption` | Suez/Panama blockage, port closure |

#### Buyer
| Sub-type | Description |
|---|---|
| `sourcing_strategy_shift` | China+1, nearshoring, diversification announcements |
| `market_entry_exit` | Buyer entering/exiting a geography |
| `supplier_consolidation` | Buyer reducing supplier count |
| `compliance_mandate` | Buyer adding new compliance requirement |
| `ma_ownership` | Buyer M&A changing sourcing priorities |
| `nearshoring` | Buyer moving volume closer to end market |

#### Supply Chain
| Sub-type | Description |
|---|---|
| `factory_capacity_change` | Factory expansion, closure, capacity overhang |
| `lead_time_change` | Production or shipping lead time shift |
| `logistics_disruption` | Port congestion, inland transport delays |
| `allocation_constraint` | Raw material allocation limits from suppliers |

---

### Material Tags
| Tag | Coverage |
|---|---|
| `material:cotton` | Raw cotton, cotton yarn, cotton woven/knit fabrics |
| `material:denim` | Denim fabric, washed denim garments |
| `material:polyester` | PSF, PET, recycled polyester |
| `material:viscose` | Viscose, rayon, modal |
| `material:wool` | Merino, lambswool, cashmere, alpaca |
| `material:synthetic_blend` | Polyester-cotton, nylon blends |
| `material:home_textile` | Bed linen, bath linen, kitchen textile |
| `material:hardgoods` | Cookware, decor, furniture, seasonal |

### Country Tags
| Tag | Country |
|---|---|
| `country:BD` | Bangladesh |
| `country:CN` | China |
| `country:IN` | India |
| `country:TR` | Turkey |
| `country:VN` | Vietnam |
| `country:PK` | Pakistan |
| `country:ID` | Indonesia |
| `country:KH` | Cambodia |
| `country:multi` | Multi-country group |

### Company Type Tags
| Tag | Type |
|---|---|
| `company_type:CMT` | Cut-Make-Trim (no sourcing control) |
| `company_type:FOB` | Full Package (sourcing + production) |
| `company_type:vertical` | Farm-to-fashion, fully integrated |
| `company_type:trader` | No factory, intermediary |
| `company_type:FDI` | Foreign-owned factory |

### Revenue Band Tags
| Tag | Range |
|---|---|
| `revenue:small` | $5–20M |
| `revenue:mid` | $20–50M |
| `revenue:large` | $50M+ |
| `revenue:micro` | <$5M |

### Buyer Geography Tags
| Tag | Coverage |
|---|---|
| `buyer_geo:EU` | European Union buyers |
| `buyer_geo:US` | United States buyers |
| `buyer_geo:APAC` | Asia-Pacific buyers |
| `buyer_geo:mixed` | Diversified across regions |

### Scenario Tags
| Tag | Scenario |
|---|---|
| `scenario:S1` | Event trigger (forward cascade) |
| `scenario:S2` | BD outreach (reverse path) |
| `scenario:S3` | Individual supplier assessment |
| `scenario:S4` | Portfolio monitoring |

### Domain Tags
| Tag | Domain |
|---|---|
| `domain:compliance` | Regulatory and compliance matters |
| `domain:finance` | Financing, cash flow, credit |
| `domain:operations` | Production, logistics, QC |
| `domain:persona` | Supplier identity and characteristics |
| `domain:risk` | Air8 portfolio risk |
| `domain:esg` | ESG credentials and requirements |
| `domain:hardgoods` | Hardgoods-specific (Josephine's domain) |

---

### Tag Ranking Rules

- Every node must have at least one `event_type:*` tag and one `country:*` tag
- **Primary tag**: the single most relevant tag for routing — used first
- **Secondary tags**: top 2 processed in cascade; rest logged for future use
- No more than 8 tags total per node (prevents over-tagging)
- Tags must be exact matches — no fuzzy matching at routing stage


---

## Canonical Terminology
> Merged from terminology.md | Owner: Jerri Zhou | Version: 2026-07-15
> ALWAYS check this section before writing new KB content.
> If a term isn't here, add it here first, then use it.

---

## Canonical Terms (Use ONLY these)

| Canonical Term | Definition | Banned Synonyms |
|---|---|---|
| **Persona** | A supplier archetype node in the KB. Identified by COMBO-xxx prefix. | ~~combo~~, ~~archetype~~, ~~profile~~, ~~factory type~~ |
| **Assessment Dimension** | A stable variable that determines the magnitude of a signal for a given Persona. Used in S3. | ~~qualifying question~~, ~~key variable~~, ~~evaluation criteria~~ |
| **Structural Nuance** | A durable truth about a Persona that an LLM would miss without KB knowledge. Max 5–10 bullets per Persona. | ~~structural note~~, ~~nuance~~, ~~context~~ |
| **LLM Directive** | A runtime instruction for the LLM to perform a web lookup or computation. Executed at Step 5. | ~~web lookup~~, ~~runtime check~~, ~~live query~~, ~~dynamic lookup~~ |
| **Principle** | A named L0 reasoning rule (prefix: RP-EVT-*, RP-RISK-*, RP-PERSONA-*). Stored in layer-1-reasoning/. | ~~rule~~, ~~logic~~, ~~guideline~~, ~~heuristic~~ |
| **Primitive** | A first-principles reasoning construct (prefix: RP-DEPENDENCY, RP-CLIFF, etc.). Stored in PRIMITIVES.md. Different from Principle — broader, not named to an event type. | ~~fallback rule~~, ~~base principle~~, ~~generic rule~~ |
| **Signal** | The output recommendation for a Persona × Event combination. One of: EXPAND · CONDITIONAL · CAUTION · NEUTRAL · DO_NOT_EXPAND | ~~recommendation~~, ~~call~~, ~~verdict~~, ~~Air8 signal~~, ~~output signal~~ |
| **Signal Flip** | When a Signal reverses from its default value due to a specific Condition being met. Defined in Persona's `Signal Flip Conditions` section. | ~~signal change~~, ~~override~~, ~~exception~~, ~~reversal~~ |
| **Event Card** | The output document produced by S1. Contains: WHY + SIGNAL + WHAT TO DO + QUALIFYING QUESTIONS + IF branches. | ~~S1 card~~, ~~event insight card~~, ~~output card~~, ~~insight card~~ |
| **Assessment** | The output document produced by S3 for a specific supplier. | ~~S3 card~~, ~~assessment card~~, ~~evaluation~~ |
| **Active Event Cache** | Runtime state file listing events currently within their TTL window. Written by S1. Read by S2/S3/S5. | ~~event cache~~, ~~active events~~, ~~cache~~, ~~event registry~~ |
| **Claim Label** | Inline confidence tag applied to every factual claim in WHY/INSIGHT sections. One of: [VERIFIED] · [EXPERT] · [HYPOTHESIS] · [PENDING DATA] | ~~confidence label~~, ~~certainty tag~~, ~~source tag~~, ~~evidence tag~~ |
| **Pain Point** | A supplier problem that creates an Air8 BD opportunity. Stored in pain-points/. | ~~pain~~, ~~problem~~, ~~issue~~, ~~friction~~ |
| **Correlated Event Pair** | Two or more Events linked by RP-EVT-CORRELATED-PAIR because they share ≥2 overlapping tags and affect the same Personas. | ~~related events~~, ~~combined events~~, ~~linked events~~, ~~event cluster~~ |
| **Scenario** | A named reasoning flow (S0 through S5). Each has one .md file in scenarios/. | ~~use case~~, ~~mode~~, ~~track~~, ~~workflow~~ |
| **Domain** | A subject-matter classification for Personas and events. Currently: apparel · hardgoods. | ~~category~~, ~~sector~~, ~~vertical~~, ~~industry~~ |
| **Buyer Edge** | A weighted relationship from a Persona to a Buyer Type. Defined in `Buyer Edges` section. | ~~buyer relationship~~, ~~buyer link~~, ~~client type~~ |
| **Archetype** | The base template a Persona extends. One of: CMT-LowMargin · FullPackage-MidMargin · Vertical-HighMargin. | ~~template~~, ~~base type~~, ~~persona type~~ |
| **Compound Bonus** | An intensity score modifier applied when multiple Pain Points or Events co-occur for a Persona. Defined in § Intensity Scoring Engine in REASONING-FLOW.md. | ~~stacking bonus~~, ~~compounding effect~~, ~~multiplier~~ |
| **Cliff Date** | A hard deadline after which an event's benefit window closes (e.g., a tariff exemption expiry). Triggers cliff-playbook.md. | ~~deadline~~, ~~expiry~~, ~~cutoff~~ |
| **Self-Liquidation Chain** | The sequence by which an Air8 disbursement is repaid without the supplier needing to refinance. Required in every Product recommendation. | ~~repayment chain~~, ~~repayment path~~, ~~liquidation path~~ |
| **Signal Derivation** | The structured block in an Event Card that traces how the Signal was produced (principles fired, flips applied). | ~~signal explanation~~, ~~reasoning trace~~, ~~derivation block~~ |
| **Pending Expert Review** | A tag applied to a Structural Nuance or claim that has not yet been validated by a named domain expert. Format: `PENDING EXPERT REVIEW: [Expert Name]`. | ~~to be reviewed~~, ~~unvalidated~~, ~~draft claim~~ |

---

### Claim Labels — Usage Rules

| Label | When to Use |
|---|---|
| [VERIFIED] | Sourced from published, named data (Eurostat, USTR, official trade body, buyer announcement). Must name source. |
| [EXPERT] | From a KB Structural Nuance that has been reviewed and approved by a named domain expert. |
| [HYPOTHESIS] | Logical inference from known Structural Nuances. Not directly sourced. Directionally correct but not proven. |
| [PENDING DATA] | Claim direction is plausible, but specific figure/fact not yet sourced. Do NOT cite as fact. Must be followed up. |

**Rule:** Every factual claim in WHY and INSIGHT sections of an Event Card must carry exactly one Claim Label. Cards without labels → G7 quality gate fails → not emitted.

---

### Signal Values — Definitions

| Signal | Definition |
|---|---|
| EXPAND | Clear positive signal. Increase Air8 exposure; new facility or limit increase recommended. |
| CONDITIONAL | Positive signal but depends on one or more unconfirmed Assessment Dimensions. Expand only after verification. |
| CAUTION | Mixed or deteriorating signal. Maintain current exposure; do not increase; monitor closely. |
| NEUTRAL | Event does not meaningfully affect this Persona. No Air8 action. |
| DO_NOT_EXPAND | Negative signal. Hold or reduce exposure. Do not increase facility under any condition. |

---

### Relationship Types (for Correlated Event Pairs)

| Type | Definition |
|---|---|
| AMPLIFYING | Both events push the Signal in the same direction for the same Persona. Urgency and magnitude increase. |
| REFRAMES | New event changes the correct interpretation of the cached event. The cached event's Signal must be revised. |
| OFFSETS | Events partially cancel each other for a specific Persona. Net Signal is muted. |
| INDEPENDENT | Overlap in tags but different mechanisms and Personas. Emit separately. |

---

### File Naming Conventions

| File Type | Convention | Example |
|---|---|---|
| Persona instance | COMBO-[NNN]-[country]-[product].md | COMBO-005-turkey-denim.md |
| Hardgoods persona | COMBO-HG-[NNN]-[country]-[product].md | COMBO-HG-001-china-outdoor-furniture.md |
| Pain point | PP-[COUNTRY]-[NNN]-[slug].md | PP-BD-001-wage-hike.md |
| Product | PROD-[NAME].md | PROD-ARP.md |
| Country | [ISO2].md | TR.md |
| Scenario flow | S[N]-[slug].md | S1-event-insights.md |
| Template | S[N]-[output-type].md | S1-event-card.md |
| Principle | Use RP- prefix in content; stored in event-principles.md, risk-principles.md, etc. | RP-EVT-DOUBLE-COMPRESS |

---

### Pending Standardization (Items Needing Update Across Files)

The following are known inconsistencies to fix in the next KB update pass:

| Current (inconsistent) | Target | Files Affected |
|---|---|---|
| "qualifying questions" | "Assessment Dimensions" | COMBO-002, COMBO-009 (older format) |
| "Air8 signal" in Persona headers | "Signal" | Multiple COMBO files |
| "dim:" shorthand | OK to keep as shorthand within Persona files | No change needed |
| "recommendation signal" | "Signal" | REASONING-FLOW.md § Signal Decision Rules |
| "event cache" | "Active Event Cache" | runtime/active_event_cache_schema.md header |
| "Correlated event" vs "CORRELATED-PAIR" | Use "Correlated Event Pair" as noun; RP-EVT-CORRELATED-PAIR as principle ID | EVENT-CLUSTERS.md § Reviewed Correlated Pairs |

