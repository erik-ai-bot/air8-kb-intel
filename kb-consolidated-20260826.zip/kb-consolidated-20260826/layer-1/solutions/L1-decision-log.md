# L1 · Decision log

Every rule change, with what it replaced and why. A framework whose history is unreadable cannot be defended.

**Governance rule:** a threshold change must edit the Layer 1 file **and** the corresponding skill `references/` file in the same session, and land a row here. We have already shipped one silent drift (see 2026-08, hardgoods v3.0).

| Date | Change | Reason | Evidence / n |
|---|---|---|---|
| 2026-07-13 | Hardgoods v1.0 — kill-rules, 4 archetypes, fallback points. LF removed as an input; value demoted to within-tier sort | Initial build | 139 suppliers / 14,048 FRs |
| 2026-07-14 | Hardgoods v2.0–v2.1 — score-primary redesign, 0–11 additive; cadence and ticket thresholds made category-conditional | Enumerated archetypes could not generalise to unseen combinations; the discriminator differs by category (ticket in Furniture, cadence in Kitchen & Dining) | same book |
| 2026-07 | Apparel v1.1 defined — 11 points; **buyer factor removed** | Buyer credit limits are matched upstream; scoring them again double-counted and pushed every big-buyer supplier into tier A | 71 supplier-buyer flows |
| 2026-07 | Density cuts set at **7.1 / 3.2** rather than round numbers | The book measures invoices per supplier-buyer *flow*; customs measures shipments per supplier across *all* buyers. Cuts re-mapped by percentile | stickiness gaps 20.6pp and 15.7pp |
| 2026-07 | Buyer-caused churn recognised as a distinct failure mode; churn must be **attributed** before it counts as a scoring miss | 21 of 33 churned flows had `buyer_still_active = False`. Excluding them, tier B retention goes 88% → 100% and tier C 30% → 52% | 33 churned flows |
| 2026-08 | Ordering: adverse bar moved from **CRITICAL only** to **MATERIAL and above** | User decision. An undisclosed allegation is itself a finding | — |
| 2026-08 | Financing need **demoted from a filter to a tie-breaker** | It is inferential and frequently unpublished — *"not always accurate and often unresearchable"*. It now never deletes a lead; published evidence of no need goes to a visible Floor instead | — |
| 2026-08 | **BD region priority placed above the score** (India, Pakistan, then China/HK, then others) | Coverage: every BD team needs callable names in the first batch. Non-priority regions slide to the 11–20 pipeline rather than being deleted | — |
| 2026-08 | Already-financed clients **stay ranked in place**; lists are topped up around them | The overlap between the model's top picks and the existing book is the validation a reviewer wants to see | — |
| 2026-08 | Hardgoods **v3.0** — realigned to measured stickiness gaps, 0–15. Activity re-banded; **product breadth and buyer quality added**; country dropped; category re-weighted | Same methodology as apparel v1.1, which is what allows both verticals in one skill | book, flow-level; validation 86% / 77% / 16% |
| 2026-08 | **Drift found and closed:** v3.0 had lived only in a spreadsheet while the deployed hardgoods skill still ran v2.1 | Two copies of a number with no governance rule. This log and the rule above exist because of it | — |

## Rules for changing a rule

| Trigger | What is permitted |
|---|---|
| **A — new FR / lending data** | Re-measure the stickiness gap at each cut and one notch either side. Move a cut only if the gap peak genuinely moved and n ≥ 5 in the affected cell (hardgoods: n ≥ 10 preferred for activity). Re-tune a threshold only if the new optimum moves more than 25% |
| **B — BD outcome tags** | Validate tiers against contact-to-conversion. Do **not** refit on a handful of calls: retention and conversion are different targets. At 30+ negatives, build the first true conversion model |
| **C — a single counter-example** | Log it. Change nothing. Three consistent exceptions pointing the same way → revisit that rule |

| 2026-08-25 | **QAQC dimension added to F2 scorecard (Dimension 3)** — 5 metrics: Product Risk Category (12.5%) / Order Volume (12.5%) / Defect Type/Ratio (25%) / Re-Inspection Ratio (5%) / 1st Final Inspection Pass Ratio (45%). Apparel and H&H have separate band tables. | Thresholds supplied by Jerri Zhou (screencap 2026-08-25). | Jerri Zhou (direct) |
| 2026-08-25 | **F2 merge weights confirmed by Jerri Zhou:** Performance 45% / B/S Pair 40% / QAQC 15%. Formula: `composite = (perf/6 × 0.45) + (bs/8 × 0.40) + (QAQC_raw × 0.15)`. 2-dim fallback (Perf 56% / B/S 44%) when QAQC unavailable. | Jerri Zhou (direct, 2026-08-25) | — |
| 2026-08-25 | **Performance dimension thresholds activated** (valid_from 2026-08-25): on-time ≥95%→3 / 85–94%→1 / <85%→0; doc accuracy ≥95%→2 / 80–94%→1 / <80%→0; discrepancy <1%→+1 / 1–5%→0 / >5%→-1 | Jerri Zhou (confirmed 2026-08-25) | — |
| 2026-08-25 | **B/S Pair dimension thresholds activated** (valid_from 2026-08-25): buyer concentration ≥50%→3 / 25–49%→2 / <25%→1; tenure ≥24m→2 / 12–23m→1 / <12m→0; flow RISING/STABLE→2 / DECLINING→0; programme ACTIVE→+1 / DEAD→0 / DEAD+no-replacement→-1 | Jerri Zhou (confirmed 2026-08-25) | — |
| 2026-08-25 | **F3 Buyer Assessment skeleton built** — NODE-buyer-indicator, NODE-buyer-scoring-framework, NODE-pair-terms-matrix. Structure confirmed; scoring bands TBD pending Jerri calibration data. | Framework alignment session (Jerri Zhou) | Pending |
| 2026-08-25 | **L1-performance-coverage built** — F2 CP1 coverage gate. Defines FR minimums (n≥3, recency ≤24m), buyer lookup sequence, QAQC coverage check, ENRICHMENT/STALE/INSUFFICIENT distinction. | Framework alignment session | — |
| 2026-08-25 | **NODE-pair-terms-matrix built** — Buyer tier × Supplier tier → pair financing terms matrix. Values TBD pending F3 calibration. | Framework alignment session | Pending |

## Open items

- **Pre-2024 FR lending export** still needed (supplier, actual_lending_date, buyer, amount) for timing-correct validation of churned clients. Until it arrives, low scores on long-churned clients are unproven in both directions
- **Conversion model** blocked on 30+ BD outcome negatives
- **Growth measured on counts, not value** — flag if a batch carries value data
- **Hardgoods product breadth censored at 10** by the source field; the ≥8 band is conservative by construction
