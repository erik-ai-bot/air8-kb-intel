# L1-compliance-response.md — Response Playbooks by Regulation Trigger

**Purpose:** For each regulation trigger, the exact response playbook — what to do, who does it, by when, and what escalation applies. Use after L1-compliance-interpretation.md confirms applicability.

---

## REACH SVHC — Article 33 Notification Triggered

**Trigger condition:** Substance on ECHA Candidate List is present in finished article at >0.1% w/w.

### Immediate Actions (Within 45 days of determination)

1. **Identify substance precisely:**
   - Get exact CAS number, SVHC name as listed on ECHA candidate list
   - Get measured or calculated concentration (% w/w in finished article)
   - Get location in article (which component/material)

2. **Downstream user notification (B2B):**
   - Supplier (client) must provide to their direct customer (EU importer/buyer):
     - Name of SVHC substance
     - Concentration (at minimum ">0.1%")
     - Safe use information (safe handling, disposal)
   - Format: Written communication (email acceptable, but keep records). Many buyers have compliance portals (e.g., Higg Index, supplier declarations on Ariba/SAP).
   - **Obligation is on the article supplier at each step in the chain.** Non-EU manufacturer → EU importer; EU importer → EU distributor; etc.

3. **Consumer notification (B2C):**
   - If product may reach consumers: any consumer can request SVHC information. Supplier must respond within 45 days.
   - Practical: set up product information system (can be simple spreadsheet/web page per product) so EU AR can respond.

### Within 6 Months: SCIP Database Submission

- **Who:** EU importer of articles (NOT the non-EU manufacturer directly, but manufacturer should provide data to enable EU importer to submit)
- **What:** Submit article information to ECHA SCIP database including:
  - Article name, category, identifier
  - SVHC substance name, CAS, concentration range
  - Safe use information
- **Cost: FREE.** ECHA SCIP submission has no fee. Third-party test to confirm substance presence/concentration: €500–2,000 per product (varies by lab, substance, number of SVHCs).
- **Platform:** ECHA SCIP submission tool (iuclid.eu or ECHA SCIP notifier)
- **Note:** Many EU importers (buyers) will ask the CN supplier to provide pre-filled SCIP data; coordinate with buyer's compliance team.

### Ongoing

- Re-check every 6 months when ECHA updates the Candidate List (typically June and December).
- If newly listed substance is found in existing products, restart notification process within 45 days of listing date.
- Maintain internal record: which products contain which SVHCs at what concentration.

### Cost Summary

| Item | Cost | Who Pays |
|---|---|---|
| SCIP database submission | FREE | EU importer |
| 3rd party substance confirmation test | €500–2,000/product | Typically supplier (CN manufacturer) |
| Internal compliance records | Staff time only | Supplier |

---

## GPSR — General Product Safety Regulation Triggered (Non-EU Manufacturer)

**Trigger condition:** Product is a consumer product sold on EU market AND manufacturer is established outside the EU.

### Step 1: Appoint EU Authorised Representative (Immediately — before shipment)

- **Who appoints:** Non-EU manufacturer (Air8's client)
- **Providers:** Many established AR service companies (e.g., Lexagent, Bureau Veritas, SGS, local law firms)
- **Cost:** €300–800/year for standard AR-only service; more if combined with CE marking management
- **What AR does:** 
  - Acts as legal contact point for EU market surveillance authorities
  - Name + address + email must appear on product or packaging
  - Must be contactable; responds to authority queries within **10 working days**
  - Must have access to technical file (can be hosted digitally; AR holds access)

### Step 2: Prepare Technical File

Technical file must contain:
1. General description of the product
2. Essential characteristics relevant to safety
3. Analysis of risks and solutions
4. List of standards applied (EN standards or alternative methods)
5. Declaration of Conformity (DoC)
6. Test reports (from accredited lab where applicable)
7. Labels/instructions for use

**Who prepares:** The manufacturer (client). AR holds and presents but does not create.

**Storage:** Must be accessible for 10 years after last product placed on market (retain even after product discontinued).

### Step 3: Label Product/Packaging

Mandatory on product or on packaging or on accompanying document:
- Manufacturer name + registered trade name/trademark
- Manufacturer postal address
- Manufacturer email address
- **EU Authorised Representative:** name, postal address, email — this is new under GPSR (was not mandatory under old GPSD)
- Unique product identifier (type, batch, serial, or model number)
- Any warnings or safety information (in language of market)

### Step 4: Declaration of Conformity (DoC)

DoC must state:
- Product identification (name, type, batch/serial)
- Manufacturer name + address
- EU AR name + address
- Standards or technical specifications applied
- Statement of conformity ("This product meets the requirements of GPSR (EU) 2023/988")
- Place + date + signature of person responsible
- Keep DoC for 10 years

### Ongoing

- EU AR must respond to market surveillance authority queries within **10 working days**.
- If product found unsafe: manufacturer/AR must cooperate with recall/corrective action.
- Update technical file if product design changes.

### GPSR Timeline Reference

| Date | Event |
|---|---|
| June 2023 | GPSR entered into force |
| December 13, 2024 | GPSR began to apply (enforcement start) |
| NOW | Full compliance required for all new EU consumer product shipments |

---

## UFLPA — Uyghur Forced Labor Prevention Act Triggered (China Origin)

**Trigger condition:** Goods imported into the US that were wholly or partly produced in Xinjiang, OR by an entity on the UFLPA entity list.

### Step 1: Supply Chain Mapping (Immediately upon identification)

Map supply chain Tier 1–3 for Xinjiang exposure:
- **Tier 1:** Direct supplier (client's factory)
  - Location? Any Xinjiang-based facilities?
  - Are workers sourced from Xinjiang labor transfer programs?
- **Tier 2:** Client's raw material suppliers (fabric mills, chemical suppliers, component makers)
  - Do any source from Xinjiang? (cotton, polysilicon, tomatoes, aluminum common Xinjiang products)
- **Tier 3:** Raw material inputs at Tier 2
  - Particularly critical for cotton (seed-to-fiber chain), polysilicon (solar), and yarn

**Xinjiang-sensitive material categories:**
- Cotton and cotton products
- Polysilicon (solar/electronics)
- Tomato products
- Apparel and textiles
- PPE
- Aluminum (smelting)

### Step 2: Prepare "Clear and Convincing Evidence" Package

If there IS Xinjiang exposure in supply chain, the US importer (buyer) must provide CBP with:
1. **Supplier attestations:** Each tier supplier states in writing they do not use Xinjiang-origin materials or forced labor
2. **Origin documentation:** Mill certificates, transaction records, shipping documents tracing material from origin
3. **Third-party audit:** Independent social audit of Xinjiang-proximate suppliers (SMETA 4-pillar preferred)
4. **OFAC/entity list check:** Confirm no supplier on UFLPA Entity List

If NO Xinjiang exposure: document that determination with supplier attestations and retain records.

### Step 3: Engage US Importer (Buyer)

- UFLPA burden falls on US importer of record (the buyer, not Air8's client directly)
- Air8's client must **provide documentation** to enable buyer to comply
- Coordinate with buyer's compliance/trade team on what specific documents they need
- Many large US buyers have standard UFLPA questionnaires for suppliers

### Ongoing

- Check UFLPA entity list monthly: [dhs.gov/uflpa-entity-list](https://www.dhs.gov/uflpa-entity-list)
- List is updated irregularly — new additions can happen at any time
- If any Tier 1–3 supplier appears on list: immediately flag to buyer, halt shipment until resolved
- Re-run supply chain mapping annually or on any supplier change

### Entity List Check Protocol

```
1. Go to dhs.gov/uflpa-entity-list
2. Download current list (Excel/PDF)
3. Search against all Tier 1-3 supplier names (including Chinese characters + romanization)
4. Document date of check + result
5. Log in Air8 internal compliance tracker
```

---

## Buyer RSL — Restricted Substances List Triggered

**Trigger condition:** Buyer (e.g., Target, Walmart, IKEA, H&M) has an RSL that applies to the product category.

### Step 1: Obtain Buyer's RSL and Test Protocol

- Access buyer's compliance portal (most large buyers have one: Target Restricted Substances, IKEA IWAY, H&M Chemical Restrictions)
- Download current version of RSL + test protocol (these update periodically — always use current version)
- Identify applicable test methods: EN/ISO or ASTM/CPSC or proprietary
- Identify which product categories and materials require testing

### Step 2: Commission Third-Party Testing

- Use ISO 17025 accredited laboratory: SGS, Bureau Veritas (BV), Intertek, TÜV Rheinland, Eurofins
- Submit samples representative of production (buyer will specify sample size; typically 3–5 units)
- Request test scope: **must match buyer's RSL exactly.** Do not use generic "full RSL" test if buyer specifies particular substances.
- Turnaround: typically 10–15 business days for full RSL
- Cost: €800–3,000 depending on material complexity and number of substances

### Step 3: Evaluate Results

- If PASS: obtain test report, upload to buyer's compliance portal, retain copy for 3+ years
- If FAIL:
  - Identify which substance, in which material, at what level
  - Engage supplier for that material to reformulate or substitute
  - Re-test reformulated material/product before shipment
  - Do NOT ship product failing RSL without buyer's explicit written waiver (rarely granted)

### Report Validity

- Standard validity: **1 year** from test date (buyer-specific; check their policy)
- Triggers for mandatory re-test before expiry:
  - Material change (new supplier, new dye batch, formulation change)
  - Buyer RSL update that adds substances not covered in existing test
  - Production facility change

---

## REACH Annex XVII (Hard Restriction) Triggered

**Trigger condition:** Substance in product exceeds threshold under a specific Annex XVII restriction entry.

### THIS IS A PROHIBITION, NOT A NOTIFICATION OBLIGATION

- **Do NOT ship.** Annex XVII restrictions are hard bans on placing products on the EU market. There is no notification to file that resolves this. The product is non-compliant and cannot be sold.
- **Escalation mandatory:** Immediately flag to client AND to buyer. Do not proceed with shipment until resolved.

### Response Actions

1. **Identify the specific Annex XVII entry** triggered — the restriction, threshold, and any transition period.
2. **Determine transition period:** Some entries have a date from which the restriction applies. Check if that date has passed.
3. **If transition period still active:** Note exact end date. Client may still ship before that date, but must reformulate before it.
4. **If restriction is in force:** Product must not be placed on EU market. Options:
   - **Reformulate:** Remove or replace restricted substance. Re-test. Typical timeline: 3–12 months depending on material.
   - **Divert to non-EU market:** If US or other market is not subject to same restriction, consider redirecting this production run (check applicable rules for that market first).
   - **Scrap:** Last resort if reformulation not feasible and no alternative market.
5. **Document decision** in client file with restriction entry reference and date.

---

## Escalation Rules

### When Air8 Must Flag to Client (Not Just Note Internally)

| Trigger | Required Action | Urgency |
|---|---|---|
| REACH Annex XVII hard ban confirmed | Flag to client + flag to buyer. Recommend hold. | Immediate — same day |
| GPSR EU AR missing, product already shipping to EU | Flag to client. Recommend EU AR appointment before next shipment. | Within 24 hours |
| SCIP notification obligation missed (EU importer has overdue obligation) | Flag to client to notify their EU importer/buyer. | Within 48 hours |
| UFLPA entity list match found for Tier 1–3 supplier | Flag to client AND US buyer immediately. Recommend halt until resolved. | Immediate |
| Buyer RSL test FAIL | Flag to client with specific substance and concentration. Do not ship. | Immediate |
| New SVHC listing affects products in current/recent shipments | Notify client within 10 days of listing date. Provide 45-day downstream notification requirement. | Within 10 days of ECHA update |

### When Air8 Notes Internally but Does Not Escalate

| Situation | Action |
|---|---|
| SVHC confirmed, notification obligation already underway by client | Log in tracking system. Confirm SCIP submission deadline. |
| AR appointed, technical file in progress | Log progress. Verify before next EU shipment. |
| UFLPA supply chain mapping complete, no Xinjiang exposure found | Document and retain. No escalation needed. |
| RSL test pass received | File report. Note expiry date. No escalation. |

---

## Cross-Reference Links

- [L1-compliance-interpretation.md](L1-compliance-interpretation.md) — Applicability determination (run before this playbook)
- [L2/NODE-compliance-product-eu.md](../L2/NODE-compliance-product-eu.md) — Full REACH Annex XVII entries, SVHC list, GPSR technical requirements
- [L2/NODE-compliance-buyer-rsl.md](../L2/NODE-compliance-buyer-rsl.md) — Buyer-specific RSL protocols, lab approval lists, compliance portal access

---

*Last updated: 2026-08-26 | Owner: Compliance KB*
