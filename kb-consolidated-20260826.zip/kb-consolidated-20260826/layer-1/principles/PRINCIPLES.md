---
type: reasoning
id: PRINCIPLES
---

# Air8 Reasoning Principles — Layer 1

This file defines all reasoning principles used by the Air8 KB engine.

## Naming Convention

Two types of principles — both live in this file:

| Prefix | Type | Role | When applied |
|---|---|---|---|
| **PRIN-** | Primary principle | Entity-focused reasoning activated by event type via `[:ACTIVATES]` edge with weight | Step 2-3 of REASONING-FLOW.md (entity type weighting) |
| **RP-** | Overlay rule | Cross-cutting reasoning applied AFTER primary signal | Steps 4-6 of REASONING-FLOW.md (signal qualification) |

**PRIN-*** principles are weighted and drive entity type scoring (country / product / persona).
**RP-*** rules are weightless overlays that qualify, flip, or time-slice the primary signal.

**Design rule:** Principles reason about entity types — they do not point to specific entity instances.
The event context fields determine which actual entities are retrieved; principles define the reasoning logic.

See `ARCHITECTURE.md` for the full weight calculation engine.

---

## Principle Summary Table

| Principle ID                  | Name                              | entity_focus                    | Activated By                                                                 |
|-----------------------------|-----------------------------------|--------------------------------|------------------------------------------------------------------------------|
| PRIN-COUNTRY-EXPOSURE        | Country Exposure                   | country                        | EVT-TARIFF, EVT-CURRENCY, EVT-MARKET-SHIFT, EVT-SUPPLY-DISRUPTION           |
| PRIN-PRODUCT-TARIFF          | Product Tariff                     | product_category               | EVT-TARIFF, EVT-REGULATION                                                   |
| PRIN-SUPPLIER-RESILIENCE     | Supplier Resilience                | persona                        | EVT-TARIFF, EVT-CURRENCY, EVT-MARKET-SHIFT, EVT-SUPPLY-DISRUPTION           |
| PRIN-BUYER-GEO-EXPOSURE      | Buyer Geo Exposure                 | country (buyer side)           | EVT-REGULATION, EVT-ESG-CERT, EVT-MARKET-SHIFT                              |
| PRIN-COMPLIANCE-COST         | Compliance Cost                    | product_category + persona     | EVT-REGULATION, EVT-ESG-CERT                                                |
| PRIN-FINANCING-MATCH         | Financing Match                    | persona + financing_product    | EVT-CURRENCY, EVT-ESG-CERT, EVT-SUPPLY-DISRUPTION                           |
| RP-PEER-FAILURE              | Peer Failure Correction             | persona                       | Any competitor closure / factory shutdown event                              |
| RP-STRUCTURAL-CHANGE         | Structural vs Cyclical              | (overlay — applies to all)   | Run after every signal before finalizing                                     |
| RP-WINDOW                    | Cliff Date / Action Window          | (overlay — applies to all)   | Run after every signal; flag active cliff dates                              |
| RP-CONCENTRATION             | Portfolio Concentration             | (overlay — applies to all)   | Run after every signal for portfolio-level risk                              |
| RP-CASCADE                   | Cascade / Downstream                | (overlay — applies to all)   | Supply disruption, factory closure events                                    |
| RP-EVT-DUTY-01               | Import/Export Duty → Pass-Through  | country + product_category     | EVT-TARIFF (subtype: import_export_duty)                                    |
| RP-EVT-ENVCOMP-01            | Env. Compliance → Scope/Timeline   | product_category + persona    | EVT-REGULATION (subtype: environmental_compliance)                          |
| RP-EVT-TRACE-01              | Traceability → Chain of Custody    | product_category               | EVT-REGULATION (subtype: traceability)                                      |
| RP-EVT-FX-01                 | FX Rate Move → Natural Hedge        | country                        | EVT-CURRENCY (subtype: fx_rate)                                             |
| RP-EVT-BUYERCREDIT-01        | Buyer Credit → Cascading Exposure   | persona                        | EVT-SUPPLY-DISRUPTION (subtype: buyer_credit_event)                        |
| RP-EVT-SOURCSHIFT-01         | Sourcing Shift → Multi-Combo Impact | country                        | EVT-MARKET-SHIFT (subtype: sourcing_strategy_shift, nearshoring)             |
| RP-EVT-POLINSTAB-01          | Political Instability → Disruption  | country                        | EVT-SUPPLY-DISRUPTION (subtype: political_instability)                      |
| RP-EVT-CMDTYSHORT-01         | Raw Material Shortage → WC Impact   | persona + product_category    | EVT-SUPPLY-DISRUPTION (subtype: raw_material_shortage, allocation_constraint) |
| RP-EVT-MKTENTRY-01           | Buyer Market Entry/Exit → PO Impact | persona                       | EVT-MARKET-SHIFT (subtype: market_entry_exit)                               |
| RP-EVT-SUPCHAIN-01           | Supply Chain Disruption → Tenor     | persona                        | EVT-SUPPLY-DISRUPTION (subtype: logistics_disruption, lead_time_change, factory_capacity_change) |
| RP-EVT-SUPCONSOLIDATE-01     | Supplier Consolidation → Depth     | persona                        | EVT-MARKET-SHIFT (subtype: supplier_consolidation)                          |
| RP-EVT-PRODTREND-01          | Product Trend → Category Trajectory | persona                        | EVT-MARKET-SHIFT (subtype: product_trend_change)                            |
| RP-EVT-PRODTECH-01           | Product Tech Disruption → Moat      | persona                        | EVT-MARKET-SHIFT (subtype: product_technology_disruption)                  |
| RP-EVT-DOUBLE-COMPRESS      | Double Tariff Compression           | country + product_category     | Any tariff event — check active_event_cache for co-occurring input + output tariff |
| RP-EVT-SEASONAL-LOCK        | Annual Purchase Cycle → Step-Down   | persona                        | Any event on seasonal category (outdoor furniture, holiday décor, home textile seasonal) |
| RP-EVT-SEGMENT-BIFURCATE    | Apparent Substitution → Bifurcation | country                        | Any sourcing shift event — verify segment overlap before calling substitution |
| RP-EVT-CORRELATED-PAIR       | Multiple Events → Combined Read     | (overlay — applies to all)    | Run when active_event_cache has ≥2 events with ≥2 overlapping tags         |

---

## PRIN-COUNTRY-EXPOSURE — Country Exposure

**entity_focus:** `country`

### Description
Assesses the geographic risk profile of a supplier's country of origin or a relevant country in the trade lane. Covers tariff exposure by country of origin, political stability, banking/FX access, regulatory environment, and trend trajectory.

### What Questions It Answers
- What is the current US/EU tariff rate for goods originating from this country?
- Is this country on the UFLPA "risk" watchlist?
- What is the political stability score? Is there active unrest?
- What is the FX volatility history? Are currency controls in place?
- Is the country gaining or losing buyer PO allocation (3-year trend)?
- What preferential trade agreements apply (GSP, EBA, FTA)?

### What Data It Pulls from Layer 2
- `layer-2-entities/countries/<Country>.md` — full country profile
  - Tariff exposure fields: `us_tariff_rate`, `eu_tariff_rate`, `gsp_status`, `uflpa_risk`
  - Risk fields: `political_stability`, `fx_volatility`, `banking_access`
  - Trend fields: `buyer_allocation_trend`, `infrastructure_score`

### Reasoning Logic
1. Match `Event.supplier_country` → Country node (role: supplier_origin, weight 0.7)
2. Match `Event.buyer_geo` → Country node (role: buyer_geo, weight 0.3)
3. For supplier country: output tariff exposure + political risk + FX risk
4. For buyer country: output import restriction risk + regulatory jurisdiction
5. Flag any active sanctions, entity list entries, or UFLPA high-risk status

### Activated By (Backlinks)
| Event Type          | Weight | Rationale                                             |
|---------------------|--------|-------------------------------------------------------|
| EVT-TARIFF          | 0.5    | Tariff changes are country-of-origin driven           |
| EVT-CURRENCY        | 0.6    | FX events are fundamentally country-level             |
| EVT-MARKET-SHIFT    | 0.4    | Origin country is gaining or losing PO allocation     |
| EVT-SUPPLY-DISRUPTION | 0.5  | Disruption is geographically localized                |

---

## PRIN-PRODUCT-TARIFF — Product Tariff

**entity_focus:** `product_category`

### Description
Assesses the tariff and regulatory exposure specific to a product category, based on HS code classification, material composition, and applicable trade measures. Identifies duty rates, anti-dumping exposure, and material substitution options that could reduce duty burden.

### What Questions It Answers
- What is the applicable HS code for this product and what duty rate applies?
- Is this product category subject to anti-dumping duties or safeguards?
- What material substitutions could shift the product to a lower-tariff HS code?
- Which compliance tests are required for this product category in the target market?
- What are the lead times and seasonal demand patterns that affect cash cycle?

### What Data It Pulls from Layer 2
- `layer-2-entities/product-categories/APPAREL.md` or `HARDGOODS.md`
  - `hs_codes`, `duty_rates`, `anti_dumping_exposure`
  - `compliance_requirements` (REACH, UFLPA, CARB, UL, CE)
  - `lead_time_days`, `seasonality`, `material_substitution_options`
- `layer-2-entities/financing-products/PROD-*.md` (when HS code triggers financing need)

### Reasoning Logic
1. Match `Event.product_category` + `Event.material` → ProductCategory node
2. Look up applicable duty rates for the origin→destination lane
3. Check for anti-dumping measures specific to this product + country combination
4. Identify material substitution options (e.g., zamak vs brass, recycled poly vs virgin)
5. Flag compliance tests required and their lead times (affects production scheduling)

### Activated By (Backlinks)
| Event Type       | Weight | Rationale                                                     |
|------------------|--------|---------------------------------------------------------------|
| EVT-TARIFF       | 0.3    | Product HS code determines applicable duty rate               |
| EVT-REGULATION   | 0.3    | Regulation scope is product-category and material-specific    |

---

## PRIN-SUPPLIER-RESILIENCE — Supplier Resilience

**entity_focus:** `persona`

### Description
Assesses a supplier's structural ability to absorb the impact of an event based on their archetype (persona). Covers revenue scale, buyer concentration, financing sophistication, ESG credentials, and operational flexibility. Uses tag overlap scoring to identify which COMBO persona(s) best match the supplier's profile.

### What Questions It Answers
- Can this supplier absorb a 15% margin squeeze without becoming a credit risk?
- How concentrated is this supplier's buyer base — is there a single-buyer dependency?
- Does the supplier have access to alternative financing (bank LC, local credit)?
- What is the supplier's financial literacy level — can they act on advice?
- Which persona archetype does this supplier most closely match?
- What pain points are most acute for suppliers of this type?

### What Data It Pulls from Layer 2
- `layer-2-entities/personas/COMBO-*.md` — scored by tag overlap ≥ 2
  - Dimensions: `country`, `revenue_band`, `company_type`, `product_focus`, `target_market`, `current_financing`, `growth_stage`, `buyer_profile`
  - Characteristics: `cash_cycle_days`, `margin_range`, `buyer_count`, `workforce_size`
  - Pain points linked from `layer-1-reasoning/pain-points/`

### Reasoning Logic
1. Build `eventTags` from: `supplier_tier`, `product_category`, `buyer_geo`, `material`
2. Score ALL Persona nodes: `overlap = size([t IN p.tags WHERE t IN eventTags])`
3. Return all personas with overlap ≥ 2
4. For each matched persona: load pain points + characteristics
5. Map pain points to urgency level given the event type (tariff hit → PP-002 intensifies)
6. Flag if any matched persona has `buyer_concentration > 30%` → heightened risk

### Activated By (Backlinks)
| Event Type          | Weight | Rationale                                                   |
|---------------------|--------|-------------------------------------------------------------|
| EVT-TARIFF          | 0.2    | Margin hit severity depends on supplier's buffer capacity   |
| EVT-CURRENCY        | 0.3    | Hedging ability varies significantly by supplier archetype  |
| EVT-MARKET-SHIFT    | 0.2    | Revenue concentration risk amplifies market shift impact    |
| EVT-SUPPLY-DISRUPTION | 0.4  | Supplier's ability to reroute/absorb disruption is archetype-dependent |

---

## PRIN-BUYER-GEO-EXPOSURE — Buyer Geographic Exposure

**entity_focus:** `country` (buyer side)

### Description
Assesses import restriction risk, regulatory jurisdiction, and demand sensitivity from the **buyer's** geography perspective. Where PRIN-COUNTRY-EXPOSURE looks at the supplier-origin country, this principle looks at the destination/buyer country to determine what rules govern the goods once they arrive and how buyer-side demand may be affected.

### What Questions It Answers
- What import regulations apply in the buyer's market (US UFLPA, EU CSDDD, CA GPSR)?
- Is there an active regulatory enforcement action at this buyer geography's ports?
- How ESG-sensitive are buyers in this market — what certification mandates are active?
- What is the buyer's financial health in this market — is there buyer distress risk?
- What is the demand trend in this market for this product category?

### What Data It Pulls from Layer 2
- `layer-2-entities/countries/<BuyerCountry>.md`
  - `import_regulations`, `enforcement_activity`, `esg_mandate_level`
  - `demand_trend`, `market_growth_rate`
- `layer-2-entities/personas/COMBO-*.md` — buyer profile fields from matched personas
  - `buyer_profile` dimension (fast_fashion, mass_market, premium)

### Reasoning Logic
1. Match `Event.buyer_geo` → Country node (buyer_geo role)
2. Load applicable import regulations and current enforcement posture
3. Assess ESG mandate level (EU = HIGH, US = MEDIUM, developing = LOW)
4. Check for active port enforcement actions (UFLPA detentions, GPSR market surveillance)
5. Output buyer-side risk signals separately from supplier-side risk

### Activated By (Backlinks)
| Event Type       | Weight | Rationale                                                         |
|------------------|--------|-------------------------------------------------------------------|
| EVT-REGULATION   | 0.2    | Regulation jurisdiction is buyer-geography driven                 |
| EVT-ESG-CERT     | 0.3    | ESG certification mandates originate from buyer market            |
| EVT-MARKET-SHIFT | 0.4    | Buyer allocation shift is a buyer-geo-level decision              |

---

## PRIN-COMPLIANCE-COST — Compliance Cost

**entity_focus:** `product_category` + `persona`

### Description
Assesses the cost, timeline, and operational burden of compliance with a specific regulation or ESG standard. This principle is unique in having **dual entity focus** — compliance cost depends on both the product (what tests are needed) and the supplier archetype (who bears the cost and whether they can absorb it).

### What Questions It Answers
- How much does compliance testing/certification cost for this product in this market?
- How long does the compliance process take (affects production scheduling)?
- Can the matched supplier archetype absorb this cost given their margin profile?
- Will compliance cost cause a price renegotiation with the buyer?
- Is there a financing mechanism (ESG Finance) to offset certification costs?
- What is the certification validity period — is annual renewal a recurring cost?

### What Data It Pulls from Layer 2
- `layer-2-entities/product-categories/APPAREL.md` or `HARDGOODS.md`
  - Section-level compliance requirements, test costs, timelines
  - WIP gate definitions (hardgoods) — which gates involve compliance tests
- `layer-2-entities/personas/COMBO-*.md` — matched personas
  - `margin_range`, `cash_cycle_days`, `financing_sophistication`
- `layer-2-entities/financing-products/PROD-ESG-FINANCING.md`
  - ESG Finance eligibility criteria

### Reasoning Logic
1. Match product category → compliance test requirements + costs
2. Match personas (overlap ≥ 2) → assess margin buffer vs compliance cost
3. If compliance cost > 5% of margin → flag as HIGH compliance burden
4. If IFC criteria could be met → flag ESG Finance eligibility
5. Output compliance timeline to identify if it creates a production scheduling conflict

### Activated By (Backlinks)
| Event Type       | Weight | Rationale                                                     |
|------------------|--------|---------------------------------------------------------------|
| EVT-REGULATION   | 0.5    | Regulatory compliance is the primary compliance cost driver   |
| EVT-ESG-CERT     | 0.4    | ESG certification costs are the defining feature of this event |

---

## PRIN-FINANCING-MATCH — Financing Match

**entity_focus:** `persona` + `financing_product`

### Description
Maps a supplier's acute pain points (surfaced by the event) to the most appropriate Air8 financing product. This is the output-oriented principle — it translates risk signals into actionable financing recommendations. Uses the linkage tables to find best-fit product-persona pairings.

### What Questions It Answers
- Given this event and supplier archetype, which Air8 product addresses the core pain?
- What are the eligibility criteria, and does the supplier likely qualify?
- What is the urgency — is this an immediate liquidity need or a structural optimization?
- What NOT to recommend — which products are contraindicated for this scenario?
- What is the revenue opportunity for Air8 if the product is deployed?

### What Data It Pulls from Layer 2
- `layer-2-entities/financing-products/PROD-*.md` — all 9 products
  - `eligibility`, `applies_when`, `not_suitable_when`, `key_differentiators`
- `layer-2-entities/personas/COMBO-*.md` — matched personas
  - Pain points → cross-referenced with `layer-1-reasoning/pain-points/`
- `linkage/linkage-persona-full.md` — pre-computed persona → product mappings
- `linkage/linkage-product-reverse.md` — product → best-fit combos

### Reasoning Logic
1. Identify active pain points for matched personas given the event type
2. Rank pain points by severity (event-amplified pain = +1 urgency level)
3. Look up `linkage-persona-full.md` for pre-computed product fit
4. Cross-check eligibility against likely supplier profile (revenue, ops history)
5. Flag any contraindications (adverse buyer news, no insurance available)
6. Output ranked product recommendations with rationale

### Activated By (Backlinks)
| Event Type          | Weight | Rationale                                                          |
|---------------------|--------|---------------------------------------------------------------------|
| EVT-CURRENCY        | 0.1    | FX events create acute financing need (currency hedging, liquidity) |
| EVT-ESG-CERT        | 0.3    | ESG Finance product is uniquely activated by ESG events             |
| EVT-SUPPLY-DISRUPTION | 0.1  | Emergency liquidity needs arise from disruptions                    |

---

## RP-EVT-DUTY-01 — Import/Export Duty Change → Blend Ratio and Pass-Through

**entity_focus:** `country` + `product_category`

### Description
When a duty change event fires, this principle forces the LLM to ask who captures the duty benefit — factory or buyer — and whether the pass-through is real or contractual. Most LLMs assume duty savings flow to the factory. Most don't.

### What Questions It Answers
- Does the duty saving apply to the factory or does buyer-nominated purchasing mean it stays with the buyer?
- What % of the input is imported vs domestic? Duty saving is pro-rated by import proportion.
- Is there a domestic price floor (MSP, CCI) that means the factory can't benefit even if world prices fall?
- Are existing supply contracts fixed for 90-180 days, creating a lag before new pricing takes effect?
- Under cost-plus pricing, does the factory pass savings to buyer automatically?

### LLM Directive Template
> For [duty change] on [material]: (1) Who purchases the input — factory or buyer? (2) What is the domestic vs imported blend ratio? (3) Is there a government support price floor? (4) Are existing supply contracts fixed or floating? (5) What is the realistic lag before new pricing takes effect (typically 90-180 days for yarn/fabric)?

---

## RP-EVT-ENVCOMP-01 — Environmental Compliance Event → Scope and Timeline

**entity_focus:** `product_category` + `persona`

### Description
Forces the LLM to distinguish between which jurisdictions are in scope, what existing certs partially satisfy the requirement, and whether the cost is an audit fee or a structural remediation that requires capital expenditure.

### What Questions It Answers
- EU only, US only, or both? Scope determines which buyer geographies are affected.
- Which existing certifications partially satisfy the new requirement (REACH ≠ ZDHC MRSL ≠ ESPR)?
- Is the cost a $3-15K audit or a $20-100K+ structural remediation?
- Is there a shipment detention risk post-effective-date if the supplier hasn't remediated?

### LLM Directive Template
> For [regulation]: (1) Which jurisdictions and buyer geographies are in scope? (2) What is the mandatory effective date? (3) Which existing certs partially satisfy this? (4) What is the typical audit + remediation cost for a mid-size supplier? (5) What is the enforcement mechanism (customs detention, buyer audit, regulator inspection)?

---

## RP-EVT-TRACE-01 — Traceability Requirement → Chain of Custody Depth

**entity_focus:** `product_category`

### Description
Forces the LLM to identify the required chain-of-custody depth (yarn/fiber/farm level) and whether the combo already has infrastructure. UFLPA and EU DPP have specific enforcement consequences — this principle flags the Air8 receivable risk if shipment is detained.

### What Questions It Answers
- Does the requirement go to yarn level, fiber level, or farm level?
- Which combos already have chain-of-custody infrastructure (GOTS, Fairtrade, T4S)?
- What is the implementation timeline for a non-compliant supplier (typically 1-3 years + capex)?
- Is this an UFLPA detention risk — which means the receivable goes unpaid?

### LLM Directive Template
> For [traceability requirement]: (1) What chain of custody depth is required? (2) Which affected combos already have infrastructure meeting this? (3) What is the timeline to implement for a non-compliant supplier? (4) What is the specific enforcement risk for Air8 (shipment detention = unpayable receivable)?

---

## RP-EVT-FX-01 — FX Rate Move → Natural Hedge Assessment

**entity_focus:** `country`

### Description
Forces the LLM to assess whether Air8's EUR/USD-denominated facility creates a natural hedge for the supplier, and which currency pairs (TRY, INR, BDT vs USD/EUR) have materially different volatility and credit access profiles.

### What Questions It Answers
- What is the typical revenue/cost currency split for this combo?
- Does the supplier have forward contracts that lock in FX?
- Does Air8's EUR/USD facility reduce or amplify the supplier's FX exposure?
- For TRY (hyperinflation): is the core problem rate or credit access?

### LLM Directive Template
> For [FX event on currency_pair]: (1) What is the typical revenue/cost currency split for [combo]? (2) Does [combo] have any forward contracts? (3) Does Air8's EUR/USD-denominated facility reduce or amplify this supplier's FX exposure? (4) What is the impact on Air8 repayment risk?

---

## RP-EVT-BUYERCREDIT-01 — Buyer Credit Event → Cascading Exposure

**entity_focus:** `persona`

### Description
Forces the LLM to check DSO trend before payment default, identify PSF/OBF anchor risk, and flag the supplier over-ship behavior that can spike Air8 exposure right at the worst time.

### What Questions It Answers
- Is DSO trending 30+ days beyond contract terms (leading indicator of default)?
- Has credit rating or coverage changed?
- Which Air8 product positions have this buyer as counterpart?
- Are suppliers over-shipping to lock in revenue before buyer halts orders (increases Air8 exposure)?

### LLM Directive Template
> For [buyer] credit event: (1) What is current DSO trend vs contract terms? (2) What credit rating/coverage signals have changed? (3) Which Air8 product positions have this buyer as counterpart? (4) What is typical supplier response to buyer distress in this category?

---

## RP-EVT-SOURCSHIFT-01 — Buyer Sourcing Strategy Shift → Multi-Combo Impact

**entity_focus:** `country`

### Description
Forces the LLM to distinguish permanent structural sourcing shifts from tactical tariff-driven diversions, and to identify which combos gain vs lose. Also flags over-commitment risk when beneficiary combos' capacity runs hot.

### What Questions It Answers
- Is the shift 12-24 month lead time meaningful volume, or still experimental?
- Is this "China+1" (complex/speed orders stay in CN, basic volume shifts)?
- Which source countries gain, which lose?
- Is the shift permanent (structural) or tactical (tariff-driven, reversible)?

### LLM Directive Template
> For [buyer sourcing shift]: (1) What product category and buyer type is shifting? (2) What is the realistic volume transfer timeline (months to meaningful impact)? (3) Which source countries gain, which lose? (4) Is this shift permanent or tactical (tariff-driven vs structural)?

---

## RP-EVT-POLINSTAB-01 — Political Instability → Production Disruption Assessment

**entity_focus:** `country`

### Description
Forces the LLM to assess production disruption days, banking system integrity (can Air8 disburse/receive normally), port/logistics impact, and buyer pre-positioning behavior. Acute phase: pause new disbursements.

### What Questions It Answers
- What is the production disruption impact (days per month historically)?
- Is the banking system disrupted — can Air8 operate normally?
- Are port/logistics affected?
- What is buyer pre-positioning behavior during past disruptions?

### LLM Directive Template
> For [country] political event: (1) What is the production disruption impact (days per month historically)? (2) Is the banking system disrupted (can Air8 disburse/receive normally)? (3) Are port/logistics affected? (4) What is buyer pre-positioning behavior during past disruptions?

---

## RP-EVT-CMDTYSHORT-01 — Raw Material Shortage → Allocation and Lead Time Impact

**entity_focus:** `persona` + `product_category`

### Description
Forces the LLM to identify who controls allocation in the supply chain (vertically integrated > FOB > CMT), the double WC impact (price spike + harder to get), and the first-mover advantage for factories that lock supply early with PSF support.

### What Questions It Answers
- Who has preferential access (vertically integrated > FOB > CMT in allocation priority)?
- What is the price spike range and lead time extension?
- Which combos are most exposed (highest dependency, lowest alternative sourcing)?
- Is there a first-mover advantage in locking supply early?

### LLM Directive Template
> For [material] shortage event: (1) Who controls allocation in the supply chain? (2) What is the price spike range and lead time extension? (3) Which combos are most exposed (highest dependency, lowest alternative sourcing)? (4) Is there a first-mover advantage in locking supply early?

---

## RP-EVT-MKTENTRY-01 — Buyer Market Entry/Exit → PO Flow Impact

**entity_focus:** `persona`

### Description
Forces the LLM to assess whether a buyer's entry creates capacity over-commitment risk or whether their exit creates a PO decline leading indicator. Entry = opportunity but risk; exit = leading indicator of receivables shrinkage.

### What Questions It Answers
- Which geography and product category is the buyer entering/exiting?
- Which combos are in that geography and serve that product?
- Is this a flagship programme or trial order (volume magnitude)?
- For exit: what % of affected combos' revenue is at risk and over what period?

### LLM Directive Template
> For buyer [market entry/exit] event: (1) Which geography and product category is the buyer entering/exiting? (2) Which combos are in that geography and serve that product? (3) What is the realistic volume available — flagship or trial? (4) What is the timeline for first order vs full ramp? (5) For exit: what % of affected combos' revenue is at risk and over what period?

---

## RP-EVT-SUPCHAIN-01 — Supply Chain Disruption → Tenor and Liquidity Impact

**entity_focus:** `persona`

### Description
Forces the LLM to check whether the lead time extension pushes Air8 tenor requirements beyond standard bands and whether it crosses any cliff date. Also flags order diversion opportunity from competitor capacity changes.

### What Questions It Answers
- What is the typical lead time extension caused by this disruption?
- Does the new lead time push Air8 tenor requirements beyond standard bands?
- Are there nearby combos that benefit from competitor disruption (order diversion)?
- What is the port/logistics situation specifically — which routes and ports affected?
- What is the recovery timeline historically for this type of disruption?

### LLM Directive Template
> For [supply chain event]: (1) What is the typical lead time extension caused by this disruption? (2) Does the new lead time push Air8 tenor requirements beyond standard bands? (3) Are there nearby combos that benefit from competitor disruption (order diversion)? (4) What is the port/logistics situation specifically — which routes and ports affected? (5) What is the recovery timeline historically for this type of disruption?

---

## RP-EVT-SUPCONSOLIDATE-01 — Buyer Supplier Consolidation → Relationship Depth Signal

**entity_focus:** `persona`

### Description
Forces the LLM to distinguish retained vs cut suppliers based on ESG compliance + OTD + quality + speed criteria, not just price. Consolidation announcement is a 12-18 month leading indicator — not when cuts actually happen.

### What Questions It Answers
- Which buyers are consolidating?
- What are the consolidation criteria (ESG, OTD, quality, price)?
- Which combo types are most likely retained vs cut?
- What is the timeline — when do first cuts happen?
- Which assessment dimensions determine if a combo is in the retained or cut group?

### LLM Directive Template
> For buyer [consolidation] event: (1) Which buyers are consolidating? (2) What are the consolidation criteria (ESG, OTD, quality, price)? (3) Which combo types are most likely retained vs cut? (4) What is the timeline — when do first cuts happen? (5) For affected combos: which assessment dimensions determine if they're in the retained or cut group?

---

## RP-EVT-PRODTREND-01 — Product Trend Change → Category Trajectory + Factory Adaptability

**entity_focus:** `persona`

### Description
Forces the LLM to distinguish structural category shifts from cyclical demand blips, and to assess whether the factory is a specialist (deep moat or existential risk) or generalist (adaptable but less defensible). Price/volume behavior determines the category trajectory type.

### What Questions It Answers
- Is the YoY demand trend for this product category in EU/US markets growing or declining?
- What % of the factory's revenue is concentrated in the affected category?
- Is the factory a specialist or generalist in this category?
- Are buyers adding or cutting programmes (public sourcing announcements)?
- What investment is required to pivot to the trending product?

### LLM Directive Template
> For product trend [growing/declining] in [category]: (1) What is the YoY demand trend for [product category] in EU/US key markets — cite data. (2) Which Air8 combo types have [product category] as their primary product_type? (3) Are major EU/US buyers adding or cutting [product category] programmes — any public sourcing announcements? (4) What production investment is typically required to pivot from [current product] to [trending product] — cost range and timeline?

---

## RP-EVT-PRODTECH-01 — Product Technology Disruption → Capability Moat vs Obsolescence

**entity_focus:** `persona`

### Description
Forces the LLM to assess whether the factory has the new technology in-house (moat) or outsourced (no moat), and whether key buyers actively require or reward the technology in their scoring. COMBO-005 (TR Denim) precedent: laser/ozone in-house = moat; outsourced = no moat.

### What Questions It Answers
- What is the adoption rate among peer factories in this country?
- What is the investment required to adopt for a mid-revenue factory?
- Do key buyers actively require or preference this technology in their scoring?
- What is the timeline before non-adopters lose competitive position?

### LLM Directive Template
> For technology disruption [tech name]: (1) What is the adoption rate among peer factories in [country]? (2) What is the investment required to adopt for a [revenue band] factory? (3) Do key buyers (H&M/Zara/etc.) actively require or preference this technology in their scoring? (4) What is the timeline before non-adopters lose competitive position?

---

## RP-EVT-DOUBLE-COMPRESS — Input + Output Tariff Co-occurrence → Double Compression Flag

**entity_focus:** `country` + `product_category`

### Description
MUST check active_event_cache before emitting output. If BOTH an input tariff AND a finished goods tariff are active for the same country × category → flag DOUBLE COMPRESSION. This is structurally different from single-direction tariff: factory pays MORE to produce AND receives LESS margin on export simultaneously. No geo-arbitrage exists for global commodities (copper, aluminum, cotton).

**Key examples:** CN brass artware (T1 copper input + Section 301 finished goods to US); CN lighting (copper in drivers + Section 301); CN outdoor furniture (aluminum + anti-dumping on extrusions).

**Signal output:** CAUTION for EU-facing programs (input cost only); DO_NOT_EXPAND for US-facing programs (double compression confirmed).

### What Questions It Answers
- Is there an existing tariff in the active_event_cache on finished goods from the same country/category?
- If both active: what is the combined margin compression (input cost rise % of BOM + output tariff rate = total)?
- Is there a viable material substitution that reduces input exposure (e.g., zamak vs true brass)?
- Are alternative production origins insulated from the input tariff?

### LLM Directive Template
> For [tariff event] on [material/country]: (1) Is there an existing tariff in the active_event_cache on finished goods from the same country/category? (2) If both active: quantify the combined margin impact — input cost rise (% of BOM) + output tariff rate = total compression. (3) Is there a viable material substitution (e.g., zamak vs true brass) that reduces input exposure? (4) Are alternative production origins insulated from the input tariff (e.g., India domestic copper vs imported copper)?

---

## RP-EVT-SEASONAL-LOCK — Annual Purchase Cycle → Permanent Step-Down Amplifier

**entity_focus:** `persona`

### Description
MUST identify whether the affected category has an annual or once-per-season purchase cycle. For these categories, sourcing shifts are BINARY per season — allocation is set once and locked for 12 months. The step-down pattern is typically PERMANENT. An in-season signal reflects NEXT season's allocation, not current-year revenue.

**Seasonal categories:** outdoor furniture, seasonal/holiday décor, Christmas goods, garden products, home textile seasonal ranges.

**Booking window rule:** expand DURING the booking window (Jan–Mar for EU outdoor); in-season disbursements are limited to already-confirmed PO books only.

### What Questions It Answers
- Is this category a once-per-year purchase cycle? When is the booking window?
- Is the signal detected during the booking window (impactable) or in-season (reflects next-year outlook)?
- What is the step-down pattern — has the buyer been reducing [origin] allocation each season?
- What % of the factory's annual revenue is at risk per seasonal step-down increment?

### LLM Directive Template
> For [sourcing shift / demand event] on [seasonal category]: (1) Is this category a once-per-year purchase cycle? When is the booking window? (2) Is the signal detected during the booking window (impactable) or in-season (reflects next-year outlook)? (3) What is the step-down pattern — has the buyer been reducing China/[origin] allocation each season? (4) Is the current signal an acceleration of an existing step-down trend, or a new shift? (5) What % of the factory's annual revenue is at risk per seasonal step-down increment?

---

## RP-EVT-SEGMENT-BIFURCATE — Apparent Substitution → Verify Segment Overlap First

**entity_focus:** `country`

### Description
When a sourcing shift is reported from Origin A to Origin B, do NOT assume it's a like-for-like substitution until segment overlap is verified. Many apparent shifts are actually bifurcation into distinct buyer tiers (mass vs premium). Substitution = direct volume loss. Bifurcation = different buyer budgets, NOT direct volume loss.

**Outdoor furniture example:** China = standard-to-mid, volume-focused; Vietnam = mid-to-high, design-led. Vietnam "shift" = new premium range added, not China replaced.

**Brass artware example:** China zamak = mass market; India Moradabad true brass = premium. "Shift to India" = premium channel upgrade, not like-for-like substitution.

### What Questions It Answers
- Do Origin A and Origin B compete at the same price point and product specification?
- What is the buyer's stated intent — reallocation of existing programs or addition of a new range?
- What is the price gap — <15% (substitution plausible) or >25% (bifurcation likely)?
- What buyer tier (mass/mid/premium) does each origin serve?

### LLM Directive Template
> For sourcing shift from [origin A] to [origin B] in [category]: (1) Do origin A and origin B compete at the same price point and product specification? (2) What is the buyer's stated intent — reallocation of existing programs or addition of a new range? (3) What is the price gap between origin A and origin B products — is it <15% (substitution plausible) or >25% (bifurcation likely)? (4) For each origin: what buyer tier (mass/mid/premium) do they serve, and does the new origin displace the same tier?

---

## RP-EVT-CORRELATED-PAIR — Multiple Active Events → Combined Read Required

**entity_focus:** (overlay — applies to all)

### Description
MANDATORY Step 3b check: before emitting any event card, query active_event_cache for events with ≥2 overlapping tags (country, material, buyer_geo, event_subtype). If found → generate a COMBINED card, not standalone cards. Relationship types: AMPLIFYING / REFRAMES / OFFSETS / INDEPENDENT.

**Deduplication:** once E1+E2 produces a combined read, mark E2 as state=incorporated_in, incorporated_in=E1_card_id. When E2 fires again, emit: "This event has been incorporated into [combined card]. See combined analysis for full read."

**Example — AMPLIFYING:** Event B (CSDDD compliance pressure) + Event E (Turkey revenue -17%) for COMBO-005 → suppliers face simultaneous revenue decline AND compliance investment pressure → double WC stress → Air8 ARP + compliance financing pitch.

**Example — REFRAMES:** E7 (+20% outdoor furniture order lift) + S1 (copper/aluminum tariff) for COMBO-HG-001 → order lift is partly price-induced pull-forward, not organic growth → E7 must be downgraded from EXPAND to CONDITIONAL.

### What Questions It Answers
- Are there events in active_event_cache with ≥2 overlapping tags?
- What is the relationship type (AMPLIFYING / REFRAMES / OFFSETS / INDEPENDENT)?
- Should the combined card supersede the individual cards?

### LLM Directive Template
> Before generating output for event [new_event]: (1) Check active_event_cache — are there events with ≥2 overlapping tags (country:[x], material:[y], buyer_geo:[z])? (2) If yes: classify relationship type (AMPLIFYING / REFRAMES / OFFSETS / INDEPENDENT) with 1-sentence rationale. (3) If AMPLIFYING or REFRAMES: generate a combined card — do not emit standalone cards for each event separately. (4) Write cache entries for all correlated events with state, relationship_type, and combined_read_id.

---

## RP-CLUSTER-SOURCING-VERIFY — Artisan/Industrial Cluster Input Sourcing → Verify Per Factory, Not Per Cluster

**entity_focus:** persona (cluster-type)
**Added:** 2026-07-16 | Source: Josephine Cheung expert review — Moradabad copper sourcing correction

### Description
For personas representing artisan or industrial clusters (e.g., Moradabad brass, Yiwu small commodities, Sialkot sportswear), commodity input sourcing claims embedded in the cluster narrative (e.g., "uses domestic copper," "sources local cotton") **must be verified per factory, not assumed from the cluster-level description**.

Cluster narratives describe the typical or historical pattern for the cluster as a whole. Individual units within the cluster frequently deviate — especially at scale:
- Larger units often import inputs for specific grade/quality requirements not available domestically
- Scrap/secondary material sourcing is common at cluster level but may not match the cluster’s "domestic sourcing" narrative
- Sub-contracting and multi-tier production means input sourcing may be one step removed from the entity Air8 finances

**Trigger:** any principle or event signal that derives benefit or risk from a claimed cluster-level input sourcing pattern (e.g., “domestic copper insulates from US tariff” for Moradabad)

**Must verify before applying the signal:**
1. Does this specific factory source the input domestically or via imports? Request supplier invoices.
2. What % of input is domestic vs imported? Partial import = partial insulation only.
3. If the factory sub-contracts production, where does the sub-contractor source inputs?
4. Is the cluster narrative current? Has the sourcing pattern shifted in the past 2–3 years?

**Signal impact if sourcing not verified:**
- Do NOT apply cluster-level benefit/risk signal (e.g., copper tariff insulation) without per-factory confirmation
- Label any signal derived from unverified cluster sourcing as `[HYPOTHESIS — cluster narrative; per-factory sourcing unverified]`
- Downgrade advance ratio or signal strength until verification is complete

### Canonical Example
Moradabad cluster narrative: "India uses domestic copper — insulated from US copper import tariffs." 
Josephine correction: Moradabad imports heavily via scrap dealers; domestic copper does not hold at scale. Larger units in particular source imported scrap, not Hindalco/Vedanta domestic supply.
Brain action: do NOT apply full copper tariff insulation benefit to all Moradabad personas. Verify per factory. Apply `[HYPOTHESIS]` label until confirmed.

### LLM Directive Template
> For any signal derived from cluster-level input sourcing (e.g., domestic copper for India, domestic cotton for Pakistan): (1) Is this a cluster-level narrative or per-factory confirmed data? (2) Ask factory directly: where do you source [input]? Domestic, imported, or mixed? (3) Request supplier invoices for the past 12 months. (4) If unverified: apply [HYPOTHESIS] label; do not apply full benefit/risk signal. (5) If partially verified (e.g., 60% domestic): scale the signal proportionally.
