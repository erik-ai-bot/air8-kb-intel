# L1 · Vertical routing

How to route a supplier to the correct scoring framework **before** any scoring begins. Routing is a prerequisite, not part of scoring — a misrouted supplier produces a number that looks valid but is not.

## Why routing is its own step

Two frameworks exist (Apparel v1.1, Hardgoods v3.0/v2.1) with different max points and different calibration bases. Scores from these frameworks are **not comparable** (see L1-data-traps §5). Routing must therefore happen first, and the routing decision must be recorded alongside the score so a reviewer can audit it.

## Routing signals, in priority order

1. **HS chapter** — authoritative when present; lookup is deterministic
2. **Product description / text** — fallback when HS is absent or ambiguous; carry a downgrade note
3. **Enrichment queue** — when neither signal is available; never assign a default vertical or award a zero score

Never skip to signal 2 if signal 1 is present. If signal 1 and signal 2 conflict, flag `ROUTING CONFLICT` and note both values — do not silently prefer either.

## HS chapter → vertical mapping

| HS Chapter(s) | Route | Basis |
|---|---|---|
| 61, 62 | Apparel v1.1 | Chapter, authoritative |
| 63, 57, 94 | Hardgoods v3.0 (thin data → v2.1) | Chapter, authoritative |
| 50–60 | **PARK** — yarn and fabric mills | Chapter, authoritative |
| 69, 70, 39, 44, 73 | Hardgoods, **text confirmation required** | Chapter mixes industrial and consumer goods — see below |
| No HS found | Route on product description; carry note `confirm vertical` | Text-based |
| No HS, no text | Enrichment queue — do not score | Neither signal |

The authoritative chapter routing is maintained in `NODE-scoring-framework.md` (Routing table). This L1 file holds the reasoning; NODE-scoring-framework holds the values.

## Chapters requiring text confirmation (69, 70, 39, 44, 73)

These HS chapters contain both industrial inputs and consumer finished goods. A glazed ceramic tile (HS 6907) is an industrial product; a ceramic dinnerware set (HS 6911) is a retail consumer product. Text confirmation resolves which:

- If product descriptions confirm retail-oriented consumer goods → Hardgoods, proceed
- If product descriptions indicate industrial components or semi-finished goods → Park with note `industrial input — outside scope`
- If text is ambiguous or unavailable → Enrichment queue

**Do not score ambiguous chapter 69/70/39/44/73 suppliers as Hardgoods without text confirmation.** Routing error on text-only classification is approximately 14% versus HS-based routing.

## PARK — yarn and fabric mills (HS 50–60)

Mills are not a scoring failure; they are a structural mismatch. A yarn or fabric mill's counterparties are other factories, not retailers. The receivable risk shape (buyer is a factory, not a mass-market retailer) is fundamentally different from the profile the Apparel and Hardgoods frameworks are calibrated on. Parking them honestly avoids false precision.

- Label: `PARK — yarn/fabric mill, different receivable profile`
- Do not route to Apparel on the grounds that yarn relates to apparel
- Do not leave a score of 0 (that asserts a verdict; PARK asserts none)
- Visible in output under a "Parked" section so a reviewer can see why they are absent from the scored list

## No HS code — text-based routing

When HS codes are missing, route on product description keywords:

- Garments, clothing, apparel, knitwear, woven tops, denim, underwear, sportswear → Apparel v1.1; carry note `confirm vertical (no HS)`
- Furniture, bedding, home textiles, tableware, kitchenware, décor, toys, pet products → Hardgoods; carry note `confirm vertical (no HS)` and use v2.1 (thin data fallback) unless breadth and buyer identity are also available
- If neither description pattern matches or the description is generic (e.g. "goods", "merchandise") → Enrichment queue

**The China/HK HS gap:** In one batch of 260 China and HK suppliers, 188 arrived with no HS codes. This is a **data gap**, not a market fact — China exports cover every chapter. Do not interpret a high no-HS rate in a batch as evidence that suppliers are unclassifiable. Route what can be routed on text; queue the rest.

## What to record

Every routed supplier must carry:

| Field | What to record |
|---|---|
| `framework_id` | e.g. `fw:hardgoods-v3.0` |
| `routing_signal` | `HS` / `TEXT` / `ENRICHMENT` |
| `routing_basis` | The chapter, description text, or explicit reason |
| `routing_note` | Required when signal = TEXT; optional otherwise |
| `routing_conflict` | `TRUE` + both values when signal 1 and signal 2 disagree |

## Links

- **←ROUTES_INTO— [NODE-scoring-framework]**: Framework instances and the authoritative chapter table
- **→ENRICHMENT**: Suppliers queued here cannot be scored; named component is `routing`
- Discipline on entity resolution before routing: `L1-evidence-discipline.md §3`
- Data traps relevant to routing: `L1-data-traps.md §5` (framework scores not comparable), §6 (HS classifier discrepancy rate)
