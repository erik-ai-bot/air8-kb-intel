# L1-compliance-scope.md — Compliance Routing Module

**Purpose:** Given a client's product category + target market, determine which compliance frameworks apply and which L2 nodes to load.

---

## Step 1: Product Type Routing

| Product Type | Applicable Regulations | Notes |
|---|---|---|
| **Decorative items** (incl. seasonal, giftware) | REACH SVHC, REACH Annex XVII, GPSR, CPSC (if US), Prop 65 (if CA/US), UFLPA (if CN origin) | No inherent RSL unless buyer mandates it |
| **Apparel / Textiles** | REACH SVHC, REACH Annex XVII, azo dyes (Annex XVII Entry 43), PFAS (Oct 2026 EU), OEKO-TEX or buyer RSL, US Flammability (16 CFR 1610), CA TB117-2013 (if upholstered), UFLPA | CA Prop 65 for dyes/finishes common |
| **Hardgoods** (furniture, home goods, metal/wood) | REACH SVHC, REACH Annex XVII, GPSR, CPSC (if US), heavy metals (Annex XVII Entry 63/27), wood TSCA formaldehyde (if US), CARB Phase 2 (if composite wood + US), Prop 65 | Check for food-contact surface; check for child-use |
| **Electronics / EEE** | RoHS 2, WEEE, REACH SVHC, GPSR, CE marking (LVD + EMC), FCC (if US), UKCA (if UK), batteries regulation, UFLPA | RoHS substances: Pb, Hg, Cd, Cr6+, PBDE, PBB + 4 phthalates |
| **Toys** | EU Toy Safety Directive (2009/48/EC) [+ NEW Regulation in force], REACH SVHC, EN 71-1/2/3 (mechanical, flammability, migration), ASTM F963 (US), CPSC 16 CFR 1500, GPSR, phthalates (Annex XVII), heavy metals migration limits stricter than general | Toys = any product designed/intended for children under 14 |

---

## Step 2: Market Routing

| Market | Core Frameworks | Key Regulators |
|---|---|---|
| **EU** | REACH (SVHC + Annex XVII), GPSR, product-specific directives (RoHS, Toy Safety, etc.), EU Official Journal | ECHA (substances), European Commission, national MSAs |
| **US** | CPSC (consumer product safety), UFLPA (Xinjiang cotton/forced labor), FTC (labeling), FDA (food contact), EPA TSCA, Prop 65 if CA | CPSC, CBP, DHS, EPA, FDA, OEHHA (CA) |
| **UK** | UKCA marking (post-Brexit), UK REACH (separate SVHC list), UKCA for EEE, UK Toy Safety Regs | OPSS, EA (Environment Agency) |
| **EU + US** | Full EU stack + CPSC + UFLPA. Dual compliance. Test reports must cover both EN and ASTM/CFR standards. | Both regulatory stacks apply simultaneously |
| **EU + UK** | CE (EU) + UKCA (UK) both required unless UK recognition of CE (check current status). Separate DoC may be needed. | — |

---

## Step 3: Special Trigger Checks

Always evaluate these triggers regardless of product category. Any "YES" expands the applicable framework.

### T1: Does the product touch children?
- **Trigger:** Intended for children under 14 / marketed as toy / child-attractive design
- **Adds:** EU Toy Safety Regulation (EN 71 series), ASTM F963 (US), CPSC Section 108 phthalates, stricter heavy metal migration limits
- **Disqualifier:** Adult decorative item ≠ toy unless packaging uses "for children" language

### T2: Is it food-contact?
- **Trigger:** Plates, bowls, cutlery, food packaging, cooking items, decorative items that hold food
- **Adds:** EU Regulation (EC) 1935/2004 (food contact materials), EU-specific migration limits by material type (plastics 10/2011, ceramics 84/500, metals), FDA CFR 21 (US)
- **Key test:** Overall Migration Limit (OML) 10 mg/dm² in EU

### T3: Does it have electrical parts?
- **Trigger:** Any power supply, battery, motor, heating element, LED, wireless
- **Adds:** RoHS 2 (2011/65/EU), WEEE, CE Low Voltage Directive (2014/35/EU), EMC Directive (2014/30/EU), FCC Part 15 (US radio), EU Batteries Regulation (2023/1542)
- **Note:** Battery-powered items with no mains connection still trigger RoHS + batteries reg

### T4: Is the product origin China?
- **Trigger:** Manufactured in mainland China, including via third-country processing of Chinese materials
- **Adds:** UFLPA due diligence (rebuttable presumption if Xinjiang exposure), Forced Labor Prevention Act (FLPA) scrutiny, enhanced CBP documentation
- **Note:** Non-Xinjiang CN origin still requires chain-of-custody documentation to rebut

---

## Step 4: Output — Applicable L2 Nodes to Load

After routing above, output this list for the client:

```
APPLICABLE COMPLIANCE NODES:
[ ] L2/NODE-compliance-product-eu.md       ← if EU market or REACH applies
[ ] L2/NODE-compliance-trade.md            ← if US market or UFLPA applies
[ ] L2/NODE-compliance-social.md           ← if buyer has CSR/ESG requirements
[ ] L2/NODE-compliance-buyer-rsl.md        ← if buyer has RSL or test protocol
[ ] L2/NODE-regulatory-intelligence.md     ← always load for upcoming changes
```

Load only the nodes that are triggered. Do not load all nodes by default — that wastes tokens and introduces false positives.

---

## Yangzhou Example: HS 9505.10 (Christmas Decorations), EU + US

**Client profile:** Yangzhou decorative manufacturer, ships to EU and US buyers.

**Step 1 — Product type:** Decorative items → REACH SVHC, REACH Annex XVII, GPSR, CPSC (US), Prop 65.

**Step 2 — Market:** EU + US → full dual stack.

**Step 3 — Special triggers:**
- Children? → Possibly, if marketed as ornaments for children's rooms. Check buyer category. If adult decor → No Toy Safety trigger. If child-oriented → flag.
- Food contact? → No (decoration, not food).
- Electrical? → If battery-operated lights embedded → YES → adds RoHS + battery regs. If purely decorative with no power → No.
- China origin? → YES → UFLPA applies. Check for Xinjiang-sourced cotton batting, polyester fiber, or glitter.

**Step 4 — Triggered nodes:**
```
APPLICABLE COMPLIANCE NODES for Yangzhou / HS 9505.10 / EU+US:
[x] L2/NODE-compliance-product-eu.md       ← REACH SVHC, Annex XVII, GPSR required
[x] L2/NODE-compliance-trade.md            ← UFLPA (CN origin), CPSC, Prop 65
[ ] L2/NODE-compliance-social.md           ← Load if buyer (e.g. Walmart) has CSR reqs
[ ] L2/NODE-compliance-buyer-rsl.md        ← Load if buyer (e.g. Target) has RSL
[x] L2/NODE-regulatory-intelligence.md     ← Monitor PFAS decor ban, GPSR updates
```

**Key substances to assess for HS 9505.10:**
- Phthalates in PVC coatings (REACH Annex XVII Entry 51)
- Lead/cadmium in paints and coatings (Annex XVII Entry 63)
- Formaldehyde in foam/adhesives (Annex XVII Entry 19)
- SVHC in surface treatments (check ECHA candidate list)
- Prop 65: lead in metallic decorations, phthalates in soft PVC, DEHP

---

## Cross-Reference Links

- [NODE-compliance-product-eu.md](../L2/NODE-compliance-product-eu.md) — REACH substance rules, GPSR, Annex XVII entries
- [NODE-compliance-trade.md](../L2/NODE-compliance-trade.md) — UFLPA, CPSC, customs, trade law
- [NODE-compliance-social.md](../L2/NODE-compliance-social.md) — CSR, ESG, buyer codes of conduct
- [NODE-compliance-buyer-rsl.md](../L2/NODE-compliance-buyer-rsl.md) — Buyer RSL protocols, test standards

---

*Last updated: 2026-08-26 | Owner: Compliance KB*
