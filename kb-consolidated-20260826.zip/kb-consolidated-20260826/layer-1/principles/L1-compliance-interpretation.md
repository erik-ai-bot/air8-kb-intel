# L1-compliance-interpretation.md — How to Read a Regulation and Judge Applicability

**Purpose:** The reasoning layer. Given a specific regulation and a specific client situation, determine whether the regulation applies, at what level, and what the correct interpretation is. This is the hardest and most valuable layer — it prevents false positives and false negatives.

---

## 4-Step Reasoning Chain

Apply this chain every time you encounter a regulation + client pair.

### Step 1: Product Classification
**Question:** What is this product, legally?

1. Identify the HS code (from shipping docs, client declaration, or product description).
2. Map HS code to regulatory product category — these are NOT the same:
   - HS 9505.10 = Christmas decorations → EU: "article" under REACH, "consumer product" under GPSR
   - HS 6203 = Men's suits → EU: "textile article" under REACH textile labeling + Annex XVII azo dyes
   - HS 8516 = Electric water heater → EU: "electrical equipment" under RoHS + LVD
3. Check if the regulation defines its own scope by product definition — always use the regulation's own definition, not the HS code.
   - GPSR Article 2: "product means any product... which is intended for consumers or likely to be used by consumers"
   - RoHS Article 2: "electrical and electronic equipment or EEE means equipment which is dependent on electric currents or electromagnetic fields"
   - Toy Safety: "toy means any product or material designed or clearly intended for use in play by children under 14 years of age"
4. Exclusions: check if the product is explicitly excluded from the regulation's scope.
   - RoHS excludes large-scale stationary industrial tools, means of transport, non-road mobile machinery, active implantable medical devices.

**Output of Step 1:** Confirmed product type + which regulations are in scope by definition.

---

### Step 2: Substance Presence Check
**Question:** Is the regulated substance actually in this product?

1. Obtain BOM (Bill of Materials) from client — list of all materials, components, coatings, finishes.
2. Obtain SDS (Safety Data Sheets) for each raw material — check Section 3 (composition) for regulated substances.
3. For polymers: SDS Section 3 lists additives; plasticizers like DEHP are common in PVC but not always disclosed on SDS if <1%.
4. For coatings/paints: heavy metals (Pb, Cd, Cr) — request pigment disclosure or commission XRF screening test.
5. For textiles: azo dyes → check if dyestuff supplier discloses banned amines; or commission azo dye test.
6. For adhesives: formaldehyde → request SDS + consider commission emission test if wood product.

**Decision logic:**
```
BOM/SDS shows substance → possible presence confirmed → proceed to Step 3
BOM/SDS shows no substance → absence claimed → is this credible?
  → Yes (e.g., substance never used in this material type) → document and exit
  → No (e.g., PVC without plasticizer disclosure is suspicious) → request additional data or test
BOM/SDS unavailable → treat as unknown → flag as data gap (Type B gap per L1-compliance-gap-method.md)
```

**Output of Step 2:** Substance present / absent / unknown-pending-data.

---

### Step 3: Threshold & Exemption Check
**Question:** Even if present, does it exceed the legal threshold? Does an exemption apply?

**Threshold rules (these are commonly misapplied):**

| Regulation | Threshold | Basis |
|---|---|---|
| REACH SVHC (Article 33) | 0.1% w/w | Per finished **article** as supplied to consumer — NOT per component, NOT per coating layer |
| REACH Annex XVII (hard restrictions) | Varies per entry; often 0.1% but check each entry individually | Per article or per material — check the specific restriction entry |
| RoHS substances | Pb, Hg, Cr6+, PBDE, PBB: 0.1% w/w; Cd: 0.01% w/w | Per **homogeneous material** (uniformly composed material that cannot be mechanically disjointed) |
| Toy Safety EN 71-3 | Migration limits (mg/kg) by substance and toy category | Per extracted amount under test conditions — not concentration in material |
| Prop 65 | NSRL (No Significant Risk Level) / MADL — varies per substance | Daily exposure basis; not simple concentration threshold |
| Phthalates (REACH Annex XVII Entry 51) | 0.1% w/w for DEHP, DBP, BBP, DIBP | Per article — applies to toys and childcare articles AND all articles placed on EU market |

**CRITICAL: "per finished article" vs "per homogeneous material"**
- REACH SVHC → **per finished article** (the item the consumer receives)
  - A Christmas ornament with a PVC coating containing 0.08% DEHP AND a PVC base containing 0.05% DEHP = combined 0.13% if article-level calculation triggers → OVER threshold
  - DO NOT calculate separately per coating vs base and both come out <0.1%
- RoHS → **per homogeneous material** (the uniform sub-material)
  - A PCB solder joint with 0.12% lead → that solder is over threshold even if total board is <0.1%

**Exemption check:**
1. REACH Annex XVII exemptions: each restriction entry lists specific exemptions. Read the entry, not the summary.
2. RoHS Annex III/IV exemptions: specific applications (e.g., lead in solders for specific uses) — must match the exact application description.
3. Transition periods: check Official Journal publication for derogation end dates. Note these in client file with exact dates.
4. Industrial use: REACH Article 33 (SVHC notification) applies to articles — if the product is only used industrially (B2B, not consumer-facing), different obligations may apply. Verify end use.

**Output of Step 3:** Below threshold / above threshold / exempt (cite entry + basis).

---

### Step 4: Legal Entity Check
**Question:** Who bears the obligation — and is that our client?

This step is often skipped and causes downstream errors. The legal entity determines who must act.

| Regulation | Obligation Holder | Definition |
|---|---|---|
| REACH Article 33 SVHC | **Supplier of the article** (each in supply chain) | Must communicate SVHC presence to customer (B2B) or consumer (on request) |
| REACH Article 7 SVHC registration | **EU importer** or **EU producer** of the article | Non-EU manufacturer has NO direct obligation; EU importer (buyer) does |
| GPSR Declaration of Conformity | **Manufacturer** (if EU-established) or **Authorised Representative** (if manufacturer is non-EU) | Non-EU manufacturer MUST appoint EU AR before placing product on EU market |
| GPSR Technical File | Same as DoC — manufacturer responsibility, held/available via EU AR | |
| RoHS DoC | **Manufacturer** (EU) or **Authorised Representative** (non-EU mfr) | Same model as GPSR |
| UFLPA | **US Importer of Record** | US buyer/importer must defend against presumption; Chinese supplier must provide evidence |
| Prop 65 | **Any person in the course of doing business** who exposes CA consumers | Applies to California-selling entities; Chinese suppliers may be contractually required by US buyer |

**Practical implications:**
- Air8's client is typically the **Chinese manufacturer/exporter**. They are NOT the EU importer.
- For REACH Article 7 registration: the EU importer (Air8's buyer's buyer) has the obligation, not the CN manufacturer. **Do not tell CN manufacturer they must register under Article 7.**
- For REACH Article 33 notification: the CN manufacturer → EU importer chain: each supplier must pass information down. CN manufacturer must tell their direct customer (which may be an EU AR or an EU distributor), who then tells the next link.
- For GPSR: the CN manufacturer must appoint an EU AR. That AR is then responsible for accepting market surveillance queries. The CN manufacturer creates and maintains the technical file; the AR stores it and presents it.
- For UFLPA: the US importer (Air8's buyer) bears the burden. But the CN supplier must provide documentation to allow the US importer to rebut the presumption.

**Output of Step 4:** Named obligated entity + their specific obligation + whether Air8's client is that entity or a supporting party.

---

## Common Misreadings — Corrected

### Misreading 1: "n-Hexane used in factory process" = "n-Hexane present in finished article"
**Wrong interpretation:** Factory uses n-hexane as cleaning solvent → product has n-hexane → REACH obligation triggered.
**Correct interpretation:** Process use ≠ presence in finished article. n-Hexane is highly volatile; residuals in finished goods typically <1 ppm. Need residual test on finished article, not process SDS. Commission a residual solvent test if client claims "no presence" and you need to verify.
**Decision:** If factory uses n-hexane AND product could retain residuals (e.g., surface coatings, adhesives) → commission residual test. If product is solid metal or ceramic with no coating → low plausibility, document rationale.

---

### Misreading 2: "0.1% SVHC threshold" applies to coating or component weight
**Wrong interpretation:** PVC coating on a metal ornament is 5g of 200g total product. Coating has 0.5% DEHP = 2.5mg DEHP. 2.5mg / 200g = 0.00125% → below 0.1% → no notification needed.
**Correct interpretation:** Under current CJEU case law (C-106/14, "FCD"), the "article" for REACH Article 33 purposes is the article as supplied to the consumer. Apply the threshold to the whole finished article weight. 2.5mg DEHP / 200g total = 0.00125% — in this case BELOW threshold. BUT: if coating is 50g with 0.5% DEHP = 250mg DEHP / 200g article = 0.125% → OVER threshold.
**Rule:** Always calculate at the finished article level. Never calculate per component and declare "all components are under threshold."

---

### Misreading 3: "EU PFAS ban on clothing applies to decorative items"
**Wrong interpretation:** PFAS restriction in Annex XVII (adopted 2025, applying to textiles from Oct 2026) bans PFAS in all products → decorative Christmas items with water-repellent coating are banned.
**Correct interpretation:** The PFAS restriction in Annex XVII Entry 68 (textile/leather/fur/hide articles) applies specifically to **textile, leather, fur, and hide articles** — NOT to decorative articles made of other materials. A polyresin Christmas ornament with PTFE coating is NOT a textile article.
**However:** PFAS may be on the SVHC candidate list separately (PFOS already restricted under Annex XVII Entry 53). Check SVHC list independently of the textile restriction.
**Rule:** Always read the restriction entry's scope definition before applying it.

---

### Misreading 4: "EU AR required = high barrier / expensive"
**Wrong interpretation:** "We need an EU Authorised Representative — this will cost thousands of euros and take months, not worth it for small orders."
**Correct interpretation:** EU AR services are a commodity. Standard AR-only service (GPSR/RoHS) costs €300–800/year per manufacturer. Setup is administrative (sign service agreement, provide company details, draft DoC template). Typical turnaround: 1–2 weeks. NOT a barrier for any commercially viable EU business. Failure to appoint AR = product cannot legally be placed on EU market = your client's EU buyer is at risk.
**Rule:** AR cost is not a reason to skip compliance. Flag to client as admin task, low cost, non-negotiable for EU market access.

---

### Misreading 5: "UFLPA rebuttable presumption = China origin → automatic seizure"
**Wrong interpretation:** Product is from China → CBP will seize it → we can't ship to US.
**Correct interpretation:** UFLPA creates a **rebuttable presumption** that goods mined, produced, or manufactured in Xinjiang (or by entities on the UFLPA entity list) are made with forced labor and cannot be imported into the US. This presumption applies specifically to: (a) goods from Xinjiang, OR (b) goods from entities on the UFLPA entity list. Non-Xinjiang Chinese goods face enhanced documentation scrutiny but are NOT automatically presumed to violate UFLPA.
**Rebuttal standard:** "Clear and convincing evidence" that (1) goods are not mined/produced/manufactured in whole or in part in Xinjiang, and (2) not produced with forced labor.
**Rule:** China origin alone does not trigger UFLPA. Xinjiang origin or UFLPA entity involvement does. Map supply chain Tier 1-3 and identify any Xinjiang exposure. Document with supplier attestations and origin docs.

---

## Decision Tree: Apply or Not Apply?

```
REGULATION X + CLIENT Y: Does it apply?

1. Is product Y in the scope of Regulation X (by definition)?
   NO → Not applicable. Document basis. STOP.
   YES → Continue

2. Is market Y targeted by Regulation X?
   NO → Not applicable. Document basis. STOP.
   YES → Continue

3. Is substance/condition X present in product Y?
   NO (documented) → Not triggered. STOP.
   UNKNOWN → Flag as Type B data gap. Cannot assess. STOP until data obtained.
   YES → Continue

4. Is the quantity/condition above the threshold, absent exemption?
   NO (with exemption or below threshold) → Not triggered. Document calculation. STOP.
   YES → Continue

5. Is client Y (or their direct counterparty) the obligated legal entity?
   NO → Obligation lies elsewhere (e.g., EU importer). Advise client to provide documentation support. STOP (for client's direct obligation).
   YES → Regulation applies. Proceed to L1-compliance-response.md for response playbook.
```

---

## Cross-Reference Links

- [L2/NODE-compliance-product-eu.md](../L2/NODE-compliance-product-eu.md) — Full REACH substance database, Annex XVII entries, GPSR requirements
- [L2/NODE-compliance-trade.md](../L2/NODE-compliance-trade.md) — UFLPA entity list, CPSC standards, customs requirements
- [DT/DT-internal-data-map.md](../DT/DT-internal-data-map.md) — Where to find BOM, SDS, test reports in Air8 internal systems

---

*Last updated: 2026-08-26 | Owner: Compliance KB*
