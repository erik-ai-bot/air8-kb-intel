---
type: reasoning
id: EVENT-PRINCIPLES
---

# Air8 Event Principles — Per Event Sub-Type

> Module: Events | Count: 17 | Updated: 2026-07-15
> Applied based on event taxonomy (2-level). Reference against EVENT-TYPES.md.
> Copy-pasted from V2 `air8-kb-v2/L0-principles/event-principles.md` — 2026-07-16.

---

## RP-EVT-DUTY-01: Import/Export Duty Change → Blend Ratio and Pass-Through
**When applies:** event_subtype: import_export_duty
**Must consider:**
- Who actually buys the input material (factory or buyer)? Buyer-nominated fabric = savings stay with buyer
- What % of input is imported vs domestic? Duty saving applies to imported portion ONLY
- Is there a domestic price floor (MSP, CCI) that limits downside even when global prices fall?
- Does the factory have supply contracts that lock them into current prices for 90-180 days?
- Downstream: does factory pass savings to buyer under cost-plus pricing, or retain margin improvement?
**LLM directive template:** "For [duty change] on [material]: (1) Who purchases the input — factory or buyer? (2) What is the domestic vs imported blend ratio? (3) Is there a government support price floor? (4) Are existing supply contracts fixed or floating? (5) What is the realistic lag before new pricing takes effect (typically 90-180 days for yarn/fabric)?"
**Freshness:** stable

---

## RP-EVT-ENVCOMP-01: Environmental Compliance Event → Scope and Timeline
**When applies:** event_subtype: environmental_compliance
**Must consider:**
- Which specific regulation is changing and for which jurisdictions (EU vs US vs both)
- What is the effective date for each affected supply chain tier
- Which certifications already satisfy the requirement (REACH compliance ≠ ZDHC MRSL ≠ ESPR)
- Cost structure: audit cost (typically $3-15K) vs remediation cost (can be $20-100K+ for structural fixes)
- Risk of shipment detention post-effective-date if supplier is non-compliant
**LLM directive template:** "For [regulation]: (1) Which jurisdictions and buyer geographies are in scope? (2) What is the mandatory effective date? (3) Which existing certs partially satisfy this? (4) What is the typical audit + remediation cost for a mid-size supplier? (5) What is the enforcement mechanism (customs detention, buyer audit, regulator inspection)?"
**Freshness:** annual

---

## RP-EVT-TRACE-01: Traceability Requirement → Chain of Custody Depth
**When applies:** event_subtype: traceability
**Must consider:**
- Traceability depth required: does it go to yarn level, fiber level, farm level?
- Which combos already have chain-of-custody infrastructure (GOTS, Fairtrade, T4S)
- Cost to build traceability where absent (typically 1-3 years and significant capex)
- UFLPA-specific: Xinjiang cotton presumption — any cotton originating in XJ is rebuttable presumption detained
- DPP (EU Digital Product Passport): by 2027-28, all products sold in EU need product-level digital passport
**LLM directive template:** "For [traceability requirement]: (1) What chain of custody depth is required? (2) Which affected combos already have infrastructure meeting this? (3) What is the timeline to implement for a non-compliant supplier? (4) What is the specific enforcement risk for Air8 (shipment detention = unpayable receivable)?"
**Freshness:** annual

---

## RP-EVT-FX-01: FX Rate Move → Natural Hedge Assessment
**When applies:** event_subtype: fx_rate
**Must consider:**
- Revenue currency vs cost currency mismatch creates open FX exposure
- EUR-denominated Air8 facility for EUR-invoicing suppliers creates a natural hedge
- TRY (Turkey), INR (India), BDT (Bangladesh) vs USD/EUR — each has different volatility profile
- Hyperinflation currencies (TRY): access to credit is the core problem, not just rate
- FX move can temporarily inflate or deflate supplier's local-currency costs — understand who benefits
**LLM directive template:** "For [FX event on currency_pair]: (1) What is the typical revenue/cost currency split for [combo]? (2) Does [combo] have any forward contracts? (3) Does Air8's EUR/USD-denominated facility reduce or amplify this supplier's FX exposure? (4) What is the impact on Air8 repayment risk?"
**Freshness:** stable

---

## RP-EVT-BUYERCREDIT-01: Buyer Credit Event → Cascading Exposure
**When applies:** event_subtype: buyer_credit_event
**Must consider:**
- Any buyer distress signal (downgrade, covenant breach, M&A uncertainty) is an early warning for DSO extension
- DSO extension precedes payment default — watch for 30+ day extension as leading indicator
- PSF/OBF anchor risk: if buyer anchor quality falls below threshold, ALL PSF positions with that buyer need review
- Concentration: check across portfolio for total exposure to this buyer as receivable debtor
- Supplier response to buyer distress: some suppliers over-ship to "lock in" revenue before buyer halts orders — increases Air8 exposure right at worst time
**LLM directive template:** "For [buyer] credit event: (1) What is current DSO trend vs contract terms? (2) What credit rating/coverage signals have changed? (3) Which Air8 product positions have this buyer as counterpart? (4) What is typical supplier response to buyer distress in this category?"
**Freshness:** stable

---

## RP-EVT-SOURCSHIFT-01: Buyer Sourcing Strategy Shift → Multi-Combo Impact
**When applies:** event_subtype: sourcing_strategy_shift OR event_subtype: nearshoring
**Must consider:**
- Buyers don't diversify instantly — typical lead time for meaningful sourcing shift is 12-24 months
- "China+1" pattern: some CN volume shifts to VN/BD/IN, but complex/speed orders stay in CN
- Nearshoring: Turkey/Morocco/Tunisia benefit for EU; Mexico/Central America benefit for US
- Beneficiary combos may surge demand → risk of over-commitment at Air8 if capacity runs hot
- Hurt combos may see gradual PO decline → leading indicator monitoring is critical (don't wait for actual PO loss)
- **Buyer diversification mandate overrides price competitiveness (CRITICAL):** When buyers are operating under a sourcing diversification policy (tariff risk mitigation, geopolitical hedging, supply chain resilience mandates), they will allocate volume to alternative origins even when the incumbent origin (e.g., CN) is still cheaper. Do NOT assume that "CN is cheaper than VN therefore no shift" — the shift happens anyway because it is policy-driven, not price-driven. The question is not IF the shift happens but HOW FAST and HOW MUCH per season.
- For seasonal categories (outdoor furniture, holiday décor): sourcing shifts lock in per-season as allocation decisions. Each season’s step-down is effectively permanent (90/10 → 80/20 → 70/30). Origin A does not recover lost allocation in subsequent seasons once it is reallocated.
**LLM directive template:** "For [buyer sourcing shift]: (1) What product category and buyer type is shifting? (2) Is this price-driven substitution or policy-driven diversification? If policy-driven — CN being cheaper does NOT prevent the shift; assess speed and magnitude instead. (3) What is the realistic volume transfer timeline (months to meaningful impact)? (4) For seasonal categories: what is the per-season step-down rate, and at what allocation % does the hurt-origin supplier reach break-even? (5) Which source countries gain, which lose?"
**Freshness:** annual

---

## RP-EVT-POLINSTAB-01: Political Instability → Production Disruption Assessment
**When applies:** event_subtype: political_instability
**Must consider:**
- Production disruption (hartal, strikes, factory closures) affects OTD — leads to buyer scorecard degradation
- Banking system disruption in country (government interference, bank runs) → liquidity crisis even for healthy factories
- Port/logistics disruption adds days to lead time → changes Air8 tenor calculation
- Buyer response: some buyers pre-source to alternatives during instability, even if they return afterward
- Air8 response: during acute disruption — pause new disbursements until clarity; existing positions monitor closely
**LLM directive template:** "For [country] political event: (1) What is the production disruption impact (days per month historically)? (2) Is the banking system disrupted (can Air8 disburse/receive normally)? (3) Are port/logistics affected? (4) What is buyer pre-positioning behavior during past disruptions?"
**Freshness:** annual

---

## RP-EVT-CMDTYSHORT-01: Raw Material Shortage → Allocation and Lead Time Impact
**When applies:** event_subtype: raw_material_shortage OR event_subtype: allocation_constraint
**Must consider:**
- Who has preferential access to scarce material (vertically integrated > FOB > CMT in allocation priority)
- Price spike accompanies shortage — double impact on working capital (more expensive + harder to get)
- Lead time extension during shortage changes Air8 tenor requirements
- Quality substitution risk: factories under pressure may accept off-grade material — hidden quality risk
- First-mover advantage: factories that lock contracts early (with PSF support) may secure allocation others can't
**LLM directive template:** "For [material] shortage event: (1) Who controls allocation in the supply chain? (2) What is the price spike range and lead time extension? (3) Which combos are most exposed (highest dependency, lowest alternative sourcing)? (4) Is there a first-mover advantage in locking supply early?"
**Freshness:** stable

---

## RP-EVT-MKTENTRY-01: Buyer Market Entry/Exit → PO Flow Impact
**When applies:** event_subtype: market_entry_exit
**Must consider:**
- Entry: which combos are in the buyer's new target geography? What capability is the buyer looking for?
- Exit: which combos have revenue concentration in this buyer × geography? How much PO volume at risk?
- Timing: buyer entry/exit is rarely immediate — 12–24 months for meaningful volume shift
- Air8 risk: entry = expansion opportunity but capacity risk (factory over-commits to new buyer); exit = PO decline leading indicator → ARP book shrinks with receivables
- Competitive dynamic: one buyer's exit often creates an opening for another buyer — check if same combos benefit
**LLM directive template:** "For buyer [market entry/exit] event: (1) Which geography and product category is the buyer entering/exiting? (2) Which combos are in that geography and serve that product? (3) What is the realistic volume available — is this a flagship programme or trial order? (4) What is the timeline for first order vs full ramp? (5) For exit: what % of affected combos' revenue is at risk and over what period?"
**Freshness:** annual

---

## RP-EVT-SUPCHAIN-01: Supply Chain Disruption → Tenor and Liquidity Impact
**When applies:** event_subtype: logistics_disruption OR event_subtype: lead_time_change OR event_subtype: factory_capacity_change
**Must consider:**
- Lead time extension = Air8 tenor must extend to cover longer cycle; check if new tenor crosses any cliff date
- Port/logistics disruption: shipment delay = receivable maturity pushed out → potential covenant on existing positions
- Factory capacity change (competitor closure): creates immediate PO inflow opportunity for nearby combos; beware over-commitment risk
- Factory capacity change (own): capacity reduction = PO pipeline risk; Air8 receivables may shrink with it
- Quality risk: disruption often forces use of secondary suppliers or overtime production → hidden quality issues
**LLM directive template:** "For [supply chain event]: (1) What is the typical lead time extension caused by this disruption? (2) Does the new lead time push Air8 tenor requirements beyond standard bands? (3) Are there nearby combos that benefit from competitor disruption (order diversion)? (4) What is the port/logistics situation specifically — which routes and ports affected? (5) What is the recovery timeline historically for this type of disruption?"
**Freshness:** stable

---

## RP-EVT-SUPCONSOLIDATE-01: Buyer Supplier Consolidation → Relationship Depth Signal
**When applies:** event_subtype: supplier_consolidation
**Must consider:**
- Buyer reducing vendor count = survivors get larger wallet share; casualties lose entire programme
- Air8 positioning: supplier that IS retained will have more volume → expand facility; supplier at risk of cut → hold
- Consolidation criteria: buyers typically retain on ESG compliance + OTD + quality score + speed, not just price
- Knowledge gap: most suppliers don't know where they stand on the buyer's scorecard
- Warning signal: a buyer's consolidation announcement is the leading indicator — 12–18 months before cuts happen
**LLM directive template:** "For buyer [consolidation] event: (1) Which buyers are consolidating? (2) What are the consolidation criteria (ESG, OTD, quality, price)? (3) Which combo types are most likely retained vs cut? (4) What is the timeline — when do first cuts happen? (5) For affected combos: which assessment dimensions determine if they're in the retained or cut group?"
**Freshness:** annual

---

## RP-EVT-PRODTREND-01: Product Trend Change → Category Trajectory + Factory Adaptability
**When applies:** event_subtype: product_trend_change OR event_subtype: product_technology_disruption
**Must consider:**
- Is the factory's core product category growing or declining structurally in key buyer markets?
- What % of the factory's revenue is concentrated in the affected category?
- Is the factory a specialist (deep capability, one category) or generalist (can pivot)?
  - Specialist in declining category = structural existential risk
  - Specialist in growing category = competitive moat
  - Generalist = more adaptable but less defensible
- Can the factory pivot to the trending product? What investment and timeline?
- Are buyers sending signals (adding/cutting programmes) before the trend is mainstream?
- Competitive context: are peers already investing in the trend? Is the window open or closing?
**LLM directive template:** "For product trend [growing/declining] in [category]: (1) What is the YoY demand trend for [product category] in EU/US key markets — cite data. (2) Which Air8 combo types have [product category] as their primary product_type? (3) Are major EU/US buyers adding or cutting [product category] programmes — any public sourcing announcements? (4) What production investment is typically required to pivot from [current product] to [trending product] — cost range and timeline?"
**Freshness:** annual

---

## RP-EVT-PRODTECH-01: Product Technology Disruption → Capability Moat vs Obsolescence
**When applies:** event_subtype: product_technology_disruption
**Must consider:**
- Does the new technology replace or augment the factory's existing production method?
- Which factories in the combo's competitive set already have the new technology?
- What is the investment to adopt vs cost of not adopting (market share loss timeline)?
- Does the factory's buyer base require or reward the new technology?
- COMBO-005 (TR Denim) precedent: laser/ozone in-house = moat; outsourced = no moat
**LLM directive template:** "For technology disruption [tech name]: (1) What is the adoption rate among peer factories in [country]? (2) What is the investment required to adopt for a [revenue band] factory? (3) Do key buyers (H&M/Zara/etc.) actively require or preference this technology in their scoring? (4) What is the timeline before non-adopters lose competitive position?"
**Freshness:** annual

---

## RP-EVT-DOUBLE-COMPRESS: Input + Output Tariff Co-occurrence → Double Compression Flag
**When applies:** Any tariff event (import_export_duty) where BOTH raw material input AND finished goods export are subject to simultaneous tariff pressure for the same country/category
**Added:** 2026-07-15 | Source: Hardgoods T1 copper tariff + Section 301 signal analysis
**Must consider:**
- Check active_event_cache for ANY existing tariff event on the same country × category before generating output
- If input tariff event AND finished goods tariff event both active: flag DOUBLE COMPRESSION — do NOT treat as independent events
- Double compression is structurally different from single-direction tariff: factory pays MORE to produce AND receives LESS margin on export → simultaneously squeezed from both ends
- No geo-arbitrage escape if input is a global commodity (copper, aluminum, cotton) — alternative production regions face same input cost pressure
- Key examples: CN brass artware (T1 copper input + Section 301 finished goods to US); CN lighting (copper in drivers + Section 301); CN outdoor furniture (aluminum + anti-dumping on extrusions)
- Signal output: CAUTION for EU-facing programs (input cost only); DO_NOT_EXPAND for US-facing programs (double compression confirmed)
- **Commercial terms qualifier (MANDATORY):** Double compression applies differently depending on the factory's commercial term:
  - **DDP (Delivered Duty Paid):** Factory bears both input cost AND export tariff → full double compression applies
  - **FOB (Free on Board):** Factory bears only the INPUT tariff (commodity cost); the OUTPUT tariff (e.g., Section 301) is borne by the buyer/importer at the US border. FOB factory's signal = input cost rise ONLY, not double compression
  - **Always confirm commercial term before applying double compression signal**
**LLM directive template:** "For [tariff event] on [material/country]: (1) What is the factory's commercial term — DDP or FOB? (2) If DDP: apply full double compression (input cost + output tariff). If FOB: apply input cost rise only; do NOT apply Section 301 to factory margin. (3) Is there an existing tariff in the active_event_cache on finished goods from the same country/category? (4) Quantify the applicable margin impact given confirmed commercial term. (5) Is there a viable material substitution that reduces input exposure? (6) Are alternative production origins insulated from the input tariff?"
**Correction source:** Josephine Cheung 2026-07-16 — DDP/FOB distinction confirmed material to double compression signal.
**Freshness:** stable

---

## RP-EVT-SEASONAL-LOCK: Annual Purchase Cycle → Permanent Step-Down Amplifier
**When applies:** Any sourcing shift, tariff, or demand event affecting a category with an annual or once-per-season purchase cycle
**Added:** 2026-07-15 | Source: Josephine Cheung expert review — E7 outdoor furniture signal analysis
**Must consider:**
- Annual purchase cycle categories: outdoor furniture, seasonal/holiday décor, Christmas goods, garden products, some home textile seasonal ranges
- For these categories, sourcing shifts are NOT gradual — they are binary per season. Buyers set allocation (China/Vietnam/India split) ONCE per buying season at the start, and it is locked for 12 months
- The step-down pattern is typically permanent: Season 1: 90/10 → Season 2: 80/20 → Season 3: 70/30. Each step-down is effectively irreversible — China supplier does not recover the lost allocation in subsequent seasons
- A +X% order lift signal during the booking window may be LAST SEASON's signal being confirmed, not a new positive development
- A -x% signal detected IN-SEASON (after booking window closes) means the allocation was already set lower BEFORE the event — the signal reflects next season's outlook, not current-year revenue impact
- Air8 disbursement timing must respect the booking window. **Booking windows are category AND destination-geography specific — do NOT apply a single global date:**
  - Outdoor furniture (EU/US): **Jun–Aug** (delivery Nov–Feb following year)
  - Outdoor furniture (AU): **Jan–Mar** (delivery Jul–Aug)
  - Holiday/Christmas décor (EU/US): **Dec–Jan** (delivery Jul–Sep)
  - Check category + destination before applying seasonal-lock logic
- Expand DURING the booking window; in-season disbursements are limited to already-confirmed PO books only
- Changes after confirmed orders affect **forthcoming orders**, not the current season
- Seasonal lock-in amplifier: any diversification signal (e.g., Vietnam gaining share) must be analyzed as a permanent step-down, not a temporary experiment
**LLM directive template:** "For [sourcing shift / demand event] on [seasonal category]: (1) Is this category a once-per-year purchase cycle? What is the booking window for [destination_geography]? (2) Is the signal detected during the booking window (impactable) or in-season (reflects next-year outlook)? (3) What is the step-down pattern — has the buyer been reducing China/[origin] allocation each season? (4) Is the current signal an acceleration of an existing step-down trend, or a new shift? (5) What % of the factory's annual revenue is at risk per seasonal step-down increment?"
**Correction source:** Josephine Cheung 2026-07-16 — EU outdoor booking window is Jun–Aug, not Jan–Mar.
**Freshness:** stable

---

## RP-EVT-SEGMENT-BIFURCATE: Apparent Substitution → Verify Segment Overlap First
**When applies:** Any sourcing shift event where volume is reported to move from one origin to another
**Added:** 2026-07-15 | Source: Josephine Cheung expert review — E7 outdoor furniture + T1 copper decor segment analysis
**Must consider:**
- Sourcing shifts are NOT always substitution within the same product segment — they may be bifurcation into distinct segments serving different buyer tiers
- Test: do the two origins actually compete at the same price point, product specification, and buyer tier? If NO → it is bifurcation, not substitution
- Outdoor furniture example: China = standard-to-mid price range, vertically integrated, volume-focused; Vietnam = mid-to-high range, natural materials, design-led. Buyers "shifting" from China to Vietnam for outdoor furniture are often adding a premium Vietnam range, not replacing China volume 1:1
- Brass artware example: the CN vs India bifurcation is **product-type specific, not a clean price-band split**. CN and India Moradabad DO compete directly on some product types. CN uses better quality alloys in many product types. India's strength is artware categories (metal lighting, planters, furniture bases, decorative trays, candle stands). When buyers report "shifting from CN to India" in brass décor, verify the specific product type before assuming bifurcation — it may be direct substitution, not segment upgrade. [VERIFIED — Josephine Cheung 2026-07-16]
- Substitution (true): same product spec, same buyer tier, same price point moves from origin A to origin B → direct volume loss
- Bifurcation: origin A retains mass/standard segment; origin B gains new premium/design-led segment → NOT direct volume loss; different buyer budgets
- Signal implication: bifurcation = China/existing origin retains its segment; new origin gains an adjacent segment. DO NOT call it a competitive threat to existing origin unless segments overlap
- Buyer intent check: ask "Is this a deliberate reallocation of existing programs, or addition of a new premium range?" — different answers, different Air8 signal
**LLM directive template:** "For sourcing shift from [origin A] to [origin B] in [category]: (1) Do origin A and origin B compete at the same price point and product specification? (2) What is the buyer's stated intent — reallocation of existing programs or addition of a new range? (3) What is the price gap between origin A and origin B products — is it <15% (substitution plausible) or >25% (bifurcation likely)? (4) For each origin: what buyer tier (mass/mid/premium) do they serve, and does the new origin displace the same tier?"
**Freshness:** stable

---

## RP-EVT-CORRELATED-PAIR: Multiple Active Events → Combined Read Required
**When applies:** When a new event is being analyzed AND the active_event_cache contains one or more events with overlapping country, material, or buyer_geo tags — whether those cached events arrived directly OR were surfaced during a prior enrichment pass
**Added:** 2026-07-15 | Updated: 2026-07-16 (unified entry point + deduplication protocol)

**Three paths that trigger this rule:**

**Path 1 — Cache-first (existing):**
Event A arrives → Step 3b checks cache → finds Event C already `state=active` → run combined read

**Path 2 — Enrichment-surfaced (new):**
Event A arrives → STEP 0 enrichment search surfaces Event C as related news → Phase A-E decomposes C → C staged as `state=draft, sourced_by=A` → Step 3b finds C in cache (as draft) → promotes C to `state=active` → run combined read A+C. One unified decomposition path regardless of how the event was found.

**Path 3 — Deduplication (new):**
Event C arrives independently AFTER already being incorporated into a combined read → Step 3b finds C with `state=incorporated_in, combined_read_id=A+C_card` → do NOT produce new standalone card. Instead:
```
Delta check: run STEP 0 enrichment search for Event C,
             filtered to developments since last_delta_check date

IF no new development:
  → Emit: "[Event C] already incorporated in [combined card A+C] on [date].
           No new signal. Reference existing combined analysis."
  → Update last_delta_check = today. No new card.

IF new development found:
  → Generate ADDENDUM to existing combined card (not a new standalone)
  → Label: "UPDATE — [Event C] — new development since [last_delta_check]"
  → Update combined_read_id card with addendum section
  → Update last_delta_check = today
```

**Relationship types (applies to all paths):**
- AMPLIFYING: both events push in the same direction → urgency increases; window tightens
- REFRAMES: new event changes interpretation of cached event → cached signal must be revised
- OFFSETS: events partially cancel → net signal muted
- INDEPENDENT: overlap in geography but different mechanisms/combos → emit separately

**Cache write rules after combined read:**
- Mark all incorporated events: `state=incorporated_in`, `combined_read_id=[combined_card_id]`
- Set `last_delta_check=today` on all incorporated entries
- The combined card is the authoritative output; individual cards are retired

**Examples:**
- E7 (outdoor order lift) surfaced during STEP 0 search for S1 (aluminum tariff) → E7 staged as `draft, sourced_by=S1` → Step 3b promotes E7 to active → combined read = REFRAMES: order lift is pull-forward, not organic demand
- E7 later arrives independently → cache hit: `state=incorporated_in` → delta check → no new development → emit reference only

**LLM directive template:** "For event [new_event]: (1) Before STEP 1: check if this event is `state=incorporated_in` in cache → if yes: run delta check, emit reference or addendum only. (2) During STEP 0 enrichment: for each found related news item, check Phase A-E threshold; if distinct event: parse and stage as draft in cache. (3) Step 3b: check cache for events with ≥2 overlapping tags (including drafts). (4) If correlated: classify AMPLIFYING/REFRAMES/OFFSETS/INDEPENDENT. (5) If AMPLIFYING or REFRAMES: generate combined card; retire individual cards; update cache states."
**Freshness:** stable

---

> **Note:** For peer failure / competitor exit events → apply **RP-PEER-FAILURE** primitive from this file (PRINCIPLES.md). This is event-agnostic and covers any country/sector where peer closures create apparent survivor signals.
