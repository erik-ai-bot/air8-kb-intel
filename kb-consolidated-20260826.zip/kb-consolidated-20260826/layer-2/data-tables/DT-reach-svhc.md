# DT-reach-svhc.md — ECHA SVHC Candidate List Data Source

**Layer:** DT (Data Source) | **Regulation:** REACH Article 59 | **Last checked:** 2026-08-26

## What This Is
The SVHC (Substances of Very High Concern) Candidate List is maintained by ECHA.
As of Feb 4, 2026: 253 substances listed.
Access: echa.europa.eu/candidate-list-table (free, public, machine-readable export available)

## How to Use It
1. Download current candidate list as CSV/Excel from ECHA website
2. Cross-reference with client BOM substance names and CAS numbers
3. Any match above 0.1% w/w in finished article → trigger SVHC obligations
4. Re-check every 6 months (ECHA updates ~Feb and ~Jul each year)

## Most Recent Updates
| Date | Substances added | CAS | Relevance to decorative items |
|------|-----------------|-----|-------------------------------|
| Feb 4, 2026 | n-Hexane | 110-54-3 | Coating solvents — HIGH risk |
| Feb 4, 2026 | BPAF (Bisphenol AF) | 1478-61-1 | Epoxy coatings — MEDIUM risk |
| Jun 2025 | [check ECHA for latest] | — | — |

## Common SVHC in Decorative Items (from previous enforcement cases)
- DEHP (phthalate plasticizer) — in soft plastic components
- DBP (phthalate) — in coatings and printing inks
- Lead compounds — in pigments and glazes
- Cadmium compounds — in yellow/red pigments
- Chromium(VI) compounds — in surface treatments
- Formaldehyde — in resins and adhesives

## SCIP Notification
When SVHC >0.1% w/w confirmed in article:
- Submit via ECHA SCIP database (iuclid.eu/scip) — free
- Required fields: substance name, CAS, article description, concentration range, safe use info
- Deadline: 6 months from SVHC listing date

## Links
→ L1-compliance-interpretation.md (how to determine if threshold applies)
→ L1-compliance-response.md (SVHC response playbook)
→ NODE-compliance-product-eu.md §SVHC (full SVHC rules)
→ DT-internal-data-map.md (what data Air8/SDU has vs. must request)
