# DT-internal-data-map — Air8 Internal Data vs. External/Client-Sourced

## Purpose
Maps every data type needed for a compliance assessment to its source.
Distinguishes: internal (Air8 already has it) | client-sourced (need to request) | external (paid/free public db).
This prevents the agent from guessing where data comes from.

---

## Data Types Required for Compliance Assessment

### 1. Company & Factory Profile

| Data | What it tells us | Source | Availability |
|------|-----------------|--------|--------------|
| Factory legal name + address | Legal entity → jurisdiction → which regulations apply | Air8 financing records (CLIENT-DB) | ✅ Internal |
| Country of manufacture | UFLPA scope, REACH importer, GPSR AR requirement | Air8 financing records | ✅ Internal |
| Named buyers (BJ's, Costco, etc.) | Which buyer RSL applies, what audit program required | Air8 financing/buyer records | ✅ Internal (if named buyer in records) |
| Product category / HS code | Regulatory scope, which EU/US regulations apply | Air8 product description in financing docs | 🟡 Partial — HS code often not recorded precisely |
| Manufacturing process description | Chemical exposure → SVHC risk, coating/painting operations | Air8 supplier profile | 🟡 Partial — may need client to clarify |
| Financing amount | Size of exposure → priority for compliance action | Air8 financing records | ✅ Internal |

**Action if missing:** Request from client via relationship manager. Flag as Type B gap.

---

### 2. Social Compliance / Labor

| Data | What it tells us | Source | Availability |
|------|-----------------|--------|--------------|
| BSCI report (date + rating) | Current social compliance status, audit expiry | Air8 inspection records (insp DT) | ✅ Internal |
| SMETA / SEDEX report | Alternative social audit, accepted by Costco/Walmart | Air8 inspection records | ✅ Internal |
| WRAP certificate | Alternative social audit | Air8 inspection records | ✅ Internal if provided |
| Audit rating (A/B/C/D/E) | Pass/fail threshold for most buyers | Air8 inspection records | ✅ Internal |
| CAPAR (corrective action plan) | Open findings → risk level | Air8 inspection records | 🟡 Internal if audit was done by Air8 |
| Worker hour records | Overtime compliance (BSCI criterion) | Factory records | ❌ Not internal — request from factory |

**Action if missing:** Request from factory. Audit typically valid 2 years.

---

### 3. Product Compliance / Chemical

| Data | What it tells us | Source | Availability |
|------|-----------------|--------|--------------|
| Bill of Materials (BOM) | Chemical composition → SVHC risk, PFAS presence | Air8 group trade records (partial) / Client or factory | 🟡 Partial — available for some clients via Air8 group internal systems; request from client where not held |
| Safety Data Sheet (SDS / MSDS) | Chemical substances used → SVHC screen | Client or factory | ❌ Not internal — must request |
| Test report (SGS/BV/Intertek) | Verified chemical levels → compliance proof | Client or factory | ❌ Not internal — must request |
| Prop 65 statement | California compliance status | Client | 🟡 Often in buyer compliance docs |
| SVHC declaration (factory) | Self-declaration of SVHC-free status | Client or factory | ❌ Not internal |
| REACH declaration | EU compliance self-declaration | Client or factory | ❌ Not internal |
| CE marking certificate | Electrical product safety (if applicable) | Client or factory | ❌ Not internal |
| RoHS test report | Electrical product chemical compliance | Client or factory | ❌ Not internal |
| GPSR EU AR appointment letter | EU Authorized Representative appointment | Client | ❌ Not internal |

**Critical path for chemical data:**
```
No BOM → ask client
  ↓
Client provides BOM → cross-reference with SVHC candidate list
  ↓
SVHC candidate match → request SDS + residual test
  ↓
Test confirms >0.1% → trigger L1-compliance-response playbook
```

---

### 4. Trade & Customs

| Data | What it tells us | Source | Availability |
|------|-----------------|--------|--------------|
| Country of Origin (COO) certificate | UFLPA scope, duty rate | Client or factory | 🟡 Often obtained by factory directly |
| Supplier names (Tier 1) | UFLPA entity list check | Air8 financing records | ✅ Internal |
| Tier 2-3 supplier names | UFLPA due diligence depth | Client | ❌ Not internal — must request |
| Xinjiang exposure assessment | UFLPA high-risk regions | Client | ❌ Not internal — must request |
| UFLPA rebuttable presumption evidence | Shipment clearance package | Client | ❌ Not internal |
| HS code (8-10 digit) | Precise tariff + regulation determination | Client or customs broker | 🟡 Rarely in Air8 records |
| ISF filing history | US import compliance history | Air8 trade records (if any) | ❌ Not internal |

---

### 5. Buyer-Specific Compliance

| Data | What it tells us | Source | Availability |
|------|-----------------|--------|--------------|
| Buyer's compliance manual / RSL | Chemical restrictions specific to that buyer | Client (provided during onboarding) | 🟡 Sometimes in Air8 records |
| Test report aligned to buyer's RSL | Proof of buyer-specific compliance | Client | ❌ Not internal |
| Factory registration with buyer | Factory approved by specific buyer | Air8 relationship records | 🟡 Partial — may have registration date |
| Prop 65 warning label on product | California compliance | Product sample or photo | ❌ Not internal |

---

## Summary: What Air8 Already Has

**From financing/relationship records:**
- Factory legal name, address, country ✅
- Named buyers ✅ (if disclosed during financing)
- Financing amount → size of exposure ✅
- Product category (text description) ✅
- Approximate HS code (6-digit level) 🟡

**From inspection/social compliance records:**
- BSCI/SMETA/WRAP audit reports ✅ (if done through Air8)
- Audit rating and CAPAR ✅ (if Air8 conducted)
- Inspection date ✅

**Never internal (must come from client/factory):**
- BOM (bill of materials)
- SDS/MSDS
- Chemical test reports
- Prop 65 / REACH / SVHC declarations
- GPSR EU AR appointment
- UFLPA Tier 2-3 supplier traceability
- HS code confirmation at 8-10 digit level
- Buyer-specific RSL test reports

---

## Data Request Protocol

When a compliance assessment hits a **Type B gap** (missing data):

```
Step 1: Check DT-internal-data-map above
        → Is it internal? Pull from Air8 records.
        → Is it client-sourced? Proceed to Step 2.

Step 2: Draft data request
        Format: [DATA TYPE] | [WHY NEEDED] | [WHO TO ASK] | [DEADLINE]
        Example: BOM | SVHC screening requires material composition | Factory → Client | 5 business days

Step 3: Flag to relationship manager (internal Air8 contact with factory)
        → They request from factory on Air8's behalf

Step 4: If data not received within deadline:
        → Note as "unconfirmed" in assessment
        → Score confidence lower (flag in CP3)
        → Do NOT block the assessment — use worst-case assumption where possible

Step 5: If data received:
        → Update internal records if appropriate
        → Re-score affected compliance items
        → Log gap as filled in gap queue
```

---

## Link to other files

- L1-compliance-gap-method.md → gap queue format + update protocol
- NODE-compliance-product-eu.md → REACH SVHC screening requires BOM
- NODE-compliance-buyer-rsl.md → buyer RSLs require test reports
- NODE-compliance-trade.md → UFLPA requires Tier 2-3 traceability

---

*Last updated: 2026-08-26 — initial version*
*Owner: Air8 Compliance KB*
