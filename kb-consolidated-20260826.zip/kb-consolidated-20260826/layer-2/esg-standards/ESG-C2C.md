---
type: esg
id: ESG-C2C
---
# ESG-C2C: Cradle to Cradle Certified

Multi-criteria product certification covering material health, circularity, clean air/water, and social fairness. Levels: Bronze, Silver, Gold, Platinum.

**Air8 Relevance:** Premium certification = strongest ESG signal. IFC/ESG financing eligible.

**Related:** [[../financing-products/PROD-ESG-FINANCING]] · [[ESG-IFC]]
**Combos:** [[../personas/COMBO-003-india-large-vertical-integrator]]
