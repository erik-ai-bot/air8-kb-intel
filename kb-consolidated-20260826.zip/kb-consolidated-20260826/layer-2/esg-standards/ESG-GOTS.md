---
type: esg
id: ESG-GOTS
---
# ESG-GOTS: Global Organic Textile Standard

## Description
Certification for organic fiber textiles (≥70% organic content). Covers processing, manufacturing, packaging, labeling, trading, distribution. Annual renewal audit.

## Air8 Relevance
GOTS-certified supplier = lower UFLPA risk (inherent traceability), ESG financing eligible

## Related: ESG Financing
[[../financing-products/PROD-ESG-FINANCING]]

## IFC Eligibility
[[ESG-IFC]]
