---
type: esg
id: ESG-HIGG
---
# ESG-HIGG: Higg Index (Sustainable Apparel Coalition / Cascale)

Suite of tools measuring environmental and social performance of textile facilities.

**Modules:** FEM (Facility Environmental), FSLM (Social Labor), BRM (Brand/Retail)

**Air8 Relevance:** HiggFEM score feeds buyer decision-making and Air8 scorecard Market Insights dimension.

**Related:** [[../pain-points/esg/PP-ESG-002-buyer-esg-escalating]]
