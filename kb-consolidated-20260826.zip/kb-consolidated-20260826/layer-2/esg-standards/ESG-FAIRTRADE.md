---
type: esg
id: ESG-FAIRTRADE
---
# ESG-FAIRTRADE: Fairtrade Cotton Certification

## Description
Fair price + premium for cotton farmers, labor standards. Covers farm level through ginning.

## Air8 Relevance
Demonstrates ethical sourcing, supports CSDDD compliance, ESG financing eligible

## Related: ESG Financing
[[../financing-products/PROD-ESG-FINANCING]]

## IFC Eligibility
[[ESG-IFC]]
