---
type: esg
id: ESG-ROC
---
# ESG-ROC: Regenerative Organic Certified

Beyond organic — adds soil health, animal welfare, and social fairness. Requires 1 year of organic certification as prerequisite.

**Air8 Relevance:** Cutting-edge ESG credential, rare, high value for CSDDD compliance conversations.

**Related:** [[../financing-products/PROD-ESG-FINANCING]] · [[ESG-IFC]]
