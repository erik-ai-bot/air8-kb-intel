---
type: esg
id: ESG-ZDHC
---
# ESG-ZDHC: Zero Discharge of Hazardous Chemicals

Industry program to eliminate hazardous chemicals from textile supply chain. ZDHC Gateway: chemical database — manufacturers must use only approved chemical formulations.

**Air8 Relevance:** Directly linked to REACH compliance. ZDHC adherence reduces [[../pain-points/compliance/PP-REG-REACH-001]] risk.

**Related:** [[../regulations/REG-REACH]]
