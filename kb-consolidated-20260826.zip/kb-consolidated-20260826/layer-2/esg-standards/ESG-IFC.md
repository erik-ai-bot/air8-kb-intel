---
type: esg
id: ESG-IFC
---
# ESG-IFC: IFC Green/Social Finance Eligibility

International Finance Corporation (World Bank) criteria for green/social bonds.

## Criteria
Climate adaptation, pollution prevention, biodiversity, access to essential services.

## Air8 Relevance
If supplier qualifies → Air8 accesses cheaper funding → passes savings to supplier as 10–25 bps discount.

## Trigger Conditions
- Supplier has ≥3 ESG certifications
- Renewable energy >20% of factory consumption
- Women employment >40% of workforce

## Related Product
[[../financing-products/PROD-ESG-FINANCING]]

## Eligible Combos
[[../personas/COMBO-003-india-large-vertical-integrator]] · [[../personas/COMBO-008-india-organic-cotton-medium]]
