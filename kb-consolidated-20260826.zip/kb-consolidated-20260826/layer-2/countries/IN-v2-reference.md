# Country: India

- id: COUNTRY-IN
- type: country_context
- category: country_facts
- freshness: annual
- last_updated: 2026-07-01

---

## Structural Facts (stable 1–3 years)

- **Cotton production:** India is one of the world's largest cotton producers. Both domestic and imported cotton are used. Domestic cotton is supported by a Minimum Support Price (MSP) — CCI (Cotton Corporation of India) buys at MSP if market falls below the floor, preventing domestic prices from falling below the government support level.
- **GST refund structure:** India operates a GST (Goods and Services Tax) refund system for exporters. Exporters can claim GST refunds on inputs used in exported goods. However, refund timelines are 30–90 days, locking working capital during this period.
- **Bank OD structure:** Indian garment factories predominantly use bank overdraft (OD) facilities for working capital. OD rates are determined by RBI policy rates plus bank margins.
- **Cotton import/export policy:** India periodically adjusts cotton import duties and export restrictions. Import duty changes create time-limited windows where importing cotton is cost-advantaged. These windows often have cliff dates (duty review dates, seasonal sunset).
- **IFC eligibility:** India's large Vertical integrators with GOTS/FAIRTRADE certifications and social criteria (women employment, renewable energy) may qualify for IFC green/social bond financing — enabling pricing advantages unavailable from commercial banks.
- **MSP floor mechanism:** The MSP for cotton sets a floor below which domestic cotton prices cannot fall regardless of global price movements. Import duty events benefit ONLY the imported portion of procurement — domestic MSP cotton is unaffected.
- **Organic cotton certification:** GOTS-certified organic cotton lines must use domestically certified cotton only. Importing conventional cotton into GOTS lines voids certification. This is a structural constraint that limits the benefit of import duty events for organic-focused factories.
- **UFLPA advantage:** India's large Vertical integrators with farm-to-fashion traceability (direct farmer network) have inherent supply chain documentation that satisfies UFLPA requirements — a competitive moat for US market.

## Key Dates & Deadlines

- **Cotton import duty review:** Annual — typically Q1 each calendar year. Effective dates and cliff dates vary by announcement.
- **GST refund processing:** Typically 30–90 days from claim submission (varies by refund type and GSTIN compliance status)
- **MSP revision:** Announced annually, typically June-July by Cabinet Committee on Economic Affairs

## LLM Directives (retrieve at runtime)

- **cotton_import_duty:** "What is the current India cotton import duty rate? Is there an active duty exemption or reduction window? What is the cliff/expiry date?"
- **msp_cotton_price:** "What is the current India MSP for cotton? Compare to international cotton prices. What is the effective floor price in USD/kg?"
- **bank_od_rate:** "What is the current India bank OD rate for textile exporters (SBI base rate + typical margin)? Compare to Air8 pricing."
- **gst_refund_timeline:** "What is the current average GST refund processing time for India textile exporters? Any recent RBI or GSTIN policy changes affecting timelines?"
- **ifc_eligibility_criteria:** "Current IFC green/social bond eligibility criteria for India textile factories. Which certifications qualify? What employment and energy criteria apply?"

---

## COMBO references using this country file
- COMBO-003 (India Large Vertical) — primary
- COMBO-008 (India Organic) — primary
- COMBO-014 (India Small Woven) — primary
