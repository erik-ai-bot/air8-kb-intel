---
type: country
dimension: DIM-1
id: country-indonesia
pain_points:
  - id: PP-IDN-001
    severity: HIGH
    context: "IDR/USD volatility squeezes USD margins"
  - id: PP-006
    severity: HIGH
    context: "Low trade finance literacy, prefer simple products"
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap, limited bank facilities"
---
# Indonesia 🇮🇩

## Industry Facts
- 8th largest garment exporter (~$8B)
- Many family-run businesses, especially in Java
- Archipelago logistics adds 3–5 days to transit
- Growing domestic consumption market

## Finance Facts
- Bank lending: 10–15% p.a.
- Rupiah volatility: 5–10% swings per quarter
- Limited trade finance literacy among SME owners

## Trade Relationships
- Top buyers: H&M, Primark, Walmart, Target (basic knitwear)
- Payment terms: OA 60–90 days

## Compliance Exposure
- [[../../regulations/REG-UFLPA]] (if cotton)
- [[../../regulations/REG-REACH]]
- [[../../regulations/REG-GPSR]]

## Pain Points
- [[../../pain-points/country/PP-IDN-001-rupiah-volatility]]
- [[../../pain-points/universal/PP-006-trade-finance-literacy]]
- [[../../pain-points/universal/PP-001-cashflow-gap]]

## Linked Personas
- [[../../personas/COMBO-007-indonesia-family-run]]

## Best Fit Products
- [[../financing-products/PROD-MINIARP]] (entry point — low friction onboarding)
- [[../financing-products/PROD-ARP]] (graduate to this after MiniARP)

## Dimension
- [[../../dimensions/DIM-1-country]]
