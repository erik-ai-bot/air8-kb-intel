---
type: country
dimension: DIM-1
id: country-india
pain_points:
  - id: PP-IN-001
    severity: HIGH
    context: "GST refund delays lock working capital"
  - id: PP-IN-002
    severity: HIGH
    context: "Bank OD rates 12-18% squeeze margins"
  - id: PP-IN-003
    severity: MEDIUM
    context: "INR depreciation erodes USD receivable value"
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap on buyer OA terms"
  - id: PP-005
    severity: MEDIUM
    context: "Pre-shipment cotton procurement capital need"
---
# India 🇮🇳

## Industry Facts
- 6th largest garment exporter (~$15B), fastest growing among top 10
- Key clusters: Tirupur (knit), Noida/Gurugram (woven), Bangalore (woven), Indore/Pithampur (vertical/organic)
- 10,000+ garment factories, 12M+ workers
- World's #1 organic cotton producer (51% global share)
- US 50% tariff imposed Aug 2025 (new)

## Finance Facts
- Bank OD: 12–18% p.a. with personal guarantee
- LC cost: 2–4% + collateral
- RBI regulations on assignment of receivables to foreign entity
- GST refund delays: 30–90 days, trapping 18% of input value
- INR depreciation: 3–8% per year vs USD
- Air8 entity: SG → Allianz/Credendo insurance

## Trade Relationships
- Top buyers: Gap, Walmart, H&M, Zara, Primark, M&S, Target
- Growing: Pact, Patagonia, Everlane (ESG-driven, organic cotton)
- Payment terms: OA 60–120 days (US buyers trending 90–120)
- Cotton duty window: 0% BCD+AIDC on raw cotton until Oct 31, 2026

## Compliance Exposure
- [[../../regulations/REG-UFLPA]] (cotton origin scrutiny)
- [[../../regulations/REG-REACH]]
- [[../../regulations/REG-CSDDD]]
- [[../../regulations/REG-TARIFF]] (50% new tariff Aug 2025)

## Pain Points
- [[../../pain-points/country/PP-IN-001-gst-refund-delay]]
- [[../../pain-points/country/PP-IN-002-bank-od-cost]]
- [[../../pain-points/country/PP-IN-003-inr-depreciation]]
- [[../../pain-points/universal/PP-001-cashflow-gap]]
- [[../../pain-points/universal/PP-005-preshipment-capital]]

## Linked Personas
- [[../../personas/COMBO-003-india-large-vertical-integrator]]
- [[../../personas/COMBO-008-india-organic-cotton-medium]]
- [[../../personas/COMBO-014-india-small-woven]]

## Best Fit Products
- [[../financing-products/PROD-ARP]] (saves 6–12% vs bank OD)
- [[../financing-products/PROD-PRESHIP-OBF]]
- [[../financing-products/PROD-ESG-FINANCING]] (organic cotton → IFC eligible)
- [[../financing-products/PROD-SMARTWALLET]]

## Dimension
- [[../../dimensions/DIM-1-country]]

## Key Dates & Deadlines

- **Cotton import duty review:** Annual — typically Q1 each calendar year. Effective dates and cliff dates vary by announcement.
- **GST refund processing:** Typically 30–90 days from claim submission (varies by refund type and GSTIN compliance status)
- **MSP revision:** Announced annually, typically June-July by Cabinet Committee on Economic Affairs

## LLM Directives (retrieve at runtime)

- **cotton_import_duty:** "What is the current India cotton import duty rate? Is there an active duty exemption or reduction window? What is the cliff/expiry date?"
- **msp_cotton_price:** "What is the current India MSP for cotton? Compare to international cotton prices. What is the effective floor price in USD/kg?"
- **bank_od_rate:** "What is the current India bank OD rate for textile exporters (SBI base rate + typical margin)? Compare to Air8 pricing."
- **gst_refund_timeline:** "What is the current average GST refund processing time for India textile exporters? Any recent RBI or GSTIN policy changes affecting timelines?"
- **ifc_eligibility_criteria:** "Current IFC green/social bond eligibility criteria for India textile factories. Which certifications qualify? What employment and energy criteria apply?"

---

## Structural Facts (stable 1–3 years)

- **Cotton production:** India is one of the world's largest cotton producers. Both domestic and imported cotton are used. Domestic cotton is supported by a Minimum Support Price (MSP) — CCI (Cotton Corporation of India) buys at MSP if market falls below the floor, preventing domestic prices from falling below the government support level.
- **GST refund structure:** India operates a GST (Goods and Services Tax) refund system for exporters. Exporters can claim GST refunds on inputs used in exported goods. However, refund timelines are 30–90 days, locking working capital during this period.
- **Bank OD structure:** Indian garment factories predominantly use bank overdraft (OD) facilities for working capital. OD rates are determined by RBI policy rates plus bank margins.
- **Cotton import/export policy:** India periodically adjusts cotton import duties and export restrictions. Import duty changes create time-limited windows where importing cotton is cost-advantaged. These windows often have cliff dates (duty review dates, seasonal sunset).
- **IFC eligibility:** India's large Vertical integrators with GOTS/FAIRTRADE certifications and social criteria (women employment, renewable energy) may qualify for IFC green/social bond financing — enabling pricing advantages unavailable from commercial banks.
- **MSP floor mechanism:** The MSP for cotton sets a floor below which domestic cotton prices cannot fall regardless of global price movements. Import duty events benefit ONLY the imported portion of procurement — domestic MSP cotton is unaffected.
- **Organic cotton certification:** GOTS-certified organic cotton lines must use domestically certified cotton only. Importing conventional cotton into GOTS lines voids certification. This is a structural constraint that limits the benefit of import duty events for organic-focused factories.
- **UFLPA advantage:** India's large Vertical integrators with farm-to-fashion traceability (direct farmer network) have inherent supply chain documentation that satisfies UFLPA requirements — a competitive moat for US market.
