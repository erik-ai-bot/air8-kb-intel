# Country: Vietnam

- id: COUNTRY-VN
- type: country_context
- category: country_facts
- freshness: annual
- last_updated: 2026-07-01

---

## Structural Facts (stable 1–3 years)

- **FDI structure dominance:** Vietnam's garment export sector is heavily FDI-dominated. The majority of large-volume exporters are wholly or partially foreign-owned (Taiwan, South Korea, Hong Kong, Japan investors). This creates the "parent authority issue" — financing decisions for Vietnamese factories are made at the parent company headquarters (Taiwan HQ, Korean HQ), not at the factory level. Air8 BD must engage at parent level, not factory level.
- **CPTPP context:** Vietnam is a signatory of CPTPP (Comprehensive and Progressive Agreement for Trans-Pacific Partnership). This provides preferential access to key markets including Canada, Japan, and Australia. Yarn-forward rules of origin requirements apply — garments exported under CPTPP must use locally produced yarn. This incentivizes domestic yarn production investment.
- **China+1 beneficiary:** Vietnam is the primary beneficiary of Western buyer China+1 diversification strategies. Significant US buyer sourcing has shifted to Vietnam since 2018. However, this creates concentration risk in the Vietnam book — Vietnam has become a correlated exposure.
- **Parent authority issue:** FDI factories in Vietnam cannot independently commit to financing facilities without parent company approval. This creates longer BD cycles and requires different approach vs locally-owned factories. Decision timeline: 3–6 months vs 1–3 months for locally-owned.
- **Yarn-forward vs tariff consideration:** Under CPTPP and US-Vietnam trade arrangements, origin rules may require local (Vietnam or CPTPP origin) yarn to qualify for preferential tariff treatment. China-origin yarn inputs may void preferential tariff benefits.
- **China input dependency:** Despite being a China+1 beneficiary, many Vietnam FDI factories source yarn and fabric inputs from China. Any China supply disruption or tariff event affecting China inputs also affects Vietnam factory costs.

## Key Dates & Deadlines

- **CPTPP preferences:** Currently in force. Check for any specific renegotiation or member addition timelines.
- **US-Vietnam trade review:** Check for any bilateral trade reviews or GSP status.

## LLM Directives (retrieve at runtime)

- **vn_fdi_decision_structure:** "For FDI garment factories in Vietnam (Taiwan/Korean/HK parent), what is the typical decision-making structure for trade finance? Who must approve and at what organizational level?"
- **cptpp_yarn_forward:** "Current yarn-forward rule of origin requirements under CPTPP for Vietnam garment exports to Canada, Japan, Australia. What % of Vietnam garment exporters currently qualify?"
- **china_plus_one_status:** "Current status of US/EU buyer China+1 sourcing shifts to Vietnam — volume trends, share of orders, any announced changes?"
- **china_input_dependency:** "What % of Vietnam garment factory inputs (yarn, fabric) are currently sourced from China? Any recent shifts to ASEAN or local sourcing?"

---

## COMBO references using this country file
- COMBO-006 (Vietnam FDI) — primary
