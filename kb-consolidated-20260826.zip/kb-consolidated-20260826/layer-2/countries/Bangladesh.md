---
type: country
dimension: DIM-1
id: country-bangladesh
pain_points:
  - id: PP-BD-001
    severity: HIGH
    context: "56% wage hike squeezing margins critically"
  - id: PP-BD-002
    severity: HIGH
    context: "Political instability, 15-20 disruption days/yr"
  - id: PP-BD-003
    severity: HIGH
    context: "LDC graduation ends EU EBA access post-2029"
  - id: PP-001
    severity: HIGH
    context: "Cash cycle 90-120 days, acute WC pinch"
  - id: PP-005
    severity: MEDIUM
    context: "30% prepay for raw material at order-booking"
---
# Bangladesh 🇧🇩

## Industry Facts
- 2nd largest garment exporter globally (~$47B exports FY2024)
- 4,000+ RMG factories, 4M+ workers (80% women)
- Minimum wage: BDT 12,500/month ($113) — 56% increase Dec 2023
- Chittagong port: avg 7–10 day congestion; inland adds 2–3 days
- Political risk: hartals average 15–20 days/year disruption
- NPL ratio surged to 35.73% by Sep 2025 — banking sector tightening

## Finance Facts
- Bank LC cost: 3–5% all-in, processing 45–60 days
- Collateral: 100–150% (factory land/building + personal guarantee)
- Bangladesh Bank FX: export proceeds must be repatriated within 4 months
- ECIC coverage available via Air8 HK entity

## Trade Relationships
- Top buyers: H&M, Zara/Inditex, Primark, Walmart, Target, C&A, Lidl
- Payment terms: OA 60–120 days (trending longer)
- LDC graduation risk: EU EBA duty-free access ends post-2029 (9.6–12% tariff incoming)

## Compliance Exposure
- [[../../regulations/REG-UFLPA]] (if cotton → US market)
- [[../../regulations/REG-REACH]] (EU market)
- [[../../regulations/REG-CSDDD]] (EU buyers)
- Accord/RSC: 2,300+ factories covered, ongoing remediation

## Pain Points
- [[../../pain-points/country/PP-BD-001-wage-hike]]
- [[../../pain-points/country/PP-BD-002-political-instability]]
- [[../../pain-points/country/PP-BD-003-ldc-graduation]]
- [[../../pain-points/universal/PP-001-cashflow-gap]]
- [[../../pain-points/universal/PP-005-preshipment-capital]]

## Linked Personas
- [[../../personas/COMBO-002-bangladesh-bank-lc]]
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-012-cambodia-eba-dependent]] (similar dynamic)

## Best Fit Products
- [[../financing-products/PROD-ARP]] (replace LC — no collateral, T+1)
- [[../financing-products/PROD-PRESHIP-RT2C]]
- [[../financing-products/PROD-PAYGUARD]]

## Dimension
- [[../../dimensions/DIM-1-country]]

## Key Dates & Deadlines

- **LDC graduation decision:** November 2026 (UN General Assembly)
- **EU EBA transition period ends:** 2029 (after graduation)
- **GSP+ eligibility review:** Ongoing — BD must ratify 32 conventions before 2029 to qualify
- **Post-2029 tariff without GSP+:** 9.6–12% on garments

## LLM Directives (retrieve at runtime)

- **bank_rate:** "What is the current local bank financing rate (OD, LC) for Bangladeshi garment factories? Compare to offshore USD trade finance pricing."
- **india_yarn_sourcing:** "What is the current Bangladesh cotton/yarn import origin breakdown by % (India, China, Pakistan, local)? Note any recent shifts."
- **wage_trajectory:** "What is the current Bangladesh garment sector minimum wage and trajectory over the past 2 years? Is the +56% 2024 increase stable or subject to further revision?"
- **ldc_graduation_gsp_status:** "What is the latest status of Bangladesh's GSP+ ratification progress? How many of 32 required ILO/UN conventions have been ratified?"
- **hartal_disruption:** "What is the average production days lost per year in Bangladesh garment sector due to political disruptions (hartals, strikes) over the past 3 years?"

---

## Structural Facts (stable 1–3 years)

- **LDC Status:** Bangladesh is a Least Developed Country (LDC). UN graduation decision: November 2026. EU EBA (Everything But Arms) transition period continues until 2029.
- **Post-EBA tariff:** After EBA transition ends (2029), Bangladesh faces 9.6–12% EU garment tariff UNLESS it qualifies for GSP+. GSP+ requires ratification of 32 ILO/UN conventions — Bangladesh has not completed this as of last review.
- **Cotton import structure:** Bangladesh does NOT produce cotton. It is 100% import-dependent for cotton/yarn inputs. Primary sourcing: India (~60%), China (~25-30%), Pakistan (~10-15%), local mills (minor). Import-dependent structure means: any India cotton price event benefits BD CMT factories only INDIRECTLY and with lag.
- **Buyer-nominated model dominance:** ~80-95% of garment orders in Bangladesh are CMT (Cut-Make-Trim), where the buyer nominates the fabric/yarn source. Raw material price events do NOT benefit the factory — savings stay with the buyer's sourcing team.
- **Hartal/political disruption:** Bangladesh experiences periodic political disruptions (hartals, strikes). Factory production lost to political disruption is a recurring structural cost, not a one-off event.
- **BSCI/Sedex compliance gap:** Most Bangladeshi factories hold BSCI or Sedex audits. However, BSCI/Sedex audit pass ≠ CSDDD or UFLPA compliance. This gap is hidden from factories who believe their audit results protect them.
- **Shadow factory risk:** When factories are overbooked, 10–20% of production may be outsourced to unverified sub-contractors without buyer or Air8 awareness — quality and compliance exposure.
- **Banking system:** Bangladesh banking system is under structural stress. Bank of Bangladesh policy rates and local LC rates are subject to regulatory change. Offshore USD trade finance is a direct alternative to local bank LC.

## BD/KH Shared Exposure Notes

# Country Context: Bangladesh & Cambodia — Shared LDC/EBA Dynamics

- id: COUNTRY-BD-KH-COMMON
- type: country_context
- category: country_facts
- freshness: annual
- last_updated: 2026-07-01

---

## Overview

Bangladesh (BD) and Cambodia (KH) share a common structural dynamic: both are LDC (Least Developed Countries) currently benefiting from EU EBA (Everything But Arms) duty-free access for garment exports. Both face a similar graduation trajectory that will end this advantage.

This file documents the SHARED structural context. Country-specific details are in BD.md and KH considerations within COMBO-012.

---

## Structural Facts (stable 1–3 years)

- **LDC status:** Both Bangladesh and Cambodia export garments to EU duty-free under EBA (0% tariff vs MFN tariff of 9.6–12% for standard origins). This is the single most important structural trade advantage for both countries.
- **EBA transition mechanism:** When an LDC graduates from LDC status, it enters a 3-year EBA transition period where duty-free access is maintained. After transition, the country faces standard GSP tariff (if eligible) or MFN tariff.
- **GSP+ pathway:** EU GSP+ provides reduced tariffs (not zero) for qualifying countries that ratify 32 ILO/UN conventions. Both BD and KH would need to qualify for GSP+ to maintain reduced-tariff access post-transition.
- **Buyer vulnerability:** EU buyers (Primark, H&M, Lidl, Aldi) heavily source from BD and KH precisely BECAUSE of the 0% duty advantage. If this advantage disappears, buyers will reassess sourcing strategy. Buyer nervousness about LDC graduation starts BEFORE graduation — factories with no ESG/GSP+ preparation may lose RFQs.
- **Factory preparation gap:** Most BD and KH factories have not begun preparing for post-EBA reality. The gap between audit-certified status and actual GSP+ readiness is wide. This creates both a risk (business model threat) and an Air8 opportunity (become the advisor during transition).
- **Timeline asymmetry:** Bangladesh graduation decision was November 2026, EBA ends 2029. Cambodia LDC status is more recent — check current UN LDC review cycle for KH graduation date. The shared dynamic means the KB must track BOTH timelines.

## Key Dates & Deadlines

- **Bangladesh LDC graduation decision:** November 2026
- **Bangladesh EBA transition period:** 2026–2029
- **Bangladesh post-EBA MFN tariff (without GSP+):** 9.6–12% on garments
- **Cambodia LDC graduation:** Subject to UN LDC review — verify current status
- **GSP+ ratification deadline for both:** Must be completed before EBA transition ends

## LLM Directives (retrieve at runtime)

- **bd_ldc_status:** "Current Bangladesh LDC graduation timeline: confirmed graduation date, EBA transition period end date, GSP+ ratification progress."
- **kh_ldc_status:** "Current Cambodia LDC graduation status and timeline. Is Cambodia's EBA access currently at risk? What is the GSP+ eligibility position?"
- **gsp_plus_requirements:** "What are the 32 ILO/UN conventions required for EU GSP+ qualification? How many has Bangladesh / Cambodia ratified? What remains?"
- **eu_buyer_sourcing_alternatives:** "Which countries do EU buyers (Primark, H&M) consider as alternatives to Bangladesh and Cambodia if EBA tariff advantage disappears? What is the cost comparison?"

---

## COMBO references using this file
- COMBO-002 (Bangladesh CMT) — see also BD.md
- COMBO-012 (Cambodia EBA) — primary use of this shared context

