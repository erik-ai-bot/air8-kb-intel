# Country Context: Bangladesh & Cambodia — Shared LDC/EBA Dynamics

- id: COUNTRY-BD-KH-COMMON
- type: country_context
- category: country_facts
- freshness: annual
- last_updated: 2026-07-01

---

## Overview

Bangladesh (BD) and Cambodia (KH) share a common structural dynamic: both are LDC (Least Developed Countries) currently benefiting from EU EBA (Everything But Arms) duty-free access for garment exports. Both face a similar graduation trajectory that will end this advantage.

This file documents the SHARED structural context. Country-specific details are in BD.md and KH considerations within COMBO-012.

---

## Structural Facts (stable 1–3 years)

- **LDC status:** Both Bangladesh and Cambodia export garments to EU duty-free under EBA (0% tariff vs MFN tariff of 9.6–12% for standard origins). This is the single most important structural trade advantage for both countries.
- **EBA transition mechanism:** When an LDC graduates from LDC status, it enters a 3-year EBA transition period where duty-free access is maintained. After transition, the country faces standard GSP tariff (if eligible) or MFN tariff.
- **GSP+ pathway:** EU GSP+ provides reduced tariffs (not zero) for qualifying countries that ratify 32 ILO/UN conventions. Both BD and KH would need to qualify for GSP+ to maintain reduced-tariff access post-transition.
- **Buyer vulnerability:** EU buyers (Primark, H&M, Lidl, Aldi) heavily source from BD and KH precisely BECAUSE of the 0% duty advantage. If this advantage disappears, buyers will reassess sourcing strategy. Buyer nervousness about LDC graduation starts BEFORE graduation — factories with no ESG/GSP+ preparation may lose RFQs.
- **Factory preparation gap:** Most BD and KH factories have not begun preparing for post-EBA reality. The gap between audit-certified status and actual GSP+ readiness is wide. This creates both a risk (business model threat) and an Air8 opportunity (become the advisor during transition).
- **Timeline asymmetry:** Bangladesh graduation decision was November 2026, EBA ends 2029. Cambodia LDC status is more recent — check current UN LDC review cycle for KH graduation date. The shared dynamic means the KB must track BOTH timelines.

## Key Dates & Deadlines

- **Bangladesh LDC graduation decision:** November 2026
- **Bangladesh EBA transition period:** 2026–2029
- **Bangladesh post-EBA MFN tariff (without GSP+):** 9.6–12% on garments
- **Cambodia LDC graduation:** Subject to UN LDC review — verify current status
- **GSP+ ratification deadline for both:** Must be completed before EBA transition ends

## LLM Directives (retrieve at runtime)

- **bd_ldc_status:** "Current Bangladesh LDC graduation timeline: confirmed graduation date, EBA transition period end date, GSP+ ratification progress."
- **kh_ldc_status:** "Current Cambodia LDC graduation status and timeline. Is Cambodia's EBA access currently at risk? What is the GSP+ eligibility position?"
- **gsp_plus_requirements:** "What are the 32 ILO/UN conventions required for EU GSP+ qualification? How many has Bangladesh / Cambodia ratified? What remains?"
- **eu_buyer_sourcing_alternatives:** "Which countries do EU buyers (Primark, H&M) consider as alternatives to Bangladesh and Cambodia if EBA tariff advantage disappears? What is the cost comparison?"

---

## COMBO references using this file
- COMBO-002 (Bangladesh CMT) — see also BD.md
- COMBO-012 (Cambodia EBA) — primary use of this shared context
