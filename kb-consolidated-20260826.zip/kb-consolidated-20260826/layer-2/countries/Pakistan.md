---
type: country
dimension: DIM-1
id: country-pakistan
pain_points:
  - id: PP-PK-001
    severity: HIGH
    context: "Energy crisis adds 10-20% production cost"
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap, severe WC shortage"
  - id: PP-002
    severity: HIGH
    context: "CRITICAL: local bank rates 15-22% inaccessible"
---
# Pakistan 🇵🇰

## Industry Facts
- 4th largest cotton producer globally
- World-class home textiles (towels, bed linen) + strong denim
- Clusters: Karachi, Lahore, Faisalabad, Sialkot
- Energy crisis: frequent power outages add 10–20% to production cost
- 60% of exports = textiles — extremely concentrated

## Finance Facts
- Bank rates: 15–22% p.a. (among highest in Asia)
- SBP FX controls limit USD availability
- Political instability creates bank credit tightening cycles
- Air8 entity: SG → ECIC/Allianz insurance
- Top denim mills: Artistic Milliners, Soorty ($100M–$400M+ revenue)

## Trade Relationships
- Top buyers: IKEA, Walmart, H&M, TJX (home textiles)
- Payment terms: OA 60–120 days

## Compliance Exposure
- [[../../regulations/REG-UFLPA]] (Pakistani cotton faces CBP scrutiny)
- [[../../regulations/REG-REACH]]
- [[../../regulations/REG-CSDDD]]

## Pain Points
- [[../../pain-points/country/PP-PK-001-energy-crisis]]
- [[../../pain-points/universal/PP-001-cashflow-gap]]
- [[../../pain-points/universal/PP-002-financing-cost]] (CRITICAL — 15–22% local rates)

## Linked Personas
- [[../../personas/COMBO-009-pakistan-home-textile]]
- [[../../personas/COMBO-001-south-asian-small-knit]]

## Best Fit Products
- [[../financing-products/PROD-ARP]] (offshore USD — massive saving vs 15–22% local)
- [[../financing-products/PROD-POOL]]

## Air8 Priority
CRITICAL — local credit is essentially inaccessible. Air8's strongest value proposition globally.

## Dimension
- [[../../dimensions/DIM-1-country]]

## Key Dates & Deadlines

- **SBP policy reviews:** Periodic, tied to IMF programme requirements. Check for current FX control status.
- **DRAP / textile policy reviews:** Annual — government textile incentive packages reviewed.

## LLM Directives (retrieve at runtime)

- **energy_cost_benchmark:** "Current Pakistan electricity cost for textile factories (grid rate vs generator backup rate). Compare to India and Bangladesh per kWh and per-unit garment/home textile production cost."
- **bank_rate:** "Current SBP policy rate and typical commercial bank lending rate for PK textile exporters (working capital OD/LC). Compare to offshore USD trade finance."
- **pk_vs_india_home_textile:** "Compare Pakistan vs India FOB cost for towels/bed sheets for US and EU buyers post-[event]. Factor in: cotton cost, energy cost, labor, and logistics."
- **els_certification_status:** "What is the current market premium for ELS-certified Pakistani cotton in US and EU home textile buyers? Is the premium verified and documented in buyer contracts?"
- **pk_export_outlook:** "Current Pakistan home textile export volumes to US and EU. Are major buyers maintaining PK as primary source or exploring alternatives?"

---

## Structural Facts (stable 1–3 years)

- **Energy crisis context:** Pakistan's energy sector is in structural crisis. Textile factories rely on a mix of grid power and generator backup when the grid fails. Generator backup power costs significantly more than grid power, adding 10–20% per-unit production cost vs peers. This is the PRIMARY structural pain for PK factories — it is not addressable by trade finance.
- **ELS cotton moat:** Pakistan's Punjab region produces Extra-Long Staple (ELS) cotton — measurably softer and more durable than standard cotton. Pakistan does NOT produce commodity short-staple cotton at scale. ELS is a quality moat for home textile (towels, bedding) vs Indian commodity alternatives. However, the moat requires certification to be verifiable by buyers.
- **Cotton producer status:** Pakistan is a major cotton producer (primarily in Punjab province). Unlike Bangladesh, Pakistan does NOT import cotton as a primary input — factories source domestically. This means India cotton duty events create a THREAT direction (India gets cheaper cotton → Indian home textiles become more competitive), NOT a benefit for Pakistani factories.
- **Bank utilisation norms:** Pakistani garment factories typically operate with bank credit facilities highly utilised. State Bank of Pakistan (SBP) FX controls limit USD availability for input procurement.
- **60% export textiles:** Textiles account for approximately 60% of Pakistan's total exports. Sector-wide stress has outsized macroeconomic impact — buyer nervousness about Pakistan as a sourcing base is systemic.
- **UFLPA advantage:** Pakistan ELS cotton is clearly non-Xinjiang origin and documentable to field level. This is a US market supply chain compliance advantage for buyers requiring UFLPA documentation.
- **SBP FX controls:** State Bank of Pakistan restrictions on USD outflows limit ability to import specialty inputs (dyes, chemicals, equipment). This constrains product development.
