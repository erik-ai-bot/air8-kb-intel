# Country: China

- id: COUNTRY-CN
- type: country_context
- category: country_facts
- freshness: annual
- last_updated: 2026-07-01

---

## Structural Country Facts (stable 1–3 years)

- **RMB regime:** Managed float vs USD; PBOC intervenes to limit volatility. RMB movements affect CN factory competitiveness for USD-priced export orders.
- **Section 301 tariff schedule:** US tariffs on CN goods imposed under Section 301 (up to 145% peak Apr 2025, reduced under 90-day US-China trade deal). See LLM directive for current rate by HTS code.
- **Cotton controversy:** Xinjiang cotton (XPCC-linked) subject to UFLPA rebuttable presumption in US/EU. All China-origin garments with any Xinjiang cotton face US Customs scrutiny. EU developing similar traceability requirements. Factories with US/EU-bound production must maintain per-order cotton traceability documentation.
- **China+1 structural trend:** CN share of US apparel imports declined structurally (~33% in 2017 → ~21% in 2025) driven by Section 301 tariffs and buyer de-sourcing strategy. This trend continues regardless of individual events. CN factories with significant US exposure are financing a structurally shrinking book.
- **Keqiao/Shaoxing fabric ecosystem:** Keqiao (Shaoxing, Zhejiang) is the world's largest fabric market. Chinese garment factories buy fabric from Keqiao mills, not raw cotton directly. Any cotton price event reaches CN factories only via Keqiao mill input cost reduction, with 90–180 day lag and partial passthrough.

> **Internal Air8 operational rules for China (Hengqin entity caps, SAFE compliance, Sinosure, SSQ e-signing)
> have been moved to `_playbooks/china-operations.md`. Do not embed operational rules in this country file.**

## Key Dates & Deadlines

- **UFLPA enforcement:** Active and ongoing. US Customs enforcement at port of entry with no advance warning. Documentation must be ready BEFORE shipment.
- **Section 301 tariff reviews:** Periodic USTR review cycles. Check for current tariff rate applicable to specific product categories (HTS codes).
- **Internal Air8 review cadence:** See `_playbooks/china-operations.md` for Hengqin entity cap review schedule.

## LLM Directives (retrieve at runtime)

- **us_tariff_rate:** "Current US tariff rate on China cotton apparel (HTS 6109, 6205 — key categories). Total effective rate including Section 301."
- **keqiao_fabric_cost:** "Current Keqiao fabric market pricing for [material] — has it adjusted post-cotton event? What is the passthrough timeline from Keqiao mills to CN garment factories?"
- **eu_buyer_cn_sentiment:** "Current EU buyer (Zara, H&M) sourcing strategy from China — maintaining or reducing? Speed advantage still intact?"
- **sinosure_policy:** "Current Sinosure premium rates and coverage scope for CN garment exports. Any recent policy changes affecting monthly declaration requirements?"

---

## COMBO references using this country file
- COMBO-004 (China Full Package T-shirt/Woven) — primary
- COMBO-013 (Multi-Country) — partial
