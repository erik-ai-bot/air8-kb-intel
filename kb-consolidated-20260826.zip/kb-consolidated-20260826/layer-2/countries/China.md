---
type: country
dimension: DIM-1
id: country-china
pain_points:
  - id: PP-CN-001
    severity: HIGH
    context: "SAFE cross-border complexity limits capital"
  - id: PP-CN-002
    severity: HIGH
    context: "Sinosure declaration burden on exporters"
  - id: PP-CN-003
    severity: MEDIUM
    context: "Hengqin portfolio capacity constraints"
  - id: PP-001
    severity: HIGH
    context: "Receivables gap on OA terms to EU/US buyers"
---
# China 🇨🇳

## Industry Facts
- Largest garment exporter globally (~$175B, declining share)
- Rising labor costs in coastal cities: avg $700–900/month
- China+1 strategy driving orders to Vietnam, Bangladesh, India
- Government policy shifting to higher-value manufacturing

## Finance Facts
- Domestic factoring: fragmented, hidden fees, opaque pricing
- Sinosure: monthly paper declaration by 15th — miss = lost coverage
- Air8 Hengqin entity constraints:
  - Single company ≤40% of portfolio
  - Group ≤50% of portfolio
  - Total balance ≤10× registered capital
- Contract signing: SSQ (上上签) required for CN entities
- SAFE regulations on offshore receivable assignment

## Trade Relationships
- Diverse buyer base (US, EU, Japan, Australia, emerging markets)
- Payment terms: OA 30–90 days
- US Section 301 tariffs: 25–50% on most apparel
- UFLPA exposure: even non-Xinjiang cotton faces CBP scrutiny

## Compliance Exposure
- [[../../regulations/REG-UFLPA]] (VERY HIGH — even non-Xinjiang cotton)
- [[../../regulations/REG-REACH]]
- [[../../regulations/REG-CSDDD]]
- [[../../compliance/COMP-SAFE]]
- [[../../compliance/COMP-SINOSURE]]

## Pain Points
- [[../../pain-points/country/PP-CN-001-safe-complexity]]
- [[../../pain-points/country/PP-CN-002-sinosure-burden]]
- [[../../pain-points/country/PP-CN-003-hengqin-capacity]]
- [[../../pain-points/universal/PP-001-cashflow-gap]]

## Linked Personas
- [[../../personas/COMBO-004-china-medium-woven]]

## Best Fit Products
- [[../financing-products/PROD-ARP]] (via Hengqin entity)
- [[../financing-products/PROD-POOL]]
- [[../financing-products/PROD-SMARTWALLET]]

## Dimension
- [[../../dimensions/DIM-1-country]]

## Key Dates & Deadlines

- **UFLPA enforcement:** Active and ongoing. US Customs enforcement at port of entry with no advance warning. Documentation must be ready BEFORE shipment.
- **Section 301 tariff reviews:** Periodic USTR review cycles. Check for current tariff rate applicable to specific product categories (HTS codes).
- **Internal Air8 review cadence:** See `_playbooks/china-operations.md` for Hengqin entity cap review schedule.

## LLM Directives (retrieve at runtime)

- **us_tariff_rate:** "Current US tariff rate on China cotton apparel (HTS 6109, 6205 — key categories). Total effective rate including Section 301."
- **keqiao_fabric_cost:** "Current Keqiao fabric market pricing for [material] — has it adjusted post-cotton event? What is the passthrough timeline from Keqiao mills to CN garment factories?"
- **eu_buyer_cn_sentiment:** "Current EU buyer (Zara, H&M) sourcing strategy from China — maintaining or reducing? Speed advantage still intact?"
- **sinosure_policy:** "Current Sinosure premium rates and coverage scope for CN garment exports. Any recent policy changes affecting monthly declaration requirements?"

---
