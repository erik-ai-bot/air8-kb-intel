# Country: Bangladesh

- id: COUNTRY-BD
- type: country_context
- category: country_facts
- freshness: annual
- last_updated: 2026-07-01

---

## Structural Facts (stable 1–3 years)

- **LDC Status:** Bangladesh is a Least Developed Country (LDC). UN graduation decision: November 2026. EU EBA (Everything But Arms) transition period continues until 2029.
- **Post-EBA tariff:** After EBA transition ends (2029), Bangladesh faces 9.6–12% EU garment tariff UNLESS it qualifies for GSP+. GSP+ requires ratification of 32 ILO/UN conventions — Bangladesh has not completed this as of last review.
- **Cotton import structure:** Bangladesh does NOT produce cotton. It is 100% import-dependent for cotton/yarn inputs. Primary sourcing: India (~60%), China (~25-30%), Pakistan (~10-15%), local mills (minor). Import-dependent structure means: any India cotton price event benefits BD CMT factories only INDIRECTLY and with lag.
- **Buyer-nominated model dominance:** ~80-95% of garment orders in Bangladesh are CMT (Cut-Make-Trim), where the buyer nominates the fabric/yarn source. Raw material price events do NOT benefit the factory — savings stay with the buyer's sourcing team.
- **Hartal/political disruption:** Bangladesh experiences periodic political disruptions (hartals, strikes). Factory production lost to political disruption is a recurring structural cost, not a one-off event.
- **BSCI/Sedex compliance gap:** Most Bangladeshi factories hold BSCI or Sedex audits. However, BSCI/Sedex audit pass ≠ CSDDD or UFLPA compliance. This gap is hidden from factories who believe their audit results protect them.
- **Shadow factory risk:** When factories are overbooked, 10–20% of production may be outsourced to unverified sub-contractors without buyer or Air8 awareness — quality and compliance exposure.
- **Banking system:** Bangladesh banking system is under structural stress. Bank of Bangladesh policy rates and local LC rates are subject to regulatory change. Offshore USD trade finance is a direct alternative to local bank LC.

## Key Dates & Deadlines

- **LDC graduation decision:** November 2026 (UN General Assembly)
- **EU EBA transition period ends:** 2029 (after graduation)
- **GSP+ eligibility review:** Ongoing — BD must ratify 32 conventions before 2029 to qualify
- **Post-2029 tariff without GSP+:** 9.6–12% on garments

## LLM Directives (retrieve at runtime)

- **bank_rate:** "What is the current local bank financing rate (OD, LC) for Bangladeshi garment factories? Compare to offshore USD trade finance pricing."
- **india_yarn_sourcing:** "What is the current Bangladesh cotton/yarn import origin breakdown by % (India, China, Pakistan, local)? Note any recent shifts."
- **wage_trajectory:** "What is the current Bangladesh garment sector minimum wage and trajectory over the past 2 years? Is the +56% 2024 increase stable or subject to further revision?"
- **ldc_graduation_gsp_status:** "What is the latest status of Bangladesh's GSP+ ratification progress? How many of 32 required ILO/UN conventions have been ratified?"
- **hartal_disruption:** "What is the average production days lost per year in Bangladesh garment sector due to political disruptions (hartals, strikes) over the past 3 years?"

---

## COMBO references using this country file
- COMBO-001 (SA small knit — partial BD context)
- COMBO-002 (Bangladesh CMT T-shirt) — primary
- COMBO-012 (Cambodia EBA — shared LDC dynamics, see BD_KH_common.md)
