---
type: country
dimension: DIM-1
id: country-vietnam
pain_points:
  - id: PP-VN-001
    severity: HIGH
    context: "FDI decision authority blocks local financing"
  - id: PP-001
    severity: HIGH
    context: "Parent HQ controls cash, local entity trapped"
  - id: PP-004
    severity: MEDIUM
    context: "Scale decisions require parent HQ approval"
---
# Vietnam 🇻🇳

## Industry Facts
- 3rd largest garment exporter (~$33B)
- Rapid growth from China+1 shift
- Strong FDI presence: 60%+ of garment capacity is Korean/Taiwanese-owned
- Dominant in sportswear/activewear (Nike, Adidas supply chain)
- Worker shortage in peak seasons

## Finance Facts
- Limited local factoring market
- FDI factories: financing decisions made at parent HQ (Korea/Taiwan)
- Domestic manufacturers: bank OD 8–12%

## Trade Relationships
- Top buyers: Nike, Adidas, Uniqlo, Gap, H&M (heavily sportswear)
- Payment terms: OA 60–90 days

## Compliance Exposure
- [[../../regulations/REG-UFLPA]] (if cotton-containing products → US)
- [[../../regulations/REG-REACH]]
- [[../../regulations/REG-CSDDD]]

## Pain Points
- [[../../pain-points/country/PP-VN-001-fdi-decision-authority]]
- [[../../pain-points/universal/PP-001-cashflow-gap]]
- [[../../pain-points/universal/PP-004-scalability-constraint]]

## Linked Personas
- [[../../personas/COMBO-006-vietnam-fdi-knit]]

## Best Fit Products
- [[../financing-products/PROD-ARP]] (pitch to parent HQ)
- [[../financing-products/PROD-PAYGUARD]]

## Key Nuance
Local GM often cannot sign agreements. Must identify and engage Korean/Taiwanese parent company.

## Dimension
- [[../../dimensions/DIM-1-country]]

## Key Dates & Deadlines

- **CPTPP preferences:** Currently in force. Check for any specific renegotiation or member addition timelines.
- **US-Vietnam trade review:** Check for any bilateral trade reviews or GSP status.

## LLM Directives (retrieve at runtime)

- **vn_fdi_decision_structure:** "For FDI garment factories in Vietnam (Taiwan/Korean/HK parent), what is the typical decision-making structure for trade finance? Who must approve and at what organizational level?"
- **cptpp_yarn_forward:** "Current yarn-forward rule of origin requirements under CPTPP for Vietnam garment exports to Canada, Japan, Australia. What % of Vietnam garment exporters currently qualify?"
- **china_plus_one_status:** "Current status of US/EU buyer China+1 sourcing shifts to Vietnam — volume trends, share of orders, any announced changes?"
- **china_input_dependency:** "What % of Vietnam garment factory inputs (yarn, fabric) are currently sourced from China? Any recent shifts to ASEAN or local sourcing?"

---

## Structural Facts (stable 1–3 years)

- **FDI structure dominance:** Vietnam's garment export sector is heavily FDI-dominated. The majority of large-volume exporters are wholly or partially foreign-owned (Taiwan, South Korea, Hong Kong, Japan investors). This creates the "parent authority issue" — financing decisions for Vietnamese factories are made at the parent company headquarters (Taiwan HQ, Korean HQ), not at the factory level. Air8 BD must engage at parent level, not factory level.
- **CPTPP context:** Vietnam is a signatory of CPTPP (Comprehensive and Progressive Agreement for Trans-Pacific Partnership). This provides preferential access to key markets including Canada, Japan, and Australia. Yarn-forward rules of origin requirements apply — garments exported under CPTPP must use locally produced yarn. This incentivizes domestic yarn production investment.
- **China+1 beneficiary:** Vietnam is the primary beneficiary of Western buyer China+1 diversification strategies. Significant US buyer sourcing has shifted to Vietnam since 2018. However, this creates concentration risk in the Vietnam book — Vietnam has become a correlated exposure.
- **Parent authority issue:** FDI factories in Vietnam cannot independently commit to financing facilities without parent company approval. This creates longer BD cycles and requires different approach vs locally-owned factories. Decision timeline: 3–6 months vs 1–3 months for locally-owned.
- **Yarn-forward vs tariff consideration:** Under CPTPP and US-Vietnam trade arrangements, origin rules may require local (Vietnam or CPTPP origin) yarn to qualify for preferential tariff treatment. China-origin yarn inputs may void preferential tariff benefits.
- **China input dependency:** Despite being a China+1 beneficiary, many Vietnam FDI factories source yarn and fabric inputs from China. Any China supply disruption or tariff event affecting China inputs also affects Vietnam factory costs.
