---
type: country
dimension: DIM-1
id: country-turkey
pain_points:
  - id: PP-TR-001
    severity: HIGH
    context: "TRY hyperinflation erodes local cost base"
  - id: PP-TR-002
    severity: HIGH
    context: "Bank credit contraction limits growth"
  - id: PP-001
    severity: HIGH
    context: "Cash flow gap on OA terms to EU buyers"
  - id: PP-002
    severity: HIGH
    context: "CRITICAL: 75% local rates make Air8 transformative"
---
# Turkey 🇹🇷

## Industry Facts
- 5th largest garment exporter (~$18B), strong in denim and knit
- Near-shoring advantage: 2–3 day shipping to EU vs 25–30 days from Asia
- Sophisticated manufacturing: denim laser/ozone finishing, technical knit
- Textile exports declined: $10.35B to $9.49B (2022–2024); 65,000+ jobs lost

## Finance Facts
- TRY hyperinflation: cumulative >300% since 2020
- Local bank rates peaked at 75% in 2024
- Bank credit lines being cut amid macro instability
- Sophisticated local factoring market exists: Air8 must win on speed + data

## Trade Relationships
- Top buyers: Zara/Inditex, H&M, Primark, C&A (near-shore fast fashion)
- Payment terms: OA 30–60 days (shorter due to proximity)

## Compliance Exposure
- [[../../regulations/REG-REACH]] (denim chemicals — HIGHEST exposure among all countries)
- [[../../regulations/REG-CSDDD]]
- [[../../regulations/REG-GPSR]]

## Pain Points
- [[../../pain-points/country/PP-TR-001-lira-hyperinflation]]
- [[../../pain-points/country/PP-TR-002-bank-credit-contraction]]
- [[../../pain-points/universal/PP-001-cashflow-gap]]
- [[../../pain-points/universal/PP-002-financing-cost]] (CRITICAL)

## Linked Personas
- [[../../personas/COMBO-005-turkey-denim-specialist]]

## Best Fit Products
- [[../financing-products/PROD-ARP]] (USD-denominated — natural hedge against TRY collapse)
- [[../financing-products/PROD-POOL]]

## Air8 Priority
CRITICAL — 75% local rates make Air8 SOFR+4% transformatively cheaper.

## Dimension
- [[../../dimensions/DIM-1-country]]

## Key Dates & Deadlines

- **EU ESPR (Ecodesign for Sustainable Products Regulation) for textiles:** Expected 2027. Compliance requirements for water use, chemical traceability, and product sustainability data.
- **EU CSDDD (Corporate Sustainability Due Diligence Directive):** Phased enforcement 2026–2028. First-tier supplier reporting requirements apply to Turkish garment factories supplying EU companies above revenue threshold.

## LLM Directives (retrieve at runtime)

- **try_bank_credit:** "Current state of TRY bank credit availability for Turkish garment exporters. What is the typical factoring rate in Turkey (TRY-denominated) vs Air8 EUR-denominated ARP pricing?"
- **eu_espr_timeline:** "Current status of EU ESPR implementation for textiles and denim. Which specific data requirements apply? When does enforcement begin?"
- **india_denim_threat:** "Current investment by Indian denim mills in laser/ozone finishing capabilities. Are any Indian mills winning EU buyer trials or sample orders in premium denim? Timeline for India to replicate Turkey's finishing moat?"
- **zara_turkey_sourcing:** "Current status of Zara/Inditex sourcing from Turkey — volume trends, share of total sourcing, any announced changes?"

---

## Structural Facts (stable 1–3 years)

- **TRY inflation context:** Turkey experienced systemic hyperinflation (cumulative >300% TRY since 2020). This is a structural backdrop, not a one-off event. TRY-denominated bank credit lines are being actively reduced by Turkish banks. Domestic factoring market exists but is TRY-denominated, creating FX risk for EUR-invoicing exporters.
- **EU proximity advantage:** Turkey's geographic proximity to EU (2–3 day shipping vs 25–30 days from Asia) is a structural competitive moat for EU fast fashion buyers using just-in-time or speed-to-market reorder models (e.g., Zara 14-day reorder model). This advantage is not replicable by any Asian origin.
- **REACH compliance baseline:** Turkish denim/textile factories selling to EU already comply with EU REACH regulations (SVHC substance restrictions). This compliance head-start is a competitive advantage over Asian origins as EU ESPR 2027 and CSDDD requirements tighten.
- **Denim finishing ecosystem:** Istanbul-based factories (Düzce, Bağcılar, Esenyurt) have concentrated denim finishing infrastructure: laser washing ($150–300K capital investment), ozone finishing ($80–150K), stone wash and permanganate. This equipment concentration defines the Istanbul premium denim segment. Interior Turkey (Düzce, Malatya) lacks this infrastructure.
- **EUR-denominated invoicing:** Istanbul garment exporters primarily invoice in EUR to EU buyers. EUR-denominated Air8 ARP facility naturally hedges TRY risk — factory earns EUR, Air8 charges EUR, no TRY exposure for either party.
- **CBRT policy:** The Central Bank of Turkey (CBRT) has periodically enacted unconventional monetary policy. Bank credit availability for exporters varies significantly with CBRT policy direction.
