# NODE · HARD-STOPS

**What this is.** Conditions that block FR release regardless of any other rule, auto-pass, or BD confirmation. Hard stops are not overridable at Ops level. Read by: SHI Validation Skill (SV3 — Resolve), first priority check.

Only rows with `valid_to = —` are active.

---

| Stop ID | Condition | Resolution Required | Resolves via | Valid from | Valid to |
|---------|-----------|---------------------|--------------|------------|---------|
| HS1 | No Air8 bank account AND no AR assignment clause AND no NoA/MNOA AND no pre-approved PSP arrangement | One of: Air8 account added to invoice / AR clause (G4) / NoA-MNOA executed / PSP pre-approved by management | NODE-auto-pass-rules [AP8.1, AP8.2, AP8.3] | 2026-08-13 | — |
| HS2 | New structure not previously approved (new PSP setup, new Amazon sub-account, new back-to-back, new platform) | Erik / management one-off approval obtained and on file before Ops release | Management approval email | 2026-08-13 | — |
| HS3 | Third-party consignee with no documented buyer link and no buyer confirmation | G4 must confirm relationship before release | G4 decision | 2026-08-13 | — |
| HS4 | Transport evidence cannot prove shipment (no BL, no FCR, no AWB, no portal/tracking, no verified alternative) | Alternative shipment proof must be obtained and verified | Carrier / G4 | 2026-08-13 | — |
| HS5 | Document is draft / unverifiable AND key payable fields (amount, due date, payee) are missing | Obtain final/verified document or G4 decision | G4 | 2026-08-13 | — |

---

## Hard Stop Priority Rule

For multi-trigger FRs: a single hard stop blocks the entire FR. Other triggers on the same FR cannot be released independently. Resolve all hard stops before processing any release.
