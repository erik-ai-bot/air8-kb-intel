# NODE · AUTO-PASS-RULES

**What this is.** Versioned auto-pass conditions derived from approved historical cases. Each rule has an ID, the trigger it resolves, the condition that must be true, the evidence required, and the case count (n) that justifies it. Read by: SHI Validation Skill (SV3 — Resolve).

**Governance:** A rule requires n ≥ 1 approved precedent case. Rules without `evidence` + `n` are provisional. To update: set `valid_to`, add new row with `valid_from` + evidence + n + log entry.

Only rows with `valid_to = —` are active.

---

## R1 Auto-Pass Rules — Payment Terms / Due Date

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP1.1 | Payment terms changed + BD or buyer written confirmation exists | BD/buyer email confirming new terms | 6 | 2026-08-13 | — |
| AP1.2 | Due date from non-standard date basis + BD/buyer written confirmation of which date applies | Written confirmation of date logic | 4 | 2026-08-13 | — |
| AP1.3 | Terms inconsistent across docs + confirmed governing document identified | BD identifies governing doc (usually invoice) | 3 | 2026-08-13 | — |
| AP1.4 | Tenor > policy limit | ESCALATE to G4 — NOT auto-pass; G4 pre-approval required | 4 | 2026-08-13 | — |
| AP1.5 | TJX buyer — any supplier | Due date = cargo received date (standing rule); split payment batch by sub-entity | TJX standing SHI #74 | 2026-08-13 | — |

**Cases supporting R1 rules:** Avanti/PetSmart, Beone/TJX, Cosmo/PPA+Bordic, Nitex/Seasalt, C&A/Vamani, Dynamic Decor/TJX, Triple999/Sophistiplate, Banatoys/TOI-Toys

---

## R2 Auto-Pass Rules — Quantity / Amount Variance

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP2.1 | Qty variance > 5% at item level but within total PO tolerance + BD confirms tolerance is at total level | BD written confirmation; Pranav email 10-Jul-2025 is standing authority | 8 | 2026-08-13 | — |
| AP2.2 | Qty difference = partial shipment + BD confirms buyer accepts partial | BD written confirmation; financed amount adjusted | 12 | 2026-08-13 | — |
| AP2.3 | Over-shipped qty + buyer written acceptance | Buyer email acceptance | 4 | 2026-08-13 | — |

**Cases supporting R2 rules:** Jiva/Chico's (AP2.1 anchor case), Cosmo/Bordic, Megix/LAUT, Nitex/Zalando, GAP/Pratibha, Innoweave/RDA

---

## R3 Auto-Pass Rules — Shipment Timing

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP3.1 | FOB terms + buyer appoints forwarder → late/partial shipment | Proof of FOB terms + buyer forwarder appointment; no additional BD confirmation needed | 10 | 2026-08-13 | — |
| AP3.2 | Late/early/partial + explicit BD or buyer email acceptance | Dated email from BD or buyer explicitly accepting | 8 | 2026-08-13 | — |
| AP3.3 | Buyer portal controls goods release timing → late shipment is buyer-caused | Evidence that buyer portal approval must precede logistics handover | 3 | 2026-08-13 | — |
| AP3.4 | PO dates marked "tentative" → no firm ship date defined | PO text showing tentative dates | 2 | 2026-08-13 | — |

**Cases:** Sara Suole/Clarks (AP3.1), Merlin Hawk (AP3.2), Nitex/Zalando (AP3.3), Gee Gee/Uniek (AP3.4)

---

## R4 Auto-Pass Rules — Transport Documents

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP4.1 | Draft FCR + forwarder is buyer-appointed | Proof that specific forwarder is buyer-designated (email, PO, buyer confirmation) | 5 | 2026-08-13 | — |
| AP4.2 | TJX buyer + draft FCR → Transcepta record as proof | Transcepta invoice submission and acceptance record | TJX SHI #74 | 2026-08-13 | — |
| AP4.3 | CMR used as transport document | Insurance company confirmation that CMR is accepted | 1 | 2026-08-13 | — |
| AP4.4 | Air shipment — no vessel/container detail | NOT an exception — no SHI required; air shipments explicitly excluded from vessel/container judgment | n/a | 2026-08-13 | — |

**Cases:** PD SD Exports (AP4.1), Emsons/NEXT (AP4.1), Nitex/Zalando (AP4.3 — insurance confirmation)

---

## R5 Auto-Pass Rules — Third-Party Shipper / Consignee

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP5.1 | Manufacturer as shipper (not supplier entity) + relationship documented | BD/supplier confirms manufacturing relationship; buyer awareness | 3 | 2026-08-13 | — |
| AP5.2 | Buyer-nominated forwarder appears as shipper on transport doc | PO or buyer email confirming forwarder appointment | 10+ | 2026-08-13 | — |
| AP5.3 | Third-party consignee = subsidiary / 100% owned entity of buyer | Buyer written confirmation of ownership/relationship | 3 | 2026-08-13 | — |

**Cases:** Beone/TJX (AP5.1 — Linkapparel), Createglory/Ziel (AP5.3 — Ameziel 100% owned), Vamani/C&A (AP5.3)

---

## R6 Auto-Pass Rules — PO / Invoice Format

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP6.1 | PO or invoice is system-generated / electronic / from buyer portal | Evidence of system/portal origin; buyer T&C must NOT explicitly require physical signature | 15+ | 2026-08-13 | — |
| AP6.2 | No Air8 bank account on invoice + invoice contains AR assignment clause (G4 pre-approved) | Clause text: "underlying AR assigned to Air8" on invoice; G4 approval on file | 3 | 2026-08-13 | — |
| AP6.3 | No physical PO (email order from buying house) + BD confirms this is standard for this buyer | BD written confirmation | 2 | 2026-08-13 | — |

**Note on AP6.1:** System-generated PO/invoice is the single most common SHI exception — applies in 15+ approved cases. The one exception: if buyer's own T&C explicitly mandates physical signature, AP6.1 does NOT apply.

**Cases anchor (AP6.1):** Avanti/PetSmart, Jiva/Chico's, Surya Roshni/FEIT, SVM/Fashion Depot, Pioneer Linens, 强丰/UNIQLO, Ahmed/Saul, Emsons/ShowPony, Radnik/Boden, Rajkamal

---

## R7 Auto-Pass Rules — Document Linkage

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP7.1 | No PO/invoice number on shipping doc + container number on invoice cross-links to BL | Container number and vessel details on invoice match BL | 2 | 2026-08-13 | — |
| AP7.2 | Name mismatch = abbreviation or trading name + registered address matches | Registered address confirmation or cross-document name match | 2 | 2026-08-13 | — |

**Cases:** Banatoys/TOI-Toys (AP7.1), Maroc Quality/Wear Pact (AP7.2)

---

## R8 Auto-Pass Rules — Payment Collection

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP8.1 | No Air8 account + AR assignment clause on invoice | G4 approval + clause on invoice | 3 | 2026-08-13 | — |
| AP8.2 | Airwallex/PSP collection account under pre-approved AWX project | NoA/MNOA executed + management awareness of AWX project | 4 | 2026-08-13 | — |
| AP8.3 | Amazon sub-account controlled by Air8 | Erik/management one-off approval on file; not standard Ops approval | 2 | 2026-08-13 | — |

**Cases:** Cosmo/PPA (AP8.1), Beone/TJX (AP8.2 — AWX project), Banatoys/Dollarstore (AP8.2), Life Plus/Amazon (AP8.3 — Erik Nov-28-2025), Aventean/Amazon (AP8.3 — management Jun-26-2026)

---

## R9 Auto-Pass Rules — Sampling / Portal-Based

| Rule ID | Condition | Evidence Required | n | Valid from | Valid to |
|---------|-----------|------------------|---|------------|---------|
| AP9.1 | Amazon/e-commerce buyer + pre-approved sampling protocol in place | Sampling scope document; portal reports; reconciliation files; audit trail retained | 3 | 2026-08-13 | — |
| AP9.2 | Buyer portal screenshot as delivery/acceptance proof + G4 awareness | Downloaded/exported portal screenshot; G4 on notice | 3 | 2026-08-13 | — |

**Cases:** Photonverse/Amazon (AP9.1), Life Plus/Amazon (AP9.1), 壹合/嘉士伯 (AP9.2), Hongkong Yongping/Walmart (AP9.2)
