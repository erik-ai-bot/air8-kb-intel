---
type: regulation
id: REG-TARIFF
---
# REG-TARIFF: US Section 301 Tariffs + New Tariffs (2025)

**Jurisdiction:** United States

## Current Status
| Country | Tariff Rate |
|---------|------------|
| China | 25–50% on most apparel (highest) |
| India | 50% on apparel (imposed Aug 2025 — NEW) |
| Vietnam | 10–25% |
| Bangladesh | Under discussion post-LDC graduation |

## Pain Point Reference
[[pain-points/compliance/PP-REG-TARIFF-001]]

## Affected Combos
[[personas/COMBO-004-china-medium-woven]] · [[personas/COMBO-014-india-small-woven]] · [[personas/COMBO-003-india-large-vertical-integrator]]
