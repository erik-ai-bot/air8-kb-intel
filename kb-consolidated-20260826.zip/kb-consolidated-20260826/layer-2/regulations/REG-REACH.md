---
type: regulation
id: REG-REACH
---
# REG-REACH: EU REACH (Registration, Evaluation, Authorisation of Chemicals)

**Jurisdiction:** EU (+ UK REACH separately) | **Effective:** 2007 (continuously updated)

## Scope
All products sold in EU that contain chemical substances. Products must NOT contain SVHC >0.1% w/w.

## Key Requirements
- BOS (Bill of Substances) required
- ECHA updates SVHC candidate list TWICE per year (Jan + Jul)
- Testing cost: $2,000–10,000 per substance per factory

## Highest Risk Products
- Denim (indigo, permanganate, PP spray, resin finishes)
- Children's apparel (stricter limits)
- Home textiles with fire retardant finishes

## Air8 Risk
DDP transactions where Air8 entity is importer of record → direct compliance liability.

## Pain Point Reference
[[pain-points/compliance/PP-REG-REACH-001]]

## Affected Combos
[[personas/COMBO-005-turkey-denim-specialist]] · [[personas/COMBO-004-china-medium-woven]] · [[personas/COMBO-009-pakistan-home-textile]]
