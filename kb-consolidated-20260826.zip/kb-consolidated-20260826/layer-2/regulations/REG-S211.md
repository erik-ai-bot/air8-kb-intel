---
type: regulation
id: REG-S211
---
# REG-S211: Canada Bill S-211 (Fighting Against Forced Labour and Child Labour)

**Jurisdiction:** Canada | **Effective:** January 1, 2024

## Scope
Entities with ≥$20M assets OR ≥$40M revenue operating in Canada.

## Requirements
Annual public reporting on forced labor / child labor risk in supply chain.

## Affected Combos
Combos selling to Canadian buyers (Gap Canada, Walmart Canada).

## Air8 Role
Supply chain traceability data (T4S) supports S-211 reporting requirements.
