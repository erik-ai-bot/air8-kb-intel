---
type: regulation
id: REG-UFLPA
---
# REG-UFLPA: Uyghur Forced Labor Prevention Act

**Jurisdiction:** United States | **Effective:** June 21, 2022

## Scope
ALL goods imported to US — rebuttable presumption for Xinjiang-origin content. Must provide "clear and convincing evidence" goods are NOT made with forced labor.

## Key Requirements
- Full supply chain traceability: finished good → raw material
- BOM, tier-by-tier mapping, origin certificates, audit reports

## Required Documents by Tier
| Tier | Documents |
|------|----------|
| Tier 1 (factory) | PO, Commercial Invoice, Packing List, BL |
| Tier 2 (mill) | PO/Contract, Invoice, Mill certificates, Testing reports |
| Tier 3 (spinner) | PO/Contract, Invoice, Origin certification |
| Tier 4+ (fiber/farm) | Origin certificates, Farm/plantation records, Lab test results |
| Cross-tier | BOM, BOS (Bill of Substances), SDS (Safety Data Sheet) |

## 2024 Enforcement Data
- Total detentions: 4,619 shipments (+14.9% YoY)
- Apparel detentions: 876 (2nd most targeted sector)
- Apparel clearance rate: **36%** (vs 58% all-sector average)
- 37 new entities added Jan 2025 (26 in cotton sector — Huafu Fashion + subsidiaries)

## Trigger Conditions
- market = US AND product contains cotton → ACTIVE
- country = CN → VERY HIGH risk
- country = BD/IN/PK/VN → MEDIUM risk (if cotton sourced from China Tier 2/3)
- organic_cotton with farm_traceability → LOW risk

## Air8 Role
- T4S Platform: 264+ POs traced, 164 styles, 74 suppliers, 7,000+ trade docs
- Traceability tier mapping (Tier 1 → Tier 4+)

## Pain Point Reference
[[pain-points/compliance/PP-REG-UFLPA-001]]

## Affected Combos
[[personas/COMBO-001-south-asian-small-knit]] · [[personas/COMBO-002-bangladesh-bank-lc]] · [[personas/COMBO-003-india-large-vertical-integrator]] · [[personas/COMBO-004-china-medium-woven]] · [[personas/COMBO-008-india-organic-cotton-medium]] · [[personas/COMBO-009-pakistan-home-textile]]
