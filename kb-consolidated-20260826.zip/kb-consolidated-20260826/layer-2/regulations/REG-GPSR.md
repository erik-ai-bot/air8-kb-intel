---
type: regulation
id: REG-GPSR
---
# REG-GPSR: EU General Product Safety Regulation

**Jurisdiction:** EU | **Effective:** December 13, 2024

## Requirements
- All consumer products must have "economic operator" designated in EU
- Product must bear EU Economic Operator name + contact info on product/packaging
- Online marketplace obligations (product safety information)

## Trigger
`market = EU AND product = consumer product`

## Affected
ALL EU-bound suppliers across all product categories.
