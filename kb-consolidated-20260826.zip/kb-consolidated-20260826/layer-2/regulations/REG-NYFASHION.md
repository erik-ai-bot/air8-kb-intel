---
type: regulation
id: REG-NYFASHION
---
# REG-NYFASHION: NY Fashion Act (Proposed)

**Jurisdiction:** New York State | **Status:** Proposed — not yet enacted

## Scope
Fashion companies in NY with >$100M global revenue.

## Requirements (if enacted)
- Supply chain mapping (≥50% of suppliers)
- Scope 1/2/3 GHG emissions disclosure

## Affected
Suppliers to NY-based brands: Ralph Lauren, PVH, Tapestry, etc.
