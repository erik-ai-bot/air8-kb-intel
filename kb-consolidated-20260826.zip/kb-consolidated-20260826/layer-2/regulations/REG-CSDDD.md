---
type: regulation
id: REG-CSDDD
---
# REG-CSDDD: EU Corporate Sustainability Due Diligence Directive

**Jurisdiction:** EU | **Published:** July 2024 | **Omnibus amendment:** Feb 2026

## Timeline
| Phase | Date | Threshold |
|-------|------|-----------|
| 1 | Jul 2028 | >€1.5B + 5,000 employees (~1,000 companies) |
| 2 | Jul 2029 | >€900M + 3,000 employees (~4,000 companies) |
| 3 | Jul 2029+ | >€450M + 1,000 employees (~6,000 companies) |

## Requirements
- Identify & assess adverse impacts in own operations + direct suppliers
- Prevent, cease, mitigate actual and potential adverse impacts
- Climate transition plan aligned with Paris Agreement
- Civil liability for damage caused by intent or negligence

## Already Happening
H&M, Zara/Inditex, Primark, C&A already sending DD questionnaires to suppliers NOW.

## Air8 Role
LF ecosystem provides factory-level data: VOICES ratings, HiggFEM, social audits, T4S traceability → Air8 suppliers have competitive advantage.

## Pain Point Reference
[[pain-points/compliance/PP-REG-CSDDD-001]]
