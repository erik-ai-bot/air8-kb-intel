---
type: persona
id: COMBO-005
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash flow gap on OA terms to EU buyers"
  - id: PP-002
    severity: HIGH
    context: "TRY bank rates erode EUR-denominated margins"
  - id: PP-003
    severity: MEDIUM
    context: "Revenue concentrated with Zara/H&M"
  - id: PP-TR-001
    severity: HIGH
    context: "TRY hyperinflation erodes local cost base"
  - id: PP-TR-002
    severity: HIGH
    context: "Bank credit contraction limits growth"
---

# COMBO-005: Turkey Denim Specialist

## Dimensions
- Country: [[dimensions/DIM-1-country]] (TR)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($20-50M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB)
- Product: [[dimensions/DIM-4-product-focus]] (denim)
- Market: [[dimensions/DIM-5-target-market]] (EU > US)
- Financing: [[dimensions/DIM-7-current-financing]] (local_factoring | bank_OD)
- Growth: [[dimensions/DIM-8-growth-stage]] (stable | struggling)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-003-buyer-concentration]]
- [[../../layer-1-reasoning/pain-points/country/PP-TR-001-lira-hyperinflation]]
- [[../../layer-1-reasoning/pain-points/country/PP-TR-002-bank-credit-contraction]]

## Products
- [[../financing-products/PROD-ARP]] (USD-denominated)
- [[../financing-products/PROD-POOL]]

## Compliance Exposure
- [[../regulations/REG-REACH]] (highest exposure — denim chemicals)
- [[../regulations/REG-CSDDD]]

## Data Entities
- fx.try_usd
- fx.try_eur
- [[data-entities/ENTITY-Buyer]] (payment_days)
- [[data-entities/ENTITY-Commodity]] (indigo_price)

## V2 Framework Extensions

### Structural Nuances
- "Denim = 95% cotton. Turkey sources from Turkish/Japanese mills — NOT Indian cotton; 0% India duty does NOT reduce Turkey's input cost"
- "Threat from opposite direction: Indian denim mills get cheaper cotton → can undercut Turkey on basic jeans in EU"
- "Turkey moat = laser/ozone finishing consistency + 2-3 day EU shipping. Hypothesis: Zara reorder model may structurally favour near-shore suppliers — needs buyer-level validation" ⚠️ PENDING ALICE REVIEW: claim that Zara 14-day reorder is impossible from Asian origin is too absolute — requires buyer-confirmed evidence before asserting
- "TRY hyperinflation is systemic but EUR-denominated ARP self-hedges: supplier earns EUR, Air8 charges EUR"
- "Hypothesis: Istanbul-area factories (proximity to buyers, full finishing) vs Interior Turkey factories (commodity denim, no finishing moat) may have different risk profiles" ⚠️ PENDING ALICE REVIEW: Istanbul vs Interior Turkey distinction lacks sourcing evidence — factory-level validation required before asserting as KB fact
- "Hypothesis: competitive threat from Indian denim mills may materialise as India invests in finishing technology — timeline uncertain" ⚠️ PENDING ALICE REVIEW: 18-24 month India timeline is too absolute — needs evidence on actual Indian denim finishing investment pace
- "EU ESPR 2027 mandates sustainability data India cannot yet provide — Turkey has window to build this moat"

### Particular Supplier (5-D)
demand:
  - "Zara / H&M reorder frequency — growing / flat / declining?"
buyers:
  - "% with top buyer direct relationship (vs via agent)?"
  - "Istanbul vs Interior Turkey location?"
product:
  - "Laser / ozone finishing capability?"
  - "Turkish domestic mill or import fabric?"
cash:
  - "EUR or USD invoiced? Payment delay trend?"
  - "TRY cost pressure — local cost base manageable?"
capacity:
  - "Full season allocation or spot orders?"
  - "Utilisation %?"

### What to Provide
- "Buyer list → direct relationship vs via agent (Zara / H&M direct = premium signal)"
- "Finishing capability evidence → laser / ozone cert or equipment list"
- "Fabric mill contracts → Turkish mill or import? Spot or fixed?"
- "Invoice currency split (EUR % vs USD %) → self-hedge indicator"

### What to Do
1. "No emergency pivot needed — Turkey finishing lead and EU proximity provide strong 2026 defence"
2. "Use global cotton softening as leverage when negotiating with Turkish fabric mills on next season pricing"
3. "Accelerate eco-denim investment (laser/ozone) — EU ESPR 2027 mandates sustainability data India cannot yet provide"
4. "Prepare EU buyer brief: 14-day TR vs 30-day India = 2 lost Zara selling cycles per season"

### Sub-Scenarios
sub_scenario_1:
  condition: "Istanbul premium — Zara/H&M direct, full laser/ozone capability"
  why: "Structurally protected from India in 2026. Receivables high quality, low dilution 2-3%, reliable payment."
  air8_signal: "EXPAND. EUR-denominated ARP on Zara/H&M receivables. Assess Air8's role in working capital relative to local banks — ask: has Air8 become more important vs bank lines? Have banks reduced credit limits or tightened collateral? ⚠️ PENDING ALICE REVIEW: do not assert Air8 is 'only liquidity source' without confirming bank/buyer finance alternatives have been exhausted"
  action: "Stay the course. Use cotton softening as leverage on Turkish mill pricing. Invest margin gain in CSDDD digital compliance data."

sub_scenario_2:
  condition: "Interior Turkey — value denim (Düzce/Malatya), basic jeans, no finishing moat"
  why: "India may challenge this segment as Indian denim mills invest in finishing technology — timeline uncertain. Buyer diversion possible. ⚠️ PENDING ALICE REVIEW: 18-month timeline needs evidence"
  air8_signal: "DO NOT EXPAND. Monitor buyer PO trend quarterly. If orders decline >15% YoY, reduce advance ratio proactively."
  action: "Watch for: buyer requesting price reductions, RFQ frequency dropping, sample orders from Indian denim mills. Any 2 signals in same quarter = flag for review."

### Competitive Position
moat: "Laser/ozone finishing capability + 2-3 day EU shipping (Zara 14-day reorder model)"
moat_horizon: "2026 strong; timeline for India to replicate finishing capability uncertain — ⚠️ PENDING ALICE REVIEW: 18-24 month figure needs evidence"
competitive_threat_from: ["COMBO-003-IN-Vertical"]
watch_signal: "Indian denim mill finishing investment pace; EU ESPR compliance data capability"

### Air8 Risk Parameters
air8_signal: "CONDITIONAL — ISTANBUL ONLY"
advance_ratio_normal: 85
advance_ratio_alert: 70
review_frequency: "quarterly"
trigger_for_reduction: "EU buyer PO declining >15% YoY OR interior Turkey signals"
monitoring_signals:
  - "Zara/H&M reorder frequency"
  - "Istanbul vs Interior revenue mix"
  - "EUR vs USD invoice split"
  - "Indian denim finishing investment news"

## V2 Assessment Chain

### impact_calculation
```yaml
formula: "moat_strength_score = (finishing_capability × proximity_advantage) - India_investment_pace"
generic_estimate: "CONDITIONAL signal; Istanbul premium = protected; Interior = at risk"
inputs:
  finishing_capability:
    source: "AC-02 supplier answer"
    values: [laser_ozone_full, partial, none]
    expert_review: "required — QAQC expert to validate finishing capability claim"
  buyer_relationship_type:
    source: "AC-01 supplier answer"
    values: [direct_zara_hm, via_agent, mixed]
    expert_review: "validate — BD expert to confirm direct vs agent relationship"
  eur_invoice_pct:
    source: "AC-03 supplier answer"
    default: 0.70
    expert_review: "validate_default — confirm typical EUR % for Istanbul premium denim"
```

### assessment_chain
```yaml
- id: AC-01
  dimension: "Buyer relationship quality — Istanbul premium or Interior value?"
  question: "Who are your top 3 buyers? Direct relationship or via agent? Istanbul or Interior location?"
  data_request: "Buyer list with relationship type (direct/agent); factory location"
  expert_review: "required — BD expert must verify direct Zara/H&M relationship (key signal)"
  branch:
    istanbul_direct_zara_hm:
      signal: EXPAND
      why: "Direct relationship + proximity = structurally protected in 2026"
      next: AC-02
    istanbul_via_agent:
      signal: CONDITIONAL
      note: "Agent margin reduces Air8 pricing advantage; verify buyer payment quality"
      next: AC-02
    interior_turkey:
      signal: DO_NOT_EXPAND
      why: "No finishing moat; India will challenge within 18 months"
      stop: true
      action: "Monitor quarterly; reduce if PO decline >15% YoY"

- id: AC-02
  dimension: "Finishing capability — is the moat real?"
  question: "Do you have laser / ozone finishing capability? What % of production uses it?"
  data_request: "Equipment list or certification; % of styles with laser/ozone finishing"
  expert_review: "required — QAQC expert to validate capability claim against equipment list"
  branch:
    full_laser_ozone:
      moat_confirmed: true
      unlocks: "EU ESPR 2027 competitive angle"
      next: AC-03
    partial_or_none:
      moat_weakened: true
      action: "BD: advise accelerate eco-denim investment; this is the window"
      next: AC-03

- id: AC-03
  dimension: "FX structure — is TRY macro risk hedged?"
  question: "What % of your invoices are EUR vs USD vs TRY?"
  data_request: "Invoice currency split (% EUR / USD / TRY) last 12 months"
  expert_review: "validate_default — risk team to confirm EUR-denominated ARP self-hedge logic"
  unlocks_calculation: "EUR_pct > 70% → ARP self-hedges TRY risk; below 70% → FX risk rises"
  next: AC-04

- id: AC-04
  dimension: "India threat timeline — is moat durable?"
  question: "Are you seeing any signs of Indian denim mills winning EU buyer trials or sample orders?"
  data_request: "Buyer RFQ changes; any sample requests sent to Indian mills by shared buyers"
  expert_review: "ai_extended — LLM monitors Indian denim investment news; expert validates when signals found"
  watch_signal: "Indian denim mill finishing investment pace"
```

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: istanbul_vs_interior_location
  why: "most critical dimension — Istanbul premium (laser/ozone, direct Zara/H&M) vs Interior value denim (no moat, India threat real within 18 months)"
  r1_question: "Is your factory in Istanbul, or another location in Turkey?"
  r2_deep: "Which district in Istanbul/Turkey? Do you have direct logistics to EU port/airport, or go via Istanbul hub?"
  collect: "Factory address; logistics setup"
  signal_impact: "Istanbul + laser/ozone: EXPAND. Interior Turkey + no finishing: DO_NOT_EXPAND."

- dim: finishing_capability
  why: "laser + ozone capability = structural moat; absence = commodity position competing on price"
  r1_question: "Do you have laser and ozone finishing capability in-house, or outsourced?"
  r2_deep: "What finishing techniques do you offer? Laser, ozone, stone wash, permanganate? Are they in-house or via sub-contractor?"
  collect: "Equipment inventory; finishing capability list"
  signal_impact: "Full laser+ozone in-house: EXPAND. Outsourced or absent: downgrade to CAUTION or DO_NOT_EXPAND."

- dim: buyer_relationship_type
  why: "direct Zara/H&M = EXPAND signal; via agent = lower stickiness + margin compression"
  r1_question: "Do you work directly with Zara/H&M, or via a buying agent?"
  r2_deep: "For your top 3 buyers: direct or agent-intermediated? What is your margin difference between direct and agent orders?"
  collect: "Order documentation showing buyer vs agent relationship; pricing comparison"
  signal_impact: "Direct Zara/H&M: EXPAND. Agent-only: reduce confidence; add CAUTION on concentration."

- dim: eur_invoice_pct
  why: "EUR% > 70% = ARP self-hedges TRY risk; below 70% = FX exposure rises"
  r1_question: "What % of your invoices are in EUR vs USD vs TRY?"
  r2_deep: "For USD-invoiced orders: do you hedge TRY/USD, or absorb the FX risk?"
  collect: "Invoice currency breakdown (last 6 months); any FX hedging contracts"
  signal_impact: "EUR% >70%: Air8 ARP is natural TRY hedge — key differentiator. EUR% <50%: flag FX exposure risk."

- dim: india_denim_threat_timeline
  why: "India mills investing cotton savings into finishing tech; moat has 18-24 month window before meaningful competition in EU"
  r1_question: "Are you seeing any new competition from Indian denim factories in your EU buyer accounts?"
  r2_deep: "Have any EU buyers mentioned Indian alternatives or sample orders from India? What is the factory's read on the competitive timeline?"
  collect: "BD market intelligence; any buyer RFQ mentions of India alternatives"
  signal_impact: "India threat confirmed in buyer accounts: downgrade EXPAND to CONDITIONAL; accelerate client deepening"

- dim: revenue_qoq_trend | why: "Existing Air8 TR clients need proactive advance ratio review when revenue declines sharply within-year; the annual YoY trigger may be too slow for a -17% volume contraction in 4 months" | r1_question: "What is your production volume in Q1 2026 compared to Q1 2025? Are buyers placing fewer orders or smaller orders?" | signal_impact: "Revenue decline >15% in any single quarter → immediate advance ratio review; reduce from 85% to 70%; if 2 consecutive quarters of decline → reduce to alert level" ⚠️ PENDING REVIEW

---

## Signal Flip Conditions
- IF location = Istanbul AND buyer = direct Zara/H&M AND finishing = full_laser_ozone → signal = EXPAND (structurally protected in 2026)
- IF location = Interior Turkey AND finishing = none → signal = DO_NOT_EXPAND (no moat; India challenging within 18 months)
- IF india_cotton_price event → signal flips from BENEFIT (direct material) to CAUTION (competitive threat from India denim mills getting cheaper cotton)
- IF eu_buyer_pct < 50% → flag; Turkey value proposition is EU-specific; without EU dominance, the moat narrative doesn't hold
- IF eu_apparel_market_contracting AND factory_revenue_declining_qoq → reduce advance ratio immediately; do not wait for annual review trigger ⚠️ PENDING REVIEW
- IF eu_demand_contraction_confirmed AND factory_is_interior_turkey → flip to DO_NOT_EXPAND regardless of other signals; demand loss + no moat = distress scenario ⚠️ PENDING REVIEW

---

## Structural Nuances
*(Enhanced from Section 9 Layer 2+4+5+6+7 and COMBO-005 V2 source)*

- "Denim is 95% cotton; Turkey sources from Turkish and Japanese denim mills — Turkey is NOT a large importer of Indian cotton, so India cotton duty events do NOT reduce Turkey's input cost directly; the threat comes from the OTHER direction (Indian mills getting cheaper cotton → can undercut Turkey on basic denim in EU)"
- "The Turkey denim moat is laser/ozone finishing quality combined with 2–3 day EU shipping — Zara's 14-day reorder model is structurally impossible from any Asian origin; this is Turkey's defensible competitive position"
- "Istanbul premium denim (direct Zara/H&M relationships, full laser/ozone capability) vs Interior Turkey value denim (Düzce/Malatya, basic jeans, no finishing moat) = completely different risk profiles — always identify which segment"
- "TRY hyperinflation (cumulative >300% since 2020) is systemic; bank credit lines are being actively cut in Turkey; domestic factoring market is sophisticated but Air8 must differentiate on speed (T+1 vs 2-5 days) and buyer intelligence"
- "EUR-denominated Air8 ARP facility self-hedges TRY risk — supplier earns EUR from EU buyers, Air8 charges EUR → no TRY exposure for either party; this is a key Air8 differentiator vs local TRY-denominated facilities"
- "EU ESPR 2027 mandates sustainability data (water use, chemical compliance, traceability) that Asian denim competitors cannot yet provide — Turkey's REACH/ZDHC compliance head-start is a competitive weapon if positioned correctly"
- "REACH denim finishing chemical compliance is operationally heavy (SVHC substances in permanganate, stone wash chemicals); Air8 compliance data integration with buyer scoring is a differentiation opportunity"
- "Denim wet finishing investment (laser: $150-300K, ozone: $80-150K) is the barrier to entry that defines the Istanbul premium segment — quantify per customer whether this equipment exists"
- "⚠️ Zara/Inditex and H&M both exceed the CSDDD Omnibus threshold (>5,000 employees AND >€1.5bn turnover) and remain DIRECTLY in scope under the amended timeline — their compliance demands on Turkish denim suppliers will not relax; the CSDDD amendment cuts bureaucratic burden for mid-market buyers, not Tier-1 fast fashion" (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ The CSDDD timeline extension to 2029 reduces NEAR-TERM urgency for Air8's ESG-Finance pitch to Turkey clients — factories that were considering CSDDD-readiness investment for 2027 may defer to 2028-2029; Air8 must reframe the pitch around ESPR (2027) and voluntary buyer requirements rather than CSDDD deadline urgency" (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "Volume-led contraction (-17.83% volume) with stable unit price (+1.49%) is a bifurcated market signal: Istanbul premium denim factories (Zara/H&M direct, laser/ozone finishing) likely retained volume better than the macro average, while Interior Turkey basic denim (no finishing moat) likely experienced the full brunt of the contraction or worse. Always segment by factory tier before reading macro Turkey statistics — the Istanbul vs Interior split is a structural market bifurcation signal, not just a Turkey-wide demand weakness." (source: Event E, freshness: annual, expert_review: VALID — direction correct; soften from 'likely' to 'structural hypothesis based on price-volume data')
- "EU apparel market contraction affects Turkey, Bangladesh, and other Asian origins simultaneously — this is a EU consumer demand signal, not a Turkey-specific share loss story. Air8 should apply macro demand caution across ALL EU-facing combos (COMBO-002, COMBO-005, COMBO-012) not just COMBO-005. The Bangladesh -3% specific figure is unverified pending Eurostat confirmation — do NOT cite as a confirmed data point until sourced; the directional point (BD also contracting) stands as a hypothesis based on EU demand weakness context." (source: Event E, freshness: quarterly, expert_review: VALID — directional point correct, -3% specific pending data)
- "A TR factory experiencing -17% revenue decline with TRY bank credit lines being cut faces elevated cash crisis probability — Air8 ARP EUR facility is an increasingly important liquidity option for these factories, particularly as domestic TRY facilities tighten; however the claim that Air8 is the ONLY option is unverified — local bank relationships, buyer credit terms, and existing trade finance arrangements may provide alternatives. Air8 differentiator is speed (T+1 vs 2-5 days) + EUR denomination hedge + buyer intelligence, not exclusivity." (source: Event E, freshness: quarterly, expert_review: VALID — soften exclusivity claim, keep differentiation on speed + EUR hedge)
- "⚠️ CSDDD compliance is demanded from suppliers by EU buyers BEFORE the regulation formally applies to the supplier — large EU retailers (H&M, Zara, Primark) are already requiring supplier due diligence data as contract condition for 2027+ programmes. This means CSDDD compliance pressure arrives 2-3 years before the 2029 formal deadline. BD/CN/TR/KH factories with EU buyer revenue >30% face de facto 2026-2027 compliance requirements through buyer contracts, not just 2029 law." (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Alice)
- "Turkey EU apparel volume contracted -17.83% in Jan-Apr 2026 (value -16.60%) — unit price rose +1.49%, confirming volume-led contraction not price competition. This structural demand reduction likely reflects EU buyer consolidation away from Turkey during TRY instability period, though TRY-induced quality concerns may also be a factor. Air8 should NOT expand COMBO-005 facilities during a volume contraction phase — CAUTION until EU demand recovers 2+ consecutive months." (source: Event E, freshness: quarterly, expert_review: VALID — data confirmed; CAUTION recommendation correct; cause attribution (EU consolidation vs TRY quality) remains hypothesis)

---

## Buyer Edges
- sells_to: [buyer_type: EUFastFashion, weight: 0.95] — Zara/Inditex, H&M Denim; speed-dependent reorder model
- sells_to: [buyer_type: EUMidMarket, weight: 0.75] — Primark, C&A, value denim; consistent volumes
- sells_to: [buyer_type: USPremiumDenim, weight: 0.40] — Madewell, J.Crew, gap brands; selective
- concentration_pattern: "Top 3 EU buyers = 50–65% of revenue. EU fast fashion is structurally dependent on Turkey's speed advantage — relationship is more balanced than BD/CMT."
- typical_payment_terms: OA 30–90 days (Zara 30-60; H&M 60-90)

---

## LLM Directives
- india_denim_threat: "Current status of Indian denim mill investment in finishing technology (laser, ozone) post-cotton duty cut. Are any Indian mills winning EU buyer trials or sample orders in premium denim? What is the realistic timeline for India to replicate Turkey's finishing capability at scale?"
- eu_espr_timeline: "Current status of EU ESPR and CSDDD requirements for denim and textile products. Which specific data requirements apply to denim finishing (water use, chemical MRSL, traceability)? What is Turkey's compliance advantage over Asian origins?"
- try_credit_environment: "Current state of TRY bank credit for Turkish garment exporters — what is the typical factoring cost in Turkey vs Air8 pricing? Are domestic credit lines being cut or maintained?"
- keqiao_vs_istanbul_comparison: "Compare Turkey domestic denim fabric cost vs equivalent Japanese or European import denim. Is Turkey's domestic fabric supply chain (Iskur, Calik, Bossa) competitive on price and innovation post-India cotton event?"

---

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-PRESHIP-OBF.md PROD-PAYGUARD.md
- pain_points: PP-001-cashflow-gap.md PP-TR-001-lira-inflation.md PP-TR-002-bank-contraction.md
- L0_principles: persona-principles.md#RP-FX-01 event-principles.md#RP-EVT-DUTY-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-TR-001-lira-hyperinflation] critical — systemic; bank credit lines being cut
- [PP-TR-002-bank-credit-contraction] critical — domestic factoring = primary competitor for Air8
- [PP-003-buyer-concentration] medium (EU fast fashion concentration manageable but real)

---
