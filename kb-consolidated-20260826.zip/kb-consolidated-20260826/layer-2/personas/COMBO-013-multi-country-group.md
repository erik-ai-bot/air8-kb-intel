---
type: persona
id: COMBO-013
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cross-entity cash flow gaps"
  - id: PP-002
    severity: HIGH
    context: "Financing cost across multiple jurisdictions"
  - id: PP-005
    severity: MEDIUM
    context: "Pre-shipment capital needed across group entities"
---

# COMBO-013: Multi-Country Corporate Group

## Dimensions
- Revenue: [[dimensions/DIM-2-revenue-band]] ($50M+)
- Type: [[dimensions/DIM-3-company-type]] (vertical | manufacturer)
- Country: [[dimensions/DIM-1-country]] (multi — e.g. IN+BD, CN+VN)
- Market: [[dimensions/DIM-5-target-market]] (US+EU+Multi)
- Financing: [[dimensions/DIM-7-current-financing]] (multi_bank + Air8)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]

## Products
- [[../financing-products/PROD-ARP]] (multi-entity)
- [[../financing-products/PROD-DDP]]
- [[../financing-products/PROD-POOL]]
- [[../financing-products/PROD-SMARTWALLET]]

## Compliance Exposure
All regulations × all countries in the group:
- [[../regulations/REG-UFLPA]]
- [[../regulations/REG-REACH]]
- [[../regulations/REG-CSDDD]]
- [[../regulations/REG-GPSR]]

## Data Entities
- [[data-entities/ENTITY-Supplier]] (entity.jurisdictions)
- [[data-entities/ENTITY-Insurance]] (per_entity)
- [[data-entities/ENTITY-Facility]] (per_entity)

## Air8 Operational Notes
- [[compliance/COMP-KYC]] multi-entity KYC required
- Air8 SG entity for non-CN; Hengqin for CN entities
- Insurance routing differs per country

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: entity_structure_by_country
  why: "each entity needs separate KYC, insurance routing, and Air8 facility; structure determines complexity"
  r1_question: "Which countries do you have entities in? What is the primary production base?"
  r2_deep: "Is each country entity independently registered? What is the legal relationship between entities (parent, subsidiary, associate)?"
  collect: "Entity registration documents for each country; group structure chart"
  signal_impact: "Each entity = separate Air8 facility + separate KYC cycle; multi-entity onboarding extends timeline."

- dim: intercompany_flow_pattern
  why: "fund transfers between entities must be declared; affects disbursement routing and compliance"
  r1_question: "How do the different country entities interact — do they transact with each other?"
  r2_deep: "Are there intercompany loans, shared treasury, or transfer pricing arrangements between entities?"
  collect: "Intercompany agreement if applicable; transfer pricing policy"
  signal_impact: "Undocumented intercompany flows: BLOCK disbursements until declared and compliant."

- dim: country_combination_advantage
  why: "IN+BD = cotton sourcing + EBA dual advantage; CN+VN = China+1 hedge; different event profiles"
  r1_question: "What is the strategic reason for the multi-country structure — sourcing, buyer access, or risk diversification?"
  r2_deep: "Does having both [country A] and [country B] entities create specific advantages with certain buyers?"
  collect: "Strategic rationale; buyer relationship by entity"
  signal_impact: "IN+BD: cotton event benefits IN entity (EXPAND); BD entity still CMT-model (NEUTRAL). Route accordingly."

- dim: primary_buyer_relationship_holder
  why: "which entity holds the buyer relationship determines which Air8 facility is the anchor"
  r1_question: "Which entity invoices the buyers — is it the same entity that does production?"
  r2_deep: "For your top 3 buyers: which legal entity receives the payment? How does cash flow between production entity and invoicing entity?"
  collect: "Sample buyer invoices showing which entity is the seller"
  signal_impact: "Production ≠ invoicing entity: complex receivable structure; map carefully before recommending facility."

- dim: group_credit_headroom
  why: "group-level bank exposure may be at cap; Air8 position must not push group over concentration limit"
  r1_question: "Does the group have a central treasury or consolidated bank facility across countries?"
  r2_deep: "What is the total group bank facility and utilisation? Is there a group credit limit that constrains individual entity borrowing?"
  collect: "Group facility letter; consolidated exposure summary"
  signal_impact: "Group credit maxed: strong Air8 opening as additive. Group facility available: focus on speed and flexibility pitch."

## Signal Flip Conditions
- IF COMBO-002 (BD entity only) pattern detected but India entity exists → flip to COMBO-013 immediately; different facility structure applies
- IF country_combination = IN+BD → EXPAND for cotton duty event (IN entity benefits directly); signal stronger than standalone COMBO-002
- IF intercompany_flow = undocumented → BLOCK; intercompany fund transfers must be declared before any disbursement
- IF primary_buyer_relationship_holder = different_entity_from_production → flag; receivable debtor structure needs careful mapping

---

## Structural Nuances
- "Multi-entity KYC complexity: Air8 must KYC each operating entity separately, not just the holding company"
- "Insurance routing differs per country — SG entity for non-CN; Hengqin for CN entities (Hengqin operational rules, entity caps, SAFE, Sinosure — see `_playbooks/china-operations.md`)"

- "Transfer pricing and intercompany flows must be declared; Air8 cannot disburse into accounts outside the KYC'd entity structure"
- "Biggest Air8 opportunity: company with BD + India entity can use India entity to source cheaper raw materials at new duty advantage while BD entity keeps the EU EBA advantage — two-entity optimization"
- "This COMBO is the highest-value BD opportunity — multiple product types, multiple entities, largest wallet share potential"

---

## Buyer Edges
- concentration_pattern: "Group typically has 10–25 active buyer relationships across entities. No single buyer dominates at group level."

---

## LLM Directives
- entity_optimization: "For a group with [country A] + [country B] entities: what is the optimal facility structure to maximize advantage of each entity's trade access, raw material sourcing, and Air8 product eligibility?"

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-POOL.md PROD-SMARTWALLET.md
- pain_points: PP-001-cashflow-gap.md PP-EXPAND.md
- L0_principles: persona-principles.md#RP-COMPETITIVE-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary (multiple entities)
- [PP-002-financing-cost] high
- [PP-005-preshipment-capital] high

---
