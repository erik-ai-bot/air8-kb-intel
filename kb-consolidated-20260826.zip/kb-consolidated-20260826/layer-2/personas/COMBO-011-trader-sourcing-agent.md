---
type: persona
id: COMBO-011
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash flow gap between buyer payment and supplier"
  - id: PP-006
    severity: HIGH
    context: "Low trade finance literacy, complex KYC requirements"
---

# COMBO-011: Trader / Sourcing Agent

## Dimensions
- Type: [[dimensions/DIM-3-company-type]] (trader)
- Country: ANY
- Revenue: ANY

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-006-trade-finance-literacy]]

## Products
- Back-to-Back/Trader TCS (with recourse)

## Compliance
- [[compliance/COMP-KYC]] (OPS-KYC-002 third-party account prohibition)

## Data Entities
- upstream_supplier.kyc_status
- [[data-entities/ENTITY-Buyer]] (payment_terms)

## Key Risk Flag
⚠️ Third-party payment prohibition applies (OPS-KYC-002).
Air8 cannot pay into unrelated accounts. Must verify ultimate manufacturer.

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: ultimate_manufacturer_identity
  why: "compliance requirement — third-party payment prohibition check; cannot proceed without documenting the factory"
  r1_question: "Which factories do you work with — do you have direct relationships with the manufacturers?"
  r2_deep: "Can you provide the factory names, locations, and registration details? Are they Air8-eligible factories in our system?"
  collect: "Factory KYC documents; manufacturer certificates; factory audit reports"
  signal_impact: "Factory not documented: BLOCK; Tier 1 compliance override. Factory documented + Air8-eligible: proceed with Trader TCS structure."

- dim: buyer_payment_terms
  why: "trader's cash gap = buyer OA days minus factory payment days; quantifies the financing need"
  r1_question: "What is your typical OA cycle from shipment to buyer payment?"
  r2_deep: "When do you need to pay the factory vs when does the buyer pay you? What is the net cash gap in days?"
  collect: "Sample buyer invoice; factory payment terms"
  signal_impact: "Large cash gap (>60d): strong Air8 value. Small gap (<30d): limited value; may not justify setup."

- dim: volume_per_transaction
  why: "traders with large single-order volumes benefit most; small sporadic orders = low value for ARP"
  r1_question: "What is a typical order size for you in USD value?"
  r2_deep: "How many orders do you process per month, and what is the average invoice value?"
  collect: "Sample invoices; order history (last 6 months)"
  signal_impact: "Average order >$100k: ARP provides meaningful WC benefit. Orders <$20k: MiniARP or advisory only."

- dim: back_to_back_structure
  why: "determines if Air8 faces third-party payment risk; must structure with recourse"
  r1_question: "Do you buy from factories on credit, or do you prepay them?"
  r2_deep: "If buying on credit: is the factory aware of Air8's role? Would they accept payment directly from Air8?"
  collect: "Factory payment arrangement documentation"
  signal_impact: "Prepay structure: simpler. Credit structure: must establish Trader TCS with recourse; add compliance flag."

- dim: exclusive_vs_open_market
  why: "exclusive trader for one buyer = more predictable flow; open market = volatile pipeline"
  r1_question: "Do you work exclusively with one or two buyers, or do you trade in open market?"
  r2_deep: "What is the buyer concentration? Largest buyer as % of your total trading volume?"
  collect: "Buyer list and volumes (last 12 months)"
  signal_impact: "Exclusive buyer relationship: more predictable; easier to underwrite. Open market: higher pipeline volatility; apply CAUTION."

## Signal Flip Conditions
- IF third_party_payment_required = true → flag immediately; cannot process through standard Air8 facility; must establish back-to-back structure with recourse
- IF ultimate_manufacturer = not_documented → BLOCK; do not proceed until factory KYC complete
- IF trader_has_no_confirmed_buyer_PO → signal = DO_NOT_PROCEED; ARP requires real receivable, not speculative trading
- IF trader_margin > 15% → flag; unusually high margin may indicate inflated invoice risk for ARP

---

## Structural Nuances
- "No factory assets → banks will not lend → highest financing need with lowest collateral = the fundamental trader problem"
- "Sits between buyer payment and factory payment — the cash gap is structural and cannot be resolved without trade finance"
- "Third-party payment prohibition applies (OPS-KYC-002): Air8 CANNOT disburse to unrelated third-party accounts"
- "Must verify and document the ultimate manufacturer before any disbursement — this is a compliance gate, not a preference"
- "Margin 3–8% (paper thin) — financing cost sensitivity is extreme; even 1% rate difference is material"

---

## Buyer Edges
- concentration_pattern: "Traders typically have 1–3 core buyer relationships and 3–5 factory relationships. Both sides are thin."

---

## LLM Directives
- trader_margin_structure: "What is the typical commission/margin structure for sourcing agents in this product category and geography? What % of FOB value do agents typically take?"
- compliance_liability: "In a CMT/FOB transaction involving a sourcing agent, who bears compliance liability (REACH, UFLPA)? How does this split between agent, factory, and buyer?"
- financing_need: "Do sourcing agents typically need pre-shipment or post-shipment financing, or do they act as pure intermediaries? When does an agent have direct financing exposure?"

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md
- pain_points: PP-001-cashflow-gap.md
- L0_principles: risk-principles.md#RP-RISK-TRADER-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-006-trade-finance-literacy] high

---
