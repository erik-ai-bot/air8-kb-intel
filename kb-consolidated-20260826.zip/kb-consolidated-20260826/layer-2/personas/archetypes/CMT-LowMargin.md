# Archetype: CMT-LowMargin

> Archetype ID: CMT-LowMargin | Updated: 2026-07-01

```yaml
behavioral_profile:
  decision_authority: owner_centric
  buyer_switching_asymmetry: high
  risk_tolerance: survival_mode
  tech_adoption: low
  financing_sophistication: none
```

---

## Identity
- archetype: CMT-LowMargin
- company_type: CMT (Cut-Make-Trim — buyer controls fabric sourcing)
- gross_margin_band: 5–12%
- revenue_band: typically small–mid ($5–20M)
- cash_cycle_days: 90–150 days (longer due to no sourcing control)
- tags: company_type:CMT, domain:persona

## Archetype Structural Nuances
*(What LLM would miss about any CMT-LowMargin factory, regardless of country)*
- "Buyer nominates fabric ~80–95% of the time — cheaper raw material prices do NOT directly reduce the CMT factory's input cost; savings stay with the buyer's sourcing team"
- "Margin is almost entirely from labor efficiency — any wage increase, production disruption, or quality failure directly hits the bottom line with no buffer"
- "Financing cost > gross margin in worst cases — if bank financing costs 13–18% and gross margin is 5–8%, working capital cost can consume all profit"
- "Owner is CEO, CFO, and Sales — no delegation, no financial sophistication, no ability to analyze financing options analytically"
- "Buyer relationships are asymmetric — buyer switches supplier easily; supplier cannot switch buyer easily; relationship logic always favors protecting the buyer even at a loss"

## Buyer Edges
- sells_to: [buyer_type: GlobalFastFashion, weight: 0.80]
- sells_to: [buyer_type: USMassMarket, weight: 0.65]
- sells_to: [buyer_type: EUDiscountRetail, weight: 0.60]
- concentration_pattern: "Top 2 buyers = 40–65% of revenue. No proactive diversification — only reacts when a buyer leaves."
- typical_payment_terms: OA 60–90 days

## Assessment Dimensions
*(Always evaluate these for any CMT-LowMargin instance)*
- dim: buyer_nominated_pct | why: determines whether any raw material cost event benefits flow through to factory
- dim: bank_financing_cost | why: financing cost vs gross margin ratio determines whether factory is viable under stress
- dim: buyer_concentration | why: top-buyer % determines existential dependency and negotiating leverage
- dim: compliance_certification_gap | why: missing certs silently lose RFQs without factory knowing why
- dim: wage_headroom | why: wage hikes hit CMT harder than any other model (labor is the only margin lever)

## Signal Flip Conditions
- IF buyer_nominated_pct > 80% → any raw material price event signal flips from BENEFIT to NEUTRAL
- IF top_buyer > 50% revenue AND buyer shows distress → flip to CAUTION regardless of event type
- IF financing_cost > gross_margin → flip any EXPAND signal to CONDITIONAL (unsustainable WC structure)

## Pain Hooks
- [PP-001-cashflow-gap] primary — always active
- [PP-002-financing-cost] primary — always active for bank-financed CMT
- [PP-004-scalability-constraint] secondary
- [PP-006-trade-finance-literacy] high (especially first-time users)

## Air8 Products
- primary: PROD-ARP (replaces bank LC; T+1 vs 45-60 day bank processing)
- entry: PROD-MINIARP (for smaller CMT factories, simplified KYC)
- condition: "ARP when buyer is eligible insured buyer; MiniARP for first-time supplier $1-5M revenue"

## LLM Directives
- financing_cost_benchmark: "What is the current local bank financing cost for CMT factories in [country]? Compare to Air8 typical pricing. Calculate net saving per $1M of receivables financed."
- wage_trend: "What is the minimum wage trajectory for [country]'s garment sector over the past 2 years and expected next 12 months?"
