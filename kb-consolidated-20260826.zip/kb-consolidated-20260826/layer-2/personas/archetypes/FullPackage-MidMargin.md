# Archetype: FullPackage-MidMargin

> Archetype ID: FullPackage-MidMargin | Updated: 2026-07-01

```yaml
behavioral_profile:
  decision_authority: delegated
  buyer_switching_asymmetry: medium
  risk_tolerance: growth_mode
  tech_adoption: medium
  financing_sophistication: basic
```

---

## Identity
- archetype: FullPackage-MidMargin
- company_type: FOB (Full Package — factory controls fabric/yarn sourcing)
- gross_margin_band: 12–25%
- revenue_band: typically mid–large ($20–80M)
- cash_cycle_days: 60–120 days (varies by speed-to-market positioning)
- tags: company_type:FOB, domain:persona

## Archetype Structural Nuances
*(What LLM would miss about any FullPackage-MidMargin factory, regardless of country)*
- "Factory controls its own fabric/yarn sourcing — raw material price events DO directly affect their input cost and margins; they can capture or lose the benefit"
- "Speed and product complexity are the competitive moat — not labor cost; losing on price is acceptable if winning on delivery speed or design co-development"
- "Buyer relationships are more balanced than CMT — factory's sourcing intelligence and speed capability makes them harder to replace"
- "Working capital structure is more complex than CMT — factory must fund fabric procurement 30-90 days before shipment, creating a pre-shipment cash gap alongside the post-shipment OA gap"
- "Buyer concentration is more manageable — typically 5-10 active buyers with deliberate diversification; no single buyer >30-40% of revenue"
- "Has professional management layer (Sales Director, sometimes Finance Director) — analytical decision making; can compare financing options"

## Buyer Edges
- sells_to: [buyer_type: EUFastFashion, weight: 0.85]
- sells_to: [buyer_type: GlobalBrand, weight: 0.70]
- sells_to: [buyer_type: DTCBrand, weight: 0.55]
- concentration_pattern: "Deliberate diversification — no single buyer >20-40%. Maintains this as a strategic policy."
- typical_payment_terms: OA 30–90 days (varies by buyer; fast fashion = shorter)

## Assessment Dimensions
*(Always evaluate these for any FullPackage-MidMargin instance)*
- dim: sourcing_network_quality | why: fabric sourcing speed and cost advantage is the core moat; determines if cost events flow through
- dim: buyer_geo_mix | why: EU vs US vs APAC mix determines tariff exposure and nearshoring vulnerability
- dim: product_complexity | why: higher complexity = less replaceable by lower-cost origins
- dim: pre_shipment_financing_need | why: fabric procurement creates cash gap that CMT doesn't have — PSF eligibility matters
- dim: speed_capability | why: 2-3 week turnaround (Turkey/CN) vs 30-day (Asia sea freight) determines buyer stickiness

## Signal Flip Conditions
- IF buyer_geo_mix: US > 40% AND event = sourcing_strategy_shift → flip from EXPAND to DO_NOT_EXPAND (shrinking US book)
- IF speed_to_EU < 5 days AND product = denim/fashion → maintains moat even if cost disadvantage (Turkey pattern)
- IF sourcing_network = spot_market_only → reduce confidence on any commodity event signal (can't lock prices)

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-005-preshipment-capital] high (own-sourced fabric = pre-shipment cash gap)
- [PP-002-financing-cost] secondary
- [PP-003-buyer-concentration] watch (typically managed but worth monitoring)

## Air8 Products
- primary: PROD-ARP (post-shipment; main product)
- secondary: PROD-PRESHIP-OBF (pre-shipment; unlock if revenue >$10M and ARP established)
- tertiary: PROD-SMARTWALLET (multi-buyer intelligence; CFO persona exists)
- condition: "Start with ARP. Introduce OBF after 6 months good track record. SmartWallet if 5+ buyers."

## LLM Directives
- sourcing_cost_benchmark: "What is the current market rate for [material] sourcing from [primary_origin] for [country] FOB factories? Compare to peer origins."
- buyer_diversification_benchmark: "What is the typical buyer concentration for [country] FOB exporters of [material] — what % revenue from top buyer?"
