# Archetype: Vertical-HighMargin

> Archetype ID: Vertical-HighMargin | Updated: 2026-07-01

```yaml
behavioral_profile:
  decision_authority: committee
  buyer_switching_asymmetry: low
  risk_tolerance: strategic
  tech_adoption: high
  financing_sophistication: intermediate
```

---

## Identity
- archetype: Vertical-HighMargin
- company_type: Vertical (farm-to-fashion or spinning-to-garment integration)
- gross_margin_band: 15–30%
- revenue_band: typically large ($50M+)
- cash_cycle_days: 120–240 days (longest due to raw fiber procurement cycle)
- tags: company_type:vertical, domain:persona

## Archetype Structural Nuances
*(What LLM would miss about any Vertical-HighMargin factory)*
- "Buys raw fiber (cotton, wool) directly — raw material events have the MOST direct and LARGEST impact on this archetype compared to CMT or FOB"
- "The domestic/imported blend ratio determines how much of any duty or price event actually benefits the factory — organic certified lines often use domestic-only fiber and don't benefit from import duty changes"
- "Domestic price floor mechanisms (MSP, CCI) mean that domestic input prices cannot fall below government support levels even when global prices drop — sets a floor on savings"
- "Pre-shipment capital need is massive: raw fiber purchase → spinning → weaving → garment = 120-240 days of cash tied up before any receivable is created"
- "ESG certifications (GOTS, FAIRTRADE, C2C, ROC) are competitive moats AND Air8 ESG-Finance eligibility triggers — do not treat them as just compliance overhead"
- "Professional management structure (Finance Director, sometimes CFO) — can analytically compare financing options; will not accept vague value propositions"
- "IFC green/social bond eligibility is possible and creates a pricing advantage that no bank can match — the ESG-Finance narrative resonates strongly"

## Buyer Edges
- sells_to: [buyer_type: ESGBrand, weight: 0.90]
- sells_to: [buyer_type: GlobalFashion, weight: 0.75]
- sells_to: [buyer_type: MultiChannel, weight: 0.60]
- concentration_pattern: "Buyer diversification is more mature — typically 10-20 active buyers. Concentration risk is lower but UFLPA compliance and ESG standards create buyer stickiness."
- typical_payment_terms: OA 60–120 days

## Assessment Dimensions
*(Always evaluate these for any Vertical-HighMargin instance)*
- dim: domestic_vs_imported_blend_ratio | why: critical for calculating actual benefit from duty or price events (organic lines may be 100% domestic)
- dim: organic_vs_conventional_split | why: GOTS-certified organic lines use domestic-only certified fiber — duty savings do not apply; mixing voids certification
- dim: gots_fairtrade_certification_scope | why: determines ESG-Finance eligibility and UFLPA advantage (inherent traceability)
- dim: pre_shipment_capital_scale | why: 120-240 day cash cycle = largest PSF need of any archetype; OBF sizing must match
- dim: buyer_passthrough_rate | why: cost-plus contracts vs fixed-price determines what % of any savings the factory keeps vs passes to buyer
- dim: post_cliff_stockpile_plan | why: Vertical integrators have the ability (and incentive) to stockpile raw material — creates post-cliff WC stress risk

## Signal Flip Conditions
- IF organic_certified_pct = 100% AND event = import_duty_on_cotton → flip from BENEFIT to NEUTRAL (all domestic certified cotton)
- IF conventional_blend_pct = 100% → full benefit flows through; apply full impact formula
- IF buyer_passthrough > 60% → net margin benefit is reduced; state explicitly
- IF post_cliff_stockpile > 3x normal inventory → flag for credit review; post-cliff WC stress risk HIGH

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-005-preshipment-capital] critical — this archetype has the largest absolute pre-shipment need
- [PP-ESG-001-credentials-not-monetized] primary for ESG-eligible factories

## Air8 Products
- primary: PROD-ARP (post-shipment; always)
- secondary: PROD-PRESHIP-OBF (critical for vertical integrators — fund raw fiber purchase)
- tertiary: PROD-ESG-FINANCING (if GOTS/FAIRTRADE certified)
- quaternary: PROD-POOL (if 10+ buyer pairs — whole-turnover simplification)
- condition: "ARP + OBF together = full cash cycle coverage. ESG-Finance layer if certs verified. POOL if 10+ buyers."

## LLM Directives
- cotton_import_breakdown: "For [country] Vertical integrators: what is the typical domestic vs imported cotton/fiber procurement split? What is the MSP or domestic support price and how does it compare to imported fiber price post-event?"
- ifc_eligibility: "Does [factory] meet IFC green/social bond eligibility criteria? Key tests: GOTS/FAIRTRADE certifications present, women employment >40%, renewable energy >20%."
- post_cliff_stress: "If a Vertical integrator in [country] stockpiles [X] months of raw fiber before the Oct 31 cliff: what is the elevated WC need in Q1 post-cliff? What is the realistic cash flow stress scenario?"
