---
type: persona
id: COMBO-015
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Severe cash flow gap, no credit facility"
  - id: PP-006
    severity: HIGH
    context: "First-time user, low trade finance literacy"
---

# COMBO-015: Micro Supplier First-Time Financing

## Dimensions
- Revenue: [[dimensions/DIM-2-revenue-band]] (<$5M)
- Financing: [[dimensions/DIM-7-current-financing]] (none)
- Country: ANY
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_CMT)
- Growth: [[dimensions/DIM-8-growth-stage]] (startup | expanding)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-006-trade-finance-literacy]]

## Products
- [[../financing-products/PROD-MINIARP]] (only if eligible: revenue >$1M, ops >2yr)

## Eligibility Gate
⚠️ Revenue <$1M OR operations <2yr → NOT ELIGIBLE for any Air8 product.
Revenue $1-5M + ops >2yr → MiniARP eligible (max $300K).

## Data Entities
- [[data-entities/ENTITY-Supplier]] (revenue, years_ops)
- [[data-entities/ENTITY-Buyer]] (single_dependency)

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: revenue_and_ops_years
  why: "hard eligibility gate — $1M revenue + 2yr ops minimum; check first, don't waste time on ineligible suppliers"
  r1_question: "How long has your business been operating? Can you give me a rough sense of your annual revenue?"
  r2_deep: "Are you exporting directly to overseas buyers, or through an agent? How many shipments have you done in the past year?"
  collect: "Business registration certificate; any export documentation"
  signal_impact: "<$1M revenue OR <2yr ops: ineligible; advisory only. Confirmed eligible: proceed to buyer assessment."

- dim: buyer_identity_and_rating
  why: "buyer quality determines MiniARP insurance availability; one strong buyer is better than three weak ones"
  r1_question: "Who are your buyers — can you name them? Which country are they in?"
  r2_deep: "Are they large branded retailers, small importers, or trading companies? Do they buy from multiple suppliers?"
  collect: "Buyer name and website; sample PO or invoice"
  signal_impact: "Recognizable brand buyer (Primark, C&A): MiniARP eligible. Unknown small importer: insurance uncertain; may block eligibility."

- dim: existing_financing_type
  why: "if already using expensive informal financing, quantifies the saving Air8 provides"
  r1_question: "How do you currently manage your working capital while waiting for buyer payment? Do you use any financing?"
  r2_deep: "Are you using buyer advances, local moneylenders, or bank credit? What rate or terms?"
  collect: "Informal financing cost if willing to share; buyer advance arrangement"
  signal_impact: "Informal finance at >20%: strong cost saving pitch. Buyer advance: quantify the discount they're giving away."

- dim: trade_finance_awareness
  why: "first-time users need education before product; pitch sequence: pain → concept → product"
  r1_question: "Have you heard of invoice financing or trade finance before? Have you used any of these services?"
  r2_deep: "What is your biggest concern about financing — cost, complexity, documentation?"
  collect: "No document needed; BD note on awareness level"
  signal_impact: "Zero awareness: budget 2x longer onboarding cycle; prioritize education. Some awareness: faster to product conversation."

## Signal Flip Conditions
- IF operations_age < 2 years → MiniARP ineligible; advisory only (minimum 2yr ops required)
- IF revenue < $1M → no Air8 product eligible; refer to microfinance / buyer advance options
- IF single_buyer_pct > 80% AND buyer_rating < BB → cap advance ratio at 70%; do NOT do PayGuard (concentration + quality risk combined)
- IF buyer has never paid via Air8 structure → require 2+ reference transactions before full facility

## Structural Nuances
- "One buyer = 60–100% of revenue — the most extreme buyer concentration of any COMBO; existential dependency"
- "Never had external financing; runs on personal savings or informal loans at 2–5%/month — financing education is part of the sales process"
- "No financial records beyond possibly a handwritten ledger — onboarding is labor-intensive"

---

## Buyer Edges
- sells_to: buyer_type:USMassMarket, weight: 0.40
- sells_to: buyer_type:GlobalFastFashion, weight: 0.35
- sells_to: buyer_type:EmergingMarkets, weight: 0.25
- concentration_pattern: "Often single-buyer dependency (1 buyer = 60–80% revenue). No leverage to diversify at micro scale."
- typical_payment_terms: OA 60–90 days (if direct); buying house may pay faster but takes 3–8% commission

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## LLM Directives
- eligibility_check: "Confirm: revenue ≥ $1M AND operations ≥ 2 years. If not both: do not proceed."

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-MINIARP.md
- pain_points: PP-001-cashflow-gap.md PP-006-trade-finance-literacy.md
- L0_principles: product-principles.md#RP-PROD-ELIGIB-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-006-trade-finance-literacy] critical

---
