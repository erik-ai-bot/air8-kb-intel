---
type: persona
id: COMBO-002
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash cycle 90-120 days, WC pinch"
  - id: PP-002
    severity: HIGH
    context: "Bank LC cost 3-5%, 45-60 day processing"
  - id: PP-004
    severity: MEDIUM
    context: "Growth constrained by collateral requirements"
  - id: PP-005
    severity: MEDIUM
    context: "30% prepay for raw material at order-booking"
  - id: PP-BD-001
    severity: HIGH
    context: "56% wage hike squeezing margins critically"
  - id: PP-BD-002
    severity: MEDIUM
    context: "Hartals 15-20 days/year disruption"
  - id: PP-BD-003
    severity: HIGH
    context: "LDC graduation Nov 2026, EU EBA ends post-2029"
---

# COMBO-002: Bangladesh Bank-LC-Dependent Factory Owner

## Dimensions
- Country: [[dimensions/DIM-1-country]] (BD)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($5-20M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB)
- Product: [[dimensions/DIM-4-product-focus]] (knit | woven)
- Market: [[dimensions/DIM-5-target-market]] (EU > US)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_LC_only)
- Growth: [[dimensions/DIM-8-growth-stage]] (stable | expanding)
- Buyer: [[dimensions/DIM-6-buyer-profile]] (fast_fashion)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-004-scalability-constraint]]
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]
- [[../../layer-1-reasoning/pain-points/country/PP-BD-001-wage-hike]]
- [[../../layer-1-reasoning/pain-points/country/PP-BD-002-political-instability]]
- [[../../layer-1-reasoning/pain-points/country/PP-BD-003-ldc-graduation]]

## Products
- [[../financing-products/PROD-ARP]] (replace LC)
- [[../financing-products/PROD-PRESHIP-RT2C]] (replace B2B LC)
- [[../financing-products/PROD-PAYGUARD]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (if US market)
- [[../regulations/REG-REACH]] (if EU market)
- Accord/RSC (factory remediation)

## Data Entities
- [[data-entities/ENTITY-Buyer]] (payment_days)
- [[data-entities/ENTITY-Commodity]] (yarn_price)
- [[data-entities/ENTITY-Insurance]] (ecic_limit)

## V2 Framework Extensions

### Structural Nuances (Tier 2 — expert-provided, LLM would miss)
- "BD CMT factories have buyer-nominated fabric ~90% — cheaper Indian cotton does NOT directly lower their input cost"
- "BD industry imports ~60% yarn from India (varies by segment; balance from China, Pakistan, local mills); if spinners pass savings, yarn prices may fall with 90-180 day lag"
- "Risk: BD and China both increasing Indian yarn demand may keep yarn prices elevated despite duty cut"
- "LDC graduation (Nov 2026 transition): EU EBA duty-free access ends post-2029; 9.6-12% EU tariff incoming"
- "BD CMT relies on India yarn supply — any India supply disruption (weather, policy) has outsized impact"
- "Cash cycle 90-120d; 30% prepay requirement for raw material creates acute WC pinch at order-booking"
- "Post-2024 minimum wage hike (+56%) squeezing margins critically"

### Particular Supplier (5-D Due Diligence)
demand:
  - "PO volume trend — buyer adding or cutting styles / programmes?"
  - "CMT or FOB orders? (FOB = more control over fabric sourcing)"
buyers:
  - "% revenue with top 1-2 buyers?"
  - "Which buyers — EU fast fashion vs US mass market?"
product:
  - "Yarn origin — India / China / Pakistan %?"
  - "Buyer-nominated fabric %? Any own-sourced fabric?"
cash:
  - "Payment cycle stable? Dilution rate trend?"
  - "Bank LC cost and processing time currently?"
capacity:
  - "Factory utilisation %? CMT vs FOB split?"
  - "Any India sourcing or manufacturing entity?"

### What to Provide
- "CMT vs FOB breakdown → CMT = buyer controls fabric (duty saving doesn't flow through)"
- "Yarn sourcing origin declaration (India / China / Pakistan %)"
- "Buyer-nominated fabric % per programme"
- "Any India sourcing or manufacturing entity? (COMBO-013 opportunity)"

### What to Do (Supplier Strategic Actions)
1. "For FOB sourcing portion: lock Indian yarn contracts at today's price — before spinners reprice and before demand surge absorbs the discount"
2. "Lead buyer conversations with EBA advantage: BD zero-duty EU until 2029 vs India 12% EU GSP"
3. "Explore selective shift to blended specs where buyer allows — India advantage is cotton-specific"
4. "Prioritise order fulfilment reliability over volume growth — consistent on-time delivery is the main defence against buyer diversion to India"

### Sub-Scenarios (IF Branches)
sub_scenario_1:
  condition: "Has sourcing / operations in India"
  why: "BD company with India sourcing (COMBO-013 dynamic). Sources cotton/yarn directly in India at 0% duty. Bypasses 90-180d yarn lag and buyer-nominated constraint."
  air8_signal: "Can consider expansion via India entity only, not BD entity. Structure facility through India operations."
  action: "India unit procures at lower cost. BD garment side benefits from cheaper internal supply — structural advantage vs pure-BD peers."

sub_scenario_2:
  condition: "Multiple warning signals trigger simultaneously (PO declining + payment lengthening + utilisation falling)"
  why: "No single signal in isolation is sufficient to act. Two or more in same quarter indicates order diversion pressure is real."
  air8_signal: "When 2-3 signals trigger: reduce advance ratio to 70% max, flag for monthly review. Single-signal: increase monitoring but hold position."
  action: "Monitor three signals: (1) PO volume trend, (2) payment speed vs terms, (3) utilisation rate. Any deterioration on 2+ in same quarter = escalate to credit review."

### Competitive Position
moat: "BD zero-duty EU access until 2029 (EBA); volume scale and buyer relationships"
moat_horizon: "2026-2029 protected by EBA; competitive erosion post-2029 unless ESG credentials built"
competitive_threat_from: ["COMBO-003-IN-Vertical", "COMBO-008-IN-Organic"]
competitive_advantage_over: []
watch_signal: "LDC graduation buyer pre-positioning signals from 2027"

### Air8 Risk Parameters
air8_signal: "CAUTION — MONITOR CLOSELY"
advance_ratio_normal: 80
advance_ratio_alert: 70
review_frequency: "quarterly"
trigger_for_reduction: "2+ signals deteriorating in same quarter"
monitoring_signals:
  - "PO volume trend by buyer"
  - "Payment speed vs agreed terms"
  - "Factory utilisation rate"
  - "Dilution rate"

## V2 Assessment Chain

### impact_calculation
```yaml
formula: "competitive_threat_score = India_cost_advantage × BD_market_overlap × (1 - BD_moat_strength)"
generic_estimate: "Competitive pressure MEDIUM-HIGH; direct margin impact NONE from this event"
inputs:
  buyer_nominated_fabric_pct:
    source: "AC-01 supplier answer"
    default: 0.90
    expert_review: "validate_default — confirm ~90% buyer-nominated typical for BD CMT"
  india_yarn_dependency_pct:
    source: "AC-02 supplier answer"
    default: 0.60
    expert_review: "validate_default — confirm ~60% BD yarn from India industry figure"
  ldc_graduation_impact_year:
    source: "KB: pain-points/PP-BD-003"
    value: 2029
    expert_review: "monitor — confirm EU buyer pre-positioning timeline"
```

### assessment_chain
```yaml
- id: AC-01
  dimension: "Fabric sourcing model — does cheaper Indian cotton reach this factory?"
  question: "What % of your fabric/yarn is buyer-nominated vs own-sourced?"
  data_request: "CMT vs FOB order breakdown; buyer-nominated fabric % per programme"
  expert_review: "validate_default — BD expert confirm typical buyer-nominated % for CMT vs FOB"
  branch:
    buyer_nominated_high_gt80pct:
      direct_saving: NONE
      why: "Buyer controls fabric source; cheaper Indian cotton does NOT lower mill's cost"
      signal_note: "Indirect benefit only via yarn price lag 90-180d"
      next: AC-02
    own_sourced_gt40pct:
      direct_saving: PARTIAL
      why: "Mill controls some fabric sourcing; can lock Indian yarn at lower price"
      signal_note: "Partial benefit — lock Indian yarn contracts now"
      next: AC-02

- id: AC-02
  dimension: "India yarn dependency — how exposed to yarn lag benefit?"
  question: "What % of your yarn comes from India vs China vs Pakistan vs local?"
  data_request: "Yarn sourcing origin declaration (% by country, last 12 months)"
  expert_review: "ai_extended — LLM can estimate from trade data; expert validates"
  unlocks_calculation: "lag_benefit = India_yarn_share × (eventual_price_reduction) × COGS%"
  next: AC-03

- id: AC-03
  dimension: "LDC graduation exposure — is this supplier's EU book at risk post-2029?"
  question: "What % of revenue is EU buyers? Are you tracking EU buyer sourcing reviews?"
  data_request: "Buyer revenue mix % (EU/US/JP/other); any buyer RFQ or programme review notice"
  expert_review: "required — BD expert must assess LDC graduation risk per supplier; timeline is 2027 pre-positioning"
  branch:
    eu_heavy_gt50pct:
      risk_flag: HIGH
      action: "BD must lead buyer EBA advantage conversation NOW; before buyers pre-position"
    us_heavy:
      risk_flag: LOW_FROM_LDC
      note: "US market: different risk profile; not LDC-affected"

- id: AC-04
  dimension: "India operations — does supplier have entity to capture direct benefit?"
  question: "Do you have any sourcing, production, or registered entity in India?"
  data_request: "Company registration documents; entity structure chart"
  expert_review: "required — if YES, restructure as COMBO-013 (multi-country group); different Air8 facility structure"
  branch:
    has_india_entity:
      signal_override: "COMBO-013 playbook — expand via India entity only"
      flag: "BD restructure conversation needed"
    no_india_entity:
      continue: true
      note: "Pure BD CMT — apply CAUTION signal"
```

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: buyer_nominated_pct
  why: "determines if any raw material event benefit flows to factory (>80% buyer-nominated = does NOT flow through)"
  r1_question: "What % of your fabric/yarn is buyer-nominated vs own-sourced?"
  r2_deep: "Which specific buyers dictate fabric source, and do any allow substitution for cost saving?"
  collect: "Procurement orders showing nominated vs own-sourced split (last 12 months)"
  signal_impact: "If >80% nominated: flip any raw material event signal from BENEFIT to NEUTRAL"

- dim: india_yarn_dependency_pct
  why: "quantifies indirect benefit via yarn price lag; also exposure if India supply disrupts"
  r1_question: "What % of your yarn/cotton comes from India vs China vs Pakistan vs local mills?"
  r2_deep: "Do you have long-term supply contracts with Indian spinners, or buy on spot market?"
  collect: "Yarn purchase invoices by origin (last 6 months)"
  signal_impact: "Higher India%: more indirect benefit from India cost events (delayed 90-180d); also more supply concentration risk"

- dim: eu_revenue_pct
  why: "LDC graduation risk is existential for EU-heavy factories; triggers urgency timeline"
  r1_question: "What % of your revenue comes from EU buyers vs US vs other markets?"
  r2_deep: "Which specific EU buyers and what % each? Are any raising questions about Bangladesh LDC graduation?"
  collect: "Sales breakdown by buyer geography (last 12 months)"
  signal_impact: "If EU% >50%: escalate LDC graduation risk to HIGH regardless of other signals"

- dim: ldc_graduation_preparedness
  why: "factories with no ESG/GSP+ preparation face existential risk post-2029 — see _country/BD_KH_common.md"
  r1_question: "Have you started any preparation for post-EBA tariff changes? Any new compliance certifications being pursued?"
  r2_deep: "Do you have a plan for GSP+ compliance? Are any buyers requesting supply chain reporting beyond BSCI/Sedex?"
  collect: "Current certification portfolio; any buyer compliance questionnaires received"
  signal_impact: "No preparation + EU% >50%: CRITICAL risk flag; recommend immediate advisory conversation"

- dim: compliance_certification_status
  why: "BSCI/Sedex audit pass does NOT equal CSDDD/UFLPA compliance; gap is hidden and costly"
  r1_question: "What compliance certifications do you hold — BSCI, Sedex, GOTS, OEKO-TEX, others?"
  r2_deep: "Are any EU buyers asking for CSDDD or supply chain traceability documentation beyond your current audits?"
  collect: "Current audit certificates; any buyer compliance questionnaires"
  signal_impact: "BSCI-only + EU fast fashion buyer: hidden compliance gap; flag for advisory"

- dim: has_india_entity
  why: "if yes: reroute to COMBO-013 (multi-country); different facility structure applies"
  r1_question: "Do you have any entity, subsidiary, or sourcing office in India or any other country?"
  r2_deep: "Is it a full legal entity or a sourcing agent relationship? Who controls procurement decisions?"
  collect: "Entity registration documents if applicable"
  signal_impact: "If yes: override to COMBO-013 playbook; restructure facility through India operations"

- dim: factory_closure_exposure | why: "When BD industry contracts, Air8 must distinguish: (a) client factory gaining share from closures = EXPAND opportunity, vs (b) client factory itself showing closure risk = CAUTION/exit" | r1_question: "How is your factory doing vs your peers — are you gaining new buyers or losing orders?" | signal_impact: "Gaining share from peer closures → WC need is real and urgent (EXPAND). Own orders declining → CAUTION; reduce advance ratio" ⚠️ PENDING REVIEW

---

- dim: survivor_bias_check | why: when peers are closing, assess if survivor faces same structural forces — new PO inflow may mask underlying deterioration (not-yet-failed pattern) | r1_question: "Are you getting more orders as other factories close? What is your margin per unit vs 12 months ago?" | r2_deep: "What caused the factories that closed to close? Do you face the same wage/compliance/buyer pressures?" | collect: "Margin comparison current vs 12m ago; new PO commitment duration; structural advantages vs closed peers" | signal_impact: "Same structural causes = CONDITIONAL not EXPAND; genuine differentiation = EXPAND; margin declining despite higher volume = DO_NOT_EXPAND"

## Signal Flip Conditions
- IF buyer_nominated_pct > 80% AND event = raw_material_cost → flip signal from BENEFIT to NEUTRAL (savings don't reach factory)
- IF eu_revenue_pct > 50% AND event = ldc_graduation_signal → escalate to HIGH risk regardless of other signals
- IF has_india_entity = true → override to COMBO-013 playbook; restructure facility through India operations
- IF 2+ of [PO_volume_declining, payment_lengthening, utilisation_falling] in same quarter → flip any EXPAND to CAUTION
- IF peer_factory_closures_detected AND survivor_faces_same_structural_cause (wage squeeze + margin compression + LDC risk) → flip EXPAND to CONDITIONAL; label: "not-yet-failed — structural risk deferred not resolved"; require genuine differentiation evidence before EXPAND confirmed
- IF new_PO_inflow_from_peer_closure AND new_PO_margin < existing_book_margin → signal = CAUTION; factory taking volume at worse economics = distress masking not recovery
- IF buyer_is_csddd_in_scope (H&M, Zara, Primark parent) AND factory has no supply chain traceability documentation → signal = COMPLIANCE risk regardless of CSDDD scope narrowing (buyer-mandated requirement supersedes regulatory threshold) ⚠️ PENDING REVIEW
- IF has_us_buyers AND no_uflpa_documentation → flag COMPLIANCE risk; do NOT advance on US-bound shipments until UFLPA documentation confirmed ⚠️ PENDING REVIEW
- IF section_301_tariff_imposed_on_BD → assess impact on US buyer competitiveness; BD US revenue may decline; flip any EXPAND (US-buyer-based) to CAUTION ⚠️ PENDING REVIEW

---

## Structural Nuances
*(What LLM would miss — extracted from Section 9 Layer 2+4+6+7, V2 source, Alice KB)*

- "Buyer-nominated fabric applies ~90% of the time — cheaper Indian cotton does NOT directly lower this factory's input cost; the buyer's sourcing team captures the saving, not the BD mill"
- "BD is 100% import-dependent for cotton/yarn; if Indian spinners pass savings downstream, yarn prices may fall but with a 90–180 day lag — benefit is indirect and delayed"
- "BD CMT yarn sourcing: ~60% from India (RP-DEPENDENCY input — freshness: annual) ⚠️"
- "Cash cycle: 90-120 days including 30% prepay requirement (RP-WINDOW input — freshness: stable)"
- "Risk of simultaneous demand surge: BD and CN mills both increasing Indian yarn demand post-duty cut may keep yarn prices elevated despite the duty reduction"
- "LDC graduation timeline: see PP-BD-003 for full angle/logic/view. Live data (tariff rate, convention count, BD ratification status) resolved via PP-BD-003 web_lookup directives at runtime — do NOT hardcode figures here."
- "Factory cash cycle 90–120 days with 30% prepay requirement for raw material — creates acute working capital pinch precisely at order-booking stage when they most need liquidity"
- "Minimum wage hike structural angle: factory absorbs the full wage cost increase because ~90% buyer-nominated fabric removes any input cost offset mechanism — wage burden is unilateral. Whether the % figure changes over time or buyers share any FOB adjustment is a live question resolved via llm_directives web_lookup at runtime, not hardcoded here."
- "Back-to-back LC for yarn adds cost layer on top of already-high local bank rates; political disruption (hartals) adds meaningful lost production days per year"
- "Shadow factory risk: when overbooked, factory outsources a portion to unverified sub-contractors — quality and compliance exposure without Air8 or buyer awareness"
- "Compliance gap is largely invisible to the factory: they do not know which buyer scorecard dimensions they are failing on; they lose RFQs without understanding why"
- "⚠️ When competing BD factories close, surviving Air8-financed factories face a paradox: they gain new buyer PO inflow (market share uplift) while simultaneously losing access to peer sub-contracting capacity — net effect on WC is non-linear and context-dependent" (source: Event A, freshness: annual, PENDING EXPERT REVIEW: Alice)
- "⚠️ Bangladesh garment labor force is not a captive pool — workers migrate to other sectors (construction, informal) during political instability; labor shortage can persist even as factories close, because the type of workers available (stitching operators vs finishing specialists) mismatches the surviving factories' needs" (source: Event A, freshness: annual, PENDING EXPERT REVIEW: Alice)
- "⚠️ Air8 advance ratio must be reviewed if Air8 client factory shows: (a) PO volume declining >15% QoQ, (b) buyer concentration rising (fewer buyers, more dependence), (c) workforce headcount dropping YoY — these are early distress signals that predate formal default" (source: Event A, freshness: stable, PENDING EXPERT REVIEW: Jerri)
- "⚠️ CSDDD Omnibus scope reduction (>5,000 employees, >€1.5bn) exempts all BD CMT factories from DIRECT legal obligation — but EU buyers who remain in scope (H&M, Primark/ABF, Lidl) will continue to cascade supply chain due diligence requirements via their own supplier codes of conduct, independent of what the CSDDD regulation formally requires of factories" (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ The CSDDD 2029 extension creates a 'false relief' window — BD factories that pause CSDDD preparation now will face compressed timelines in 2027-2028 when implementation guidance firms up; factories that maintain compliance investment through the window will have a 24-month head start when buyers re-activate supplier questionnaires" (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ CSDDD consultation deadline 24 July 2026 is the window for industry to submit commentary on implementation guidelines — any BD-specific concerns (traceability at yarn mill level, audit fatigue from overlapping buyer codes) should be surfaced via BGMEA or buyer industry associations now, not in 2028" (source: Event B, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Section 301 forced labor tariff (country-level additional duty) and UFLPA import ban (shipment-level detention) are PARALLEL mechanisms that can apply simultaneously — Section 301 tariff applies to all exports from a listed country; UFLPA ban applies when specific factory cannot prove no forced labor; BD factory needs both factory-level documentation AND awareness of country-level tariff risk" (source: Event D, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ BD yarn sourcing from India (~60% of yarn inputs) does NOT create UFLPA risk — Indian cotton is not subject to UFLPA Xinjiang rebuttable presumption; a BD factory documenting its yarn as 'Indian origin' may actually have a compliance ADVANTAGE vs BD factories using Chinese yarn — Air8 should flag this positively in BD client assessment" (source: Event D, freshness: annual, PENDING EXPERT REVIEW: Alice)
- "⚠️ Air8 receivable quality protocol for UFLPA-detained shipments: if a client's US-bound shipment is detained by CBP, the buyer receivable becomes disputed or unpayable; Air8 advance on that specific shipment is at risk; Air8 should implement a 'US-bound shipment compliance check' gate before advancing on any BD factory with US buyer exposure" (source: Event D, freshness: stable, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Section 301 tariffs, unlike IEEPA, require a formal investigation finding and cannot be removed by presidential executive order alone — once S301 tariffs on Bangladesh are published in the Federal Register, they become structural and long-lived (typical S301 tariffs have lasted 5-10+ years); any Air8 expansion into BD factories with US buyer concentration should be paused pending S301 investigation outcome" (source: Event F, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Bangladesh has historically avoided US tariff action due to LDC status and goodwill diplomacy; the USTR S301 forced labor framing is a different legal basis than competitiveness — BD government response may be more conciliatory (labor law reform pledges) than retaliatory, which may narrow or delay tariff implementation for BD specifically" (source: Event F, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ US Section 301 forced labor investigations and UFLPA operate as SEPARATE legal tracks — a shipment can face both simultaneously: UFLPA creates a rebuttable presumption of detention at CBP, while S301 adds tariff liability. BD/VN/KH factories with US buyers must have SEPARATE documentation for each: UFLPA traceability + S301 country-of-origin compliance. Air8 must NOT advance on US-bound shipments from these origins without both clearances confirmed." (source: Events D+F, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ CSDDD compliance is demanded from suppliers by EU buyers BEFORE the regulation formally applies to the supplier — large EU retailers (H&M, Zara, Primark) are already requiring supplier due diligence data as contract condition for 2027+ programmes. This means CSDDD compliance pressure arrives 2-3 years before the 2029 formal deadline. BD/CN/TR/KH factories with EU buyer revenue >30% face de facto 2026-2027 compliance requirements through buyer contracts, not just 2029 law." (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Alice)

---

- "⚠️ SURVIVOR BIAS TRAP: When BD peers close, do NOT automatically assume survivor benefits — check if survivor faces same root causes (wage squeeze, margin compression, LDC risk). A factory gaining POs from a closed competitor may be a 'not-yet-failed' factory, not a genuine winner. New PO inflow can MASK structural deterioration — factory looks busy but is taking on volume at worse economics." (source: Event A + RP-EVT-SURVIVOR-BIAS-01, freshness: stable, PENDING EXPERT REVIEW: Jerri)

## Buyer Edges
- sells_to: [buyer_type: EUDiscountRetail, weight: 0.85] — Primark, Lidl, Aldi, Walmart EU
- sells_to: [buyer_type: EUFastFashion, weight: 0.60] — H&M (stretch, requires ESG investment)
- sells_to: [buyer_type: USMassMarket, weight: 0.45]
- concentration_pattern: "Top 2 buyers = 40–60% of revenue. No proactive diversification. Relationship > margin — will absorb loss to protect key buyer relationship."
- typical_payment_terms: OA 60–90 days

---

## LLM Directives
- india_yarn_dependency: "Quantify BD cotton/yarn sourcing origin breakdown (% from India vs China vs Pakistan vs local). Cite year and source. Note any recent supply chain shifts affecting origin mix."
- ldc_graduation_timeline: "What is the exact Bangladesh LDC graduation date and EU EBA transition period? What tariff rate applies to BD garments in EU post-transition without GSP+? What are the GSP+ ratification requirements? Cross-reference _country/BD.md and _country/BD_KH_common.md."
- financing_cost: "What is the current local bank financing rate for BD garment factories (bank OD, LC rate)? Compare to Air8 pricing. Calculate net saving per $1M of receivables."
- wage_impact: "What is the current Bangladesh garment sector minimum wage and the % increase from the most recent revision? Calculate the gross margin impact for a typical CMT factory at 5-12% margin band."
- hartal_disruption: "What is the average production days lost per year in Bangladesh garment sector due to political disruptions over the past 3 years? Cite source."
- shadow_factory_rate: "What % of Bangladesh garment production is estimated to be sub-contracted to unverified factories (shadow outsourcing)? What compliance/audit organizations track this?"
- competitive_position: "Post-[event]: how does BD compare to India, Vietnam, Cambodia on total landed cost for EU cotton T-shirts? Is BD's EU duty advantage (EBA) still the primary competitive defense?"

---

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-PRESHIP-RT2C.md
- pain_points: PP-001-cashflow-gap.md PP-002-financing-cost.md PP-BD-001-wage-hike.md PP-BD-003-ldc-graduation.md
- L0_principles: persona-principles.md#RP-MATERIAL-01 risk-principles.md#RP-RISK-CONC-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary — always active; 90-120 day cycle + 30% prepay
- [PP-002-financing-cost] primary — bank rate often exceeds gross margin (see web_lookup: bd_bank_od_rate for current rate)
- [PP-004-scalability-constraint] high — cash gap prevents taking new orders
- [PP-005-preshipment-capital] high — back-to-back LC for yarn = additional pre-shipment need
- [PP-BD-001-wage-hike] high — minimum wage hike squeezing margins with no FOB offset (see web_lookup: bd_minimum_wage for current figure)
- [PP-BD-002-political-instability] medium — hartal disruptions 15-20 days/year
- [PP-BD-003-ldc-graduation] critical — EU EBA ends post-2029

---
