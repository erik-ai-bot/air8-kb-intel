---
type: persona
id: COMBO-012
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap on OA terms"
  - id: PP-002
    severity: HIGH
    context: "Financing cost burden on CMT margins"
  - id: PP-003
    severity: HIGH
    context: "EU market concentration, EBA withdrawal risk"
---

# COMBO-012: Cambodia Garment Factory (EU EBA Dependent)

## Dimensions
- Country: [[dimensions/DIM-1-country]] (KH)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($5-20M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_CMT)
- Product: [[dimensions/DIM-4-product-focus]] (knit | woven)
- Market: [[dimensions/DIM-5-target-market]] (EU)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_LC | none)
- Growth: [[dimensions/DIM-8-growth-stage]] (stable)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-003-buyer-concentration]]

## Products
- [[../financing-products/PROD-ARP]]
- [[../financing-products/PROD-MINIARP]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (if cotton)
- REG-EBA (EU trade preference risk)
- [[../regulations/REG-CSDDD]]

## Key Risk
⚠️ EBA graduation risk: any political/governance deterioration in Cambodia can trigger EU review of EBA status.
Revenue concentration on EU market = existential if EBA withdrawn.

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: eu_eba_risk_exposure
  why: "Cambodia graduates EBA eventually; factory's EU revenue % directly determines existential risk level — see _country/BD_KH_common.md"
  r1_question: "What % of your revenue comes from EU buyers vs US vs other markets?"
  r2_deep: "Have any EU buyers mentioned concern about Cambodia's EBA status or asked about post-graduation sourcing plans?"
  collect: "Sales breakdown by buyer geography (last 12 months)"
  signal_impact: "EU% >70% + active EBA graduation signal: flip any EXPAND to CAUTION; existential risk flag."

- dim: buyer_concentration
  why: "extreme EU concentration compounds EBA risk; one buyer leaving = multiple risks at once"
  r1_question: "Who are your top 2-3 buyers and what % of revenue each?"
  r2_deep: "Is any single buyer >30% of revenue? Any signals of buyer reducing Cambodia sourcing?"
  collect: "Buyer revenue breakdown"
  signal_impact: "Top buyer >40% + EU-heavy: dual concentration + EBA risk = CAUTION regardless of other signals."

- dim: compliance_upgrade_path
  why: "if factory is investing in HIGG/ESG compliance now, they may qualify for GSP+ pathway"
  r1_question: "Are you currently pursuing any ESG certifications — HIGG, GOTS, Better Work, or others?"
  r2_deep: "What is the current status? Any buyer requirements driving the certification investment?"
  collect: "Current certification portfolio; planned certifications"
  signal_impact: "Active HIGG + ESG investment: flip to CONDITIONAL; GSP+ pathway reduces medium-term EBA risk."

- dim: alternative_buyer_market
  why: "US, Japan, Australia buyers don't depend on EBA; diversification = natural hedge against EBA risk"
  r1_question: "Do you have any US, Japan, or Australia buyers? What % of revenue?"
  r2_deep: "Are you actively trying to diversify away from EU buyers? Any new non-EU buyer programs being developed?"
  collect: "Non-EU buyer revenue; any buyer development pipeline"
  signal_impact: "Non-EU revenue >30%: natural hedge; reduces EBA existential risk; flip to CONDITIONAL."

- dim: air8_financing_dependency
  why: "if Air8 replaces bank LC entirely, factory has no fallback if Air8 relationship disrupted"
  r1_question: "Do you still maintain a local bank facility alongside Air8, or is Air8 your primary/only financing?"
  r2_deep: "If Air8 facility was unavailable for 30 days, do you have an alternative financing bridge?"
  collect: "Bank facility status alongside Air8"
  signal_impact: "100% Air8 dependent: flag; recommend maintaining minimum bank facility as backup."

- dim: buyer_csddd_cascade_readiness | why: "KH factories' EU buyers (H&M, Primark) remain in CSDDD scope even post-amendment; their supplier requirements will flow to KH regardless of KH factory's own regulatory threshold" | r1_question: "Have any EU buyers recently sent you supply chain questionnaires about your subcontractors, chemical use, or labor practices beyond standard BSCI/Sedex audits?" | signal_impact: "Buyer-mandated CSDDD questionnaire received → CSDDD compliance pathway is active; Air8 ESG-Finance pitch is relevant. No buyer requests yet → monitor; CSDDD compliance investment may be premature" ⚠️ PENDING REVIEW

- dim: us_uflpa_compliance_status | why: "KH factories are primarily EU-focused; if they have any US buyers, they need UFLPA documentation; many KH factories have not built this system because US is not their primary market; a pending Section 301 investigation makes this more urgent" | r1_question: "Do you have any US buyers? Do you have supply chain traceability documentation showing your cotton/yarn origin?" | signal_impact: "US buyers present AND no UFLPA docs → COMPLIANCE_BLOCK; advance only on EU-bound shipments. No US buyers → lower risk; monitor S301 tariff risk" ⚠️ PENDING REVIEW

## Signal Flip Conditions
- IF eu_revenue_pct > 70% AND eba_graduation_signal_active → flip any EXPAND to CAUTION; existential risk outweighs short-term opportunity
- IF factory_has_us_or_japan_buyer → signal flips from CAUTION to CONDITIONAL; non-EBA revenue provides hedge
- IF compliance_upgrade_underway (HIGG + ESG certs) → flip to CONDITIONAL; GSP+ pathway reduces EBA risk medium-term
- IF EU political/governance event targeting Cambodia → elevate to HIGH risk; monitor EBA status immediately
- IF us_s301_tariff_on_KH_confirmed AND factory_has_us_buyers → COMPLIANCE_BLOCK on US-bound shipments; dual EBA+S301 threat = exit US buyer exposure immediately ⚠️ PENDING REVIEW

---

## Structural Nuances
- "Revenue is heavily dependent on EU EBA (Everything But Arms) duty-free access — if EBA is withdrawn or modified, the factory's EU cost competitiveness collapses"
- "USD-dollarized economy is a structural FX advantage (no local currency risk) — Air8 USD-denominated ARP fits naturally"
- "EU EBA withdrawal has precedent (Cambodia 2020 partial withdrawal due to political concerns) — governance risk is real and buyers are aware"
- "Limited domestic financing options — loan shark rates, no formal MSME trade finance market"
- "⚠️ Cambodia faces simultaneous threats: EU EBA graduation/risk (primary market) AND US Section 301 tariff investigation (secondary market) — this dual-market access risk makes KH the highest-risk country in Air8's portfolio for 2026-2029; any EXPAND signal for COMBO-012 should be reviewed against this dual-threat context" (source: Event F, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ US Section 301 forced labor investigations and UFLPA operate as SEPARATE legal tracks — a shipment can face both simultaneously: UFLPA creates a rebuttable presumption of detention at CBP, while S301 adds tariff liability. BD/VN/KH factories with US buyers must have SEPARATE documentation for each: UFLPA traceability + S301 country-of-origin compliance. Air8 must NOT advance on US-bound shipments from these origins without both clearances confirmed." (source: Events D+F, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ CSDDD compliance is demanded from suppliers by EU buyers BEFORE the regulation formally applies to the supplier — large EU retailers (H&M, Zara, Primark) are already requiring supplier due diligence data as contract condition for 2027+ programmes. This means CSDDD compliance pressure arrives 2-3 years before the 2029 formal deadline. BD/CN/TR/KH factories with EU buyer revenue >30% face de facto 2026-2027 compliance requirements through buyer contracts, not just 2029 law." (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Alice)

---

## Buyer Edges
- sells_to: [buyer_type: EUDiscountRetail, weight: 0.80]
- sells_to: [buyer_type: EUFastFashion, weight: 0.60]
- concentration_pattern: "Top 2 EU buyers often >60% revenue. EU concentration is structural — EBA makes EU the primary viable market."

---

## LLM Directives
- eba_timeline: "What is the current status of Cambodia's EU EBA (Everything But Arms) access? What are the key milestones for potential suspension or graduation? What % of Cambodia's garment exports go to EU?"
- post_eba_cost: "If Cambodia loses EBA, what would the tariff impact be on garment exports to EU? Which product categories are most exposed?"
- buyer_response: "How are EU fast fashion buyers (H&M, Primark, C&A) responding to Cambodia's EBA risk? Are they pre-positioning sourcing elsewhere?"

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-MINIARP.md PROD-ARP.md PROD-ESG-FINANCING.md
- pain_points: PP-001-cashflow-gap.md PP-BD-003-ldc-graduation.md
- L0_principles: persona-principles.md#RP-GRADUATION-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-002-financing-cost] high (limited local alternatives)
- [PP-003-buyer-concentration] critical (EU EBA compounds concentration)

---
