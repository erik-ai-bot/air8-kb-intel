---
type: persona
id: COMBO-014
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap, limited OD facility"
  - id: PP-002
    severity: HIGH
    context: "Bank OD rates 12-18% vs Air8 savings"
  - id: PP-003
    severity: MEDIUM
    context: "Single-buyer concentration risk"
  - id: PP-005
    severity: MEDIUM
    context: "Pre-shipment capital constrained by bank limits"
  - id: PP-IN-001
    severity: HIGH
    context: "GST refund delays lock working capital"
  - id: PP-IN-002
    severity: HIGH
    context: "Bank OD rates 12-18% exceed margins"
---

# COMBO-014: India Small Woven Manufacturer (Bank OD Dependent)

## Dimensions
- Country: [[dimensions/DIM-1-country]] (IN)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($5-20M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB)
- Product: [[dimensions/DIM-4-product-focus]] (woven)
- Market: [[dimensions/DIM-5-target-market]] (US | EU)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_OD)
- Growth: [[dimensions/DIM-8-growth-stage]] (expanding)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-003-buyer-concentration]]
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]
- [[../../layer-1-reasoning/pain-points/country/PP-IN-001-gst-refund-delay]]
- [[../../layer-1-reasoning/pain-points/country/PP-IN-002-bank-od-cost]]

## Products
- [[../financing-products/PROD-ARP]] (cost savings vs OD)
- [[../financing-products/PROD-PRESHIP-RT2C]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (if cotton → US)
- [[../regulations/REG-REACH]] (if EU)

## Data Entities
- [[data-entities/ENTITY-Buyer]] (payment_days)
- [[data-entities/ENTITY-Supplier]] (bank_rate)
- [[data-entities/ENTITY-Commodity]] (cotton_price)

## Assessment Dimensions
- dim: bank_od_utilisation
  why: "High utilisation = credit-constrained; Air8 is additive capacity at lower cost with no collateral"
  answered_by_questions: [Q-BANK-UTIL-01]
  primary_question: Q-BANK-UTIL-01
  r1_question: "What is your current bank OD limit and how much is currently drawn?"
  r2_deep: "Have you faced any recent bank line reductions or rate increases?"
  collect: "Bank facility letter showing limit and current utilisation"
  signal_impact: "If utilisation > 85% → strong EXPAND (additive capacity, no collateral); if utilisation < 50% → CONDITIONAL (may not need Air8 urgently)"

- dim: gst_refund_lag
  why: "Quantifies additional WC locked beyond buyer OA — real cash cycle often 30–90d longer than it appears"
  answered_by_questions: [Q-GST-LAG-01]
  primary_question: Q-GST-LAG-01
  r1_question: "How long does your GST refund typically take after export shipment?"
  r2_deep: "Do you have a pending GST refund backlog currently?"
  collect: "Last 3 months GST refund receipts with dates"
  signal_impact: "If lag > 60d → EXPAND signal strengthens; actual WC need = OA days + GST lag → larger Air8 value"

- dim: uflpa_readiness
  why: "Cotton woven to US = UFLPA traceability required; non-compliance = detention = unpayable receivable"
  answered_by_questions: [Q-UFLPA-01]
  primary_question: Q-UFLPA-01
  r1_question: "Do you sell woven cotton garments to US buyers? Do you have UFLPA traceability documentation?"
  r2_deep: "Can you trace your cotton supply chain to gin level? Which certification do you use?"
  collect: "UFLPA compliance documentation or supply chain traceability certificate"
  signal_impact: "If US buyer AND no UFLPA docs → flag COMPLIANCE risk before proceeding; ARP on that shipment only after UFLPA clearance confirmed"

- dim: buyer_geo_mix
  why: "US-heavy = UFLPA compliance critical; EU-heavy = CSDDD timeline matters; mix determines risk profile"
  answered_by_questions: [Q-BUYER-GEO-01]
  primary_question: Q-BUYER-GEO-01
  r1_question: "What % of your revenue is US vs EU vs other markets?"
  r2_deep: "Any plans to shift mix in next 12 months?"
  collect: "Revenue breakdown by buyer geography (last 12 months)"
  signal_impact: "If US > 60% → UFLPA compliance is highest priority; if EU > 40% → CSDDD supply chain due diligence timeline relevant"

- dim: upgrade_path_to_fob
  why: "If actively upgrading from CMT to FOB, OBF unlocks sourcing capital; new FOB wins need pre-shipment finance"
  answered_by_questions: [Q-FOB-UPGRADE-01]
  primary_question: Q-FOB-UPGRADE-01
  r1_question: "Are you sourcing fabric and trims yourself, or is it still buyer-nominated?"
  r2_deep: "How many FOB orders do you have vs CMT? What's your fabric sourcing setup?"
  collect: "Order breakdown (FOB vs CMT) for last 12 months"
  signal_impact: "If upgrading to FOB (>30% FOB orders) → OBF eligibility opens; sourcing capital need is real"

---

## Signal Flip Conditions
- IF bank_od_utilisation > 85% → signal = strong EXPAND; Air8 ARP is additive capacity at no collateral — highest priority pitch
- IF uflpa_exposure confirmed AND order_destination = US AND no_traceability_docs → flip to COMPLIANCE_BLOCK; do not proceed with ARP on that shipment
- IF gst_refund_lag > 90d → EXPAND signal strengthens; real cash cycle significantly longer than OA days
- IF upgrading_cmt_to_fob = active (>30% FOB orders) → unlock PROD-PRESHIP-RT2C pitch; sourcing capital need confirmed
- IF us_revenue_pct > 70% AND india_cotton_duty_event → EXPAND signal strengthened (direct benefit to FOB factory buying own cotton)
- IF india_uk_fta_ratified AND has_uk_buyers → signal flips from NEUTRAL to EXPAND (duty saving = direct margin uplift for FOB pricing to UK buyers; working capital need increases with order growth) ⚠️ PENDING REVIEW
- IF india_uk_fta_ratified AND no_uk_buyers → signal = BD opportunity trigger (help factory pitch to UK buyers using FTA cost advantage) ⚠️ PENDING REVIEW
- IF us_s301_tariff_on_IN_confirmed → CAUTION on US-bound order expansion; consolidation risk = small FOB exporters lose orders to larger verticals first ⚠️ PENDING REVIEW

---

## Structural Nuances
- "Bank OD at 12–18% p.a. — among highest globally for formal credit; personal guarantee from owner required; Air8 ARP with no collateral = significant structural advantage" (RP-DEPENDENCY input — freshness: annual) ⚠️
- "GST refund on exports locked in government receivables 30–90 days beyond buyer OA cycle — real cash cycle is materially longer than OA days alone" (RP-WINDOW input — freshness: stable)
- "Woven garments = longer lead time than knit (90–120d vs 60–90d) → larger absolute working capital gap per order cycle"
- "If selling cotton woven to US → UFLPA traceability applies: must prove cotton supply chain does NOT include Xinjiang; non-compliant = shipment detention = unpayable Air8 receivable"
- "Noida/Gurugram/NCR cluster: well-connected logistics, proximity to Delhi airport for air freight, but higher overhead than Tirupur or Surat"
- "Typically upgrading from CMT to FOB — has buyer relationships but limited sourcing infrastructure; FOB margin 15–22% but sourcing risk now carried by factory"
- "India small FOB exporters often under-utilize export finance schemes (ECGC, EXIM Bank) due to complexity → Air8 simpler onboarding is a genuine differentiator"
- "⚠️ Section 301 tariffs on India would be unprecedented (India has not faced S301 tariffs since the 2019 GSP revocation for different reasons); if implemented, the 15-25% additional tariff on Indian woven cotton garments would significantly erode India's cost competitiveness in US market — exactly at the moment when India was expected to gain share from China+1 and the India-UK FTA momentum" (source: Event F, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Small Indian woven FOB exporters (COMBO-014) have less political clout than large verticals (COMBO-003) to navigate US trade negotiations; COMBO-014 factories may be the first to lose US buyer orders if tariff uncertainty grows — US buyers will consolidate with fewer, larger suppliers in a high-tariff environment" (source: Event F, freshness: annual, PENDING EXPERT REVIEW: Alice)
- "⚠️ India-UK FTA (in negotiation 2026): if enacted, removes India's 8-12% duty disadvantage in UK market. UK imports ~$20bn apparel annually; India currently holds only 6% share. FTA completion = India EXPANDS into UK market at scale, creating a new buyer market signal. Air8 should monitor FTA progress and prepare S2 UK-buyer outreach for IN Vertical and IN Small Woven combos." (source: Event C, freshness: annual, PENDING EXPERT REVIEW: Jerri)

---

## Buyer Edges
- sells_to: [buyer_type: USMassMarket, weight: 0.70] — Walmart, Target, JCPenney
- sells_to: [buyer_type: EUMidMarket, weight: 0.65] — C&A, Marks & Spencer
- sells_to: [buyer_type: USPremium, weight: 0.35] — smaller specialty buyers
- concentration_pattern: "Typically 2–3 buyers. US-heavy (60–70% revenue). Growing EU to diversify."
- typical_payment_terms: OA 60–90 days (US buyers); OA 60 days (EU)

---

## LLM Directives
- bank_od_benchmark: "What is the current bank OD rate for small FOB woven exporters in India (MSME category)? Compare private banks vs PSU banks. Cite most recent RBI data."
- gst_refund_timeline: "What is the current average GST refund timeline for apparel exporters in India? Any recent GST council changes? Cite GST council or FIEO data."
- uflpa_india_cotton: "What is the current UFLPA enforcement status for Indian cotton woven garments exported to US? Any Indian mills on the UFLPA entity list? Cite CBP enforcement data."
- cotton_duty_impact: "After India's cotton import duty cut (11% → 0%), how does this affect small Indian woven FOB exporters who source their own fabric? Calculate blended impact for a factory sourcing 60% imported cotton."
- competitive_context: "Post India cotton duty event: how does small India woven FOB compare to Bangladesh and Vietnam on cotton fabric cost? Who gains competitive advantage?"

---

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-PRESHIP-RT2C.md
- pain_points: PP-001-cashflow-gap.md PP-002-financing-cost.md PP-IN-002-bank-od-cost.md PP-IN-001-gst-refund.md PP-005-preshipment-capital.md
- L0_principles: persona-principles.md#RP-MATERIAL-01 event-principles.md#RP-EVT-DUTY-01
- edges: _links/cross-module-edges.md
- country: _country/IN.md
- compliance: regulations/REG-UFLPA.md (if US buyer detected)

## Pain Hooks
- [PP-001-cashflow-gap] primary — woven longer lead time = larger gap
- [PP-002-financing-cost] primary — bank OD 12–18% is the core pain
- [PP-005-preshipment-capital] high — FOB factory now carries sourcing risk
- [PP-IN-001-gst-refund] high — 30–90d lock-up compounds cash cycle
- [PP-IN-002-bank-od-cost] critical — this is the primary Air8 opportunity anchor

---
