---
type: persona
id: COMBO-006
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Parent HQ controls receivables, cash trapped"
  - id: PP-004
    severity: HIGH
    context: "Scale decisions require parent HQ approval"
  - id: PP-VN-001
    severity: HIGH
    context: "FDI decision authority blocks local financing"
---

# COMBO-006: Vietnam FDI Knit Factory

## Dimensions
- Country: [[dimensions/DIM-1-country]] (VN)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($10-50M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_CMT | FOB)
- Product: [[dimensions/DIM-4-product-focus]] (knit_activewear)
- Market: [[dimensions/DIM-5-target-market]] (US > EU)
- Financing: [[dimensions/DIM-7-current-financing]] (parent_company | bank_LC)
- Growth: [[dimensions/DIM-8-growth-stage]] (expanding)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-004-scalability-constraint]]
- [[../../layer-1-reasoning/pain-points/country/PP-VN-001-fdi-decision-authority]]

## Products
- [[../financing-products/PROD-ARP]] (pitch to parent HQ)
- [[../financing-products/PROD-PAYGUARD]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (if cotton)
- [[../regulations/REG-CSDDD]]

## Data Entities
- [[data-entities/ENTITY-Buyer]] (payment_days)
- parent_company.credit_rating

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: decision_authority_level
  why: "local GM vs parent HQ authorization determines who needs to be in the Air8 conversation"
  r1_question: "Who is the parent company and which country? Who is the decision authority for financing?"
  r2_deep: "Is the local GM authorized to sign financing agreements, or does this go to Taiwan/Korea/HK HQ?"
  collect: "Entity structure documents; parent company name and country"
  signal_impact: "Parent HQ required: route conversation to parent finance team; BD cycle extends to 3-6 months"

- dim: parent_credit_availability
  why: "parent company credit limits may already be maxed — this is the opening for Air8 as an additive facility"
  r1_question: "Does the parent company have an existing group credit facility that covers the Vietnam entity?"
  r2_deep: "What is the current utilisation of the parent group credit facility? Is there headroom for Vietnam expansion?"
  collect: "Parent group facility utilisation if available"
  signal_impact: "Parent facility maxed: strong Air8 opening as additive. Parent facility available: harder sell; focus on speed/flexibility"

- dim: buyer_program_size
  why: "program supplier with confirmed volumes is ideal PSF anchor"
  r1_question: "Who are your top 2-3 buyers and what % of revenue each?"
  r2_deep: "Do buyers issue confirmed annual programs or season-by-season POs? What is the typical PO-to-payment cycle?"
  collect: "Buyer PO samples; program confirmation letters if available"
  signal_impact: "Confirmed buyer program (Nike/Adidas): strong PSF anchor; EXPAND signal. Season-only POs: less certainty; CONDITIONAL"

- dim: china_plus_one_growth_rate
  why: "fast China+1 growth = WC strain = Air8 opportunity; but also means book can grow quickly"
  r1_question: "Has your production volume grown significantly in the past 2 years? Are you adding new buyer programs?"
  r2_deep: "What is the YoY growth rate in PO volume? What is your current capacity utilisation?"
  collect: "Production volume trend; capacity utilisation data"
  signal_impact: "Fast growth (>20% YoY): EXPAND signal; WC strain is real and growing. Flat/declining: NEUTRAL"

- dim: parent_relocation_risk | why: "If VN labor costs are rising 15%/year, parent company may shift capex to other countries — Air8 must identify if parent is still investing in VN capacity or planning to shift" | r1_question: "Is your parent company investing in new production capacity in Vietnam, or are they exploring other countries?" | signal_impact: "Parent actively investing in VN → EXPAND. Parent evaluating relocation → CAUTION; reduce advance ratio trajectory" ⚠️ PENDING REVIEW

---

## Signal Flip Conditions
- IF parent_hq_has_group_facility → confirm parent credit headroom before pitching independent Air8 facility
- IF local_gm_no_authority → route conversation to parent HQ finance team immediately
- IF section_301_tariff_imposed_on_VN → immediately reduce advance ratio to alert level (70%); trigger parent HQ conversation about production shift timeline ⚠️ PENDING REVIEW
- IF parent_company_announces_VN_capacity_reduction → exit orderly; do not extend new facilities ⚠️ PENDING REVIEW

---

## Structural Nuances
- "Parent company (Korean or Taiwanese HQ) makes financing decisions — local GM may not have authority to sign a financing agreement; must pitch to parent HQ, not local factory"
- "FDI factories are direct beneficiaries of China+1 sourcing diversification; rapid PO volume growth creates WC needs that parent company credit lines cannot keep pace with"
- "VN factories have strong activewear/sportswear positioning (Nike, Adidas supply chain) — technical product capability; not easy to replicate in BD or IN"
- "Worker shortage in peak season is a persistent production risk — constrains growth even when orders are available"
- "CPTPP advantage: VN has CPTPP trade access to Japan, Australia, Canada at preferential rates that BD and PK don't have"
- "⚠️ Vietnam government implements annual minimum wage adjustments (typically Jan 1 effective) — FDI factories in Zone 1 (HCMC, Hanoi metro) face the highest minimum wage tier; 2025-2026 trajectory suggests continued 8-12% annual wage increases even without labor shortages" (source: Event A, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ VN FDI factory parent company (Korean/Taiwanese) may respond to rising labor costs by shifting production investment to lower-cost countries (Indonesia, India) rather than absorbing locally — this creates an Air8 client attrition risk that is invisible until the parent announces the shift" (source: Event A, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Nike and Adidas maintain their own supply chain compliance programs (VF Supplier Compliance Standards, FLA accreditation) — these create a compliance documentation layer that reduces but does NOT eliminate UFLPA detention risk; UFLPA presumption is rebuttable but requires factory-level documentation of cotton origin, not just brand compliance certification" (source: Event D, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Section 301 country-level tariff on Vietnam (if imposed) would apply to ALL Vietnamese exports to US regardless of individual factory compliance — a VN FDI factory with perfect labor practices would still pay the tariff; the parent company's decision to maintain or shift VN production would then depend on tariff-adjusted cost competitiveness vs alternative countries" (source: Event D, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Korean/Taiwanese FDI parent companies have demonstrated ability to rapidly shift production countries when tariff risk materializes (e.g., China → VN shift 2018-2020); if S301 tariffs on VN are implemented, parent company may relocate orders to ID or IN within 6-12 months — Air8 VN facility could become stranded; advance ratio should be reduced immediately upon S301 tariff confirmation" (source: Events D+F, freshness: quarterly, PENDING EXPERT REVIEW: Jerri)
- "⚠️ US Section 301 forced labor investigations and UFLPA operate as SEPARATE legal tracks — a shipment can face both simultaneously: UFLPA creates a rebuttable presumption of detention at CBP, while S301 adds tariff liability. BD/VN/KH factories with US buyers must have SEPARATE documentation for each: UFLPA traceability + S301 country-of-origin compliance. Air8 must NOT advance on US-bound shipments from these origins without both clearances confirmed." (source: Events D+F, freshness: annual, PENDING EXPERT REVIEW: Jerri)

---

## Buyer Edges
- sells_to: [buyer_type: USGlobalBrand, weight: 0.90] — Nike, Adidas, Under Armour
- sells_to: [buyer_type: EUFastFashion, weight: 0.55]
- concentration_pattern: "Brand concentration is typical — sportswear factories often have 60-70% from 1-2 global brands (program supplier model)."
- typical_payment_terms: OA 60–90 days

---

## LLM Directives
- vn_growth_outlook: "Current Vietnam garment export growth rate and China+1 beneficiary status. Which buyer types are expanding VN sourcing? What WC constraint signals are common for FDI factories growing >20% YoY?"

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-PRESHIP-OBF.md
- pain_points: PP-001-cashflow-gap.md PP-VN-001-fdi-authority.md
- L0_principles: persona-principles.md#RP-BUYER-FIN-01 event-principles.md#RP-EVT-SOURCSHIFT-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-004-scalability-constraint] high — fast growth outpacing parent credit
- [PP-VN-001-fdi-decision-authority] high — structural friction in Air8 sales process

---
