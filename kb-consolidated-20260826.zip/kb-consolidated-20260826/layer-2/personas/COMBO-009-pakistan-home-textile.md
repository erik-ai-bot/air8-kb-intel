---
type: persona
id: COMBO-009
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap on buyer payment terms"
  - id: PP-002
    severity: HIGH
    context: "Local bank rates 15-22%, inaccessible credit"
  - id: PP-PK-001
    severity: HIGH
    context: "Energy crisis adds 10-20% production cost"
---

# COMBO-009: Pakistan Home Textile Exporter

## Dimensions
- Country: [[dimensions/DIM-1-country]] (PK)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($10-50M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB)
- Product: [[dimensions/DIM-4-product-focus]] (home_textiles)
- Market: [[dimensions/DIM-5-target-market]] (US+EU)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_LC)
- Growth: [[dimensions/DIM-8-growth-stage]] (stable)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/country/PP-PK-001-energy-crisis]]

## Products
- [[../financing-products/PROD-ARP]]
- [[../financing-products/PROD-POOL]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (cotton)
- [[../regulations/REG-REACH]] (fire retardants in home textiles)

## Data Entities
- [[data-entities/ENTITY-Commodity]] (cotton_price)
- energy.pakistan_tariff
- [[data-entities/ENTITY-Buyer]] (payment_days)

## V2 Framework Extensions

### Structural Nuances
- "Pakistan is a cotton producer — different dynamic. PK mills buy domestic cotton, NOT Indian. Event does not lower their input cost directly."
- "Threat: India mills at cotton cost advantage → can undercut PK FOB on home textiles and denim with same US/EU buyers"
- "Energy crisis adds +10-20% production cost on top of already-high bank rates (15-22%)"
- "PK ELS (Extra-Long Staple) long-staple cotton is a quality asset but insufficient to offset price gap at commodity scale"
- "SBP FX controls limit USD availability — difficult to lock import cotton prices in advance"

### Particular Supplier (5-D)
demand:
  - "PO volume trend? Buyer growing or cutting PK allocation?"
buyers:
  - "% with top buyer? Home textile vs denim revenue split?"
product:
  - "Cotton sourcing — domestic PK or import? ELS / Pima premium lines?"
cash:
  - "Payment on time? Bank facility utilisation — how much headroom?"
capacity:
  - "Factory utilisation %? Seasonal or year-round orders?"

### What to Provide
- "Cotton sourcing declaration → domestic Pak or import? Certified ELS / Pima?"
- "Home textile vs denim revenue split (%) → determines exposure profile"
- "Export market mix (US / EU / CN) → US = tariff risk, EU = stable"
- "Bank facility info → credit line size and current utilisation %"

### What to Do
1. "Buy domestic PK cotton now — India import surge may soften PK domestic prices slightly; lock before any reversal"
2. "Differentiate on ELS (Extra-Long Staple) cotton from Punjab — softer, more durable towels India cannot match at scale"
3. "For US buyers: leverage UFLPA traceability — PK cotton origin is documentable and clearly non-Xinjiang"
4. "Lobby on energy stabilisation — energy cost gap is the bigger structural problem long-term"

### Sub-Scenarios
sub_scenario_1:
  condition: "Premium ELS towels — verified quality story"
  why: "PK ELS cotton produces measurably higher quality towels. India does not have ELS at equivalent scale. Defensible 5-8% premium vs commodity India."
  air8_signal: "CONDITIONAL: ARP only on premium-range buyer POs. Monitor monthly. Verify ELS certification and buyer PO trend before approving."
  action: "Position explicitly as premium ELS. Quantify quality difference with durability and hand-feel data. A documented quality story is the only sustainable differentiator."

sub_scenario_2:
  condition: "Repayment or PO signal deteriorates"
  why: "If buyer PO volume falls >15%, payment cycles lengthen, or dilution rate increases — signals India is winning the price battle."
  air8_signal: "Reduce advance ratio to 65% max. Shorten review cycle to monthly. If 2+ signals deteriorate in same quarter, consider reducing facility size."
  action: "Early warning checklist: invoice frequency, payment speed vs terms, dilution rate, buyer RFQ engagement. Review all four quarterly."

### Competitive Position
moat: "ELS/Pima cotton quality story; UFLPA non-Xinjiang traceability advantage for US buyers"
moat_horizon: "Defensible in premium segment; commodity segment under structural pressure"
competitive_threat_from: ["COMBO-003-IN-Vertical"]
competitive_advantage_over: []
watch_signal: "India home textile export growth rate; PK energy cost trajectory"

### Air8 Risk Parameters
air8_signal: "CAUTION — DO NOT EXPAND, MONITOR EXISTING"
advance_ratio_normal: 80
advance_ratio_alert: 65
review_frequency: "monthly"
trigger_for_reduction: "2+ signals: PO decline, payment lengthening, dilution increase"
monitoring_signals:
  - "PO volume by buyer"
  - "Payment speed vs terms"
  - "Bank facility headroom (SBP FX availability)"
  - "Energy cost per unit trajectory"

## V2 Assessment Chain

### impact_calculation
```yaml
formula: "net_risk_score = (India_cost_advantage × market_overlap) + energy_cost_burden + financing_cost_burden"
generic_estimate: "Triple-pressure scenario; CAUTION signal; ELS premium = only defensible niche"
inputs:
  els_pima_certification:
    source: "AC-02 supplier answer"
    values: [certified_els, conventional_only]
    expert_review: "required — QAQC expert to validate ELS/Pima certification authenticity"
  bank_facility_utilisation:
    source: "AC-04 supplier answer"
    expert_review: "required — credit team to assess headroom before any new facility"
  energy_cost_per_unit:
    source: "AC-03 supplier answer OR benchmark"
    default: "+15% vs pre-crisis"
    expert_review: "validate_default — PK expert confirm current energy cost premium"
```

### assessment_chain
```yaml
- id: AC-01
  dimension: "Cotton sourcing — is this supplier affected by India duty at all?"
  question: "Do you source domestic Pakistani cotton, import from India, or mix?"
  data_request: "Cotton sourcing declaration — domestic PK vs import % (last 12 months)"
  expert_review: "ai_extended — LLM default: PK = domestic producer; verify any import component"
  branch:
    domestic_pk_only:
      direct_saving: NONE
      why: "PK mills buy domestic cotton; India duty does NOT lower their cost"
      signal_note: "Threat comes from India's competitive advantage, not direct cost change"
      next: AC-02
    imports_from_india:
      direct_saving: PARTIAL
      why: "Minority case; some PK mills import specialty cotton from India"
      next: AC-02

- id: AC-02
  dimension: "ELS / Pima quality differentiation — is there a defensible moat?"
  question: "Do you produce ELS (Extra-Long Staple) or Pima cotton lines? Are they certified?"
  data_request: "ELS/Pima certification; product spec showing staple length; buyer premium paid"
  expert_review: "required — QAQC expert must validate ELS certification; this is the only moat"
  branch:
    certified_els_with_buyer_premium:
      signal: CONDITIONAL_EXPAND
      why: "India cannot match ELS at scale; 5-8% quality premium defensible"
      next: AC-03
    conventional_commodity:
      signal: DO_NOT_EXPAND
      why: "No differentiation; India will undercut on price within 12 months"
      action: "Monitor existing facility; prepare for reduction"
      next: AC-03

- id: AC-03
  dimension: "Energy cost burden — how much is this squeezing the supplier?"
  question: "What is your energy cost as % of production cost? Do you have backup generation?"
  data_request: "Energy cost breakdown (grid vs generator %) + monthly utility bills (3 months)"
  expert_review: "validate_default — PK operations expert confirm current energy premium range"
  unlocks_calculation: "energy_burden = generator_hours% × (diesel_cost - grid_rate)"
  next: AC-04

- id: AC-04
  dimension: "Bank facility headroom — can supplier absorb more stress?"
  question: "What is your current bank credit line size and utilisation %?"
  data_request: "Bank facility letter + current utilisation statement"
  expert_review: "required — credit team to assess before approving any ARP facility"
  branch:
    utilisation_lt60pct:
      headroom: ADEQUATE
      note: "Supplier can absorb shock; ARP facility feasible"
    utilisation_gt80pct:
      headroom: TIGHT
      signal_flag: "High bank utilisation + energy cost + India pressure = triple stress"
      action: "Do not approve new facility; restructure existing if any"
```

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: els_pima_certification
  why: "the ONLY defensible moat vs India commodity competition; must be certified and verifiable"
  r1_question: "What product lines do you produce — towels, bedding, or both? Do you have ELS or Pima cotton certification?"
  r2_deep: "Do buyers pay a verified premium for ELS certification, and how much per unit? Is it documented in contracts?"
  collect: "ELS/Pima certification documents; buyer contract pricing showing premium"
  signal_impact: "ELS certified + verified premium: CONDITIONAL_EXPAND on premium buyer POs. No certification: DO_NOT_EXPAND for commodity segment."

- dim: energy_cost_per_unit
  why: "generator backup costs erode margin; must quantify to understand true competitiveness vs peers"
  r1_question: "How much of your production runs on generator backup vs grid power? Do you have a sense of the cost difference?"
  r2_deep: "Can you estimate the generator backup cost premium per unit of output vs grid power? How does this compare to your 2022 energy baseline?"
  collect: "Energy cost breakdown (grid vs generator); production records showing fuel consumption"
  signal_impact: "Energy cost >15% premium over peers: flag in competitive analysis; reduces margin buffer for Air8 pricing"

- dim: bank_facility_utilisation
  why: "existing credit headroom determines whether Air8 adds capacity or just replaces bank facility"
  r1_question: "What is your current bank facility rate and how much is currently drawn?"
  r2_deep: "If we structured ARP to replace part of your bank LC facility, how much headroom would that free up?"
  collect: "Bank facility letter showing limit and current utilisation; LC facility structure"
  signal_impact: "Utilisation >80%: triple stress indicator (India competition + energy + credit exhausted); flag Tier 2 risk"

- dim: domestic_vs_import_cotton
  why: "confirms PK is a domestic cotton producer — India duty events = competitive threat direction, NOT benefit"
  r1_question: "What % of your cotton is domestic Pakistan cotton vs imported?"
  r2_deep: "Do you source primarily from Punjab ELS cotton producers? Any Indian cotton in your supply chain?"
  collect: "Cotton purchase records by origin (last 6 months)"
  signal_impact: "100% domestic PK cotton confirmed: India cotton price event flips to CAUTION (competitive threat, not benefit)"

- dim: uflpa_documentation_readiness
  why: "non-Xinjiang PK cotton is a US market advantage — must be documented to realize the benefit"
  r1_question: "Do US buyers ask for supply chain traceability documentation? Do you have cotton origin certificates?"
  r2_deep: "Can you trace cotton origin to Punjab field level? What documentation do Walmart/Target require for UFLPA compliance?"
  collect: "Cotton origin certificates; UFLPA documentation package if available"
  signal_impact: "Documented non-Xinjiang origin: US market advantage vs China; flag as competitive differentiator in BD pitch"

---

## Signal Flip Conditions
- IF domestic_pk_cotton_only = confirmed → any India cotton price event signal flips to CAUTION (competitive threat, not benefit)
- IF els_certification = none → signal = DO_NOT_EXPAND for commodity segment (India will undercut within 12 months)
- IF els_certified_premium_range = confirmed → signal = CONDITIONAL_EXPAND on premium buyer POs only
- IF bank_utilisation > 80% → flag triple stress: India competition + energy cost + credit exhausted

---

## Structural Nuances
- "Pakistan is a cotton producer — PK home textile mills buy domestic cotton; India cotton duty events do NOT lower PK input cost directly; the threat runs the OTHER direction (India gets cheaper cotton → India home textiles become cheaper → undercut PK in same US/EU buyers)"
- "Energy crisis adds +10–20% to production cost (generator backup when grid fails) — this is the BIGGER structural problem than financing cost; Air8 addresses the financing side, not the energy side"
- "SBP FX controls limit USD availability — difficult to import specialty chemicals or dyes priced in USD; limits product development and input cost management"
- "Bank rates 15–22% p.a. — offshore USD trade finance is a direct gap that Air8 fills at competitive pricing"
- "PK ELS (Extra-Long Staple) long-staple cotton from Punjab is a quality asset: measurably softer and more durable towels than commodity cotton; India does NOT have ELS at equivalent scale — 5–8% quality premium defensible"
- "60% of Pakistan's exports are textiles — any sector shock is existential; buyer nervousness about placing large orders is structural"
- "UFLPA: PK cotton is clearly non-Xinjiang and documentable; this is a defensible advantage for US buyers needing supply chain compliance"

---

## Buyer Edges
- sells_to: [buyer_type: USMassMarket, weight: 0.85] — Walmart, Target, Costco
- sells_to: [buyer_type: EUHomeRetail, weight: 0.70] — IKEA, H&M Home, Zara Home
- concentration_pattern: "High buyer concentration — PK home textile exports concentrated in 3-5 major importers. Top buyer often >30% revenue."
- typical_payment_terms: OA 60–120 days

---

## LLM Directives
- pk_vs_india_home_textile: "Post-[event]: compare Pakistan vs India on towel/bed sheet FOB cost for US and EU buyers. Factor in cotton price, energy cost, labor, and logistics. Is India's cotton advantage enough to overcome PK's ELS quality premium?"
- energy_cost_benchmark: "Current Pakistan electricity cost for textile factories (grid vs generator mix). Compare to India and Bangladesh. What is the per-unit cost penalty PK factories absorb?"
- pk_export_outlook: "Current Pakistan home textile export volumes and buyer confidence levels. Are major US/EU buyers maintaining PK as a primary source or exploring alternatives?"

---

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-POOL.md
- pain_points: PP-001-cashflow-gap.md PP-PK-001-energy-crisis.md PP-003-buyer-concentration.md
- L0_principles: persona-principles.md#RP-MATERIAL-01 risk-principles.md#RP-RISK-CONC-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-002-financing-cost] critical (15–22% bank rates; offshore Air8 competitive)
- [PP-PK-001-energy-crisis] critical — structural; most important non-financing pain

---
