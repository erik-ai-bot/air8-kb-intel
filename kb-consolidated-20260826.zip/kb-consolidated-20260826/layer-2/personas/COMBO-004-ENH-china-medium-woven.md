---
type: persona
id: COMBO-004-ENH
extends: COMBO-004
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Receivables gap on OA terms"
  - id: PP-002
    severity: HIGH
    context: "Sinosure and local bank financing burden"
  - id: PP-CN-001
    severity: HIGH
    context: "SAFE cross-border complexity limits capital"
  - id: PP-CN-002
    severity: MEDIUM
    context: "Sinosure declaration burden on exporters"
  - id: PP-CN-003
    severity: MEDIUM
    context: "Hengqin portfolio capacity constraints"
---
# COMBO-004-ENH: China Full Package (Cotton Event Variant)

## V2 Framework Extensions

### Structural Nuances
- "CN factories source fabric from Keqiao mills (Shaoxing, Zhejiang) — world's largest fabric trading market"
- "CN garment factories do NOT buy cotton directly; they buy fabric from Keqiao mills who source yarn globally including from India"
- "As Indian cotton gets cheaper, Keqiao mills' input cost may fall → pass-through is possible but NOT immediate or full (lag + partial)"
- "Keqiao mills source yarn from multiple origins and manage exposure via futures/FX contracts → benefit to CN factories arrives with lag"
- "India garment factories also become more competitive on same cotton categories — dual threat"
- "US tariffs on CN at 25-50% and India's cotton cost now lower → India has structural cost advantage on US-bound cotton T-shirts"
- "CN share of US apparel: 33% (2017) → 21% (2025) — pre-existing trend this event accelerates"

### Particular Supplier (5-D)
demand:
  - "EU PO growing? US orders stable or declining?"
buyers:
  - "US vs EU vs JP revenue mix? Any buyer cutting CN allocation?"
product:
  - "Keqiao or domestic fabric? Xinjiang cotton in any product line?"
cash:
  - "Payment speed by buyer? Dilution rate per buyer?"
capacity:
  - "EU vs US order utilisation split? Any idle capacity?"

### What to Provide
- "Buyer revenue mix % (EU / US / JP / other)"
- "Fabric sourcing → Keqiao mill or domestic? Spot or forward contract?"
- "Fabric origin declaration by order destination (compliance for US orders)"
- "US buyer PO trend (12 months) → growing or cutting?"

### What to Do
1. "Pre-position with Keqiao fabric/yarn now — forward PO commitments and relationship pricing before mills adjust"
2. "Optimise procurement mix by order destination: redirect to non-Xinjiang or Indian-origin fabric for US/EU compliance-sensitive production"
3. "Accelerate EU/Japan buyer acquisition — CN tariff to EU 0-12%, Keqiao speed gives 2-3 week turnaround"
4. "Accept declining US commodity T-shirt volume; redirect lines to complex prints, DTC co-development, special finishes"

### Sub-Scenarios
sub_scenario_1:
  condition: "EU >50% revenue, deep Keqiao network"
  why: "EU buyers are not de-sourcing from CN. Keqiao speed (2-3 week EU turnaround vs 4+ weeks from India) is structural advantage."
  air8_signal: "EXPAND. PreShip-OBF for Keqiao sourcing. ARP on EU receivables (H&M, Zara — low dilution 1-5%). Hengqin entity caps: single company ≤40% of portfolio."
  action: "Use lower Keqiao fabric cost + CN speed to offer EU buyers faster turnaround — counter-attack against India price advantage."

sub_scenario_2:
  condition: "US-heavy mix (>40% US revenue)"
  why: "US buyers actively reducing CN orders (33%→21% market share over 8 years). This event accelerates that. Air8 would finance a shrinking book."
  air8_signal: "DO NOT EXPAND. For existing facility: monitor PO volume quarterly. If US buyer orders decline >10% YoY, reduce advance ratio and do not renew at same size."
  action: "Do not defend US commodity basics on price. Retain only technical/co-developed US orders. Pivot capacity to EU/Japan."

### Competitive Position
moat: "Keqiao fabric market speed (2-3 week EU turnaround); CN speed and product complexity capability"
moat_horizon: "EU: strong ongoing; US: structural decline due to tariffs + India competition"
competitive_threat_from: ["COMBO-003-IN-Vertical"]
competitive_advantage_over: []
watch_signal: "EU buyer de-sourcing signals; US PO trend decline rate"

### Air8 Risk Parameters
air8_signal: "CONDITIONAL — VERIFY BUYER MIX FIRST"
advance_ratio_normal: 85
advance_ratio_alert: 75
review_frequency: "quarterly"
trigger_for_reduction: "US buyer PO decline >10% YoY"
monitoring_signals:
  - "EU vs US PO mix quarterly"
  - "Keqiao fabric cost trend"
  - "Xinjiang cotton compliance flags"
  - "US buyer concentration change"

## V2 Assessment Chain

### impact_calculation
```yaml
formula: "net_signal = (EU_revenue_pct × keqiao_advantage) - (US_revenue_pct × tariff_headwind)"
generic_estimate: "CONDITIONAL — entirely buyer-mix dependent"
inputs:
  eu_revenue_pct:
    source: "AC-01 supplier answer"
    expert_review: "validate — BD to confirm EU vs US split before any facility decision"
  keqiao_relationship:
    source: "AC-02 supplier answer"
    values: [deep_network, standard, limited]
    expert_review: "ai_extended — LLM can estimate from factory location/size; expert validates"
  xinjiang_cotton_exposure:
    source: "AC-03 supplier answer"
    expert_review: "required — compliance team must verify; UFLPA risk is critical for US orders"
```

### assessment_chain
```yaml
- id: AC-01
  dimension: "Buyer geography mix — the single most important variable"
  question: "What % of revenue is EU vs US vs Japan vs other? Any buyer cutting CN allocation?"
  data_request: "Buyer revenue mix % last 12 months; any buyer communication re: sourcing review"
  expert_review: "required — this single answer determines expand vs do-not-expand"
  branch:
    eu_gt50pct:
      signal: EXPAND
      why: "EU buyers not de-sourcing from CN; Keqiao speed advantage holds"
      next: AC-02
    us_gt40pct:
      signal: DO_NOT_EXPAND
      why: "US buyers actively reducing CN orders; Air8 finances shrinking book"
      stop: true
      action: "Monitor PO volume quarterly; do not renew at same size"
    balanced:
      signal: CONDITIONAL
      next: AC-02

- id: AC-02
  dimension: "Keqiao network depth — is speed advantage real?"
  question: "Do you source fabric from Keqiao mills? Spot market or forward contracts?"
  data_request: "Fabric sourcing → Keqiao mill names; contract type (spot/forward); lead time"
  expert_review: "ai_extended — LLM can assess from factory location; expert validates Keqiao relationships"
  branch:
    deep_keqiao_forward_contracts:
      advantage_confirmed: true
      action: "Pre-position now at lower Indian cotton-based prices before mills reprice"
    spot_market_only:
      advantage_partial: true
      note: "Can still benefit but less locked-in; advise relationship pricing"

- id: AC-03
  dimension: "Xinjiang cotton exposure — compliance risk for US/EU orders"
  question: "Does any product line use cotton from Xinjiang? For which order destinations?"
  data_request: "Fabric origin declaration by order destination; UFLPA compliance statement"
  expert_review: "required — compliance team mandatory review; UFLPA violation = facility termination"
  branch:
    xinjiang_cotton_present:
      flag: CRITICAL
      action: "Redirect to non-Xinjiang or Indian-origin fabric for US/EU compliance orders immediately"
    no_xinjiang_cotton:
      compliance_clear: true
      note: "Document for buyer compliance requirements"
```
