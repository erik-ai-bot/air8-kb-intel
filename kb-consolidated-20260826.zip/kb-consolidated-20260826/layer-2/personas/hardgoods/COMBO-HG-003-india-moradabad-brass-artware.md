# COMBO-HG-003: India Moradabad Brass Artware (Small MSME, FOB)

> extends: FullPackage-LowMargin archetype | New: Hardgoods domain v1
> Created: 2026-07-15 | Freshness: annual
> country_ref: _country/IN.md | domain_ref: hardgoods/geo-swot.md
> Expert review: Josephine Cheung — COMPLETED 2026-07-16. Corrections applied.

---

## Identity
- id: COMBO-HG-003
- archetype: FullPackage-LowMargin
- country: IN
- revenue_band: cluster dominated by small MSME units ($2–10M, ~95% of production units), but output aggregated by a powerful layer of large consolidated exporters ($10M+) who hold buyer relationships
- product_type: handcrafted brass/copper artware (vases, bowls, decorative figurines, temple/religious items, homeware)
- materials: true brass (60–70% copper; sourced significantly via scrap copper imports — NOT primarily domestic copper at scale), copper sheet, mixed metal finishes
- company_type: FOB
- buyer_geo: EU premium (Pottery Barn, Restoration Hardware, Williams-Sonoma), Middle East, US premium (tariff-advantaged vs CN)
- cash_cycle_days: 90–150 days (long artisan production cycle + buyer OA terms)
- tags: country:IN, product:brass-artware, material:brass, material:copper, buyer_geo:EU, buyer_geo:US, scenario:S1, scenario:S2, domain:hardgoods

---

## Structural Nuances
*(Built from hardgoods geo-swot.md + Event T1 copper tariff BENEFIT signal + L0 event principles)*

- "Moradabad 'Brass City' — largest brass artware cluster globally; 4,000+ production units; 400,000+ artisan workers; city-level specialization in handcrafted decorative brass with generations of craft knowledge embedded in the workforce. No other single location replicates this concentration."
- "⚠️ COPPER SOURCING CORRECTION: Moradabad units import copper heavily via scrap dealers — domestic Indian copper does NOT hold at scale for the cluster. Larger units in particular source imported scrap copper, not Hindalco/Vedanta domestic supply. The 'domestic copper insulation from US tariffs' claim requires per-factory verification; do NOT assume the full cluster is insulated. [VERIFIED — Josephine Cheung 2026-07-16]"
- "To the extent factories DO use domestic Indian copper, structural cost advantage vs CN exists: CN brass = input tariff on imported copper + Section 301 on finished goods to US. India (domestic copper) = no input tariff + lower US finished goods duty. BUT verify per factory: only factories confirmed using domestic copper, not scrap imports, carry this insulation. [VERIFIED — Josephine Cheung 2026-07-16]"
- "Moradabad operates on a two-tier production structure: **Tier 1 (larger units)** uses machines for stamping, forming, plating, and laser engraving; **Tier 2** decentralises to smaller workshops for manual/artisan production. Sub-contracting is common — verify when onboarding. Premium Western buyers source Moradabad for hand-finishing quality (hand-hammering, hand-engraving, hand-patina); the 'purely artisan, no machines' framing is inaccurate. [VERIFIED — Josephine Cheung 2026-07-16]"
- "Long payment cycles (90–150 days OA) combined with MSME credit gap is the classic Air8 opportunity — Moradabad units are micro to small; they have confirmed EU/US premium buyer invoices but cannot access working capital against them. Indian banks do not extend working capital against foreign buyer invoices easily for MSMEs."
- "REACH compliance for EU: heavy metal testing (lead, cadmium in surface finishes) is required per batch. Moradabad units often lack in-house testing facilities; they rely on third-party labs (SGS, Intertek, BV in Moradabad/Delhi) but don't always run tests proactively. Compliance documentation is the gap, not compliance intent."
- "GST complexities and export documentation (MEIS/RODTEP incentive claims, MSME classification) add cash flow friction — units often wait 60–120 days for export incentive refunds that are part of their margin. Air8's ARP can free up cash even before incentive refunds arrive."
- "⚠️ T1 copper tariff BENEFIT signal: if T1 copper tariff event is active AND factory is confirmed using DOMESTIC Indian copper (not scrap imports) → signal = EXPAND for US-facing programs (input insulation + lower US finished goods duty vs CN). If factory sources imported scrap copper → partial benefit only; quantify import share before applying full EXPAND signal. [VERIFIED — Josephine Cheung 2026-07-16]"
- "⚠️ Segment bifurcation is NOT clean: CN factories compete directly with Moradabad, and CN uses better quality alloys in many product types. Product type ranges differ between the two countries. When buyers report 'shifting from CN to India,' it depends on the specific product — India's strength is artware categories (metal lighting, planters, structural furniture bases, decorative trays, candle stands); CN's range is broader. US premium buyer shift to Moradabad post-tariff is actively happening in 2026 — not just anticipated. [VERIFIED — Josephine Cheung 2026-07-16]"
- "US buyer shift actively happening in 2026 for: metal lighting, metal planters, structural furniture bases, decorative trays, candle stands. These are the product categories where Moradabad is gaining US market share from CN post-tariff. [VERIFIED — Josephine Cheung 2026-07-16]"

---

## Buyer Edges
- sells_to: [buyer_type: USPremiumHome, weight: 0.80] — Pottery Barn, Restoration Hardware, Williams-Sonoma, CB2; premium hand-finished programs
- sells_to: [buyer_type: EUPremiumHome, weight: 0.65] — Maisons du Monde (premium range), specialty home décor EU; growing channel
- sells_to: [buyer_type: MiddleEastPremium, weight: 0.50] — UAE luxury retail, Jordan/Qatar souvenir premium; religious/decorative crossover
- sells_to: [buyer_type: EUMassHomeDécor, weight: 0.30] — limited; Moradabad artisan units rarely scale to mass volume
- concentration_pattern: "Often 1–2 US premium buyers = 60–80% of revenue. Very high concentration; buyer loss = existential for MSME unit."
- typical_payment_terms: OA 90–150 days (US premium retail OA); sometimes 30% advance from premium buyer on new programs

---

## Assessment Dimensions

- dim: buyer_concentration_and_stickiness
  why: "MSME concentration risk is existential — 1-2 buyers = 60-80% revenue; any buyer program change = survival event"
  r1_question: "Who are your top 3 buyers and what % of revenue does each represent?"
  r2_deep: "How long have you worked with each buyer? Are you on their preferred vendor list or in active program? Have any buyers reduced orders in the past 12 months?"
  collect: "Buyer revenue breakdown; purchase order history last 24 months; any buyer communication about program changes"
  signal_impact: "Top buyer >50% revenue: HIGH concentration flag; verify relationship stickiness before EXPAND. Sticky multi-year program: EXPAND. New buyer relationship (<12 months): CAUTION."

- dim: domestic_copper_sourcing_chain
  why: "Moradabad imports copper heavily via scrap dealers; domestic copper does NOT hold at scale. Must verify per factory whether they use domestic or imported copper — insulation from US copper tariff is NOT automatic for this cluster."
  r1_question: "Where do you source your copper and brass — domestic Indian suppliers (Hindalco, Vedanta), local scrap dealers, or imported?"
  r2_deep: "What % of your copper input is domestic vs imported scrap? Do you have supplier invoices? Any US-origin copper?"
  collect: "Copper/brass supplier invoices; import records if any"
  signal_impact: "100% domestic Indian copper (confirmed): BENEFIT signal applies (T1 tariff insulation). Significant imported scrap share: partial benefit only; quantify to adjust signal. Majority imported: treat similarly to CN for copper cost exposure."

- dim: artisan_quality_tier
  why: "Moradabad is two-tier: T1 (machines for stamping, forming, plating/laser engraving) + T2 (workshop manual production). Sub-contracting is common. Verify which tier factory operates in and whether sub-contracting is disclosed. Premium buyers require hand-finishing; mass buyers accept machine; segment defines margin and stickiness."
  r1_question: "What finishing techniques are used — hand-hammering, hand-engraving, machine polishing, electroplating? What is the average unit price of your products?"
  r2_deep: "Do any of your buyers specifically require 'artisan-made' or 'handcrafted' certification? Do you have any fair-trade or artisan cluster certifications?"
  collect: "Product catalogue with retail price points; any artisan certification; production method documentation"
  signal_impact: "Hand-finishing + premium buyer confirmed: EXPAND (irreplaceable quality; moat vs CN). Machine-finishing + mass buyer: CAUTION (CN competes at lower cost on non-artisan items)."

- dim: reach_and_export_compliance_maturity
  why: "heavy metal testing gap is the most common compliance failure for Indian brass exporters; need to assess before ARP"
  r1_question: "Do you run REACH/heavy metal tests for EU/US buyers? Which lab? How often?"
  r2_deep: "Has any shipment been held at customs or rejected by buyer for compliance issues in the past 24 months? How do you handle compliance testing costs?"
  collect: "REACH/RoHS test reports; any customs clearance history; lab receipts"
  signal_impact: "Regular testing + clean history: standard advance ratio. No documentation or recent failure: lower advance ratio; compliance support needed."

- dim: export_incentive_cash_flow_cycle
  why: "RODTEP/MEIS refund delays add cash flow friction — understanding the gap helps size Air8 product correctly"
  r1_question: "Do you claim RODTEP or other export incentives? How long does it typically take to receive the refund?"
  r2_deep: "What is the monthly value of outstanding export incentive claims? Does the delay affect your working capital cycle materially?"
  collect: "RODTEP claim history; outstanding refund amounts"
  signal_impact: "Large outstanding incentive claims + long refund delay: ARP sizing should cover both buyer OA gap AND incentive delay period."

---

## Signal Flip Conditions
- IF material = domestic_indian_copper AND buyer_geo = US AND T1_copper_tariff_active = true → signal = EXPAND (structural cost advantage activated)
- IF buyer_concentration > 60% in single buyer → flag HIGH_CONCENTRATION; require buyer stickiness verification before EXPAND
- IF compliance_failure_recent = true → CAUTION; resolve compliance before ARP
- IF product_type = machine_produced AND competition = CN → CAUTION (no artisan moat; CN regains competitiveness post-tariff)
- IF product_type = handcrafted AND buyer = US_premium AND T1_active → EXPAND with high confidence (dual advantage: input hedge + output tariff differential vs CN)

---

## Pain Hooks
- [PP-001-cashflow-gap] primary — 90-150 day OA cash cycle; MSME cannot bridge without financing
- [PP-003-buyer-concentration] CRITICAL — 1-2 US premium buyers = existential concentration
- [PP-HG-003-india-copper-hedge] BENEFIT — domestic copper insulation from import tariff (PENDING EXPERT REVIEW: Josephine — pain point ID to be formalized)
- [PP-HG-005-reach-compliance] medium — per-batch heavy metal testing; documentation gap common in MSME units
- [PP-IN-001-msme-credit-gap] primary — standard India MSME working capital gap (PENDING EXPERT REVIEW: Josephine — pain point ID to be formalized)

---

## Product Links

- product_ref: PROD-ARP | rank: primary | weight: 0.90
  condition: "US or EU premium buyer invoices confirmed; domestic copper sourcing verified; REACH compliance clean"
  unique_value: "Bridges 90-150 day US premium retail payment cycle; MSME units cannot access this from Indian banks"
- product_ref: PROD-PRESHIP-OBF | rank: secondary | weight: 0.65
  condition: "New large premium buyer program confirmed; factory needs copper rod procurement before production starts"
  unique_value: "Enables copper pre-buy for confirmed program; prevents production delay from WC shortage"

## LLM Directives
- india_copper_pricing: "Current price of domestic Indian copper (Hindalco CU cathode price) vs LME copper spot price. Is India domestic copper priced at a discount or premium to LME? Has T1 US copper tariff created a domestic price divergence?"
- moradabad_cluster_status: "Current production activity in Moradabad brass cluster — any capacity constraints, new buyer interest, or cluster-level disruptions in 2026? Is US buyer demand for Indian handcrafted brass growing post-tariff?"
- india_us_brass_artware_tariff: "Current US import tariff for handcrafted brass artware from India (HS 8306) — MFN rate + any GSP eligibility? Compare with CN Section 301 + MFN rate for same HS code."
- eu_india_premium_home_decor: "Is EU demand for Indian handcrafted home décor growing in 2026? Which EU retailers are expanding India sourcing for premium brass/copper artware?"

---

## Air8 Risk Parameters (Internal)
- air8_signal: CONDITIONAL — verify buyer concentration + domestic copper sourcing before EXPAND
- advance_ratio_normal: 82%
- advance_ratio_alert: 70% (MSME; higher concentration risk)
- review_frequency: quarterly
- trigger_for_reduction: top buyer order decline >20% YoY; any REACH failure; copper sourcing shift to imports

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- domain: hardgoods/geo-swot.md#India hardgoods/wip-categories.md#Metal
- products: PROD-ARP.md PROD-PRESHIP-OBF.md
- compare_with: COMBO-HG-002-china-brass-artware.md (structural competitive counter-read)
- L0_principles: event-principles.md risk-principles.md#RP-RISK-COUNTRY-01
- edges: _links/cross-module-edges.md
