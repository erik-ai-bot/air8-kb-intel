# COMBO-HG-004: China Decorative Lighting (Mid, FOB)

> extends: FullPackage-MidMargin archetype | New: Hardgoods domain v1
> Created: 2026-07-15 | Freshness: annual
> country_ref: _country/CN.md | domain_ref: hardgoods/geo-swot.md
> Expert review: Josephine Cheung — COMPLETED 2026-07-16. Corrections applied.

---

## Identity
- id: COMBO-HG-004
- archetype: FullPackage-MidMargin
- country: CN
- revenue_band: mid $10–40M
- product_type: decorative lighting (LED chandeliers, table lamps, pendant lights, string lights, smart lighting accessories)
- materials: copper (in drivers, wiring, socket components: varies by product type — simple table lamp 2–5%, smart LED fixture 4–6%, luxury chandelier 8–10%), aluminum housing, steel, glass shades, resin/acrylic
- company_type: FOB
- buyer_geo: EU (dominant; CE mark required), US (tariff-impacted; UL mark required), Middle East premium (growing)
- cash_cycle_days: 60–120 days
- tags: country:CN, product:decorative-lighting, material:copper, material:aluminum, material:LED, buyer_geo:EU, buyer_geo:US, scenario:S1, scenario:S2, domain:hardgoods

---

## Structural Nuances
*(Built from hardgoods geo-swot.md + Event T1 copper tariff + Section 301 + L0 event principles)*

- "Copper is EMBEDDED in every electrical component — LED drivers, copper wire harnesses, lamp sockets, dimmer modules. Copper BOM% varies significantly by product type: simple table lamp 2–5%, smart LED fixture 4–6%, luxury chandelier 8–10%. Do NOT apply a blanket 10–15% figure. A copper tariff event (T1-type) increases BOM cost, but impact magnitude varies by product mix — confirm actual product type before quantifying exposure. [VERIFIED — Josephine Cheung 2026-07-16]"
- "CE marking (EU) and UL listing (US) are MANDATORY per SKU, per product variant. Certification timelines differ: **CE (EMC + LVD) = 2–3 weeks**; **UL listing = 2–4 months**. If factory uses pre-certified components and UL-recognized wire (all core electrical components with individual certifications), UL can be reduced to **3–4 weeks**. For full origin transfer (same design, new factory), realistic timeline: **1–2 months fast-track** if design is identical; **3–6 months** for new design or modified components. This is the HIGHEST barrier to origin shift in the hardgoods space. [VERIFIED — Josephine Cheung 2026-07-16]"
- "This certification barrier is DOUBLE-EDGED for Air8: (1) CN lighting factories are sticky — buyers cannot easily walk away without 6-month re-certification delay; (2) BUT if a factory is LOSING customers, we have the same 6-month delay before replacement volumes arrive. Default is structural stability; the flip case is structural slow-motion loss."
- "Double compression for US-bound lighting: (1) T1-type copper tariff increases driver/wiring input cost; (2) Section 301 25%+ on finished CN lighting at US border. Combined effect compresses margin from both sides. Unlike brass artware where substitution is theoretically possible, lighting re-certification from Vietnam takes 6 months — buyers are locked in short-term but actively re-certifying elsewhere."
- "EMC (electromagnetic compatibility) + LVD (low voltage directive) for EU; FCC Part 15 for US smart lighting — each regulatory framework tests different things; a CE-marked product is NOT automatically UL-listed or FCC-compliant. Multi-market compliance adds test cost per SKU."
- "Smart lighting (WiFi/Bluetooth/Zigbee controllable) adds FCC/IC radio certification on top of EMC/LVD/UL — certification cost per smart SKU can be $8,000–$15,000. Factories producing smart lighting carry higher compliance overhead; Air8 compliance financing could be a differentiated product angle."
- "Seasonal concentration for decorative lighting: Q3-Q4 (Sep–Dec) is 60–70% of annual volume (Christmas, holiday programs). Cash cycle: buyer programs confirmed Dec–Jan → material procurement Feb–Mar → production Mar–Jun → shipment Jul–Sep → buyer receipt Sep–Oct → OA 60–90 days payment Nov–Dec. **Total cash cycle: 12–13 months** from buyer program confirmation to final invoice payment. [VERIFIED — Josephine Cheung 2026-07-16]"
- "⚠️ T1 copper tariff + Section 301 DOUBLE COMPRESSION for US-bound CN lighting: signal = CRITICAL CAUTION. **This double compression applies under DDP commercial terms; may NOT apply under FOB terms** — confirm the commercial term with factory before applying. Quantify: (a) what % of revenue is US-bound?; (b) have buyers signaled re-sourcing intent?; (c) is the factory actively getting VN/IN factories CE/UL certified? If re-cert in progress at alternative origin, US book will decline in 6–12 months. [VERIFIED — Josephine Cheung 2026-07-16]"
- "⚠️ Certification barrier as a timing signal: if US-bound factory is under tariff pressure AND beginning VN/IN CE/UL re-certification → Air8 has a 6–12 month window (full re-cert duration) or 1–2 month window (fast-track, identical design). EXPAND short-term on confirmed US book with explicit conversation about re-cert timeline. DO NOT EXPAND multi-year facilities if buyer has signaled origin shift intent. VN is a viable alternative for CE/UL decorative lighting (labs: UL, TUV, Intertek; EU buyers already sourcing VN: IKEA, Zara Home, H&M Home). [VERIFIED — Josephine Cheung 2026-07-16]"

---

## Buyer Edges
- sells_to: [buyer_type: EUMassRetail, weight: 0.80] — IKEA (indirect), Leroy Merlin, MediaMarkt; standard CE-marked decorative; volume
- sells_to: [buyer_type: EUPremiumLighting, weight: 0.55] — BHS (UK), Nordlux (DK), Eglo (AT); CE-marked + design-led
- sells_to: [buyer_type: USMassRetail, weight: 0.40] — Home Depot, Wayfair, Target; UL-listed standard lighting; declining
- sells_to: [buyer_type: MiddleEastPremium, weight: 0.30] — UAE hospitality procurement; chandeliers, premium pendant; growing
- concentration_pattern: "EU mass retail often 40-60% of revenue. US declining; Middle East growing as offset."
- typical_payment_terms: OA 60–90 days (EU mass retail); OA 30-60 days (US mass retail); sometimes LC for Middle East first orders

---

## Assessment Dimensions

- dim: us_eu_revenue_mix_and_trajectory
  why: "US-bound CN lighting = double compression risk; trajectory matters as much as current mix — buyers may be re-certifying alternatives"
  r1_question: "What is your revenue split — US%, EU%, Middle East%? Has the US share changed in the past 2 years?"
  r2_deep: "Have any US buyers mentioned re-sourcing from Vietnam or India? Are you aware of any US buyer re-certification projects at alternative origins?"
  collect: "Revenue breakdown by market (24-month trend); any buyer communication about origin shift"
  signal_impact: "EU% >60%: EXPAND on CE-certified EU book. US% >35% AND re-cert signals from buyers: CAUTION — finite tenure. US% >35% AND no re-cert signal: CONDITIONAL on tariff severity."

- dim: copper_bom_exposure
  why: "copper BOM% varies significantly by product type (simple lamp 2-5%, smart LED 4-6%, chandelier 8-10%); must confirm actual product mix before quantifying T1 tariff impact"
  r1_question: "What product types make up your range — simple table lamps, smart LED fixtures, chandeliers? What is the breakdown of your revenue by product type?"
  r2_deep: "For each product type, what is the approximate split of material costs — housing, glass/shade, electrical (driver, wire, socket)? Have driver/wiring costs increased in the past 6 months?"
  collect: "BOM breakdown for 2-3 representative SKUs across product types; recent electrical component purchase records"
  signal_impact: "Simple lamp range (2-5% copper): T1 tariff impact minor (1-2% margin compression). Smart LED (4-6%): moderate impact. Chandelier-heavy (8-10%): meaningful impact. Any exposure >10%: escalate to CAUTION and verify."

- dim: certification_portfolio_status
  why: "CE/UL count and currency determines market access and buyer stickiness; lapsed or limited certifications = risk"
  r1_question: "How many CE-marked SKUs and UL-listed SKUs do you have? When were they last updated?"
  r2_deep: "How many new SKUs are introduced per year? What is the certification budget for new SKUs? Any lapsed certifications?"
  collect: "CE certificate list + issue dates; UL listing numbers; certification lab relationship"
  signal_impact: "Large active certification portfolio: HIGH buyer stickiness; support EXPAND. Small or ageing portfolio: buyer relationship at risk; CAUTION on long-term expansion."

- dim: smart_lighting_exposure
  why: "smart lighting = additional FCC/IC/radio certification + higher compliance cost; also higher margin and stickiness if certified"
  r1_question: "Do you produce smart lighting (WiFi/Bluetooth/Zigbee controllable)? What % of revenue?"
  r2_deep: "What radio certifications do you hold — FCC, IC (Canada), CE RED (EU)? What is your certification cost per smart SKU?"
  collect: "FCC/IC/CE RED certificate list; smart product revenue breakdown"
  signal_impact: "Smart lighting >20% revenue with full certs: EXPAND (higher margin + high stickiness). Smart products without required radio certs: COMPLIANCE FLAG; resolve before ARP."

- dim: seasonal_order_book_position
  why: "60-70% of annual volume in Q3-Q4; pre-season financing gap is 6-10 months; must confirm where in cycle"
  r1_question: "Have you confirmed your Q3-Q4 2026 programs already? What is your capacity utilization for Q3-Q4?"
  r2_deep: "When did buyers place orders for this Q4 season? What is the expected shipment window?"
  collect: "Q4 program PO schedule; capacity plan"
  signal_impact: "Q4 programs confirmed: EXPAND ARP on confirmed invoice pool. Still in booking window: assess new program potential."

---

## Signal Flip Conditions
- IF buyer_geo = EU AND CE_certs_active = true AND us_revenue < 30% → signal = EXPAND
- IF buyer_geo = US AND Section_301_tariff_active AND buyer_recert_signal_detected = true → signal = CAUTION; discuss finite tenure with factory
- IF copper_bom_pct > 20% AND T1_tariff_active → flag margin compression; review advance ratio
- IF smart_lighting_pct > 20% AND missing_radio_certs = true → COMPLIANCE FLAG; suspend until resolved
- IF Q4_orders_confirmed AND seasonal_booking_open = false → EXPAND on confirmed book only; no new capacity speculation

---

## Pain Hooks
- [PP-001-cashflow-gap] primary — 6-10 month seasonal cash cycle; pre-season production requires large WC
- [PP-003-buyer-concentration] watch — EU mass retail concentration common
- [PP-HG-002-tariff-double-compress] primary — copper input + Section 301 for US-bound (PENDING EXPERT REVIEW: Josephine)
- [PP-HG-007-certification-barrier] structural — CE/UL per SKU; blocks rapid origin shift in both directions (PENDING EXPERT REVIEW: Josephine)
- [PP-HG-008-smart-compliance] medium — FCC/IC/CE RED per smart SKU; cost barrier for new SKUs (PENDING EXPERT REVIEW: Josephine)

---

## Product Links

- product_ref: PROD-ARP | rank: primary | weight: 0.88
  condition: "CE/UL certified SKU pool confirmed; EU buyer OA invoices; Q4 programs in hand"
  unique_value: "Bridges 6-10 month seasonal cash cycle; buyer intelligence on EU mass retail payment track record"
- product_ref: PROD-PRESHIP-OBF | rank: secondary | weight: 0.70
  condition: "Q4 programs confirmed; factory needs driver/component procurement before production starts; supply chain disruption risk"
  unique_value: "Pre-season component procurement (copper drivers, wire harnesses); bridges booking confirmation to production start"
- product_ref: PROD-SMARTWALLET | rank: tertiary | weight: 0.55
  condition: "If 5+ EU buyer pairs with recurring seasonal programs and smart lighting growing"
  unique_value: "Seasonal buyer pipeline forecasting; Q4 order tracking across EU mass retail accounts"

## LLM Directives
- copper_driver_price_trend: "Current pricing trend for LED drivers and copper wire harnesses sourced in China — what is the typical copper content in a standard LED driver (watt range 10-60W)? How has driver pricing changed in Q1-Q2 2026 vs 2025?"
- section_301_cn_lighting: "Current Section 301 tariff rate for CN decorative lighting (HS 9405) destined for US market. Effective rate including MFN duty. Any product exclusions or rulings applicable to LED decorative fixtures?"
- vietnam_lighting_certification: "Is Vietnam a viable alternative origin for CE/UL-certified decorative lighting at scale? What is the realistic timeline for a VN factory to obtain CE (EMC+LVD) and UL listing for standard decorative lighting SKUs? Which labs are active in VN for lighting certification?"
- eu_lighting_demand: "EU decorative lighting market demand in 2026 — any major buyer sourcing strategy shifts? IKEA, Leroy Merlin, Eglo procurement posture on CN origin for 2026-2027?"

---

## Air8 Risk Parameters (Internal)
- air8_signal: CONDITIONAL — verify buyer market mix + certification status + seasonal order position
- advance_ratio_normal: 85%
- advance_ratio_alert: 75%
- review_frequency: semi-annual (pre-season Feb; post-Q4 booking Sep)
- trigger_for_reduction: US buyer PO decline >15% YoY; buyer re-cert signal at alternative origin; smart cert compliance gap

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- domain: hardgoods/geo-swot.md#China hardgoods/wip-categories.md#Seasonal
- products: PROD-ARP.md PROD-PRESHIP-OBF.md PROD-SMARTWALLET.md
- compare_with: COMBO-HG-002-china-brass-artware.md (same country, different tariff exposure)
- L0_principles: event-principles.md risk-principles.md
- edges: _links/cross-module-edges.md
