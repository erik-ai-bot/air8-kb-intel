# COMBO-HG-001: China Outdoor Furniture (Mid, FOB)

> extends: FullPackage-MidMargin archetype | New: Hardgoods domain v1
> Created: 2026-07-15 | Freshness: annual
> country_ref: _country/CN.md | domain_ref: hardgoods/geo-swot.md
> Expert review: Josephine Cheung — COMPLETED 2026-07-16. Corrections applied.

---

## Identity
- id: COMBO-HG-001
- archetype: FullPackage-MidMargin
- country: CN
- revenue_band: mid $10–30M
- product_type: outdoor furniture (garden sets, patio chairs, dining sets, sun loungers)
- materials: aluminum (primary), steel, HDPE/PP plastic, teak/eucalyptus (EU-compliant sourcing)
- company_type: FOB
- buyer_geo: EU (dominant, growing), US (declining — tariffs), Australia/Middle East (growing)
- cash_cycle_days: 90–150 days (long lead time; extreme seasonal concentration)
- tags: country:CN, product:outdoor-furniture, material:aluminum, material:steel, buyer_geo:EU, buyer_geo:US, scenario:S1, scenario:S2, domain:hardgoods

---

## Structural Nuances
*(Built from hardgoods geo-swot.md + Event E7 signals + L0 event principles)*

- "Outdoor furniture is a once-per-year purchase cycle for most EU/US/AU buyers. **EU/US order placement window: Jun–Aug**, with delivery Nov–Feb the following year (6-12 months lead time). **AU order placement: Jan–Mar**, delivery Jul–Aug. Missing the buying window = no recovery for that season. This is the most extreme seasonal lock-in pattern across all hardgoods categories. [VERIFIED — Josephine Cheung 2026-07-16]"
- "A +20% order lift signal (Event E7) for CN outdoor furniture must be READ WITH CAUTION — if the surge coincides with an aluminum or steel tariff event (materials-cost compression elsewhere), the order increase may be buyers pulling forward volumes to lock pre-tariff FOB prices, not organic demand growth. Check correlation against any active commodity tariff events before calling it a demand boom."
- "CN outdoor furniture faces US Section 301 tariffs of 25%+ plus any anti-dumping duties on aluminum extrusions — US-bound outdoor furniture is structurally challenged; EU and Australia/Middle East are the viable expansion markets. Any factory with >30% US revenue is financing a shrinking book."
- "Aluminum is the primary material; BOM share varies significantly by product type: deep-seating lounge sets and sofa sets 40–50% (foam + cushions reduce aluminum's share); dining sets 70–80% (key structure is the aluminum frame). Aluminum price volatility directly hits BOM cost with no buffer. Factories that do NOT hedge aluminum input pricing absorb full commodity risk — pre-season ARP helps lock production cost before aluminum moves. [VERIFIED — Josephine Cheung 2026-07-16]"
- "Wood components (teak, eucalyptus, acacia) in EU-bound outdoor furniture require EUTR (EU Timber Regulation) compliance documentation. FSC certification is NOT a legal regulatory requirement — it is retailer-driven; major EU retailers have varying requirements. Without FSC, access to premium EU retail programs is limited but not legally blocked. [VERIFIED — Josephine Cheung 2026-07-16]"
- "CARB formaldehyde Phase 2 compliance is REQUIRED for any composite wood (MDF, plywood components in sets) destined for the US market — apply even to non-wood-primary sets if packaging or subcomponents contain composite wood."
- "Cash cycle is uniquely extended for outdoor furniture. EU/US cycle: order placement Jun–Aug → material procurement Jul–Sep → production Aug–Nov → shipment Nov–Feb → buyer receipt Feb–Mar → OA 60–90 days payment → cash receipt Apr–Jun. **Total operating cycle: 12–13 months from order placement to final invoice payment.** AU cycle: order Jan–Mar, delivery Jul–Aug, similar total duration. [VERIFIED — Josephine Cheung 2026-07-16]"
- "⚠️ If Event E7 (+20% outdoor order lift) is active in active_event_cache AND a copper/aluminum commodity tariff event is also active: E7 signal REFRAMES from EXPAND to CONDITIONAL — confirm with factory whether the order lift is organic EU demand growth or buyer pre-tariff pull-forward. Pull-forward = orders concentrated especially for hot items, then collapse post-tariff. Do NOT expand credit on pull-forward signals. [VERIFIED — Josephine Cheung 2026-07-16]"
- "⚠️ Pre-shipment finance for outdoor furniture is HIGH RISK due to the very long operating cycle (12–13 months) and elevated order qty reduction / cancellation risk. Post-shipment finance (ARP on confirmed invoices) is significantly safer and preferred for this COMBO. [VERIFIED — Josephine Cheung 2026-07-16]"
- "⚠️ CN outdoor furniture is facing structural volume downsize on US exposure (Section 301 + AD duties). EU, AU, and ME markets are viable alternatives but may NOT fully recover the volume lost from US de-sourcing — CN suppliers should be assessed on declining book trajectory, not assumed full substitution. [VERIFIED — Josephine Cheung 2026-07-16]"
- "⚠️ Seasonal lock-in principle applies: once the buying window (EU/US: Jun–Aug; AU: Jan–Mar) has closed and orders are confirmed, any new event signal during production season does NOT change the annual revenue base — it affects forthcoming orders only. Air8 ARP decisions in-season should be based on confirmed PO book, not event signals. [VERIFIED — Josephine Cheung 2026-07-16]"

---

## Buyer Edges
- sells_to: [buyer_type: EUMassRetail, weight: 0.80] — IKEA (indirect via sourcing agents), Leroy Merlin, OBI, B&Q; standard designs, high volume
- sells_to: [buyer_type: EUPremiumGarden, weight: 0.50] — Garden Trading, Fermob (CN supplements); better margin, lower volume
- sells_to: [buyer_type: AURetail, weight: 0.40] — Bunnings, Harvey Norman; growing for CN outdoor
- sells_to: [buyer_type: USMassMarket, weight: 0.20] — structurally declining; tariff-impacted
- concentration_pattern: "Single buyer often 40–60% of revenue (IKEA or equivalent) — high concentration risk. Often sourced via IKEA IWAY-certified agent, not direct."
- typical_payment_terms: OA 60–90 days (EU mass retail); L/C sometimes for first orders

---

## Assessment Dimensions

- dim: seasonal_order_book_status
  why: "most critical variable — all decisions contingent on whether annual orders are confirmed or pending; event signals are backward-looking if booking window is closed"
  r1_question: "Have you confirmed your 2026 orders already? EU/US booking window is Jun–Aug; AU is Jan–Mar."
  r2_deep: "What % of your annual revenue is already covered by confirmed POs? Do you have any remaining capacity for new buyers this season?"
  collect: "Confirmed PO schedule for current season; capacity utilization"
  signal_impact: "Orders confirmed + full capacity: EXPAND ARP on confirmed book. Open capacity: check if new orders realistic or buyer pull-forward risk."

- dim: us_vs_eu_revenue_mix
  why: "US-heavy = financing a declining book; EU-heavy = viable expansion"
  r1_question: "What is your buyer market split — US%, EU%, Australia%, Other%?"
  r2_deep: "Is the US share declining YoY? Which EU buyers are growing?"
  collect: "Revenue breakdown by buyer geography (last 12 months)"
  signal_impact: "EU% >60%: EXPAND. US% >35%: CAUTION — tariff headwind; review US buyer stability."

- dim: aluminum_price_risk_management
  why: "aluminum BOM varies by product type (lounge/sofa 40-50% due to foam+cushions; dining sets 70-80% as frame is the key structure). Dining-heavy factories = highest aluminum price sensitivity = tightest pre-purchase window"
  r1_question: "What is your main product mix — dining sets, lounge/sofa sets, or mixed? Do you have forward contracts for aluminum, or spot market?"
  r2_deep: "For your primary product type, what % of BOM is aluminum? When did you lock material pricing for this season? Has price moved since then?"
  collect: "Product revenue breakdown by type; aluminum procurement contracts or spot purchase records"
  signal_impact: "Dining-heavy (70-80% aluminum BOM) + spot purchasing: CAUTION on margin; PRESHIP-OBF window for aluminum pre-buy is tightest — must be done before EU/US booking window closes (Jun-Aug). Lounge-heavy (40-50%): moderate aluminum exposure; less urgent pre-buy. Forward contracts confirmed: EXPAND (margin protected)."

- dim: us_compliance_exposure
  why: "Section 301 + anti-dumping on aluminum extrusions = variable tariff rate; need to confirm factory's tariff classification and whether US orders are legally viable"
  r1_question: "For your US orders, what is the current tariff rate you're paying at the border?"
  r2_deep: "Do you have an HS code ruling for your products? Are you affected by anti-dumping duties on aluminum extrusions?"
  collect: "US customs documentation; HS code ruling if available"
  signal_impact: "AD duty confirmed: DO_NOT_EXPAND US-facing facilities. Section 301 only (25%): CAUTION, depends on price positioning."

- dim: vn_diversification_plan
  why: "CN outdoor suppliers are on a predictable seasonal step-down as buyers systematically raise VN allocation each year (90/10 → 80/20 → 70/30). The supplier's VN strategy is the single most important determinant of long-term Air8 risk profile — not current order volume."
  r1_question: "Are you currently qualifying any buyers in Vietnam or other alternative origins? Do any of your buyers source from both you (China) and Vietnam?"
  r2_deep: "Which specific buyers are raising their VN allocation? What % of your revenue do they represent? Do you have or are you establishing any VN production capacity?"
  collect: "Buyer allocation history last 3 seasons; any VN entity setup or sourcing agent relationships"
  signal_impact:
    CN-only + concentrated buyers (>50% single buyer) + no VN plan: HIGH RISK — predictable decline curve; Season 3-4 volume may breach break-even. Do NOT expand; flag for enhanced monitoring.
    CN-only + diversified buyers + no VN plan: MEDIUM RISK — track VN allocation trend; CONDITIONAL EXPAND on confirmed current-season book only.
    CN + VN dual-source (own VN capacity or agent): LOW RISK — aligned with buyer diversification strategy; stable; EXPAND on confirmed EU book.

- dim: fsc_and_timber_compliance
  why: "EU Timber Regulation and buyer FSC requirements — without FSC supplier chain, EU premium programs inaccessible"
  r1_question: "Do you have FSC Chain of Custody certification? What wood species and sources do you use?"
  r2_deep: "For EU orders with wood components: do buyers require FSC certification? Are you EUTR compliant with due diligence documentation?"
  collect: "FSC certificate; wood supplier documentation; EUTR due diligence records"
  signal_impact: "FSC certified + EUTR compliant: EXPAND on EU premium programs. No FSC: limit to mass retail IKEA-type programs only."

---

## Signal Flip Conditions

**Tier-based signal — assess VN plan first, then apply:**

| Supplier Profile | Signal | Air8 Action |
|---|---|---|
| CN only + buyer concentration >50% + no VN plan | HIGH RISK — structural decline | Monitor only; reduce advance ratio; no expansion |
| CN only + diversified buyers + no VN plan | CONDITIONAL | ARP on confirmed current-season book only; no multi-year |
| CN + VN dual-source | EXPAND | ARP on EU confirmed book; standard advance ratio |

**Additional flip conditions:**
- IF eu_revenue_pct > 60% AND seasonal_orders_confirmed = true AND dual-source → EXPAND (ARP)
- IF us_revenue_pct > 35% → CAUTION regardless of tier; tariff headwind on US book
- IF E7 order_lift AND aluminum/tariff event in active_event_cache → REFRAME: verify pull-forward before EXPAND
- IF seasonal_booking_window_open (EU/US: Jun–Aug; AU: Jan–Mar) AND spare capacity → opportunity to fill; tier still applies
- IF post-booking-window AND new order inquiry → affects forthcoming season only; assess next-season outlook
- IF dining-heavy product mix AND aluminum spot-only purchasing AND booking window open → PRESHIP-OBF for aluminum pre-buy; time-sensitive before Jun-Aug window closes

---

## Pain Hooks
- [PP-001-cashflow-gap] primary — 6-9 month cash cycle from order to cash receipt
- [PP-003-buyer-concentration] watch — IKEA or single-buyer concentration common
- [PP-HG-006-seasonal-lockin] primary — extreme annual purchase cycle; once-per-year order window (PENDING EXPERT REVIEW: Josephine — pain point ID to be formalized)
- [PP-HG-007-tariff-us-exposure] — Section 301 + AD duty on US-bound outdoor furniture

---

## Product Links

- product_ref: PROD-ARP | rank: primary | weight: 0.90
  condition: "Confirmed PO book in hand; EU buyer relationships verified; ARP on invoice pool"
  unique_value: "Bridges 6-9 month cash cycle gap; buyer intelligence on IKEA/mass retail payment track record"
- product_ref: PROD-PRESHIP-OBF | rank: secondary | weight: 0.75
  condition: "Factory in seasonal booking window (EU/US: Jun–Aug; AU: Jan–Mar); needs aluminum/steel pre-purchase before order confirmation; verified buyer relationship. NOTE: pre-shipment finance carries HIGH cancellation risk for outdoor furniture given 12-13 month cycle — use only with confirmed buyer relationship and verified order intent."
  unique_value: "Enables material lock-in before price moves; pre-season financing window matches buyer booking cycle"
- product_ref: PROD-SMARTWALLET | rank: tertiary | weight: 0.50
  condition: "If 3+ active EU buyers with seasonal recurring programs"
  unique_value: "Seasonal order pipeline forecasting; IKEA payment monitoring"

## LLM Directives
- aluminum_price_outlook: "Current aluminum price trend and Q3 2026 forward curve — relevant to pre-season material procurement decisions and margin compression risk for CN outdoor furniture."
- eu_outdoor_furniture_demand: "EU outdoor furniture market demand trend for 2026 season — is Event E7 (+20% CN outdoor orders) confirmed as organic demand growth or buyer pull-forward ahead of tariff implementation? Check EU retail channel sell-through data."
- us_tariff_outdoor_furniture: "Current US tariff status for CN outdoor furniture: Section 301 rate for aluminum patio furniture (HS 9403.51, 9403.59) + any anti-dumping duties on aluminum extrusions applicable to furniture components. Current effective rate?"
- vietnam_outdoor_alternative: "Is Vietnam a viable alternative origin for EU/AU-bound outdoor furniture at scale? Lead time comparison with CN? Compliance gap (FSC, EUTR)?"

---

## Air8 Risk Parameters (Internal)
- air8_signal: CONDITIONAL — verify buyer mix + seasonal order confirmation
- advance_ratio_normal: 85%
- advance_ratio_alert: 75%
- review_frequency: semi-annual (pre-season Feb; mid-season Jun)
- trigger_for_reduction: US buyer PO decline >15% YoY; aluminum price move >20% mid-season

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- domain: hardgoods/geo-swot.md#China hardgoods/wip-categories.md#Metal
- products: PROD-ARP.md PROD-PRESHIP-OBF.md
- pain_points: PP-001-cashflow-gap.md PP-003-buyer-concentration.md
- L0_principles: event-principles.md risk-principles.md#RP-RISK-COUNTRY-01
- edges: _links/cross-module-edges.md
