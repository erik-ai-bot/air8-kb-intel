# COMBO-HG-002: China Brass/Metal Artware (Small-Mid, FOB)

> extends: FullPackage-LowMargin archetype | New: Hardgoods domain v1
> Created: 2026-07-15 | Freshness: annual
> country_ref: _country/CN.md | domain_ref: hardgoods/geo-swot.md
> Expert review: Josephine Cheung — COMPLETED 2026-07-16. Corrections applied.

---

## Identity
- id: COMBO-HG-002
- archetype: FullPackage-LowMargin
- country: CN
- revenue_band: small–mid $5–20M
- product_type: metal artware (brass decorative items, picture frames, candle holders, figurines, decorative hardware)
- materials: true brass (copper 60–70%), zamak (zinc alloy, copper-free), mixed; plated/lacquered finishes
- company_type: FOB
- buyer_geo: EU (dominant), US (tariff-impacted), Middle East (growing premium)
- cash_cycle_days: 60–120 days
- tags: country:CN, product:metal-artware, material:brass, material:copper, material:zamak, buyer_geo:EU, buyer_geo:US, scenario:S1, scenario:S2, domain:hardgoods

---

## Structural Nuances
*(Built from hardgoods geo-swot.md + Event T1 copper tariff + Event S1 signals + L0 event principles)*

- "TRUE BRASS = approximately 60–70% copper by weight, though the exact copper content varies by product structural requirements. Any copper tariff event (T1-type) hits these factories' input cost directly — no lag, no pass-through delay. BOM copper exposure must be confirmed via alloy certificate before applying any copper-event signal. [VERIFIED — Josephine Cheung 2026-07-16]"
- "ZAMAK (zinc alloy, typically Zamak-3 or Zamak-5) = near-zero copper content (<1%). A factory producing zamak artware is NOT exposed to copper tariff events on the input side — misidentifying zamak as brass is a critical error. Always ask about specific alloy in production. Other common substitute materials to be aware of: cast iron, aluminum alloys (risk: rusting and weight issues), polyresin/plastics with cold-cast brass powder, and Albright/Yellow Lead metal (HIGH RISK — lead-based, likely to violate environmental regulations; flag for compliance review if encountered). [VERIFIED — Josephine Cheung 2026-07-16]"
- "Double compression for US-bound true brass artware: (1) T1-type copper tariff increases input cost; (2) Section 301 25%+ on finished CN metal artware at the US border. The combined effect = both buying and selling at a structural disadvantage vs India Moradabad and other origins. This is a DO_NOT_EXPAND signal for US-facing true brass factories."
- "India Moradabad is the structural competitive threat: domestic copper (Hindalco, Vedanta) + artisan labor + lower overhead = Moradabad brass artware is cost-competitive even without tariff events; with T1 copper tariff adding to CN cost, the gap widens. CN brass advantage is retained only on: machine-produced complexity, fast turnaround, and mass-volume orders."
- "REACH/RoHS compliance: the primary regulated substances in CN metal artware are **Lead, Cadmium, Cr6 (hexavalent chromium), and phthalates** — found in plating, surface coatings, lacquers, and dyes. EU buyers require REACH SVHC declaration per SKU + test reports per batch. Factories without in-house REACH testing workflow → elevated QC risk for Air8. [VERIFIED — Josephine Cheung 2026-07-16]"
- "Surface treatment approval (plating thickness, coating adhesion) is the highest WIP risk gate for metal artware — adhesion failures are discovered at QC stage, after full production cost is sunk. A factory with no formal surface treatment approval process = higher advance ratio risk."
- "CN metal artware factories are pivoting US-bound programs to EU and Middle East to escape Section 301 — EU mass retail (TK Maxx, Maisons du Monde, JYSK) is growing alternative; Middle East premium channels (UAE luxury retail) are absorbing premium brass."
- "⚠️ If T1 copper tariff event is active AND factory produces TRUE BRASS for US market: signal = CRITICAL CAUTION (double compression); recommend immediate buyer mix audit — what % of confirmed orders are US-bound vs EU/ME? US-bound true brass = financing at-risk revenue. EU-bound true brass = standard ARP viable." (source: Event T1 + S1 copper signals, freshness: annual, PENDING EXPERT REVIEW: Josephine)
- "⚠️ MATERIAL VERIFICATION IS MANDATORY before any hardgoods metal artware ARP is issued: 'brass' in catalogue does not mean true brass (60-70% copper). Material substitution is common — factory may use zamak, cast iron, aluminum alloys, polyresin with cold-cast brass powder, or (HIGH RISK) Albright/Yellow Lead metal. Confirm alloy spec with factory — request material test certificate or alloy declaration. Albright/Yellow Lead metal = do not finance; environmental regulatory violation risk. [VERIFIED — Josephine Cheung 2026-07-16]"

---

## Buyer Edges
- sells_to: [buyer_type: EUMassHomeDécor, weight: 0.75] — TK Maxx, Maisons du Monde, JYSK, Flying Tiger; standard brass-look items
- sells_to: [buyer_type: USMassRetail, weight: 0.40] — declining; Section 301 tariff headwind; previously Target, HomeGoods
- sells_to: [buyer_type: MiddleEastPremium, weight: 0.35] — UAE luxury retail, Saudi home décor; growing channel for brass premium
- sells_to: [buyer_type: EUSpecialty, weight: 0.30] — independent gift/homewares retailers; seasonal programs
- concentration_pattern: "Multiple mid-size buyers; no single buyer typically >30%. EU mass retail growing as US declines."
- typical_payment_terms: OA 60–90 days (EU); L/C 30–60 days (Middle East, first orders)

---

## Assessment Dimensions

- dim: material_composition_verification
  why: "MOST CRITICAL — true brass vs zamak = completely different copper tariff exposure; cannot use any event signal without confirming actual alloy"
  r1_question: "What alloys do you use in production — true brass (copper/zinc), zamak, or mixed?"
  r2_deep: "For your brass products: what is the copper content percentage? Do you have alloy test certificates? What are your main alloy suppliers?"
  collect: "Alloy material specifications; test certificates or supplier mill certs"
  signal_impact: "True brass confirmed: apply copper tariff exposure model. Zamak confirmed: copper tariff NOT applicable; reassess event signal entirely."

- dim: us_vs_eu_order_mix
  why: "US-bound true brass = double compression risk (copper input + Section 301 output); EU-bound = avoid output tariff but input tariff still hits"
  r1_question: "What is your revenue split by market — US%, EU%, Middle East%, Other%?"
  r2_deep: "Is the US share growing, flat, or declining? Are you actively shifting programs from US to EU/ME?"
  collect: "Revenue breakdown by buyer geography (last 12 months); current order book US vs EU split"
  signal_impact: "US% >40% + true brass: DO_NOT_EXPAND. EU% >60% + true brass: CAUTION (input cost rise only). Zamak: CONDITIONAL — no copper exposure."

- dim: reach_compliance_workflow
  why: "lead/cadmium failure in plating = EU customs detention or buyer rejection; must confirm factory has test workflow"
  r1_question: "Which compliance tests do you run for EU/US buyers — REACH, RoHS, lead/cadmium? Who certifies?"
  r2_deep: "Do you test per batch or per SKU? Which lab do you use? Has any batch been rejected in the past 12 months for REACH failure?"
  collect: "REACH/RoHS test reports; lab certificates"
  signal_impact: "In-house test workflow + no recent failures: standard advance ratio. No test documentation or recent failure: lower advance ratio; increased monitoring."

- dim: surface_treatment_process
  why: "adhesion failure at QC stage = 100% rejection post-production; assess WIP risk"
  r1_question: "What surface treatments do you apply — electroplating, lacquering, powder coating? Is the approval process in-house?"
  r2_deep: "Do you have a formal surface treatment approval (PP sample + adhesion test) before mass production? Who signs off?"
  collect: "PP sample approval records; surface treatment process documentation"
  signal_impact: "Formal PP approval + adhesion testing: standard risk. No formal process: increase monitoring; consider lower advance ratio."

- dim: india_competitive_pressure
  why: "Moradabad is structural threat on true brass; need to know factory's competitive positioning vs Indian origin"
  r1_question: "Are your EU/US buyers also sourcing from India Moradabad? Have any buyers shifted volume from you to India in the past 12 months?"
  r2_deep: "What is your unique advantage vs Moradabad (machine volume, turnaround time, design complexity)? What product types can India NOT replicate at your price?"
  collect: "Buyer sourcing mix context; product comparison vs India"
  signal_impact: "Factory has differentiated positioning vs India (machine complexity, MOQ, speed): CONDITIONAL EXPAND. No differentiation: CAUTION on true brass programs."

---

## Signal Flip Conditions
- IF material = zamak AND buyer_geo = EU → signal = EXPAND (no copper tariff exposure; EU demand viable)
- IF material = true_brass AND buyer_geo = US → signal = DO_NOT_EXPAND (double compression: copper input + Section 301)
- IF material = true_brass AND buyer_geo = EU → signal = CAUTION (copper input cost rise; EU border clear but margin compressed)
- IF reach_compliance_failure_recent = true → flag CRITICAL QC; suspend expansion until next clean batch report
- IF material_verification = unconfirmed → suspend all event signals; verify material first

---

## Pain Hooks
- [PP-001-cashflow-gap] primary — OA 60-90 days; long production cycle
- [PP-003-buyer-concentration] watch — EU mass retail concentration risk
- [PP-HG-002-tariff-double-compress] primary — copper input + Section 301 on true brass to US (PENDING EXPERT REVIEW: Josephine — pain point ID to be formalized)
- [PP-HG-005-reach-compliance] medium — lead/cadmium in plating; per-batch testing burden

---

## Product Links

- product_ref: PROD-ARP | rank: primary | weight: 0.85
  condition: "EU buyer programs confirmed; material verified as zamak OR true brass EU-only; REACH compliance clean"
  unique_value: "Bridge 60-90 day EU mass retail payment cycle; buyer intelligence on EU mass retail payment track record"
- product_ref: PROD-PRESHIP-OBF | rank: secondary | weight: 0.60
  condition: "True brass factory with confirmed EU orders; copper pre-purchase needed before price moves further"
  unique_value: "Lock copper input price before tariff-driven commodity move; pre-production financing on confirmed EU PO"

## LLM Directives
- copper_price_trend: "Current copper spot price and 6-month forward curve — what is the BOM cost impact for a true brass factory producing at 60% copper content? Compare with Jan 2026 baseline."
- section_301_cn_metal_artware: "Current Section 301 tariff rate for CN decorative metal artware (HS 8306, 8307 range) destined for US market. Any exclusions or product-specific rulings? Effective rate including any stacking with base MFN duty."
- moradabad_competitive_status: "Current cost comparison for true brass artware: CN (Guangdong/Zhejiang producers) vs India Moradabad. Factor in: raw material (copper price + tariff), labor, logistics to EU. Which product types has India gained share in recently?"
- eu_brass_artware_demand: "EU market demand for metal/brass decorative artware in 2026 — growing, stable, or declining? Key buyers (Maisons du Monde, JYSK, TK Maxx) sourcing strategy changes?"

---

## Air8 Risk Parameters (Internal)
- air8_signal: CONDITIONAL — material verification required before any signal applied
- advance_ratio_normal: 82%
- advance_ratio_alert: 72%
- review_frequency: quarterly
- trigger_for_reduction: copper price rise >15% since factory's material procurement date; any REACH failure

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- domain: hardgoods/geo-swot.md#Metal hardgoods/wip-categories.md#Metal
- products: PROD-ARP.md PROD-PRESHIP-OBF.md
- compare_with: COMBO-HG-003-india-moradabad-brass-artware.md (structural competitive read)
- L0_principles: event-principles.md risk-principles.md
- edges: _links/cross-module-edges.md
