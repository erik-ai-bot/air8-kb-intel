---
type: persona
id: COMBO-004
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Receivables gap on OA terms"
  - id: PP-002
    severity: HIGH
    context: "Sinosure and local bank financing burden"
  - id: PP-CN-001
    severity: HIGH
    context: "SAFE cross-border complexity limits capital"
  - id: PP-CN-002
    severity: MEDIUM
    context: "Sinosure declaration burden on exporters"
  - id: PP-CN-003
    severity: MEDIUM
    context: "Hengqin portfolio capacity constraints"
---

# COMBO-004: China Medium Woven Exporter

## Dimensions
- Country: [[dimensions/DIM-1-country]] (CN)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($20-50M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB)
- Product: [[dimensions/DIM-4-product-focus]] (woven | denim)
- Market: [[dimensions/DIM-5-target-market]] (US+EU)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_LC + domestic_factoring)
- Growth: [[dimensions/DIM-8-growth-stage]] (stable)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/country/PP-CN-001-safe-complexity]]
- [[../../layer-1-reasoning/pain-points/country/PP-CN-002-sinosure-burden]]
- [[../../layer-1-reasoning/pain-points/country/PP-CN-003-hengqin-capacity]]

## Products
- [[../financing-products/PROD-ARP]] (via Hengqin entity)
- [[../financing-products/PROD-SMARTWALLET]]
- [[../financing-products/PROD-POOL]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (high for CN cotton)
- [[../regulations/REG-REACH]]
- [[../regulations/REG-CSDDD]]
- [[compliance/COMP-SAFE]]

## Data Entities
- [[compliance/COMP-SINOSURE]] (declaration_status)
- hengqin.portfolio_capacity
- safe.entity_registration

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: eu_vs_us_revenue_mix
  why: "this SINGLE variable determines EXPAND vs DO_NOT_EXPAND for any trade/tariff event"
  r1_question: "What is your current buyer market split — US%, EU%, Asia%?"
  r2_deep: "Has the US share been declining? Which EU buyers are growing? Any Japan or Middle East programs?"
  collect: "Sales breakdown by buyer geography (last 12 months)"
  signal_impact: "EU% >50%: EXPAND for most events. US% >40%: DO_NOT_EXPAND for sourcing/tariff events."

- dim: keqiao_fabric_network_depth
  why: "forward contracts with Keqiao mills = can lock lower fabric prices; spot-market-only = partial benefit only"
  r1_question: "Do you source fabric from Keqiao/Shaoxing mills, or import from elsewhere?"
  r2_deep: "Do you have forward contracts with specific Keqiao mills, or buy on spot market? What's your typical fabric lead time?"
  collect: "Fabric supply contracts or purchase order history (last 6 months)"
  signal_impact: "Forward contracts: EXPAND signal with higher confidence. Spot-market-only: downgrade signal confidence."

- dim: xinjiang_cotton_exposure
  why: "UFLPA critical — any XJ cotton in US/EU-bound production is a compliance violation risk"
  r1_question: "Do you have any Xinjiang cotton exposure in your supply chain? How is traceability managed?"
  r2_deep: "For US/EU-destined orders: can you trace cotton origin to field level? What documentation do buyers require?"
  collect: "Supply chain traceability documentation; Keqiao mill cotton origin records"
  signal_impact: "Any XJ exposure + US/EU orders: CRITICAL flag; Tier 1 compliance override; suspend expansion"

- dim: product_complexity_level
  why: "complex prints/DTC co-dev = irreplaceable; commodity basics = replaceable by India/BD"
  r1_question: "What product types do you produce — basic T-shirts, complex prints, activewear, fashion-forward designs?"
  r2_deep: "Do you do design co-development with any buyers? What is your minimum order quantity?"
  collect: "Product portfolio sample; key buyer collaboration examples"
  signal_impact: "High complexity: EXPAND (irreplaceable). Commodity basics: CAUTION (India/BD threat growing)"

- dim: buyer_relationship_type
  why: "direct brand relationship = higher stickiness; via sourcing agent = lower stickiness and margin compression"
  r1_question: "Do you work directly with brands like Zara/H&M, or through buying agents?"
  r2_deep: "For your top 3 buyers: direct or agent-intermediated? What % of revenue is direct?"
  collect: "Order confirmation documentation showing buyer vs agent relationship"
  signal_impact: "Direct relationship: higher stickiness, more confident EXPAND. Agent-only: lower stickiness, add CAUTION"

---

## Signal Flip Conditions
- IF eu_revenue_pct > 50% → signal = EXPAND for most events (EU buyers not de-sourcing from CN; Keqiao speed holds)
- IF us_revenue_pct > 40% → signal = DO_NOT_EXPAND for any buyer_sourcing_strategy event (financing a shrinking book)
- IF xinjiang_cotton_detected AND order_destination = US or EU → flag CRITICAL; require immediate compliance action
- IF keqiao_network = spot_market_only → downgrade confidence on commodity event benefit signal (can't lock forward prices)

---

## Structural Nuances
*(Enhanced from Section 9 Layer 2+4+5+6+7 and COMBO-004-ENH)*

- "CN factories buy fabric from Keqiao mills (Shaoxing, Zhejiang) — they do NOT buy cotton directly; any cotton price event benefits arrive via Keqiao mill input cost reduction, with a 90–180 day lag and partial pass-through"
- "Keqiao fabric market (world's largest) is a structural sourcing advantage unique to CN — proximity enables 5–7 day fabric prototype turnaround and 2–3 week EU order fulfillment vs 4+ weeks from other Asian origins"
- "CN share of US apparel imports has declined structurally (33% in 2017 → ~21% 2025) driven by tariffs and geopolitics — this trend continues regardless of individual events; US-heavy CN factories are financing a shrinking book"
- "US tariff structure: CN cotton T-shirt faces total tariff ~24% (16.5% base + 7.5% Section 301) — manageable for premium/complex product; existential for commodity basics competing on price"
- "Deliberate buyer diversification is a strategic characteristic: no single buyer >20%; EU/Asia mix is expanding, US share shrinking by design"
- "When India gets a cost advantage on cotton basics, CN factories double down on EU market with speed and complexity — the competitive response is product complexity and geographic pivot, not cost matching"
- "Air8 Hengqin entity operational rules apply (entity caps, SAFE compliance, Sinosure, SSQ e-signing) — see `_playbooks/china-operations.md` before onboarding any CN client"
- "Xinjiang cotton compliance is critical for US/EU orders — any Xinjiang cotton exposure triggers UFLPA rebuttable presumption; compliance documentation must be maintained per order destination"
- "⚠️ CSDDD compliance is demanded from suppliers by EU buyers BEFORE the regulation formally applies to the supplier — large EU retailers (H&M, Zara, Primark) are already requiring supplier due diligence data as contract condition for 2027+ programmes. This means CSDDD compliance pressure arrives 2-3 years before the 2029 formal deadline. BD/CN/TR/KH factories with EU buyer revenue >30% face de facto 2026-2027 compliance requirements through buyer contracts, not just 2029 law." (source: Event B, freshness: annual, PENDING EXPERT REVIEW: Alice)

---

## Buyer Edges
- sells_to: [buyer_type: EUFastFashion, weight: 0.90] — Zara, H&M; speed + co-development
- sells_to: [buyer_type: GlobalDTCBrand, weight: 0.70] — Allbirds, Everlane; low MOQ + design collab
- sells_to: [buyer_type: USMassMarket, weight: 0.25] — explicitly declining; accepted as structural trend
- concentration_pattern: "Deliberate diversification: no buyer >20%. EU increasingly dominant. Screens incoming inquiries — rejects commodity basics >100K pcs."
- typical_payment_terms: OA 60–90 days (Zara 30-60; H&M 60-90)

---

## LLM Directives
- keqiao_cost_trend: "Has the Keqiao fabric market adjusted pricing post-[cotton event]? What is the expected pass-through timeline from Keqiao mills to CN garment factories?"
- eu_buyer_cn_sentiment: "Current status of EU buyer sourcing from China — any major brands announcing de-sourcing or maintaining? What is the speed advantage CN maintains over India/VN for EU fast fashion?"
- competitor_comparison: "Post-[event]: compare CN vs India, Turkey, Vietnam on FOB cost for EU market cotton woven/knit garments. Factor in: material cost, labor, logistics speed, and tariff."
- xinjiang_compliance: "Current status of UFLPA enforcement for CN textiles. What documentation is required for CN cotton garments destined for US? What is the rebuttable presumption standard?"

---

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-PRESHIP-OBF.md PROD-SMARTWALLET.md
- pain_points: PP-001-cashflow-gap.md PP-CN-001-safe-complexity.md PP-CN-002-sinosure.md
- L0_principles: persona-principles.md#RP-COMPETITIVE-01 risk-principles.md#RP-RISK-COUNTRY-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-003-buyer-concentration] watch (deliberately managed low, but check)
- [PP-CN-001-safe-complexity] medium — SAFE cross-border regulations
- [PP-CN-002-sinosure-burden] medium — Sinosure monthly declaration requirement
- [PP-CN-003-hengqin-capacity] internal — Hengqin entity cap constraints

---
