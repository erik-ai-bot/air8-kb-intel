---
type: persona
id: COMBO-007
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap, limited bank facilities"
  - id: PP-002
    severity: HIGH
    context: "High bank interest, collateral-heavy lending"
  - id: PP-003
    severity: MEDIUM
    context: "Revenue concentrated on 1-2 buyers"
  - id: PP-006
    severity: MEDIUM
    context: "Low trade finance literacy, prefer simple products"
  - id: PP-IDN-001
    severity: MEDIUM
    context: "IDR/USD volatility squeezes USD margins"
---

# COMBO-007: Indonesia Family-Run 2nd Generation

## Dimensions
- Country: [[dimensions/DIM-1-country]] (ID)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($5-20M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB)
- Product: [[dimensions/DIM-4-product-focus]] (knit)
- Market: [[dimensions/DIM-5-target-market]] (EU | US)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_LC | none)
- Growth: [[dimensions/DIM-8-growth-stage]] (expanding)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-003-buyer-concentration]]
- [[../../layer-1-reasoning/pain-points/universal/PP-006-trade-finance-literacy]]
- [[../../layer-1-reasoning/pain-points/country/PP-IDN-001-rupiah-volatility]]

## Products
- [[../financing-products/PROD-MINIARP]] (start small)
- [[../financing-products/PROD-ARP]] (graduate to)

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (if cotton)
- [[../regulations/REG-REACH]]
- [[../regulations/REG-GPSR]]

## Data Entities
- fx.idr_usd
- [[data-entities/ENTITY-Buyer]] (payment_days)
- [[data-entities/ENTITY-Supplier]] (revenue)

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: generational_decision_authority
  why: "who is effectively making the decision (founder vs 2nd gen) determines tone and timeline — 2nd gen more open to trade finance"
  r1_question: "How long has the business been operating? Who is the main decision-maker for financing?"
  r2_deep: "Is the founder still active in day-to-day decisions, or has a second generation taken over operations?"
  collect: "No specific document; BD note on decision-maker profile"
  signal_impact: "Founder-primary: slow trust-build; do not push product on first meeting. 2nd gen: faster decision cycle."

- dim: rupiah_fx_exposure
  why: "USD revenue vs IDR cost = open FX exposure; Air8 USD-denominated ARP reduces IDR bank conversion friction"
  r1_question: "What currency do your buyers pay in — USD or another currency?"
  r2_deep: "Do you hedge USD/IDR exposure, or absorb it? Has IDR volatility caused margin problems recently?"
  collect: "Invoice currency confirmation; any FX hedging arrangements"
  signal_impact: "USD revenue + IDR costs: Air8 USD ARP is natural FX advantage; include in BD pitch"

- dim: existing_agent_relationships
  why: "legacy buying house agents may see Air8 as competition; must understand and navigate agent structure"
  r1_question: "Do you work directly with buyers or through a buying agent?"
  r2_deep: "Who introduced you to your key buyers? Is the agent involved in order management or just sourcing?"
  collect: "Order documentation showing buyer vs agent role"
  signal_impact: "Strong agent relationship: engage agent in conversation; do not appear to disintermediate"

- dim: bank_od_utilisation
  why: "IDR bank OD is the current financing method; utilisation level shows how credit-constrained they are"
  r1_question: "Do you currently use bank OD or LC for financing? What is your rate?"
  r2_deep: "What is the total OD limit and how much is currently drawn? Have there been any recent limit reductions?"
  collect: "Bank facility letter showing limit and current utilisation"
  signal_impact: "High utilisation (>70%): credit-constrained; Air8 is additive capacity. Low utilisation: harder sell; focus on speed/cost."

- dim: buyer_payment_terms
  why: "OA cycle drives actual WC need; longer terms = larger absolute gap Air8 fills"
  r1_question: "What is your typical OA cycle in days from shipment to payment receipt?"
  r2_deep: "Do different buyers have different payment terms? Who is your slowest payer?"
  collect: "Sample buyer invoice with payment terms; recent payment history"
  signal_impact: "OA >90 days: large WC gap; strong Air8 value. OA <45 days: smaller gap; softer pitch."

- dim: us_market_exposure | why: "COMBO-007 has US + EU buyer mix; S301 tariff on Indonesia directly affects US-bound orders; must quantify US exposure before S301 implementation" | r1_question: "What % of your revenue comes from US buyers? Which US buyers?" | signal_impact: "US revenue >40% AND S301 tariff confirmed → CAUTION; reduce advance on US-bound shipments; EU-bound receivables remain clean" ⚠️ PENDING REVIEW

## Signal Flip Conditions
- IF founder_still_primary_decision_maker → slow down; trust-build before product pitch; do not push Air8 on first meeting
- IF generational_handover_in_progress → CAUTION on limit expansion; decision authority unclear during transition
- IF bank_od_utilisation > 85% → strong EXPAND signal; Air8 ARP replaces constrained OD with no collateral required
- IF rupiah_depreciation event → EXPAND signal for USD-denominated ARP; natural hedge value is high
- IF us_s301_tariff_on_ID_confirmed AND us_revenue_pct > 40% → CAUTION; reduce advance on US-bound shipments; EU-bound receivables remain clean ⚠️ PENDING REVIEW

---

## Structural Nuances
- "Generational transition creates a split decision dynamic: father (founder) has established bank relationships and legacy agents; second generation is open to modern tools but needs to build buy-in"
- "Rupiah volatility erodes margins 5–10% in bad FX years — USD-invoiced but IDR cost structure creates open FX exposure that factory does not hedge"
- "Trust-based decision making: relationship with Air8 person matters more than product features at this stage — referral or warm introduction is worth more than a deck"
- "No AR aging system — cannot easily produce aged receivables report for Air8 onboarding without manual work"
- "⚠️ Indonesia's GSP (Generalized System of Preferences) with US was under review before IEEPA; Section 301 investigation adds a new tariff mechanism on top of existing GSP uncertainty — Indonesian garment exporters face potential loss of ALL US market preferential access simultaneously" (source: Event F, freshness: quarterly, PENDING EXPERT REVIEW: Josephine)
- "⚠️ IDR (Indonesian rupiah) is sensitive to US trade policy uncertainty — if S301 tariffs materially reduce Indonesian exports, IDR may depreciate 5-10% vs USD; for a factory earning USD from exports but paying IDR wages, the net effect is mixed (USD revenue drops from lower orders, but IDR cost competitiveness improves slightly)" (source: Event F, freshness: quarterly, PENDING EXPERT REVIEW: Josephine)

---

## Buyer Edges
- sells_to: [buyer_type: EUFastFashion, weight: 0.65]
- sells_to: [buyer_type: USMassMarket, weight: 0.60]
- concentration_pattern: "2–3 active buyers; top buyer often 40-50% of revenue."
- typical_payment_terms: OA 60–90 days

---

## LLM Directives
- idr_fx_outlook: "Current IDR/USD trend and IDR volatility profile. How does Air8 USD-denominated ARP reduce currency risk for an IDR-cost-base supplier?"

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-MINIARP.md PROD-ARP.md
- pain_points: PP-001-cashflow-gap.md PP-IDN-001-rupiah.md
- L0_principles: persona-principles.md#RP-FX-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-002-financing-cost] high
- [PP-003-buyer-concentration] medium
- [PP-006-trade-finance-literacy] high (especially founder generation)
- [PP-IDN-001-rupiah-volatility] high

---
