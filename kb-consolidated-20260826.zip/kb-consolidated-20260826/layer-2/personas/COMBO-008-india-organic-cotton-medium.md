---
type: persona
id: COMBO-008
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash cycle gap on buyer OA terms"
  - id: PP-002
    severity: HIGH
    context: "Bank OD cost 12-18%, financing expensive"
  - id: PP-005
    severity: HIGH
    context: "Organic cotton procurement requires pre-season capital"
  - id: PP-IN-001
    severity: HIGH
    context: "GST refund delays lock working capital"
  - id: PP-IN-002
    severity: HIGH
    context: "Bank OD rates 12-18% uncompetitive"
  - id: PP-ESG-001
    severity: MEDIUM
    context: "Organic/GOTS credentials not monetized in pricing"
---

# COMBO-008: India Organic Cotton Knit (Medium)

## Dimensions
- Country: [[dimensions/DIM-1-country]] (IN)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($20-50M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB | vertical)
- Product: [[dimensions/DIM-4-product-focus]] (knit_organic)
- Market: [[dimensions/DIM-5-target-market]] (US+EU)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_OD | Air8)
- Growth: [[dimensions/DIM-8-growth-stage]] (expanding)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]
- [[../../layer-1-reasoning/pain-points/country/PP-IN-001-gst-refund-delay]]
- [[../../layer-1-reasoning/pain-points/country/PP-IN-002-bank-od-cost]]
- [[../../layer-1-reasoning/pain-points/esg/PP-ESG-001-credentials-not-monetized]]

## Products
- [[../financing-products/PROD-ARP]]
- [[../financing-products/PROD-PRESHIP-OBF]]
- [[../financing-products/PROD-PRESHIP-RT2C]]
- [[../financing-products/PROD-ESG-FINANCING]]
- [[../financing-products/PROD-SMARTWALLET]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (advantage: organic traceability)
- [[../regulations/REG-CSDDD]] (data provider)
- [[../regulations/REG-REACH]]

## Data Entities
- [[data-entities/ENTITY-Commodity]] (organic_cotton_premium)
- [[data-entities/ENTITY-Buyer]] (payment_terms)
- esg.certifications

## Traceability
- [[../traceability/TRACE-ORGANIC-ADVANTAGE]]
- [[../esg-standards/ESG-IFC]]

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: gots_scope
  why: "which product lines are GOTS certified determines which are 100% domestic cotton (import duty irrelevant for GOTS lines)"
  r1_question: "Are you GOTS certified? What % of your production is on certified organic lines?"
  r2_deep: "Which specific product lines carry GOTS certification? Do you segregate certified vs non-certified cotton procurement?"
  collect: "GOTS certificate; production line segregation records"
  signal_impact: "100% GOTS: import duty events are NEUTRAL (all domestic certified cotton). Partial GOTS: apply benefit to non-certified portion only."

- dim: farmer_program_scale
  why: "larger farmer network = stronger UFLPA traceability claim = US market advantage"
  r1_question: "Do you have a direct farmer network for organic cotton sourcing? How many farmers are in your program?"
  r2_deep: "Can you trace cotton to individual farm level? Do you have Fairtrade or ROC certifications that document the farmer relationship?"
  collect: "Farmer program documentation; Fairtrade/ROC certificates if available"
  signal_impact: "Large farmer network (>1,000): strong UFLPA advantage; unlock US market pitch. Small/no program: UFLPA claim is weaker."

- dim: bank_od_vs_air8_cost
  why: "the most compelling Air8 argument is cost saving on OD rate; must be quantified"
  r1_question: "Do you currently use bank OD for working capital? What rate are you paying?"
  r2_deep: "What is your current OD limit and utilisation? Have rates increased recently due to RBI policy changes?"
  collect: "Bank OD facility letter showing rate and utilisation"
  signal_impact: "OD rate >14%: strong cost saving pitch; calculate net saving per $1M financed. OD rate <12%: weaker cost argument; emphasize other benefits."

---

## Signal Flip Conditions
- IF all_lines = GOTS certified → import duty events = NEUTRAL (all domestic cotton; see COMBO-003 for same logic)
- IF growing > 20% YoY → PSF/OBF is the priority product (WC constraint is growth limiter)

---

## Structural Nuances
- "Located near India's organic cotton belt (MP, Gujarat, Rajasthan) — connected to 500–5,000 farmer programs; this is the UFLPA advantage (trace to farm level inherently)"
- "GOTS + FAIRTRADE + OCS certifications are simultaneously compliance requirements AND IFC green/social bond eligibility triggers — treat as financing advantage, not just compliance overhead"
- "Growing 10–20% annually as sustainable fashion demand rises — WC constraint is the primary growth limiter, not market demand"
- "Bank OD at 12–18% = among highest financing costs in India; financing cost consumes a disproportionate share of ESG-premium margin"
- "Organic cotton uses domestic-only certified sources — import duty changes do NOT benefit organic lines; only any conventional blend lines would benefit from import duty reduction"
- "⚠️ UK sustainable/organic fashion market (est. £2.5bn, growing 15-20% annually) is structurally different from EU: UK consumers pay premium for GOTS/FAIRTRADE certifications AND have high willingness to pay for farmer-story brands (People Tree, Patagonia UK) — India organic knit with direct farmer narrative is uniquely positioned for UK post-FTA" (source: Event C, freshness: annual, PENDING EXPERT REVIEW: Alice)

---

## Buyer Edges
- sells_to: [buyer_type: ESGBrand, weight: 0.95] — Pact, Patagonia (possibility), EILEEN FISHER
- sells_to: [buyer_type: EUEthicalFashion, weight: 0.80]
- concentration_pattern: "ESG brands are stickier than commodity buyers — supplier is harder to replace due to certification pipeline. Typical 3-8 active buyers."
- typical_payment_terms: OA 30–90 days

---

## LLM Directives
- esg_financing_benchmark: "What is the interest rate premium a GOTS/FAIRTRADE-certified Indian mid-size exporter pays vs an IFC green bond-funded facility? Calculate saving per $1M financed."
- organic_market_growth: "Current growth rate of sustainable/organic fashion market in EU and US. Which buyer types are expanding organic cotton sourcing? Timeline for GOTS becoming a mainstream requirement vs premium niche?"

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ESG-FINANCING.md PROD-PRESHIP-OBF.md PROD-ARP.md
- pain_points: PP-005-preshipment-capital.md PP-ESG-001-credentials-not-monetized.md PP-IN-002-bank-od-cost.md
- L0_principles: persona-principles.md#RP-MATERIAL-01 persona-principles.md#RP-COMPLIANCE-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-005-preshipment-capital] high
- [PP-IN-001-gst-refund-delay] high
- [PP-IN-002-bank-od-cost] critical — 12-18% OD rate
- [PP-ESG-001-credentials-not-monetized] primary

---
