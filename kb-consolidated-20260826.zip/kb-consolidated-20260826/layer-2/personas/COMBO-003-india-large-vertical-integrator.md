---
type: persona
id: COMBO-003
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cotton 60-70% COGS, long cash cycle"
  - id: PP-002
    severity: HIGH
    context: "Bank OD cost 12-18%, high financing burden"
  - id: PP-005
    severity: HIGH
    context: "Cotton procurement needs 120-180 day capital"
  - id: PP-IN-001
    severity: HIGH
    context: "GST refund delayed, locks working capital"
  - id: PP-IN-002
    severity: HIGH
    context: "Bank OD rates 12-18% squeeze margins"
  - id: PP-ESG-001
    severity: MEDIUM
    context: "GOTS/organic credentials not monetized"
---

# COMBO-003: India Large Vertical Integrator

## Dimensions
- Country: [[dimensions/DIM-1-country]] (IN)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($50M+)
- Type: [[dimensions/DIM-3-company-type]] (vertical_integrator)
- Product: [[dimensions/DIM-4-product-focus]] (knit_organic | sustainable)
- Market: [[dimensions/DIM-5-target-market]] (US+EU+Multi)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_OD+Air8 | multi_bank)
- Growth: [[dimensions/DIM-8-growth-stage]] (expanding)
- Buyer: [[dimensions/DIM-6-buyer-profile]] (ESG_brands + global_brands)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]
- [[../../layer-1-reasoning/pain-points/country/PP-IN-001-gst-refund-delay]]
- [[../../layer-1-reasoning/pain-points/country/PP-IN-002-bank-od-cost]]
- [[../../layer-1-reasoning/pain-points/esg/PP-ESG-001-credentials-not-monetized]]

## Products
- [[../financing-products/PROD-ARP]]
- [[../financing-products/PROD-PRESHIP-OBF]]
- [[../financing-products/PROD-POOL]]
- [[../financing-products/PROD-SMARTWALLET]]
- [[../financing-products/PROD-ESG-FINANCING]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (advantage: organic cotton = inherent traceability)
- [[../regulations/REG-CSDDD]] (data provider advantage)
- [[../regulations/REG-REACH]]

## Data Entities
- [[data-entities/ENTITY-Commodity]] (cotton_price)
- [[data-entities/ENTITY-Buyer]] (payment_terms)
- [[data-entities/ENTITY-Regulation]] (uflpa_status)
- esg.voices_rating

## Traceability
- [[../traceability/TRACE-ORGANIC-ADVANTAGE]]
- [[../traceability/TRACE-T4S]]

## V2 Framework Extensions

### Structural Nuances (Tier 2 — expert-provided, LLM would miss)
- "Buys raw cotton directly from 10,000+ farmers; cotton = 60-70% COGS"
- "Blends imported cotton with domestic MSP cotton (40-60% split); duty saving applies to imported portion only → blended saving 5-8% on total cotton cost"
- "MSP acts as domestic price floor — CCI buys at MSP if market falls below it; domestic price cannot fall below ~$0.87/kg"
- "India now at raw material/yarn cost parity with BD/VN on imported cotton; end-product competitiveness still depends on labour, efficiency, product mix"
- "GOTS/organic lines use domestic-only certified cotton — cotton import duty saving does NOT apply to organic lines"
- "PreShip-OBF self-liquidates: cotton → production → ARP receivables within 120-180 days. Low Air8 risk when buyer investment-grade"

### Particular Supplier (5-D Due Diligence)
demand:
  - "PO volume growing / stable / declining?"
  - "Post-Oct stockpile plan for cotton procurement?"
buyers:
  - "% revenue concentrated with one buyer?"
  - "US vs EU vs others breakdown?"
product:
  - "Cotton % per style? Organic (domestic) vs conventional (import) split?"
  - "GOTS / BCI certification — which lines certified?"
cash:
  - "Payment on time? Deduction or dilution trend?"
  - "Bank OD utilisation — current headroom?"
capacity:
  - "Mill at full capacity or underutilised?"
  - "India entity to capture direct duty benefit?"

### What to Provide
- "BOM / tech pack → confirms cotton % and fibre mix per style"
- "GOTS / BCI cert documents → confirms organic vs conventional lines"
- "Import vs domestic cotton split (by volume, last 12 months)"
- "Factory list → any India processing entity for direct duty benefit?"

### What to Do (Supplier Strategic Actions)
1. "Import 3-5 months cotton before Oct 31 cliff — duty reverts after that, cost advantage disappears"
2. "Lock downstream supply contracts at new cost base before buyers discover input cost fell"
3. "Position for yarn export to China — Indian yarn demand from CN mills likely to increase; monitor spot pricing before committing volumes"
4. "Plan working capital for the stockpile surge — WC need increases 30-50%; bank OD will be the first constraint"

### Sub-Scenarios (IF Branches)
sub_scenario_1:
  condition: "GOTS-certified organic lines"
  why: "COMBO-003 primarily sources certified organic cotton from domestic farmer programs — India #1 organic cotton producer (51% global supply). Pure organic cotton lines = domestic sourcing = duty saving largely does not apply. Only specialty blend yarns (organic/linen, organic/modal) where imported component exists would benefit."
  air8_signal: "EXPAND on conventional lines only. Organic lines unchanged — only check whether specialty blend yarns are imported."
  air8_caveat: "Verify factory records keep conventional and certified-organic streams separate. Mixing conventional imported cotton into GOTS production voids certification — far greater loss than any cotton cost saving."
  action: "No change needed on organic lines. Import cheaper global cotton for conventional lines only. Keep cotton streams physically and documentarily separate."

sub_scenario_2:
  condition: "October 31 cliff approaches (< 45 days remaining)"
  why: "Duty exemption ends Oct 31. Factories that over-stockpiled imported cotton face elevated WC needs into Q1 2027 as duty reverts Nov 1."
  air8_signal: "Front-load PSF drawdowns Jun-Jul; reduce by Sep-Oct as stockpile completes."
  action: "Plan production capacity to absorb 3-5 months imported cotton. Front-load procurement Jun-Jul, reduce by Sep-Oct before Oct 31 cliff."

### Competitive Position
moat: "World-class organic cotton traceability (GOTS, FAIRTRADE, C2C, ROC) — structural UFLPA advantage"
moat_horizon: "2026+ strong; organic credentials are multi-year competitive moat"
competitive_advantage_over: ["COMBO-002-BD-CMT", "COMBO-009-PK-Home-Textile"]
competitive_threat_from: []
watch_signal: "Other India verticals capturing same cotton cost window before Oct 31"

### Air8 Risk Parameters
air8_signal: "EXPAND — MONITOR POST-OCT REVERSAL"
advance_ratio_normal: 85
advance_ratio_alert: 70
review_frequency: "quarterly (monthly post-Oct 31)"
trigger_for_reduction: "Over-stockpiling detected; WC stress in Q1 2027"
monitoring_signals:
  - "Cotton procurement pace vs Oct 31 cliff"
  - "Post-cliff WC utilisation trend"
  - "Organic vs conventional line revenue split"

## V2 Assessment Chain

> Reasoning chain: event × combo → assess this specific supplier → collect data → sharpen calculation

### impact_calculation
```yaml
formula: "Δduty × imported_share × cotton_COGS_pct × (1 - buyer_passthrough)"
generic_estimate: "+1-2% gross margin uplift"
inputs:
  imported_share:
    source: "AC-02 supplier answer"
    default: 0.50
    expert_review: "validate_default — confirm typical import ratio for IN large verticals"
  cotton_COGS_pct:
    source: "supplier financials OR benchmark"
    default: 0.65
    expert_review: "validate_default — confirm 60-70% COGS range for verticals"
  buyer_passthrough:
    source: "AC-04 contract terms"
    default: 0.40
    expert_review: "validate_default — confirm typical passthrough for IN verticals"
example_with_data:
  inputs: {imported_share: 0.60, cotton_COGS_pct: 0.68, buyer_passthrough: 0.30}
  result: "11% × 60% × 68% × 70% = 3.1% net margin uplift"
  vs_generic: "was '1-2%', now precise"
```

### assessment_chain
```yaml
- id: AC-01
  dimension: "Direct cotton purchasing — does benefit apply at all?"
  question: "Do you buy raw cotton directly, or do you buy yarn / fabric?"
  data_request: "Procurement type declaration (cotton vs yarn vs fabric)"
  expert_review: "ai_extended — LLM can infer from vertical integrator archetype; expert confirms edge cases"
  branch:
    cotton_direct:
      impact_level: FULL
      next: AC-02
    yarn_or_fabric:
      signal_modifier: "indirect benefit via yarn supply chain, 90-180d lag"
      impact_level: REDUCED
      next: AC-03  # skip blend ratio; still check organic/conventional

- id: AC-02
  dimension: "Import vs domestic cotton blend ratio"
  question: "What % of your cotton procurement is imported vs domestic MSP cotton?"
  data_request: "Cotton procurement breakdown by origin — last 12 months (volume, %)"
  expert_review: "validate_default — Jerri/cotton expert to confirm 40-60% domestic blend assumption"
  unlocks_calculation: "narrows estimate from '1-2%' to exact using formula above"
  next: AC-03

- id: AC-03
  dimension: "Organic vs conventional line split — does duty saving actually flow?"
  question: "Which product lines are GOTS / BCI certified? What % of revenue is organic vs conventional?"
  data_request: "BOM per product line + GOTS/BCI certificate + revenue split organic vs conventional"
  expert_review: "required — expert must confirm: organic lines use domestic certified cotton only; mixing voids certification"
  branch:
    all_conventional:
      apply: "full AC-02 formula"
      next: AC-04
    mixed:
      apply: "AC-02 formula on conventional COGS portion only"
      add_data_request: "Revenue % organic vs conventional to weight the calculation"
      next: AC-04
    all_organic:
      signal_override: NEUTRAL
      why: "Domestic certified cotton — 0% duty saving does not apply"
      stop: true

- id: AC-04
  dimension: "Buyer passthrough — what % of saving does mill actually keep?"
  question: "Are your supply contracts fixed-price or cost-plus? Can you retain input cost savings?"
  data_request: "Contract pricing clause extract OR buyer correspondence re: cost adjustments"
  expert_review: "validate_default — BD expert to confirm typical IN vertical passthrough rate"
  unlocks_calculation: "finalises net margin uplift = gross uplift × (1 - passthrough)"
  next: AC-05

- id: AC-05
  dimension: "Post-cliff working capital plan — is Air8 exposure clean?"
  question: "Do you plan to stockpile cotton before Oct 31? How much above normal inventory?"
  data_request: "Procurement forward plan / purchase order pipeline Oct-Nov"
  expert_review: "required — risk team must set drawdown schedule; flag if tenor extends past Oct 31"
  branch:
    stockpile_within_capacity:
      air8_action: "front-load PSF drawdowns Jun-Jul; taper by Sep"
    aggressive_stockpile:
      air8_action: "cap tenor at 90d; require WC plan for post-cliff period"
      flag: "escalate to credit review"
```

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: domestic_vs_imported_cotton_ratio
  why: "determines actual magnitude of any cotton price/duty event benefit (import duty applies to imported share only)"
  r1_question: "Do you buy raw cotton directly from farmers/traders, or purchase pre-spun yarn/fabric?"
  r2_deep: "What % of your cotton is imported vs domestic MSP cotton? Do you use forward contracts or spot market?"
  collect: "Cotton procurement records by origin (last 12 months); forward contract schedule if applicable"
  signal_impact: "Imported%: determines share of COGS benefiting from duty event; domestic% is MSP-floored and unaffected"

- dim: organic_vs_conventional_line_split
  why: "organic lines use domestic certified cotton only — import duty saving does not apply; mixing voids GOTS certification"
  r1_question: "Which product lines are GOTS/BCI certified? What % of revenue is organic vs conventional?"
  r2_deep: "For GOTS lines: do you source 100% domestic certified cotton? Have you ever tested imported cotton in these lines?"
  collect: "GOTS certificate scope; production records showing certified vs non-certified line split"
  signal_impact: "If all-organic (100% domestic certified): flip cotton import duty event from BENEFIT to NEUTRAL"

- dim: buyer_passthrough_rate
  why: "cost-plus vs fixed-price contracts determines what % of savings factory keeps vs passes to buyer"
  r1_question: "Do you have fixed-price seasonal contracts with buyers, or cost-plus pricing?"
  r2_deep: "For your top 3 buyers: are prices fixed at season booking or adjusted as input costs change?"
  collect: "Sample buyer contract or PO terms showing pricing structure"
  signal_impact: "If buyer_passthrough >60%: reduce net benefit in WHY section; state explicitly what factory retains"

- dim: post_cliff_stockpile_plan
  why: "aggressive pre-buying creates post-cliff WC stress; Air8 PSF must not extend past cliff date — see _playbooks/cliff-playbook.md"
  r1_question: "Do you have a stockpile plan for any upcoming tariff deadline? How many months above normal inventory?"
  r2_deep: "What is your planned cotton purchase volume for the next 3 months vs seasonal norm? Do you have financing for the elevated position?"
  collect: "Inventory plan; production calendar; current cotton stock vs normal seasonal level"
  signal_impact: "If stockpile >3x normal: flip EXPAND to CONDITIONAL; require WC plan for post-cliff period"

- dim: ifc_eligibility_criteria
  why: "GOTS + FAIRTRADE + women employment + renewables → ESG-Finance pricing advantage"
  r1_question: "What ESG certifications do you hold — GOTS, FAIRTRADE, BCI, ROC, OEKO-TEX?"
  r2_deep: "What is your women employment % in production? Do you use renewable energy? Any IFC-supported financing previously?"
  collect: "ESG certificate portfolio; energy audit; employment data"
  signal_impact: "If all 4 criteria met (GOTS, women >40%, renewable >20%, FAIRTRADE): unlock ESG-Finance pricing advantage"

- dim: uk_buyer_revenue_pct | why: "UK is the most directly impacted market by India-UK FTA; factory with existing UK buyers captures immediate duty saving; factory without UK buyers needs BD support to develop UK pipeline" | r1_question: "What % of your revenue is from UK-headquartered buyers (M&S, Next, ASOS, Tesco F&F, Primark UK)?" | signal_impact: "UK buyers already >20% revenue → FTA ratification = immediate margin uplift; Air8 EXPAND signal strengthens. No UK buyers → FTA is a BD outreach opportunity (help factory develop UK buyer pipeline)" ⚠️ PENDING REVIEW

---

## Signal Flip Conditions
- IF all_production_lines = GOTS certified organic → flip india cotton duty event from BENEFIT to NEUTRAL (100% domestic certified cotton; import duty irrelevant)
- IF conventional_blend = partial → apply formula to conventional COGS portion only; organic portion stays NEUTRAL
- IF post_cliff_stockpile > 3x normal inventory → flip EXPAND to CONDITIONAL; require WC plan for post-cliff period
- IF buyer_passthrough > 60% → reduce net benefit in WHY section to reflect retained margin only

---

## Structural Nuances
- "Buys raw cotton directly from farmers — cotton = 60–70% of COGS; raw material price events have the LARGEST and most DIRECT impact of any apparel combo"
- "Domestic/imported blend: blends domestic MSP cotton with imported cotton at roughly 40–60% imported split (RP-DEPENDENCY input — freshness: annual) ⚠️; duty saving applies ONLY to the imported portion"
- "India MSP (Minimum Support Price) for cotton acts as a domestic price floor — CCI buys at MSP if market falls below; domestic cotton price cannot fall below ~$0.87/kg regardless of global price"
- "GOTS/organic certified lines use domestic-only certified cotton; importing cheaper global cotton into GOTS lines voids the certification — this is not a nuance LLM would assume"
- "PreShip-OBF self-liquidates: cotton → spinning → weaving/knitting → garment → buyer receivable, typically 120–180 days. Low Air8 risk when buyer is investment-grade."
- "Farm-to-fashion traceability (10,000+ farmer network) is a structural UFLPA advantage — organic cotton = inherent traceability to farm level; this is a competitive moat for US market entry"
- "Over-stockpiling risk before cliff dates: Vertical integrators have the capital and motivation to pre-buy 3–5 months of cotton during duty exemption windows; this creates elevated WC needs in the quarter after cliff"
- "Post-cliff timing: disbursements must be front-loaded Jun-Jul; tapered Sep-Oct before Oct-31 cliff; all PSF must self-liquidate before cliff date"
- "⚠️ UK operates its own DCTS (Developing Countries Trading Scheme) post-Brexit — Bangladesh and Cambodia retain 0% duty on garments in UK; India's 8-12% duty disadvantage vs BD specifically in UK market suppresses M&S and ASOS sourcing from India; FTA ratification = structural shift in UK-India sourcing economics" (source: Event C, freshness: annual, PENDING EXPERT REVIEW: Jerri)
- "⚠️ Marks & Spencer (M&S) UK sources ~15-20% of its garments from India; post-FTA, M&S sourcing of India could increase to 25-30%+ as duty removal closes cost gap with Bangladesh; Air8-financed Indian verticals with M&S programs should anticipate order acceleration — and corresponding WC needs — within 12 months of ratification" (source: Event C, freshness: annual, PENDING EXPERT REVIEW: Alice)
- "⚠️ The India-UK FTA is specifically expected to include a 'rules of origin' clause requiring substantial transformation in India — factories that source fabric from Bangladesh or China and process in India may NOT benefit from FTA duty reduction; only factories with domestic Indian fabric sourcing (vertically integrated) fully capture the FTA upside" (source: Event C, freshness: stable, PENDING EXPERT REVIEW: Alice)
- "⚠️ India-UK FTA (in negotiation 2026): if enacted, removes India's 8-12% duty disadvantage in UK market. UK imports ~$20bn apparel annually; India currently holds only 6% share. FTA completion = India EXPANDS into UK market at scale, creating a new buyer market signal. Air8 should monitor FTA progress and prepare S2 UK-buyer outreach for IN Vertical and IN Small Woven combos." (source: Event C, freshness: annual, PENDING EXPERT REVIEW: Jerri)

---

## Buyer Edges
- sells_to: [buyer_type: ESGBrand, weight: 0.90] — Patagonia, Pact, organic-focused brands
- sells_to: [buyer_type: GlobalFashion, weight: 0.80] — H&M, Marks & Spencer, Gap (sustainable lines)
- sells_to: [buyer_type: USMultiChannel, weight: 0.70]
- concentration_pattern: "Well-diversified — typically 10–20 active buyers. ESG certifications create buyer stickiness that price-only suppliers cannot replicate."
- typical_payment_terms: OA 60–120 days

---

## LLM Directives
- cotton_import_blend: "For India large Vertical integrators: what is the typical domestic vs imported cotton procurement split? What is the current MSP floor vs imported price post-event? Calculate blended impact using formula: Δduty × imported_share × cotton_COGS_pct × (1 - buyer_passthrough)."
- organic_conventional: "For a factory with GOTS-certified lines: what % of their cotton procurement is certified organic (domestic only) vs conventional (importable)? Confirm: mixing imported conventional cotton into GOTS lines voids certification — alert if any risk of this."
- ifc_eligibility: "Does this factory meet IFC green/social bond eligibility? Key tests: (1) GOTS/FAIRTRADE present, (2) women employment >40%, (3) renewable energy >20% of factory consumption."

---

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-PRESHIP-OBF.md PROD-ARP.md PROD-ESG-FINANCING.md
- pain_points: PP-005-preshipment-capital.md PP-IN-002-bank-od-cost.md PP-IN-001-gst-refund.md
- L0_principles: persona-principles.md#RP-MATERIAL-01 persona-principles.md#RP-TARIFF-CLIFF-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-005-preshipment-capital] critical (180-240 day cycle = largest pre-shipment need)
- [PP-IN-001-gst-refund-delay] high — GST refund delays lock WC in receivables from government
- [PP-IN-002-bank-od-cost] high — bank OD at 12–18%
- [PP-ESG-001-credentials-not-monetized] primary — certifications exist but not priced into financing

---
