---
type: persona
id: COMBO-001
pain_points:
  - id: PP-001
    severity: HIGH
    context: "Cash cycle 120-150 days, financing gap"
  - id: PP-002
    severity: HIGH
    context: "Margin 8-12%, hyper-sensitive to cost"
  - id: PP-003
    severity: MEDIUM
    context: "Over-reliance on single fast-fashion buyer"
  - id: PP-004
    severity: MEDIUM
    context: "Capacity limited without working capital"
  - id: PP-006
    severity: MEDIUM
    context: "Low awareness of trade finance options"
---

# COMBO-001: South Asian Small Knit Manufacturer

## Dimensions
- Country: [[dimensions/DIM-1-country]] (BD | IN | PK | KH)
- Revenue: [[dimensions/DIM-2-revenue-band]] ($5-20M)
- Type: [[dimensions/DIM-3-company-type]] (manufacturer_FOB)
- Product: [[dimensions/DIM-4-product-focus]] (knit)
- Market: [[dimensions/DIM-5-target-market]] (US+EU)
- Financing: [[dimensions/DIM-7-current-financing]] (bank_LC)
- Growth: [[dimensions/DIM-8-growth-stage]] (expanding)
- Buyer: [[dimensions/DIM-6-buyer-profile]] (fast_fashion + mass_market)

## Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[../../layer-1-reasoning/pain-points/universal/PP-003-buyer-concentration]]
- [[../../layer-1-reasoning/pain-points/universal/PP-004-scalability-constraint]]
- [[../../layer-1-reasoning/pain-points/universal/PP-006-trade-finance-literacy]]
- Country-specific (BD/IN/PK) pain points

## Products
- [[../financing-products/PROD-ARP]]
- [[../financing-products/PROD-PRESHIP-RT2C]]
- [[../financing-products/PROD-PAYGUARD]]

## Compliance Exposure
- [[../regulations/REG-UFLPA]] (cotton → US)
- [[../regulations/REG-REACH]] (EU market)
- [[../regulations/REG-CSDDD]] (EU buyers)

## Data Entities
- [[data-entities/ENTITY-Buyer]] (payment_days)
- [[data-entities/ENTITY-Supplier]] (revenue)
- [[data-entities/ENTITY-Facility]] (advance_ratio)
- [[data-entities/ENTITY-Insurance]] (buyer_limit)
- [[data-entities/ENTITY-Commodity]] (yarn_price)

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: trade_finance_literacy
  why: "most important for entry product selection (MiniARP vs ARP vs education-first)"
  r1_question: "Have you used invoice financing or trade finance before? Do you currently use bank LC or OD?"
  r2_deep: "What is your biggest concern about using trade finance — cost, documentation, or understanding the product?"
  collect: "No document needed; BD note on awareness level"
  signal_impact: "Zero awareness: education-first approach before product pitch. Some experience: proceed to product comparison."

- dim: buyer_concentration
  why: "top buyer % determines vulnerability and PayGuard eligibility"
  r1_question: "Who are your top 2-3 buyers and what % of revenue each?"
  r2_deep: "Is any single buyer >40% of revenue? Have you ever had a buyer miss a payment or reduce orders unexpectedly?"
  collect: "Sales breakdown by buyer"
  signal_impact: "Top buyer >40%: concentration risk; flag PayGuard if >$2M exposure. Top buyer <20%: well diversified."

- dim: bank_financing_cost
  why: "cost comparison to Air8 is the primary sales argument"
  r1_question: "Do you use any bank financing currently? What rate are you paying?"
  r2_deep: "Is the bank facility secured on assets? How long did it take to set up?"
  collect: "Bank facility letter showing rate and conditions"
  signal_impact: "High bank cost (>12%): strong Air8 cost saving pitch. Bank rate <8%: focus on speed and flexibility instead."

- dim: country_of_operation
  why: "for precise analysis, reroute to country-specific COMBO (002 BD, 003/008/014 IN, etc.)"
  r1_question: "Where is your factory located? What country?"
  r2_deep: "Have you had any country-specific challenges — currency volatility, political disruptions, regulatory changes?"
  collect: "No document needed; routing information"
  signal_impact: "Identified country: load country-specific COMBO for precise signal instead of this generic COMBO."

---

## Signal Flip Conditions
- IF trade_finance_literacy = none → route to education-first approach before product pitch
- IF revenue < $1M OR ops < 2yr → not eligible even for MiniARP; flag and close
- IF country specific risk triggers active → defer to country-specific COMBO for more precise signal

---

## Structural Nuances
- "Cash cycle 120–150 days (fabric procurement → OA 90 days) is the longest in the CMT segment due to limited financing sophistication — cannot stagger receivables"
- "3–5 active buyers with top buyer typically >30% revenue = concentration risk that compounds any buyer distress event"
- "Owner makes all decisions without financial delegation — cannot analyze financing options analytically; needs simple, tangible comparison (vs bank LC cost in days and %)"
- "May not understand factoring concept at all — education is part of the Air8 sales process, not a pre-condition"
- "Margin 8–12% nominally, hyper-sensitive to financing cost — a 2% financing cost reduction on $5M of receivables = $100K annual saving = material for this segment"

---

## Buyer Edges
- sells_to: [buyer_type: USMassMarket, weight: 0.70]
- sells_to: [buyer_type: EUDiscountRetail, weight: 0.65]
- concentration_pattern: "Top buyer = 30-40% revenue. No active diversification. Relationship protection logic dominates."
- typical_payment_terms: OA 60–90 days

---

## LLM Directives
- financing_cost_comparison: "What is the current bank financing cost for small knit manufacturers in [country]? Calculate net saving vs Air8 pricing on $[X]M of annual receivables."

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-MINIARP.md
- pain_points: PP-001-cashflow-gap.md PP-002-financing-cost.md
- L0_principles: persona-principles.md#RP-MATERIAL-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-002-financing-cost] primary
- [PP-003-buyer-concentration] high
- [PP-004-scalability-constraint] high
- [PP-006-trade-finance-literacy] primary

---
