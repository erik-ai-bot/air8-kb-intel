---
type: persona
id: COMBO-010
pain_points:
  - id: PP-EXPAND-001
    severity: HIGH
    context: "Low wallet share, massive upsell gap"
  - id: PP-EXPAND-002
    severity: HIGH
    context: "Missing product coverage limits financing"
  - id: PP-EXPAND-003
    severity: MEDIUM
    context: "Operational friction in existing setup"
---

# COMBO-010: Existing Air8 Client — Expansion Scenario

## Dimensions
- Financing: [[dimensions/DIM-7-current-financing]] (already_Air8)
- All other dimensions: ANY

## Pain Points
- [[../../layer-1-reasoning/pain-points/expansion/PP-EXPAND-001-low-wallet-share]]
- [[../../layer-1-reasoning/pain-points/expansion/PP-EXPAND-002-missing-product-coverage]]
- [[../../layer-1-reasoning/pain-points/expansion/PP-EXPAND-003-operational-friction]]

## Products (Focus: Whatever They Don't Have Yet)
- [[../financing-products/PROD-ARP]] (new buyer pairs)
- [[../financing-products/PROD-PRESHIP-OBF]]
- [[../financing-products/PROD-PRESHIP-RT2C]]
- [[../financing-products/PROD-SMARTWALLET]]
- [[../financing-products/PROD-PAYGUARD]]
- [[../financing-products/PROD-ESG-FINANCING]]

## Data Entities
- [[data-entities/ENTITY-Facility]] (wallet_share, buyer_pairs_active, products_used)

## Agent Query Notes
- Check facility.wallet_share — if <50%, massive upsell opportunity
- Check products_used — if ARP_only, pitch PreShipment and SmartWallet
- Check buyer pairs — any uncovered buyers?

## Assessment Dimensions
*(Canonical questions merged — replaces separate Qualifying Questions section)*

- dim: wallet_share_pct
  why: "primary expansion indicator; <50% = immediate action"
  r1_question: "What is the current Air8 facility size and utilisation vs your total annual AR volume?"
  r2_deep: "If we mapped Air8 coverage to your total AR, what % is currently covered? Which buyers have the most uncovered AR?"
  collect: "Total buyer AR volume; Air8 facility current limit and utilisation"
  signal_impact: "<50% wallet share: immediate expansion opportunity. >80%: shift focus to limit lift or new products."

- dim: products_currently_used
  why: "ARP-only = pitch RT2C/OBF; no SmartWallet = pitch if 3+ buyers"
  r1_question: "Which Air8 products are you currently using — ARP, RT2C, OBF, SmartWallet?"
  r2_deep: "Are there any pre-shipment financing needs that aren't currently covered by Air8?"
  collect: "Current Air8 facility structure"
  signal_impact: "ARP-only + 6mo track record: pitch RT2C/OBF. 3+ buyers + no SmartWallet: pitch SmartWallet."

- dim: uncovered_buyer_pairs
  why: "any eligible, insured buyer not in Air8 facility = immediate expansion opportunity"
  r1_question: "Do you have any current buyers who are NOT covered under the Air8 facility?"
  r2_deep: "For each uncovered buyer: what is the OA volume? Is the buyer eligible for insurance?"
  collect: "Full buyer list with OA volumes; current Air8 facility buyer coverage list"
  signal_impact: "Eligible uncovered buyers: immediate EXPAND; prioritize by OA volume."

- dim: operational_friction_type
  why: "friction (doc matching, insurance limits) blocks wallet share growth; must resolve before volume growth"
  r1_question: "Are there any operational issues with the current Air8 facility — documentation, insurance, payments?"
  r2_deep: "Has any invoice been rejected or delayed due to documentation issues? Any insurance limit constraints?"
  collect: "Ops team feedback; recent exception log"
  signal_impact: "High friction: resolve before expanding; risk of client churn if friction unaddressed."

---

## Signal Flip Conditions
- IF wallet_share > 80% → focus on limit lift or better terms (ESG pricing), not new pairs
- IF operational_friction = HIGH → resolve friction first; do not expand facility until issue resolved

---

## Structural Nuances
- "KYC is complete; agreement is signed — expansion levers are: (a) more buyer pairs, (b) more products, (c) higher limits, (d) better terms"
- "Wallet share <50% is the primary indicator of expansion opportunity — if Air8 touches <50% of their AR, massive whitespace exists"
- "Product cross-sell sequencing: ARP → RT2C → OBF → POOL → ESG (each unlocks on eligibility milestones)"
- "Operational friction (doc matching, FR holds, insurance limits) is the most common reason for low wallet share — fix friction before pitching new products"

---

## Buyer Edges
- concentration_pattern: "Check existing facility data — are there uncovered buyer pairs with eligible, insured buyers?"

---

## LLM Directives
- wallet_share_analysis: "For existing Air8 client: calculate current wallet share (Air8 facility size / estimated total AR × 100). What is the expansion opportunity if wallet share reaches 70%?"

*(Qualifying Questions merged into Assessment Dimensions above — see r1_question and r2_deep per dimension)*

## Next Reads (Retrieval Chain Pointers)
*After loading this file, load ONLY these — no other files needed*
- products: PROD-ARP.md PROD-POOL.md PROD-PRESHIP-RT2C.md
- pain_points: PP-EXPAND.md
- L0_principles: product-principles.md#RP-PROD-TENOR-01
- edges: _links/cross-module-edges.md

## Pain Hooks
- [PP-EXPAND-001-low-wallet-share] primary
- [PP-EXPAND-002-missing-product-coverage] high
- [PP-EXPAND-003-operational-friction] medium

---
