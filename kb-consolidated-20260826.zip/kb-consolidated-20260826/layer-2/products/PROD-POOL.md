---
type: product
id: PROD-POOL
---
# PROD-POOL: Pool Factoring (Whole Turnover)

## What It Does
One facility covers ALL buyer relationships instead of pair-by-pair. Simpler admin overhead for suppliers with 5+ buyers.

## Eligibility
- Revenue >$20M
- 5+ active buyer pairs
- Good overall scorecard

## Applies When
- buyer_count ≥ 5
- Revenue >$20M

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]

## Best Fit Combos
- [[personas/COMBO-003-india-large-vertical-integrator]]
- [[personas/COMBO-004-china-medium-woven]]
- [[personas/COMBO-009-pakistan-home-textile]]
- [[personas/COMBO-013-multi-country-group]]
