---
type: traceability
id: TRACE-T4S
---
# TRACE-T4S: T4S Platform (Air8/LF Traceability)

## Status (2025)
- 264+ POs traced
- 164 styles
- 74 suppliers
- 7,000+ trade documents collected

## Capability
Maps supply chain from Tier 1 → Tier 4+ with document verification at each tier.

## Value
Directly addresses [[../regulations/REG-UFLPA]] traceability requirement.

## Competitive Advantage
No other trade finance provider offers integrated supply chain traceability.

## Tier Structure
[[TRACE-TIERS]]
