---
type: traceability
id: TRACE-TIERS
---
# TRACE-TIERS: Supply Chain Tier Definitions

| Tier | Definition |
|------|-----------|
| **Tier 1** | Manufacturing Factory — finished products (garment assembly) |
| **Tier 1.5** | Processing Factory — printing, washing, embroidery, finishing |
| **Tier 2** | Fabric/Material Mill — weaving/knitting fabric, yarn production |
| **Tier 3** | Yarn Spinner — converting fiber to yarn |
| **Tier 4** | Fiber Producer — raw fiber (cotton farm, chemical plant for polyester) |
| **Tier 5+** | Input Suppliers — chemicals, dyes, accessories, machinery |

## UFLPA Relevance
Full Tier 1 → Tier 4+ mapping required for US cotton imports.
See [[../regulations/REG-UFLPA]]
