---
type: product
id: PROD-MINIARP
---
# PROD-MINIARP: MiniARP (Simplified ARP for Small Suppliers)

## What It Does
Same mechanics as ARP but with simplified KYC and lower exposure limits. Entry point for micro/small suppliers getting external financing for the first time.

## Limits
Max exposure: $300K

## Eligibility
- Revenue >$1M
- Operations >2 years
- (Even if non-LF)

## Applies When
- [[../../layer-1-reasoning/pain-points/universal/PP-006-trade-finance-literacy]] is active
- Revenue $1–5M range

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-006-trade-finance-literacy]]

## Best Fit Combos
- [[personas/COMBO-015-micro-first-time]]
- [[personas/COMBO-007-indonesia-family-run]] (first step)
- [[personas/COMBO-012-cambodia-eba-dependent]]
