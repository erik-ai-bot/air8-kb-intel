---
type: product-category
id: APPAREL
layer: 2
---

# Apparel & Textile Product Categories

This file consolidates all 5 apparel/textile product focus areas from the Air8 KB.
Each section preserves the full original content from the corresponding `dimensions/product-focus/` file.

---

## Summary Table

| Category              | ID                    | Lead Time     | Key Risk          | Country Strength                         |
|-----------------------|-----------------------|---------------|-------------------|------------------------------------------|
| Denim                 | product-denim         | 90–120 days   | Chemical (REACH)  | Turkey, Bangladesh, Pakistan, India      |
| Knit Apparel          | product-knit          | 60–90 days    | UFLPA (cotton)    | Bangladesh, India, Vietnam, Indonesia    |
| Woven Apparel         | product-woven         | 90–120 days   | UFLPA + REACH     | China, India                             |
| Home Textiles         | product-home-textiles | 60–90 days    | Fire retardants   | Pakistan, India, Turkey, Egypt           |
| Organic / Sustainable | product-organic       | 90–120d + 2–4w| Cert chain gap    | India (#1 organic globally), Turkey      |

---

## Section 1: Denim

---
**Dimension:** DIM-4-product-focus | **ID:** product-denim

**Products:** Jeans, jackets, shorts, denim skirts
**Raw material:** Denim fabric (indigo-dyed cotton)
**Lead time:** 90–120 days
**Seasonality:** Low-medium

### Key Quality Issue
Wash/finish consistency critical: laser, ozone, stone wash must match across lots.

### Compliance (HIGHEST CHEMICAL EXPOSURE)
- `layer-2-entities/esg-standards/ESG-ZDHC.md` — ZDHC MRSL Gateway adherence required
- **REACH** (`layer-1-reasoning/regulations/REG-REACH.md`) — CRITICAL (indigo, permanganate, PP spray, resin finishes)
- **UFLPA** (`layer-1-reasoning/regulations/REG-UFLPA.md`) — if cotton → US

### Wet Process Types
Stone wash, enzyme, acid, laser, ozone, sand/spray, resin, overdye (8–12 types)

### Country Strength
Turkey, Bangladesh, Pakistan, India

### WIP Profile
- **production_cycle_days:** 90–120
- **fob_per_unit_usd:** $6.00–15.00
- **cost_structure:** fabric 30–40% | labor 20–30% | wet_process 8–12% (complex/eco: 10–15%) | machine_depreciation 3–5%
- **wip_stages:**
  1. Fabric receipt & inspection (~3 days)
  2. Cut (~5 days)
  3. Sew (~7 days)
  4. Wash development — BOT (normal 10–12 wks; rush 6 wks) (~10 days bulk)
  5. Washing & finish (stone/enzyme/acid/laser/ozone/sand/resin/overdye) (~7 days)
  6. QC — shade consistency critical (~3 days)
  7. Pack & ship (~3 days)
- **typical_margin_band:** 8–14%
- **seasonality:** low-medium
- **bottleneck:** Wash development — new recipe adds 2–3 weeks; shade variance across lots is top defect risk
- **water_intensity:** HIGH — 50–80 L/garment (eco: 5–15 L with laser/ozone)
- **raw_material_sensitivity:** [indigo, cotton_denim_fabric, specialty_chemicals]
- **key_equipment_capex:** laser $150–300K | ozone $80–150K | drums $50–100K (total $2–5M)
- **source:** Alice Wong expert review, Jun 2026

### Linked Personas
- `layer-2-entities/personas/COMBO-005-turkey-denim-specialist.md`
- `layer-2-entities/personas/COMBO-004-china-medium-woven.md`

---

## Section 2: Knit Apparel

---
**Dimension:** DIM-4-product-focus | **ID:** product-knit

**Products:** T-shirts, polos, activewear, innerwear, thermals, socks
**Raw material:** Yarn (cotton, poly, blends)
**Lead time:** 60–90 days
**Seasonality:** Relatively stable (basics = year-round demand)

### Compliance
- **REACH** (`layer-1-reasoning/regulations/REG-REACH.md`) — dyes
- **UFLPA** (`layer-1-reasoning/regulations/REG-UFLPA.md`) — if cotton → US
- OEKO-TEX Standard 100

### WIP Profile
- **production_cycle_days:** 60–90
- **fob_per_unit_usd:** $4.00–5.80 (basic T-shirt) | $5.00–80.00+ (knitwear/sweater)
- **cost_structure:** fabric/yarn 45–55% | labor 15–25% | wet_process 2–3% (basic softener) | machine_depreciation 1–3% (basic) to 8–15% (sweater machines)
- **wip_stages:**
  1. Yarn/fabric receipt (~2 days)
  2. Cut (basic) OR Machine programming + panel knit (knitwear) (~5–7 days)
  3. Sew / Link (knitwear) (~7 days)
  4. Wet finish — softening, anti-pilling, fulling, pre-shrink, garment dye (~5 days)
  5. Block & press (knitwear) (~3 days)
  6. QC — pilling grade, gauge accuracy, hand-feel, shrinkage (~2 days)
  7. Pack & ship (~2 days)
- **typical_margin_band:** 8–12%
- **seasonality:** basic knit = year-round | knitwear/sweater = EXTREME 70%+ revenue Jul–Nov
- **bottleneck:** Yarn sourcing (cashmere/merino price volatility) | Machine availability (sweater peak season)
- **raw_material_sensitivity:** [cotton_jersey, yarn_acrylic, yarn_merino, yarn_cashmere]
- **fiber_price_volatility:** cotton $3–6/kg | acrylic $2–4 | merino $12–20 | cashmere $80–200/kg
- **source:** Alice Wong expert review, Jun 2026

### Linked Personas
- `layer-2-entities/personas/COMBO-001-south-asian-small-knit.md`
- `layer-2-entities/personas/COMBO-002-bangladesh-bank-lc.md`
- `layer-2-entities/personas/COMBO-006-vietnam-fdi-knit.md`
- `layer-2-entities/personas/COMBO-007-indonesia-family-run.md`

---

## Section 3: Woven Apparel

---
**Dimension:** DIM-4-product-focus | **ID:** product-woven

**Products:** Shirts, trousers, jackets, formal wear
**Raw material:** Woven fabric (cotton, poly, linen, blends)
**Lead time:** 90–120 days (longer due to complexity)
**Seasonality:** Moderate (spring/fall collections drive peaks)

### Compliance
- **REACH** (`layer-1-reasoning/regulations/REG-REACH.md`) — finishing chemicals
- **UFLPA** (`layer-1-reasoning/regulations/REG-UFLPA.md`) — if cotton → US

### WIP Profile
- **production_cycle_days:** 90–120
- **fob_per_unit_usd:** $6.00–18.00 (shirts, trousers, formal)
- **cost_structure:** fabric 45–55% | labor 20–28% | wet_process 3–6% | finishing 2–4%
- **wip_stages:**
  1. Fabric receipt & inspection (~3 days)
  2. Cut & bundle (~5 days)
  3. Sew — higher complexity vs knit (~10 days)
  4. Finishing & pressing (~5 days)
  5. QC — dimensional accuracy, colorfastness, seam strength (~3 days)
  6. Pack & ship (~3 days)
- **typical_margin_band:** 9–13%
- **seasonality:** moderate — spring/fall collections drive peaks
- **raw_material_sensitivity:** [cotton_woven_fabric, polyester_blend, linen]
- **source:** Alice Wong expert review + KB apparel data, Jun 2026

### Linked Personas
- `layer-2-entities/personas/COMBO-004-china-medium-woven.md`
- `layer-2-entities/personas/COMBO-014-india-small-woven.md`

---

## Section 4: Home Textiles

---
**Dimension:** DIM-4-product-focus | **ID:** product-home-textiles

**Products:** Towels, bed sheets, curtains, table linen, soft furnishings, rugs
**Raw material:** Cotton yarn/fabric (often thicker gauges)
**Lead time:** 60–90 days
**Seasonality:** Moderate (Q3–Q4 peak for holiday gifting)

### Compliance
- **REACH** (`layer-1-reasoning/regulations/REG-REACH.md`) — dyes, fire retardant chemical finishes
- **UFLPA** (`layer-1-reasoning/regulations/REG-UFLPA.md`) — if cotton → US
- OEKO-TEX Standard 100

### Country Strength
Pakistan (world-leading terry/woven), India (bed linen, rugs), Turkey (premium), Egypt (long-staple cotton)

### WIP Profile
- **production_cycle_days:** 60–90
- **fob_per_unit_usd:** $2.50–12.00 (towels, bedding)
- **cost_structure:** fabric/yarn 50–60% | labor 18–25% | wet_process 4–7% | finishing 3–5%
- **wip_stages:**
  1. Yarn/fabric receipt (~2 days)
  2. Weaving / Terry loop formation (~7 days)
  3. Bleaching & dyeing (~5 days)
  4. Lab dip approval — BOT (shade consistency across lots) (~3 days)
  5. Cutting & hemming / stitching (~5 days)
  6. QC — GSM, shrinkage, colorfastness, fire retardant compliance (~3 days)
  7. Pack & ship (~2 days)
- **typical_margin_band:** 7–11%
- **seasonality:** moderate — Q3–Q4 peak for holiday gifting
- **bottleneck:** Lab dip shade consistency; fire retardant compliance (if FR grade required)
- **raw_material_sensitivity:** [cotton_yarn, cotton_fabric]
- **source:** KB home textiles data, Jun 2026

### Linked Personas
- `layer-2-entities/personas/COMBO-009-pakistan-home-textile.md`
- `layer-2-entities/personas/COMBO-001-south-asian-small-knit.md`

---

## Section 5: Organic / Sustainable Textiles

---
**Dimension:** DIM-4-product-focus | **ID:** product-organic

**Products:** Any garment category made with organic/recycled materials
**Raw material:** Organic cotton, recycled polyester, Tencel, linen
**Lead time:** 90–120 days + 2–4 weeks for organic cotton availability
**Premium:** 10–30% higher than conventional

### Certifications Required
- `layer-2-entities/esg-standards/ESG-GOTS.md` — organic fiber chain of custody (mandatory)
- `layer-2-entities/esg-standards/ESG-FAIRTRADE.md` — farm-level social compliance
- `layer-2-entities/esg-standards/ESG-C2C.md` — premium circular credentials
- `layer-2-entities/esg-standards/ESG-ROC.md` — regenerative organic

### UFLPA Advantage
Inherently more traceable — farm registration, gin certification, spinning chain of custody all documented.
See `layer-2-entities/traceability/TRACE-ORGANIC-ADVANTAGE.md`

### Buyer Demand
Growing 20–30% annually: H&M Conscious, Patagonia, Pact, Everlane

### Country Strength
India (#1 organic cotton globally — 51% share), Turkey, Tanzania

### WIP Profile
- **production_cycle_days:** 90–120 days + 2–4 weeks organic cotton availability buffer
- **cost_structure:** fabric 45–55% (premium +20–40% vs conventional) | labor 18–25% | certification overhead 3–8%
- **wip_stages:** Same as underlying category (knit/woven/home textile) + traceability documentation at every stage
- **typical_margin_band:** 10–16% (10–30% premium over conventional)
- **certification_overhead:** GOTS audit + re-certification 1–2% of revenue annually
- **raw_material_sensitivity:** [organic_cotton, recycled_polyester, tencel]
- **uflpa_advantage:** Inherently more traceable — farm registration + gin certification + spinning chain documented
- **source:** KB organic data, Jun 2026

### Linked Personas
- `layer-2-entities/personas/COMBO-003-india-large-vertical-integrator.md`
- `layer-2-entities/personas/COMBO-008-india-organic-cotton-medium.md`
