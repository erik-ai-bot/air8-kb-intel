---
type: product
id: PROD-DDP
---
# PROD-DDP: DDP Financing

## What It Does
Financing for DDP (Delivered Duty Paid) shipments where supplier is responsible for customs clearance in destination country.

## Applies When
- incoterm = DDP or DDU
- Import complexity is high (EU, US customs)

## Risk Note
When Air8 entity is the importer of record under DDP, Air8 bears direct compliance risk for [[../regulations/REG-REACH]] and customs requirements.

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]] (DDP-specific variant)

## Best Fit Combos
- [[personas/COMBO-013-multi-country-group]]
