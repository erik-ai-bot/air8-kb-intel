---
type: product-category
id: HARDGOODS
layer: 2
---

# Hardgoods Product Categories

This file covers all 7 hardgoods categories (19 product types + cookware) with WIP gate milestones, risk levels, key compliance requirements, and market intelligence alerts.

**Note:** "Home Textiles" in this file refers to hardgoods-category home textiles (towels, bedding manufactured as hard-process goods). This is distinct from the apparel-sector Home Textiles in `APPAREL.md`.

---

## Summary Table

| Category                    | Products                                 | Risk Level   | Gates | Key Risk                              |
|-----------------------------|------------------------------------------|--------------|-------|---------------------------------------|
| 1. Metal Artware            | Metal Décor, Brass Artware               | 🔩 High      | 5     | Copper tariff T1 exposure             |
| 2. Glass Artware            | Glass Artware                            | 🔷 High      | 4     | Annealing defect rate                 |
| 3. Ceramic & Resin          | Ceramic & Resin Artware                  | 🏺 High      | 4     | Lead/cadmium leaching; BOT: glost fire|
| 4. Furniture                | Indoor Furniture, Outdoor Furniture      | 🪑 High      | 5     | CARB Phase 2; Salt spray 21-day delay |
| 5. Home Textiles            | Home Textiles (hardgoods)                | 🧵 Medium    | 4     | Lab dip shade consistency             |
| 6. Lighting                 | Luminaire (LED/decorative)               | 💡 High      | 5     | Copper tariff + UL/CE non-transfer    |
| 7. Hand & Power Tools / Seasonal | Hand Tools, Power Tools, Holiday Décor, Christmas Trees | 🛠️ High / 🎄 Medium | 3–5 | Safety cert re-test on geo shift |
| + Cookware                  | Hard-Anodized Cookware                   | 🍳 Medium    | 4     | PFAS compliance (EU)                  |

---

## Universal Rules

- **PP Sample ★** written approval is required before mass production for ALL product types, no exceptions.
- All prerequisite gates must be completed in sequence before advancing.
- **BOT** = Bottleneck — the step that causes the most delays and costs if missed.
- Gate nodes: green border for G1/G2/G3/G4 gates; orange border for PP Sample ★.

---

## Category 1: Metal Artware 🔩 High Risk

**Products:** Metal Décor, Brass Artware

### Metal Décor — 5 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Material Specification Sign-off | Metal grade / alloy / purity confirmed before production begins |
| G2 | Color Swatch Approval | Anodizing tone / powder coat / paint confirmed before bulk surface treatment |
| G3 | Finishing Swatch Approval | Matte / gloss / brushed / hammered / antique / hand-painted swatch retained as reference |
| G4 | REACH Heavy Metal Compliance | Cr VI, nickel, lead, cadmium test report (3–5 days) before bulk finishing |
| G5 | PP Sample ★ | Fully finished piece, written sign-off required |

### Brass Artware — 5 WIP Gates
Same gate sequence as Metal Décor. Electroplating gate = REACH gate (G4).

### 📊 T1 Copper Tariff Alert (July 2026)

**Metal Décor:** T1 exposure depends entirely on actual alloy composition — NOT the product name or finish.
- True solid brass = high exposure
- Zinc alloy (zamak) with copper plating = near-zero exposure
- **Check G4 REACH test report to confirm alloy**
- Premium channel buyers (Restoration Hardware, Williams-Sonoma) shifting to India for authentic brass
- Mass market buyers (Walmart, Target) stable on zamak

**Brass Artware:** Brass is 60–70% copper — highest direct T1 exposure of all hardgoods categories.
- China brass artware suppliers face double squeeze: export tariff + copper input cost
- India (Moradabad cluster) is the primary buyer diversification destination
- Domestic copper supply chain gives India structural cost insulation Vietnam cannot match
- G4 REACH test report confirms actual alloy composition — use to verify true brass vs zamak exposure

See `skills/hardgoods-analytics/references/copper-tariff-market-intelligence.md` for full analysis.

---

## Category 2: Glass Artware 🔷 High Risk

**Products:** Glass Artware

### Glass Artware — 4 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Color/Design Proof | Color match + pattern confirmed on full kiln-test piece before bulk production |
| G2 | Annealing Test | Polariscope pass required (stress-free annealing); reject = kiln temperature profile adjustment |
| G3 | REACH Compliance | Lead crystal / surface treatment chemicals (if applicable) |
| G4 | PP Sample ★ | Full piece with approved color / finish / structural integrity, written sign-off required |

### Key Risk
Annealing defect rate is the primary production bottleneck. Polariscope test at G2 must be completed before bulk production runs to avoid kiln restart costs.

---

## Category 3: Ceramic & Resin 🏺 High Risk

**Products:** Ceramic & Resin Artware

### Ceramic & Resin — 4 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Glaze/Color Swatch Approval | FIRED tile swatch required (unfired is not representative) |
| G2 | Finishing Swatch Approval | Gloss / matte / textured / crackle glaze confirmed |
| G3 | Heavy Metal Compliance Test | Lead/cadmium leaching per ASTM C738/C927, EN 1388, FDA CFR 21, CA Prop 65 (3–5 days); run in parallel with glazing |
| G4 | PP Sample ★ | Written sign-off required |

### ⚠️ BOT (Bottleneck)
Glost firing = most expensive gate. Cooling too fast = dunting cracks. Pieces touching = fused together.
Run G3 in parallel (not sequential) to avoid extending overall lead time.

---

## Category 4: Furniture 🪑 High Risk

**Products:** Indoor Furniture, Outdoor Furniture

### Indoor Furniture — 5 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Material Certification | FSC chain of custody + CARB Phase 2 compliance for composite wood (MDF / plywood / particleboard) |
| G2 | Color/Finish Swatch Approval | Wood stain / paint / lacquer / varnish + fabric colorway confirmed |
| G3 | Formaldehyde/VOC Pre-Production Test | CARB Phase 2 / EU E1 / JIS F★★★★ (7–14 days); **MUST START DAY 1 OF PRODUCTION** |
| G4 | Structural Load Test | ASTM F2057 tip-over test mandatory for US case goods (wardrobes, bookcases, dressers) |
| G5 | PP Sample ★ | Fully assembled, written sign-off required |

### Outdoor Furniture — 5 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Material Certification | FSC (teak) + stainless steel / hot-dipped galvanized hardware grade + REACH for powder coat |
| G2 | Color/Finish Swatch Approval | Frame powder coat / teak oil / PE wicker color confirmed |
| G3 | Salt Spray + UV Test | ASTM B117 (min 500 hrs = 21 days for steel) + UV weathering (AATCC 16 / EN ISO 105-B02); **MUST START DAY 1** — cannot compress; these ARE the critical path |
| G4 | Structural Load Test | Frame integrity under rated outdoor load (wind + dynamic) |
| G5 | PP Sample ★ | Fully assembled outdoor piece, written sign-off required |

### ⚠️ BOT (Outdoor Furniture)
Salt spray + UV = 21-day critical path. Cannot be compressed. Starting late = production delay of exactly 21 days minimum.

### 📊 Market Alert (July 2026)
Outdoor furniture is subject to active sourcing diversification (China → Vietnam) driven by buyer tariff-risk policy — NOT cost arbitrage.
- China remains cheaper, but buyers are allocating 10–30% of wallet to Vietnam as strategic hedge
- This is a seasonal product (once-a-year purchase), so each buying season is a binary decision point — no mid-season recovery
- Track buyer China/Vietnam allocation % as a leading risk indicator

See `skills/hardgoods-analytics/references/outdoor-furniture-market-intelligence.md` for full analysis.

---

## Category 5: Home Textiles 🧵 Medium Risk

**Products:** Home Textiles (hardgoods context — towels, bedding, soft furnishings as manufactured goods)

### Home Textiles — 4 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Lab Dip Approval | Dyed yarn / fabric sample submitted to customer before bulk dyeing; shade band ±5% max |
| G2 | Color Range Sample | Full colorway range (all options in PO) submitted for confirmation after Lab Dip |
| G3 | Bulk Fabric Approval | Washed / shrunk representative fabric panel approved before cutting; includes shrinkage test |
| G4 | PP Sample ★ | Fully sewn garment / textile piece with approved color, written sign-off required |

### Key Risk
Lab dip shade consistency — if shade band exceeds ±5%, buyer rejects and G1 restarts. Each iteration = 5–7 days.

---

## Category 6: Lighting 💡 High Risk

**Products:** Luminaire (LED / decorative lighting)

### Luminaire — 5 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Electrical Safety Sign-off | Driver / transformer spec + wiring diagram approved before PCB production |
| G2 | Color Swatch (if decorative) | Shade material / color confirmed |
| G3 | Safety Certification | UL 1598 (US), CE LVD (EU), or ETL equivalent; test lab submission; 2–4 weeks |
| G4 | EMC/EMI Test | FCC Part 15 (US) / CE EMC (EU) for any electronic driver |
| G5 | PP Sample ★ | Fully wired and operational sample, written sign-off required |

### 📊 T1 Copper Tariff Alert (July 2026)
Lighting faces the most severe T1 double compression:
- Section 301 tariff on finished goods
- Copper input cost pressure on drivers, wiring, and heat sinks

**Geo diversification is slow:** Safety certifications (G3 — UL/CE) do not transfer between production geographies. Require 2–4 weeks re-testing for any geo shift, making rapid China exit difficult.

China lighting suppliers are at high risk of cash flow deterioration even if volumes hold. Financing demand from this segment expected to increase.

See `skills/hardgoods-analytics/references/copper-tariff-market-intelligence.md` for full analysis.

---

## Category 7: Hand & Power Tools / Seasonal 🛠️ High / 🎄 Medium

**Products:** Hand Tools, Power Tools, Holiday Décor, Christmas Trees

### Hand Tools — 4 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Material/Steel Grade Sign-off | Steel grade and alloy specification confirmed |
| G2 | Drop Forge/Hardness Test | Mechanical property verification post-forging |
| G3 | Safety/Ergonomics Test | GS / CE / ANSI certification |
| G4 | PP Sample ★ | Written sign-off required |

### Power Tools — 5 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Electrical Safety Sign-off | Motor and wiring specification approved |
| G2 | EMC/EMI Test | Electromagnetic compatibility per FCC/CE requirements |
| G3 | Safety Cert | UL / CE / GS certification; test lab submission |
| G4 | Performance/Torque Test | Output performance verified against rated specs |
| G5 | PP Sample ★ | Written sign-off required |

### 📊 T1 Copper Tariff Alert — Power Tools (July 2026)
Copper-wound motors are the core component — moderate T1 exposure.
Slower-moving risk than lighting or brass artware. Monitor supplier margin trends before escalating.
Safety cert re-testing (G3) required for any geo shift.

### Holiday Décor — 3 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | Color Swatch | Color palette confirmed |
| G2 | Finishing Swatch | Surface finish / coating confirmed |
| G3 | PP Sample ★ | Written sign-off required |

### Christmas Trees — 4 WIP Gates (FR Flammability First)

| Gate | Name | Description |
|------|------|-------------|
| G1 | FR Flammability Test | **Passes BEFORE color swatch** (BS 5852 / California TB 117 / EN 13501) |
| G2 | Color Swatch | Color palette confirmed post-FR pass |
| G3 | Finishing Swatch | Surface finish confirmed |
| G4 | PP Sample ★ | Written sign-off required |

**Critical:** FR Flammability is Gate 1 — non-negotiable sequence. Starting color swatch before FR pass wastes all sample materials if FR fails.

---

## Hard-Anodized Cookware 🍳 Medium Risk

**Note:** Cookware is tracked separately from the 7 main categories.

### Hard-Anodized Cookware — 4 WIP Gates

| Gate | Name | Description |
|------|------|-------------|
| G1 | PFOA/PFAS-Free Declaration | Non-stick coating material declaration; PFAS compliance for EU |
| G2 | Anodizing Spec Sign-off | Hardness (Vickers), thickness (μm), color confirmed |
| G3 | Food Safety / FDA Test | FDA CFR 21 / EU 10/2011 migration test for food contact |
| G4 | PP Sample ★ | Written sign-off required |

### Key Compliance Context
- EU PFAS restrictions are expanding — PFOA already banned; broader PFAS ban under REACH being phased in
- G1 declaration must name specific non-stick coating compound (not just "PFOA-free")
- G3 migration testing takes 7–10 days; must be scheduled early in production

---

## Defect Classification by Product Type
> Source: Josephine Cheung expert input, Jun 2026
> 🔴 Critical = reject/hold shipment | 🟡 Minor = acceptable within tolerance or rework

### Cookware — Without Coating (Stainless Steel, Cast Iron, Uncoated Aluminum)
🔴 Critical: Sharp edges/burrs on rims, handles, or base | Handle detachment or instability under load | Structural deformation affecting stovetop stability | Non-food-safe base materials (lead/cadmium exceeding limits) | Cast iron cracks or fractures | Missing/incorrect compliance markings (CA Prop 65, food contact)
🟡 Minor: Minor surface scratches or machining marks (non-structural) | Slight color variation or uneven polishing | Minor dents not affecting function | Off-center logo | Slight warping of base (<1mm)

### Cookware — With Coating (PTFE/Ceramic/Enamel)
🔴 Critical (PTFE): Coating peeling/flaking/blistering | PFOA or prohibited chemical content | Coating adhesion failure | Exposed base metal on cooking surface | Handle detachment
🔴 Critical (Ceramic sol-gel): Coating chipping/cracking on cooking surface | Heavy metal leaching (Pb/Cd) above limits | Surface porosity allowing bacterial harbor
🔴 Critical (Enamel): Chipping on interior cooking surface (ingestion risk) | Lead/cadmium in enamel frit above limits | Base metal exposed on cooking surface
🟡 Minor: Cosmetic scratches not penetrating coating | Slight color variation | Minor drips at rim (non-cooking zone) | Slight gloss variation

### Glass (Drinking Ware, Containers, Bakeware)
🔴 Critical: Sharp chips or cracks | Seam cracks or stress fractures | Lead/cadmium in decorative coating above regulatory limits | Thermal shock failure (bakeware) | Improper annealing (spontaneous breakage risk)
🟡 Minor: Minor bubbles or inclusions within tolerance | Slight ovality | Minor scratches on non-contact surfaces | Slight decoration misalignment

### Ceramic Dining Ware (& Resin Artware)
🔴 Critical: Lead/cadmium leaching above FDA/EU limits | Chipping exposing rough or sharp base clay | Crazing (micro-cracks in glaze — bacterial harbor) | Structural fractures | Glaze crawling on food-contact surface
🟡 Minor: Pinhole in glaze (non-contact zone) | Minor color variation within tolerance | Slight warping within flat tolerance | Slight over/under-spray of decoration

### Luminaire (Indoor / Outdoor)
🔴 Critical: Live parts accessible to contact (IEC 60598) | Insulation failure / short circuit risk | Incorrect IP rating vs claim (outdoor) | Non-compliant wiring (color coding, gauge) | Overheating above rated temperature | Missing CE/UL marking | Incorrect lamp compatibility labeling
🟡 Minor: Minor scratches on housing (non-functional) | Slight color variation in finish | Minor surface blemishes on shade | Off-center logo

### Hand Tools & Power Tools
🔴 Critical: Shank/handle detachment under load | Incorrect material grade (hardness failure) | Blade geometry out of spec (cutting tools) | Torque rating failure (sockets/wrenches) | Power tool: no double insulation compliance | Missing safety guard | Non-compliant markings (size/rating)
🟡 Minor: Surface rust on non-functional zone (cosmetic only) | Minor handle finish variation | Off-center stamping | Slight packaging damage

### Seasonal Products (Holiday Décor, Christmas Trees, Ornaments)
🔴 Critical: Flammability non-compliance (artificial tree — UL 588 / BS 8428) | Lead paint/prohibited coatings on ornaments | Sharp wire ends accessible on wreaths/garlands | Electrical: unsafe extension cords or improper lighting sets | Structural collapse (tree stand failure) | Choking hazard ornaments in children's range without marking
🟡 Minor: Minor color variation in ornaments | Slight irregularity in artificial foliage | Minor paint imperfections (non-lead) | Slight size variation within tolerance | Packaging cosmetic damage

### Furniture (Indoor / Outdoor)
🔴 Critical: CARB Phase 2 formaldehyde non-compliance (wood panels) | Salt spray failure (outdoor, <500hr) | Structural instability under load test | Missing/incorrect safety hardware | Non-compliant surface coating chemicals (REACH)
🟡 Minor: Minor surface scratches in non-structural zones | Color variation within tolerance | Minor assembly mark-up | Slight dimension variance within spec

