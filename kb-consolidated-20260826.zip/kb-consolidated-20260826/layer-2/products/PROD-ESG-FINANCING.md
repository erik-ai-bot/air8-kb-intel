---
type: product
id: PROD-ESG-FINANCING
---
# PROD-ESG-FINANCING: ESG-Linked Financing

## What It Does
Preferential pricing (10–25 bps discount) for suppliers meeting defined ESG criteria. Funded via IFC green/social bond eligibility.

## Eligibility
- Verifiable ESG certifications: [[esg-standards/ESG-GOTS]], [[esg-standards/ESG-FAIRTRADE]], [[esg-standards/ESG-C2C]], [[esg-standards/ESG-ROC]]
- IFC eligibility check passed
- Renewable energy >20% of factory consumption
- Women employment >40% of workforce

## Applies When
- [[../../layer-1-reasoning/pain-points/esg/PP-ESG-001-credentials-not-monetized]] is active

## Discount
10–25 bps off standard pricing

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/esg/PP-ESG-001-credentials-not-monetized]]

## Best Fit Combos
- [[personas/COMBO-003-india-large-vertical-integrator]]
- [[personas/COMBO-008-india-organic-cotton-medium]]

## ESG Reference
- [[esg-standards/ESG-IFC]]
