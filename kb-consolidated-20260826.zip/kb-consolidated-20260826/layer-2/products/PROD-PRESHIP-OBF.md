---
type: product
id: PROD-PRESHIP-OBF
---
# PROD-PRESHIP-OBF: Order Book Financing (Pre-Shipment)

## What It Does
Financing based on confirmed PO, disbursed BEFORE production starts. Supplier uses funds to buy raw materials and pay workers.

## Eligibility
- Revenue >$10M
- Existing ARP client
- LF vendor preferred

## Applies When
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]] is active
- Revenue >$10M

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]

## Best Fit Combos
- [[personas/COMBO-003-india-large-vertical-integrator]]
- [[personas/COMBO-008-india-organic-cotton-medium]]
- [[personas/COMBO-013-multi-country-group]]
