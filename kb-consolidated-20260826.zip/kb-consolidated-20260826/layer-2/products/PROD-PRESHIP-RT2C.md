---
type: product
id: PROD-PRESHIP-RT2C
---
# PROD-PRESHIP-RT2C: Rapid Trade 2 Cash (Pre-Shipment, lighter)

## What It Does
Pre-shipment financing with lighter credit check, based on existing ARP track record. Faster to approve than OBF.

## Eligibility
- Revenue >$1M
- Existing ARP client with >6 months good track record

## Applies When
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]] is active
- Existing Air8 client
- Revenue $1–10M

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]

## Best Fit Combos
- [[personas/COMBO-001-south-asian-small-knit]]
- [[personas/COMBO-002-bangladesh-bank-lc]]
- [[personas/COMBO-014-india-small-woven]]
