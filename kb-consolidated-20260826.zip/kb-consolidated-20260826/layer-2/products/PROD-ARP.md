---
type: product
id: PROD-ARP
---
# PROD-ARP: Accounts Receivable Purchase (Post-Shipment)

## What It Does
Air8 purchases supplier's invoice (receivable) after shipment. Pays supplier T+1 at 70–90% advance. Collects full amount from buyer at maturity.

## Eligibility
| Lane | Requirement |
|------|------------|
| LF Vendor (Lane A) | Revenue >$1M, operations >2yr, buyer_rel >2yr, KPI >90% |
| Non-LF (Lane B/C) | Revenue >$3M, operations >3yr, buyer_rel >3yr, KPI >90% |

## Applies When
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]] is active
- Eligible buyer pair exists with insurance coverage

## Not Suitable When
- Buyer has adverse_news = CRITICAL
- Buyer rating = E
- No insurance available for buyer

## Key Differentiators vs Bank LC
- No collateral required
- No personal guarantee
- T+1 disbursement (vs 30–60 day LC processing)
- Pricing: SOFR+4% minimum (vs 3–18% bank alternatives)

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[../../layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]

## Best Fit Combos
All combos (001–015) — core Air8 product

## Pre-conditions
Eligible buyer pair + insurance coverage available
