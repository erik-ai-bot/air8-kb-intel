---
type: product
id: PROD-SMARTWALLET
---
# PROD-SMARTWALLET: SmartWallet (Cash Flow Intelligence)

## What It Does
AI-powered dashboard for AR aging, payment forecasting, cash flow projection, and multi-buyer reconciliation. Non-financing tool (NFT) — for CFO persona.

## Applies When
- buyer_count ≥ 3
- CFO or finance team exists

## Solves Pain Points
- [[../../layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]] (visibility layer)

## Best Fit Combos
- [[personas/COMBO-003-india-large-vertical-integrator]]
- [[personas/COMBO-004-china-medium-woven]]
- [[personas/COMBO-008-india-organic-cotton-medium]]
- [[personas/COMBO-013-multi-country-group]]
