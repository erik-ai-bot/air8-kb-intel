# NODE · SCORING-FRAMEWORK

**What this is.** A calibrated, versioned scoring model. All weights, thresholds, tiers, gates, and caps live in the tables below — **changing a number means changing one cell**: fill in the `valid_to` date on the old row, add a new row with evidence and sample size. No other file changes.

**How these numbers execute**: `../layer1/L1-scoring-method.md`. Only rows with a blank `valid_to` are active.

## Framework Instances

| ID | Vertical | Max | Calibration basis | Predicts | Valid from | Valid to |
|---|---|---|---|---|---|---|
| fw:apparel-v1.1 | Apparel | 11 | 71 supplier-buyer flows (apparel financing ledger 2024-01–2026-06) | Retention (not demand) | 2026-07 | — |
| fw:hardgoods-v3.0 | Hardgoods | 15 | 139 suppliers / 14,048 FR rows (hardgoods ledger) | Retention | 2026-08 | — |
| fw:hardgoods-v2.1 | Hardgoods (thin-data fallback) | 11 | Same ledger, lead-level | Retention | 2026-07 | — |

Scores across frameworks are **not directly comparable** (11 and 15 are different scales). Compare tier or `score_pct`. v2.1 output must be labelled v2.1 — never presented as v3.0.

---

## Apparel v1.1 — Indicators

| Indicator | Max · Wt | Bands | Evidence (stickiness gap, n) | Valid from | Valid to |
|---|---|---|---|---|---|
| Activity (`act_months`) | 4 · 36% | ≥10 → 4 · 7–9 → 2 · else → 0 | 65.0pp, n=71 | 2026-07 | — |
| Growth (`yoy_growth`) | 3 · 27% | ≥+15% → 3 · −15% to +15% → 1 · <−15% → 0 | 43.8pp, n=71 | 2026-07 | — |
| Density (`density`) | 2 · 18% | ≥7.1 → 2 · ≥3.2 → 1 · else → 0 | 20.6pp / 15.7pp (percentile-remapped from ledger units) | 2026-07 | — |
| Category Spread (`category-spread`) | 2 · 18% | ≥2 segments → 2 · single → 0 | Mixed retention 84.6% vs single 35.3% | 2026-07 | — |

Category spread not determinable → Enrichment queue. **Do not award 0** — that asserts "single segment" when the truth is simply unknown.

**Tier**: A ≥9 · B ≥6 · C else. (Backtest: A 100% n=10 · B 88%, excl. buyer-caused churn 100% n=17 · C 30%→52% n=44)

---

## Hardgoods v3.0 — Indicators

| Indicator | Max · Wt | Bands | Evidence | Valid from | Valid to |
|---|---|---|---|---|---|
| Activity (`act_months`) | 4 · 27% | ≥10 → 4 · 7–9 → 3 · 4–6 → 1 · else → 0 | 88% vs 5% retention (83pp), n=139 | 2026-08 | — |
| Growth Trend (`trend`) | 3 · 20% | RISING → 3 · STABLE → 1 · else → 0 | 82% vs 19% (64pp) | 2026-08 | — |
| Product Breadth (`breadth`) | 3 · 20% | ≥8 → 3 · 4–7 → 1 · else → 0 | 79% vs 14% (65pp); source field censored at 10 — do not rescale | 2026-08 | — |
| Buyer Quality (`buyer-quality`) | 2 · 13% | US mass/discount retail → 2 · else → 0 | 80% vs 24% (56pp) | 2026-08 | — |
| Category (`category`) | 2 · 13% | Home textiles/décor → 2 · Kitchen/tableware → 1 · else → 0 | 73% vs 27% (46pp) | 2026-08 | — |
| Ticket (`ticket`) | ±1 · 7% | Within category range → +1 · Above penalty line → −1 · between → 0 | 59% vs 29% (30pp) | 2026-08 | — |

**Tier**: A ≥10 · B ≥6 · C else. (Backtest: 86% n=14 · 77% n=13 · 16% n=19)

### Ticket Category Ranges (shared by v3.0 and v2.1 — one copy only)

| Category | Range (+1) | Penalty line (above → −1) |
|---|---|---|
| Home Textiles / Bedding | $5K–50K | $60K |
| Home Decor | $2K–20K | $30K |
| Kitchen / Tableware | $2K–20K | $30K |
| Furniture | $5K–30K | $40K |
| Other (default) | $2K–30K | $50K |

---

## Hardgoods v2.1 (Fallback) — Indicators

Use when thin-data sources (customs, 1688-style) lack breadth, buyer identity, or avg invoice. Label output as v2.1 — never as v3.0.

| Indicator | Max | Bands | Notes | Valid from | Valid to |
|---|---|---|---|---|---|
| Cadence (`cadence`) | 3 | hi → 3 · good → 2 · min → 1 · else → 0 (thresholds by category — table below) | | 2026-07 | — |
| Category (`category`) | 3 | Home textiles/décor → 3 · Kitchen/tableware → 2 · Pet → 1 · else → 0 | | 2026-07 | — |
| Trend (`trend`) | 2 | RISING → 2 · STABLE → 1 · else → 0 | | 2026-07 | — |
| Buyer Count (`n_buyers`) | 1 | ≥2 → 1 | | 2026-07 | — |
| Country (`country`) | 1 | India / Hong Kong → 1 | India 56% / HK 60% / China 8% durable; removed in v3.0, retained here to compensate for the missing buyer-quality component | 2026-07 | — |
| Ticket (`ticket`) | ±1 | Use v3.0 range table above | One copy only, not duplicated | 2026-07 | — |

**Cadence thresholds by category:**

| Category | cad_min | cad_good | cad_hi | Evidence |
|---|---|---|---|---|
| Home Textiles / Bedding | 2 | 5 | 10 | |
| Home Decor | 2 | 5 | 15 | |
| Kitchen / Tableware | 2 | 4 | 8 | Cadence is the key differentiator: durable 3.5/month vs failed 1.4/month |
| Furniture | 2 | 3 | 6 | Ticket is the key differentiator: durable ≈$22K vs failed $64–296K |
| Default | 2 | 4 | 10 | |

**Tier**: A ≥7 · B ≥4 · C else.

---

## Gates & Caps

| Rule | Applies to | Condition | Effect | Evidence | Valid from | Valid to |
|---|---|---|---|---|---|---|
| flow-stale | apparel v1.1 | >6 months since last transaction with target buyer | Tier demoted one level | Stagnant flows and slow flows are different risks | 2026-07 | — |
| CNY domestic-only | hardgoods v3.0 + v2.1 | Only CNY domestic transactions | Hard exclude | 164/164 such invoices came from churned customers | 2026-07 | — |
| kill combo | hardgoods v3.0 + v2.1 | China + ≤1 buyer + ticket above penalty line + cadence below cad_min | Hard exclude | 4% durable fingerprint | 2026-07 | — |
| furniture cap | hardgoods v3.0 + v2.1 | Category = furniture | Max Tier B | 33% durable; must not reach A by stacking points | 2026-08 | — |
| declining cap | hardgoods v2.1 | Trend = DECLINING | Max Tier B | No A-tier behaviour recorded for declining suppliers | 2026-07 | — |

---

## Routing (←ROUTED_FROM— [EVENT-KB: PRODUCT])

| HS Chapter | Route | Basis |
|---|---|---|
| 61 / 62 | Apparel v1.1 | Chapter, authoritative |
| 63 / 57 / 94 | Hardgoods v3.0 (thin data → v2.1) | Chapter, authoritative |
| 50–60 | PARK — yarn/fabric mills sell to factories, not retailers | Chapter |
| 69 / 70 / 39 / 44 / 73 | Hardgoods, **text confirmation needed** (these chapters mix industrial goods) | Text |
| No HS, no text | Enrichment queue | Do not assign default or award 0 |

**Apparel segment reference** (for category-spread scoring):
Knit 6103-06 / 6109 / 6110 / 6114 / 6115 · Woven 6204-06 · Outerwear 6101-02 / 6201-03 / 6210 · Underwear 6107-08 / 6207-08 / 6212 · Infant/Children 6111 / 6209 · Sportswear 6112-13 / 6211 · Accessories 6116-17 / 6213-17 · Denim = product text only. Two HS codes within the **same segment** do not count as spread.

---

## Links

- **—SCORES→ [EVENT-KB: SUPPLIER]**: One verdict per supplier per run written back to DB (framework ID+version, component scores, total, tier, queue, gates triggered, date). Verdicts always cite the version that produced them; re-scoring under a new framework is a new verdict, not a correction.
- **—TIEBREAK_BY→ [EVENT-KB: COUNTRY]**: Score is primary in sort order; country breaks ties only (India/Pakistan preferred); financing need is the tertiary tie-breaker and never removes from the list. Normalise country values before comparing.
- **—READS→ [EVENT-KB: BUYER]**: Two read-only fields — `programme_status` (dead programme flows are never a selling point; 64% of churn in the ledger was buyer-caused) and `months_since_last_txn` (feeds the flow-stale gate).

---

## How to Change This Model

1. Fill `valid_to` on the old row
2. Add a new row: `valid_from`, new values, **evidence and n that justify the change**
3. Increment the framework version (fw:apparel-v1.2 — verdicts cite the version)
4. One line in `../layer1/L1-decision-log.md` explaining why

Prerequisites: **Trigger A** (new disbursement data, stickiness-gap peak has genuinely shifted, n ≥ 5 per band) · **Trigger B** (30+ BD call outcomes) · **Trigger C** (3 consistent counter-examples). Never change a rule for a single case.
