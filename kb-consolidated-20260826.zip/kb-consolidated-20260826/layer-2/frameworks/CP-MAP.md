# CP Map v2 — every checkpoint, its KB reads, its core logic

Backward-compatible with the existing skill's CP0–CP5. Same steps, same outputs, same Telegram citation style — only the file each CP reads has moved. Old→new mapping at the bottom.

## F1 Lead Scoring — Checkpoints

| CP | Name | L1 (how — method) | L2 (what — values/knowledge) | Core logic | Blocking? |
|---|---|---|---|---|---|
| CP0 | Data load & dedup | `layer1/L1-db-field-contract.md` | `NODE-indicator.md` (locators) | Map columns→indicators; trailing-12; nulls stay null; dedup on normalized name | Yes |
| CP1 | Vertical routing | `L1-ordering-and-gates.md` §3 | `NODE-scoring-framework.md` §ROUTED_FROM | HS chapter → framework; text = downgrade; none → Enrichment | Yes |
| CP2 | Component scoring | `L1-scoring-method.md` | **`NODE-scoring-framework.md` §USES_INDICATOR + Tier rules** | Banded additive scoring; filter `valid.to = null`; missing → Enrichment not zero; scores freeze | Yes |
| CP3 | Gate checks | `L1-ordering-and-gates.md` §gates | `NODE-scoring-framework.md` §Gates and caps | flow-stale / cny-domestic / kill-combo / furniture cap; adverse+default = NOT SCREENED here, expected | No |
| CP4 | Sort + call list | `L1-ordering-and-gates.md` §sort | `NODE-scoring-framework.md` §TIEBREAK_BY | Score primary; region tie-break; need tertiary; Floor/Bench/Gated visible; user filter re-sorts, never re-scores | No |
| CP4.5 | Shortlist enrichment | `L1-evidence-discipline.md` | **`NODE-adverse-screen.md` · `NODE-financing-need.md` · `NODE-outreach-profile.md` · `NODE-evidence-source.md`** | Adverse verdict → re-gate loop to CP3; need band → tiebreak/Floor; buyers/contacts per source boundary | No |
| CP5 | Export | `L1-evidence-discipline.md` | — | All rows out (not just top 20); audit log cites framework instance versions | No |

## F2 Supplier Scoring — Checkpoints

| CP | Name | L1 | L2 | Core logic | Blocking? |
|---|---|---|---|---|---|
| CP0 | Data load & dedup | `L1-db-field-contract.md` | `NODE-indicator.md` | Same as F1 — trailing-12, nulls stay null | Yes |
| CP1 | Coverage + buyer lookup | `L1-performance-coverage.md` | `NODE-bs-proxy.md` · DB buyer table | FR n ≥ 3, recency ≤ 24m, buyer resolved, QAQC data available | Yes |
| CP2 | Indicator scoring | `L1-scoring-method.md` · `L1-trend-method.md` | `NODE-performance-scorecard.md` · `NODE-product-trend.md` · `NODE-market-trend.md` · `NODE-adverse-screen.md` | 3-dim: Perf 45% / B/S Pair 40% / QAQC 15% | Yes |
| CP3 | Gate + assembly | `L1-ordering-and-gates.md` | `NODE-rating-assembly.md` · `NODE-adverse-screen.md` | MATERIAL → max Tier C; composite score → final tier | No |
| CP5 | Export | — | — | All rows; cite `scorecard_version`, `scorecard_date` | No |

## F3 Buyer Assessment — Checkpoints

| CP | Name | L1 | L2 | Core logic | Blocking? |
|---|---|---|---|---|---|
| CP0 | Data load | `L1-db-field-contract.md` | `NODE-buyer-indicator.md` | Buyer fields; intermediary → end brand | Yes |
| CP1 | Coverage | `L1-performance-coverage.md` | `NODE-buyer-indicator.md` | Programme status, payment data availability | Yes |
| CP2 | Scoring | `L1-scoring-method.md` | `NODE-buyer-scoring-framework.md` · `NODE-adverse-screen.md` | 3-dim buyer scoring. Bands TBD. DEFAULTED → T4 gate | Yes |
| CP3 | Buyer tier output | — | `NODE-pair-terms-matrix.md` | Buyer tier → pair terms row | No |
| CP5 | Export | — | DB buyer table | `buyer_tier` written | No |

> ⚠️ **F3 is a structural skeleton only.** CP2 bands are TBD — do not score buyers until Jerri provides calibrated thresholds.

## Citation format (Telegram)

`[KB: NODE-scoring-framework.md · fw:apparel-v1.1]` — file + instance version. The CP2 "Core logic" block in the Telegram message is **rendered from the node's YAML at runtime**, never hard-coded, so the message always matches what actually executed.

## The re-gate loop

CP4.5 is the only loop: adverse results feed Gate 1 back at CP3 semantics (MATERIAL+ → Gated Out tab), then CP4 re-sorts and backfills from Bench. Everything else is forward-only.

## Old file → new home

| Skill currently reads | Now reads | Content change |
|---|---|---|
| `L1-db-field-contract.md` | same (layer1/) + `NODE-indicator.md` | locators formalized per indicator |
| `L1-vertical-routing.md` | `NODE-scoring-framework.md` §ROUTED_FROM | none — same rules as links |
| `L1-scoring-apparel.md` / `L1-scoring-hardgoods.md` | `NODE-scoring-framework.md` §USES_INDICATOR | none — same bands, now versioned entries |
| `L1-ordering-and-gates.md` | `L1-ordering-and-gates.md` + node §Gates/§TIEBREAK | renamed (was `L1-pipeline-and-gates.md`); content unchanged |
| `L1-adverse-severity.md` | `NODE-adverse-screen.md` | ladder unchanged; now bands on a node linked to SUPPLIER |
| `L1-financing-need.md` | `NODE-financing-need.md` | six angles unchanged; now indicators with locators |
| `L1-evidence-discipline.md` | same (layer1/, stays L1) | cross-cutting method; applies to every node |
| `L1-buyer-types.md` *(referenced in skill but never existed in layer1 — pre-existing bug)* | `NODE-outreach-profile.md` §buyer-edge readings | fixed in skill v2 |
| old `L2-buyer-types.md` / `L2-supplier-types.md` / `L2-group-and-funding-types.md` | `NODE-outreach-profile.md` (+ funding readings in `NODE-financing-need.md`) | renamed: was mislabelled as entity types; it is the CP4.5 interpretation pattern |
| *(new)* | `L1-performance-coverage.md` | F2 CP1 coverage gate; FR minimums, buyer lookup, QAQC routing |
| *(new)* | `NODE-buyer-indicator.md` | F3 buyer data dictionary; source locators |
| *(new)* | `NODE-buyer-scoring-framework.md` | F3 buyer scoring; bands TBD (Jerri to calibrate) |
| *(new)* | `NODE-pair-terms-matrix.md` | Buyer tier × Supplier tier → pair financing terms; values TBD |
