# NODE · BUYER-SCORING-FRAMEWORK (F3 Buyer Assessment — Scoring)

**What this is.** F3's scoring rules. Translates buyer indicator values into a buyer rating (Tier 1–4 + UNKNOWN). The buyer rating feeds `NODE-pair-terms-matrix.md` (financing terms) and is also stored on the DB buyer record for use in F2 B/S Pair assessments.

**Status.** ⚠️ **Skeleton — thresholds TBD.** Sub-indicator structure is confirmed; scoring bands and tier cut points to be supplied by Jerri once calibration data is available. Do not score buyers until bands are filled in.

**How the numbers execute.** Same method as F1/F2: `L1-scoring-method.md` — banded additive scoring, `valid_to IS NULL` filter, missing → no band → Enrichment (never zero).

---

## Framework Instances

> When calibrated thresholds are added, create an entry below. Format follows `NODE-scoring-framework.md` governance (valid_from · evidence · n).

| Instance | Version | Vertical | Valid from | Valid to | Status |
|---|---|---|---|---|---|
| buyer-v0.1 | 0.1 | All buyers | TBD | — | ⚠️ Skeleton — no bands yet |

---

## Dimension 1 · Programme Health (40 pts max — TBD)

> **Why this dimension leads.** A dead or winding-down programme is the dominant buyer risk signal in the calibration data — it is both the most common driver of unexpected pair churn and the most detectable in advance.

| Sub-indicator | Max pts | Band | Valid from | Valid to |
|---|---|---|---|---|
| Programme status | — | TBD (ACTIVE → X · WINDING DOWN → Y · DEAD → 0) | TBD | — |
| Programme age (months) | — | TBD | TBD | — |
| Active Air8 supplier count | — | TBD (proxy for programme breadth and stickiness) | TBD | — |

---

## Dimension 2 · Payment Performance (30 pts max — TBD)

> **Why this dimension.** Air8's own FR data is the most reliable signal for buyer payment behaviour — it is from confirmed transactions, not self-reported. Even a small n (≥ 3 FRs) is meaningful because it is our data.

| Sub-indicator | Max pts | Band | Valid from | Valid to |
|---|---|---|---|---|
| Average payment delay (days) | — | TBD (e.g. ≤0 → X · 1–7 → Y · 8–30 → Z · >30 → 0) | TBD | — |
| Dispute rate | — | TBD | TBD | — |
| Worst payment event | — | TBD (NONE → X · DELAYED → Y · DISPUTED → Z · DEFAULTED → 0 + flag) | TBD | — |

**Missing data policy:** If buyer has zero FRs in Air8 DB (new buyer) → `OWN DATA: NONE`. Score Dimension 2 as UNKNOWN, not zero. Proceed to Dimension 3. Report partial.

---

## Dimension 3 · Market & Scale (30 pts max — TBD)

> **Why this dimension.** Buyer type and market trend are directional signals available even for buyers with no Air8 payment history. They are lower-confidence than D1/D2 but still informative for new buyer programmes.

| Sub-indicator | Max pts | Band | Valid from | Valid to |
|---|---|---|---|---|
| Buyer type premium | — | TBD (US mass retail vs EU fast fashion vs specialty vs unknown) | TBD | — |
| Buyer market trend | — | TBD (from NODE-market-trend: RISING → X · STABLE → Y · DECLINING → Z) | TBD | — |
| SKU rationalization signal | — | TBD (EXPANDING/STABLE → X · RATIONALIZING → Y · UNKNOWN → Z) | TBD | — |

---

## Buyer Tier Cuts (TBD)

> Cut points below are structural placeholders. Fill `valid_from` and add evidence + n when calibration is available.

| Tier | Score range (0–100) | Meaning | Effect on pair terms |
|---|---|---|---|
| T1 | ≥ TBD | Strong buyer — well-established programme, strong payment record, favourable market | Best terms (see NODE-pair-terms-matrix T1 row) |
| T2 | ≥ TBD | Adequate buyer — active programme, no major payment issues | Standard terms |
| T3 | ≥ TBD | Weak buyer — programme risk signals or payment delays | Restricted terms |
| T4 | < TBD | Poor buyer — dead/winding programme OR defaulted payment event | Minimal or no eligibility |
| UNKNOWN | — | Insufficient data to score | No terms issued until data obtained |

**DEFAULTED payment event → maximum T4 regardless of D1/D3 score.** A confirmed default is a hard gate, not a scoring input.

---

## Override Conditions

| Condition | Effect |
|---|---|
| `buyer_programme_status = DEAD` | Maximum T3 (programme is over; relationship is historical only) |
| `worst_payment_event = DEFAULTED` | Maximum T4 (hard gate regardless of other scores) |
| `INTERMEDIARY UNRESOLVED` | No tier — cannot assess buyer without confirmed end brand |
| All three dimensions UNKNOWN (no data) | Tier UNKNOWN — do not estimate |

---

## Score Change Protocol

When calibrated thresholds are supplied:
1. Fill band rows with `valid_from` + bands + `evidence` + `n`
2. Update instance table (version, valid_from)
3. Update `NODE-pair-terms-matrix.md` to reference new tier definitions
4. One line in `L1-decision-log.md`

Calibration prerequisites (same triggers as F1): Trigger A (n ≥ 5 per band) OR Trigger B (30+ BD outcomes by buyer) OR Trigger C (3+ consistent counter-examples).

---

## Links

- **—READS→ [NODE-buyer-indicator]**: indicator values used in scoring
- **—READS→ [L1-scoring-method]**: method — how banded additive scoring executes
- **—READS→ [NODE-market-trend]**: buyer market trend signal (Dimension 3)
- **—READS→ [NODE-outreach-profile]**: buyer type taxonomy (Dimension 3)
- **—READS→ [NODE-adverse-screen]**: DEFAULTED payment event → T4 hard gate override
- **—FEEDS→ [NODE-pair-terms-matrix]**: buyer tier → row selection in pair terms matrix
- **—FEEDS→ [DB buyer table]**: `buyer_tier`, `buyer_score`, `buyer_score_date`, `buyer_score_version`
- Decision log: `../layer1/L1-decision-log.md`
- Decision log: `../layer1/L1-decision-log.md`
