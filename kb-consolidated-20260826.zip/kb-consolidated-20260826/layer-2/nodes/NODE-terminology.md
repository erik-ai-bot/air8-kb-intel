# NODE · TERMINOLOGY

**What this is.** Two-part OCR normalization map for the SHI validation agent.

- **Part A — Field Name Aliases** (below): Different documents label the same field differently. Normalize the field name first before reading the value.
- **Part B — Value Aliases** (below): Different documents express the same value differently. E.g. "TT 30 days from BL" = "NET 30" on FOB shipment.


Read by: SHI Validation Skill (SV1 — Parse).

**This list is not exhaustive.** The agent is expected to:
1. Match phrases to the closest risk concept using trading domain knowledge when a phrase is not listed
2. FLAG unrecognised phrases to the Ops expert for confirmation (see `L1-reasoning-principles.md` — When terms are not in the KB)
3. After expert confirmation, new phrases are added here and logged in `ops/decision-log.md`

This file grows over time as new document variants are encountered in live operations.

---


## PART A — Field Name Aliases (by Document)

> Agent: identify which document you are reading first, then use that document's alias table.
> Same label (e.g. "Date") means different things on different documents.

---

### A1 — Purchase Order (PO)

| Canonical Field | Role | Common Aliases |
|---|---|---|
| `PO_NUMBER` | Primary key | Order No, Order Number, PO No, PO#, P.O. No., Purchase Order No, Order Ref, Reference No, Ref No, Your Order No |
| `ORDER_DATE` | When PO was issued | Date, PO Date, Order Date, Issue Date, Dated |
| `SHIP_BY_DATE` | Latest ex-factory / ship date | Ship By, Ship By Date, Required Delivery Date, Ex-Factory Date, EX-FACTORY, Ex Factory, Latest Ship Date, Shipment Date, Delivery Date |
| `BUYER` | Issuing party | Buyer, Customer, Purchaser, Bill To, Ordering Party |
| `SUPPLIER` | Receiving party | Supplier, Vendor, Seller, Manufacturer, Factory, To |
| `PAYMENT_TERMS` | Payment method + tenor | Payment Terms, Terms of Payment, Terms, Payment Conditions, Net Terms |
| `INCOTERMS` | Trade terms | Incoterms, Trade Terms, Delivery Terms, Shipment Terms, Price Terms |
| `CURRENCY` | Invoice currency | Currency, CCY, Ccy |
| `STYLE_NUMBER` | Line item product code | Style No, Style#, Item No, Item Code, Article No, SKU, Product Code, Part No, Model No, Code |
| `QUANTITY` | Units ordered | Quantity, Qty, QTY, PCS, Units, Nos, Pieces |
| `UNIT_PRICE` | Price per unit | Unit Price, Price, Rate, Price per Unit, Per PCS |
| `TOTAL_VALUE` | PO total | Total, Total Amount, Order Value, Grand Total, PO Value |

---

### A2 — Commercial Invoice (CI)

| Canonical Field | Role | Common Aliases |
|---|---|---|
| `INVOICE_NUMBER` | Primary key | Invoice No, Invoice#, Inv No, Inv#, Doc No, Bill No, CI No, Invoice Ref |
| `INVOICE_DATE` | When invoice was issued | Date, Date of Issue, Issue Date, Billing Date, Dated, Invoice Date |
| `PO_REF` | Cross-ref to buyer PO | PO No, Order No, Purchase Order No, Buyer's PO, Your PO, Your Order No, Customer PO, Ref No, Buyer's Ref |
| `SELLER` | Exporting party | Seller, Exporter, Shipper, Supplier, Vendor, From, Consignor, Beneficiary |
| `BUYER` | Importing party | Buyer, Importer, Consignee, Bill To, Purchaser, To, Customer, Sold To |
| `PAYMENT_TERMS` | Payment method + tenor | Payment Terms, Terms of Payment, Terms, Settlement Terms, Net Terms — Note: compare against PO payment terms for R1 check |
| `INCOTERMS` | Trade terms | Incoterms, Trade Terms, Delivery Terms, Price Terms |
| `CURRENCY` | Invoice currency | Currency, CCY, Ccy, Invoice Currency |
| `HS_CODE` | Customs classification | HS Code, HS, HTS Code, HTS, Tariff Code, Commodity Code, HTSUS |
| `COUNTRY_OF_ORIGIN` | Manufacturing origin | Country of Origin, Origin, Made In, Country of Manufacture, Place of Origin |
| `QUANTITY` | Units shipped | Quantity, Qty, QTY, PCS, Units, Nos |
| `UNIT_PRICE` | Price per unit | Unit Price, Price, Rate, Unit Cost, Per PCS |
| `GRAND_TOTAL` | Invoice total | Grand Total, Total Amount, Invoice Total, Total, Amount Due, Total Payable |
| `PORT_OF_LOADING` | Departure port | Port of Loading, POL, Loading Port, Port of Shipment, From Port |
| `PORT_OF_DISCHARGE` | Arrival port | Port of Discharge, POD, Destination Port, Discharge Port, To Port |
| `BANK_DETAILS` | Payment recipient | Bank Details, Beneficiary Bank, Payment To, Remit To — watch for R8: should be Air8 account |

---

### A3 — Bill of Lading (BL) / Air Waybill (AWB)

| Canonical Field | Role | Common Aliases |
|---|---|---|
| `BL_NUMBER` | Primary key | B/L No, BL No, Bill of Lading No, B/L Number, BL# |
| `AWB_NUMBER` | Primary key (air) | Air Waybill No, AWB No, AWB#, Waybill No |
| `BL_DATE` | On-board date — key for tenor calculation | Date of B/L, B/L Date, On Board Date, Shipped on Board Date, Date Laden on Board, Issue Date (on BL) |
| `INVOICE_REF` | Cross-ref to invoice | Invoice No, Invoice#, Inv No, CI No |
| `PO_REF` | Cross-ref to PO | PO No, Order No, Purchase Order No |
| `SHIPPER` | Exporting party — check vs supplier name for R5 | Shipper, Exporter, Consignor, Sender, From |
| `CONSIGNEE` | Receiving party | Consignee, To, To the Order of, To Order — "To Order of [Bank]" = negotiable BL under LC |
| `NOTIFY_PARTY` | Usually the actual buyer | Notify Party, Also Notify, Notify, Notification Party |
| `PORT_OF_LOADING` | Departure port | Port of Loading, POL, Loading Port, Place of Loading, Place of Receipt |
| `PORT_OF_DISCHARGE` | Arrival port | Port of Discharge, POD, Discharge Port, Destination Port |
| `VESSEL_NAME` | Carrying vessel | Vessel, Vessel Name, Ship Name, MV, S.S., Per Vessel |
| `VOYAGE_NUMBER` | Voyage ref | Voyage No, Voyage, Voy, Voy. |
| `CONTAINER_NUMBER` | Container ID | Container No, CNTR No, CTR No, Container#, Equipment No |
| `SEAL_NUMBER` | Seal ID | Seal No, SL No, Seal#, Seal |
| `GROSS_WEIGHT` | Total weight | Gross Weight, G.W., GW, Total Gross Weight |
| `TOTAL_CBM` | Total volume | Total CBM, CBM, Volume, M3, Measurement, Meas. |
| `FREIGHT_TERMS` | Who pays freight | Freight Prepaid / Freight Collect — values: PREPAID, COLLECT |
| `BL_TYPE` | Negotiability — key for R4 | See Value Aliases §BL Type |

Special BL signals for R4 detection:
- `FLXT-[number]` prefix on BL number → Flexport House BL → check AP4.1
- "House BL" / "Forwarder BL" / "HBL" → third-party issued, not carrier original
- "Surrendered" / "Telex Release" / "Express Release" → non-original BL

---

### A4 — Packing List (PL)

| Canonical Field | Role | Common Aliases |
|---|---|---|
| `PL_NUMBER` | Primary key | Packing List No, P/L No, PL No, Packing No |
| `PL_DATE` | Issue date | Date, Packing List Date, P/L Date, Issue Date |
| `INVOICE_REF` | Cross-ref to invoice | Invoice No, CI No, Inv No |
| `PO_REF` | Cross-ref to PO | PO No, Order No, Your PO |
| `CARTON_NUMBER` | Carton identifier | Carton No, CTN No, Case No, Box No, Carton Mark, Mark No, Nos. |
| `TOTAL_CARTONS` | Total carton count | Total Cartons, Total Ctns, Total Cases, No. of Cartons, Total Pkgs |
| `QTY_PER_CARTON` | Units per box | Qty per Carton, Qty/CTN, PCS per Carton, Pack, Inner Qty |
| `TOTAL_QUANTITY` | Total units | Total Qty, Total PCS, Total Units, Grand Total Qty |
| `GROSS_WEIGHT` | Weight incl. packaging | Gross Weight, G.W., GW, Gross Wt |
| `NET_WEIGHT` | Weight excl. packaging | Net Weight, N.W., NW, Net Wt |
| `TOTAL_CBM` | Total volume | Total CBM, CBM, Total Volume, M3, Total Measurement, Meas. |
| `CARTON_DIMENSIONS` | Box size | Carton Size, Dimensions, L x W x H, Outer Dimensions, Size (cm) |

---
## PART B — Value Aliases

> Once you know the field, normalize the value. Different docs express the same thing differently.

### Payment Method
| Canonical | Aliases |
|---|---|
| `T/T` | TT, T.T., Telegraphic Transfer, Wire Transfer, Bank Transfer, SWIFT Transfer |
| `O/A` | OA, O.A., Open Account, Net Terms, Account Terms |
| `D/A` | DA, D.A., Documents Against Acceptance, Documents vs Acceptance |
| `D/P` | DP, D.P., Documents Against Payment, Cash Against Documents, CAD |
| `L/C` | LC, L.C., Letter of Credit, Documentary Credit, Irrevocable LC |
| `CIA` | Cash in Advance, Advance Payment, Prepayment, 100% TT in Advance |

### Payment Tenor Patterns
```
T/T tenor:  (?:T/?T|Telegraphic Transfer)\s*(\d+)\s*days?\s*(?:after|from)?\s*(.+)?
NET tenor:  (?:Net|NET)\s*(\d+)\s*days?
O/A tenor:  (?:O/?A|Open\s*Account)\s*(\d+)\s*days?\s*(?:from|after)?\s*(.+)?
D/A tenor:  (?:D/?A)\s*(\d+)\s*days?
```
Reference event aliases:
- `BL_DATE`: "BL date", "B/L date", "Bill of Lading date", "date of B/L", "date of shipment"
- `INVOICE_DATE`: "invoice date", "date of invoice"
- `SIGHT`: "sight", "at sight"

**Cross-document payment tenor expressions (aliases):**
The same tenor may be written differently on different documents. Normalize to canonical form before comparing.

| Canonical | PO label | Invoice / system label | Notes |
|---|---|---|---|
| `T/T [X] days from BL` | NET [X] | TT [X] days from BL / TT [X] from date of B/L | FOB shipments; BL date = reference event |
| `O/A [X] days from BL` | NET [X] | O/A [X] / O/A [X] days from BL | O/A terms; same BL reference |
| `T/T [X] days from invoice` | NET [X] | TT [X] days from invoice date | Non-FOB or stated otherwise |

*Authority: Ops confirmed on live run FR 245/1950 Gee Gee/Uniek; logged 2026-08-13.*

### Incoterms
| Canonical | Aliases |
|---|---|
| `FOB` | F.O.B., Free On Board |
| `CIF` | C.I.F., Cost Insurance Freight |
| `CFR` | C.F.R., CNF, C&F, C+F, Cost and Freight |
| `EXW` | Ex Works, Ex-Works, Ex Factory, Ex-Factory |
| `DDP` | D.D.P., Delivered Duty Paid |
| `DAP` | Delivered At Place |
| `FCA` | F.C.A., Free Carrier |

### Quantity Units
| Canonical | Aliases |
|---|---|
| `PCS` | pcs, pcs., Pieces, Units, Nos, EA, Each, PC |
| `SET` | Set, Sets, Kit, Kits |
| `PR` | Pr., Pair, Pairs |
| `DZ` | DOZ, Dozen, Dozens |
| `KG` | kg, KGS, Kgs, Kilogram |
| `MT` | M/T, Metric Ton, Tonne |

### Shipment Mode
| Canonical | Aliases |
|---|---|
| `FCL` | Full Container, Full Container Load |
| `LCL` | Less Container, Consolidation, Consolidated |
| `AIR` | Air Freight, By Air, Airfreight |
| `SEA` | Sea Freight, By Sea, Ocean Freight |

### BL Type
| Canonical | Aliases |
|---|---|
| `ORIGINAL_BL` | Original, OBL, 3/3 Originals, Full Set |
| `SEA_WAYBILL` | Sea Waybill, Waybill, Non-Negotiable, Express BL |
| `SURRENDERED` | Surrendered, Telex Release, Express Release |

---

### Standard Trade Reference Codes

> Abbreviations that appear on trade documents. Provided for context and parsing — not exception triggers.

| Term | Full Form | Context |
|---|---|---|
| `SLAC` | Shipper's Load And Count | BL notation: carrier did not count/verify cartons |
| `NRA` | Named Rate Arrangement | Freight rate agreement between shipper and carrier |
| `S.BILL NO` | Shipping Bill Number | Indian customs export document reference |
| `IEC` | Importer Exporter Code | Indian regulatory export code |
| `AMS` | Automated Manifest System | US customs advance cargo reporting |
| `GSTIN` | Goods and Services Tax Identification Number | Indian tax registration number on commercial invoices |
| `LUT` | Letter of Undertaking | Indian GST zero-rated export compliance document |
| `RBI` | Reserve Bank of India | Appears on Indian FIRA/payment documents |

*Authority: Ops confirmed on live run FR 245/1950 Gee Gee/Uniek; logged 2026-08-13.*

---

