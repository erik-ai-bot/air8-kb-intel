# NODE · MARKET-TREND (Market Trend)

**What this is.** Rules for determining the market trend for a buyer's sector. Measures the trajectory of the end-market the buyer operates in — not the supplier's own business performance. Used in F2 (market trend dimension) and F3 buyer assessment (context overlay). The reasoning layer for trend assessment is in `../layer1/L1-trend-method.md`.

**Where results go.** DB fields: `market_trend`, `market_trend_sector`, `market_trend_basis`, `market_trend_source`, `market_trend_as_of`. Date every market trend finding — macro conditions change and an undated finding cannot be refreshed.

**Key distinction from product trend.** Product trend is about the supplier's own business range over time. Market trend is about the demand environment the supplier's buyer operates in. A supplier may have RISING product variety while selling into a CONTRACTING market — both signals are real and must be reported separately.

## Market trend categories

| Label | Definition |
|---|---|
| EXPANDING | Demand growing in the sector; new market entrants or increasing retail sales; rising import volumes for the category |
| STABLE | Mature market; no significant structural growth or decline; cyclical variation within normal bounds |
| CONTRACTING | Sector in structural decline; retail closures; shrinking import data; consumer shift away from the category |
| VOLATILE | High quarter-to-quarter swings; geopolitical sensitivity; unpredictable demand patterns; category subject to sudden policy or tariff changes |

VOLATILE is not the same as CONTRACTING. A volatile market may have aggregate growth but with high variance — that affects the risk profile of the receivable differently from a smoothly contracting one.

## Data sources (in priority order)

| Priority | Source type | Examples |
|---|---|---|
| 1 | Government statistics | US Census Bureau (import data, retail sales), Eurostat, ONS, ABS |
| 2 | Multilateral institutions | WTO trade data, World Bank commodity markets, ILO sector reports |
| 3 | Industry associations | Trade body import/export trackers, sector annual reports |
| 4 | Trade press | Sourcing Journal, Home Textiles Today, Furniture Today |
| 5 | News signals | Major retailer earnings reports, macro consumer sentiment surveys |
| 6 | Web research | General search; directional only |

Lower-priority sources corroborate higher-priority findings. Do not use news signals or web research to override government statistics pointing in the opposite direction.

## Country routing for market data

Use the buyer's primary market country to route to the appropriate data source:

| Buyer Market | Primary Sources |
|---|---|
| United States | US Census Bureau import data (trade.gov); Fed retail sales releases; major retailer earnings (Walmart, Target, Amazon, TJX) |
| European Union | Eurostat external trade statistics; ECB consumer expenditure survey |
| United Kingdom | ONS retail sales index; HMRC trade statistics |
| Canada | Statistics Canada trade data |
| Australia | ABS merchandise imports; retail trade data |
| Global / Multi-region | WTO trade data; World Bank pink sheet commodity data; ILO World Employment & Social Outlook |

For emerging or secondary markets, default to WTO data supplemented by trade press. Do not fabricate a source.

## Sector-specific signals

### Home Textiles / Bedding
- US: Census Bureau trade code 6301–6302 import volumes; major retailer (Bed Bath & Beyond successor entities, Walmart home, Amazon home) GMV trends
- Relevant signal: housing market activity (new household formation → bedding demand)

### Kitchen / Tableware
- US: restaurant supply vs direct-to-consumer split; gifting season data
- Relevant signal: home cooking trends, formal dining frequency (post-COVID recovery vs sustained change)

### Furniture / Home Décor
- US: US Census Bureau Advance Monthly Retail Trade (home furniture & furnishings); housing starts (lagged demand signal)
- Relevant signal: housing turnover rate; consumer confidence

### Apparel
- US: AAFA Annual Benchmarking Study; US Census Bureau textile and apparel import data
- Relevant signal: fashion cycle velocity, discount vs premium retail split

## How market trend feeds scoring

### F2 (market trend dimension)
A supplier selling into an EXPANDING market scores better on the market dimension, all else equal. The market dimension is an overlay on the supplier's own metrics — it does not replace them.

| Market Trend | Effect on F2 market dimension |
|---|---|
| EXPANDING | Positive — demand tailwind supports receivables performance |
| STABLE | Neutral |
| CONTRACTING | Negative — structural demand decline is a receivable quality risk |
| VOLATILE | Mixed — flag separately; do not score as EXPANDING or CONTRACTING |

### F3 (buyer assessment context overlay)
Market trend overlays the buyer's base rating:

- EXPANDING → improves buyer outlook (demand supports buyer's business)
- CONTRACTING → worsens buyer outlook (even a well-rated buyer faces structural headwinds)
- VOLATILE → flag as a risk factor in the buyer narrative; do not average with STABLE

## Staleness and expiry

Market trend findings have a shelf life. Macro conditions can shift materially within 6–12 months (tariff changes, consumer cycle turns, geopolitical events).

- Label every finding with `market_trend_as_of` date
- Do not carry forward an undated market trend finding
- Re-assess at each batch run; prior findings are informative but not binding

## What to record

| Field | Value |
|---|---|
| `market_trend` | EXPANDING / STABLE / CONTRACTING / VOLATILE |
| `market_trend_sector` | e.g. `home textiles`, `kitchenware`, `apparel` |
| `market_trend_basis` | e.g. `US Census Bureau import data + retailer earnings` |
| `market_trend_source` | Specific source URL or publication cited |
| `market_trend_as_of` | Date of most recent source used |
| `market_trend_note` | Required for VOLATILE; context for CONTRACTING; optional otherwise |

## Links

- **←READS— [L1-trend-method]**: Reasoning layer for trend assessment methodology
- **—FEEDS→ [NODE-performance-scorecard]**: Market trend feeds F2 market dimension
- **—FEEDS_OVERLAY→ [NODE-rating-assembly]**: F2 trend overlay only — not included in composite score; affects `final_tier_flags` directionally
- **—READS_BY_COUNTRY→ [NODE-evidence-source]**: Source routing by buyer market country
- **—CONTEXT_FOR→ [EVENT-KB: BUYER]**: Buyer assessment uses market trend as a context overlay (F3)
