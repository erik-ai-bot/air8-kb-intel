# NODE · EVIDENCE-SOURCE (Evidence Sources)

**What this is.** What each registry or document can and cannot determine. ADVERSE-SCREEN and FINANCING-NEED both select sources from here. CP4.5 uses the contact-finding hierarchy below when researching shortlist names.

---

## Contact-Finding Hierarchy (CP4.5)

Work through these in order. Stop when you have a named finance contact with a reachable route (direct email, direct line, or a named warm-introduction path). `NOT FOUND` with the sources checked ships as a completed record — an invented address does not.

**0. Internal first (for LF-tagged / own-book suppliers).** 128 of the NEXT names carry an LF tag. Those suppliers completed vendor onboarding, meaning a contact record already exists internally. For any tagged supplier, check the internal vendor record before running any external search. Web research only fills gaps that the internal record does not.

**1. Annual reports and prospectuses.** The single best external source. A listed or NEEQ-filed company must disclose its board secretary (董秘) and CFO, often with a direct line. An HKEX or NEEQ annual report gives you the only named finance contact where nothing else works — take one document, not a web search. For prospectuses, the IR contact is always published.

**2. Rating rationales.** PACRA / VIS / CRISIL / ICRA reports name the management they interviewed. This is how you get "GM Finance" as a title even when no email is published — pair the name with the company's published switchboard.

**3. Regulator filings.** SECP, MCA, Companies House give directors and registered addresses. Good for *who*; rarely gives *how to reach*.

**4. Trade fair exhibitor directories.** Canton Fair, Heimtextil, Magic — companies publish export-manager contacts there deliberately, so they are both acceptable sources and BD-friendly (the person expects calls). Search `"{company name}" site:cantonfair.net.cn` or equivalent.

**5. Certification databases.** Sedex, BSCI, Accord factory listings carry an audit contact person. The person is usually a compliance or operations manager, not finance — but they can route you.

**6. B2B self-published pages.** Alibaba / 1688 / Global Sources company profiles are self-disclosed by the supplier, so they pass the source rule. Pakistan and India exporters often list a WhatsApp Business number there. Acceptable as a contact source when clearly self-published.

**7. Company website.** Usually only info@ and a switchboard, but a generic mailbox paired with a named person to ask for is a legitimate route.

**8. IR advisers for listed groups.** For any listed entity whose CFO publishes nothing, the IR firm is the correct door — it exists to be contacted.

**Search the person, not just the company.** Once a source gives you a name, a second search on `"{name}" "{company}"` surfaces LinkedIn and conference listings. Two hops often gets a direct email where one hop did not.

**Use local-language search for China and Pakistan.** `董秘 {company name} 年报` for China/HK; Urdu-language registry and news search for Pakistan. English-only search is the primary reason China names return empty.

**Expected hit rates:** a named finance person for roughly half of shortlist names; a direct email for about a quarter; a usable switchboard or general mailbox almost always. Partnerships are the worst — often nothing published at all, which is why those records read "needs warm introduction" rather than a blank.

**Never fabricate.** No email constructed from a name pattern. No guessed phone extensions. No personal home addresses or personal social accounts. Full discipline: `../layer1/L1-evidence-discipline.md`.

---

## Source types

| Source | Can determine | Cannot determine | Notes |
|---|---|---|---|
| National company registry | Legal existence, registration number, legal form, directors — **the only authoritative answer to "is this the same company"** | Actual operations, buyer relationships | Highest authority on identity questions |
| Credit rating agencies | Bank facility size, utilisation, covenant pressure, trajectory | Unrated entities (most private companies) | **Rating action is a demand signal, never a negative finding** |
| Charge / security registration | Pledged assets, collateral exhaustion, who holds security | Unsecured borrowing | |
| Audited financial statements + contingent liabilities note | Borrowing structure and cost, DSO, related-party loans, top-five customers, **unprovisioned claims (hidden in contingent liabilities)** | Unaudited / private companies | |
| Exchange announcements / material event index | Litigation, penalties, pledges, defalcation | Non-listed companies | A checked "none" is **auditable evidence of absence** — better than silence |
| Court records | Current and historical proceedings, tribunal | Sealed / undisclosed allegation content | An allegation you cannot read ≠ clean |
| Regulatory appeal filings | Whether the matter is pending | Entity content that cannot be accessed | Inaccessible file = flag, not blank |
| Environmental / municipal authorities | Factory-level fines, permits, shutdowns | Group-level conduct | |
| Sanctions and forced labour lists | Hard eliminations | Everything below the line | OpenSanctions (includes UFLPA mirror), CBP WRO |
| Labour inspection NGOs | Factory site conditions and history | Current conditions (reports may be stale) | Check dates first — closed-factory old reports = MINOR |
| Industry associations / export promotion councils | **Scale evidence in thin-data markets** | Financial condition | TDAP, India Export Promotion Council |
| Buyer-published factory lists | Relationship likely exists | Which of two same-named companies | High name-collision source |
| Customs / bill of lading aggregators | Shipment rankings, named counterparties | Business share | **Not visible outside the US**; per-company 10-15 min manual research, not a bulk feed |
| Trade fair directories | Export-manager contacts (self-disclosed, BD-appropriate) | Financial contacts | Canton Fair, Heimtextil, Magic |
| Certification databases | Audit contact person | Finance contacts | Sedex, BSCI, Accord |
| B2B self-published profiles | WhatsApp, general manager (self-disclosed = acceptable) | Anything requiring verification | Alibaba, 1688, Global Sources |
| Company website | Published contacts, client logos | Anything requiring dates / verification | |

---

## Country routing (←ROUTED_BY— [EVENT-KB: COUNTRY])

| Country | Ratings | Registry / Charges | Notes |
|---|---|---|---|
| India | CRISIL · ICRA · CARE · Acuité · Infomerics | MCA (via ZaubaCorp / TheCompanyCheck) | PAN 4th character F = partnership |
| Pakistan | PACRA · VIS | SECP | TDAP rankings = scale evidence |
| Bangladesh | CRAB · CRISL | RJSC | |
| Sri Lanka | Fitch Lanka | ROC | |
| UK | — | Companies House (statements + charges) | |
| HK / China | — | HKEX · NEEQ · STAR | Mainland registries often block automated access — **report this state honestly, it is not "clean"**; use `董秘 {name} 年报` search |
| Generic | — | GLEIF LEI · IFC / development bank loan disclosures | Development bank pricing = the price you must beat |


---

## Links

- **←USES_SOURCE— [NODE-adverse-screen]**: routes adverse search by source type and country; this node provides the hierarchy
- **←ROUTES_SOURCE_BY— [NODE-financing-need]**: country-specific institution lookup uses this node's country routing table
- **←READS_SOURCE_HIERARCHY— [NODE-bs-proxy]**: source credibility for customs / CI / PulseLink signals
- **←READS_CONTRACT_FROM— [NODE-buyer-indicator]**: buyer indicator data sourced per this node's hierarchy (Group A–D indicators)
- **←READS— [L1-evidence-discipline]**: discipline layer; this node provides the *what* (sources), L1-evidence-discipline provides the *how* (grades, absence rules, audit log)
- **—ROUTED_BY→ [EVENT-KB: COUNTRY]**: country routing table (§Country routing above) reads country from the supplier/buyer event record
