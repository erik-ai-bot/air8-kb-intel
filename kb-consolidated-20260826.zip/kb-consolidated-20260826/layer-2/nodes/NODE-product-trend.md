# NODE · PRODUCT-TREND (Product Trend)

**What this is.** Rules for determining the product trend signal for a supplier: whether their product range is widening, stable, or narrowing over time. Used in F1 (hardgoods `trend` indicator), F2 (product breadth dimension + trend dimension). The reasoning layer for how to assess trend from available data is in `../layer1/L1-trend-method.md`.

**Where results go.** DB fields: `product_trend`, `product_trend_basis`, `product_trend_period`, `product_trend_note`.

**What product trend is not.** Product trend is not the same as revenue trend or shipment volume trend. A supplier may have RISING product variety with DECLINING shipment volume — these are separate dimensions and must be reported separately.

## Data sources (in priority order)

| Priority | Source | What it provides |
|---|---|---|
| 1 | Customs (distinct HS codes over time) | Most reliable; directly observable from shipment records |
| 2 | Trading documents (invoices, packing lists, Bills of Lading) | Product descriptions; less standardised than HS codes |
| 3 | Web research (company website, product catalogues, trade listings) | Directional only; may not reflect current active shipping range |

When a higher-priority source is available, do not use lower-priority sources to change the direction of the finding. Lower-priority sources can confirm; they cannot override.

## Determination method

### Comparison basis

| Period | Definition |
|---|---|
| P1Y | Trailing 12 months from reference date |
| P2Y | 12 months immediately prior to P1Y |

**Compare:** distinct product count in P1Y versus distinct product count in P2Y.

For customs-based determination, "distinct product count" = count of distinct HS codes at the 6-digit level within the period. If HS data is unavailable, use distinct product description keywords from trading documents.

### Direction thresholds

| Label | Condition |
|---|---|
| RISING | Product count increased ≥20% period-over-period, OR supplier entered a new product category not present in P2Y |
| STABLE | Product count within ±20% period-over-period, no new category entry or exit |
| DECLINING | Product count decreased ≥20% period-over-period, OR supplier exited a product category present in P2Y |

Category entry/exit is a stronger signal than a 20% count change: a supplier who ships 8 HS codes instead of 9 is STABLE, but one who adds an entirely new category (e.g. moves from home textiles into kitchen/tableware) is RISING regardless of the count ratio.

## Band assignment for scoring frameworks

### F1 — Hardgoods v3.0 / v2.1 (`trend` indicator)

The `trend` indicator in F1 uses the product trend signal as its primary input:

| Product Trend | Points (v3.0) | Points (v2.1) |
|---|---|---|
| RISING | 3 | 2 |
| STABLE | 1 | 1 |
| DECLINING or INSUFFICIENT DATA | 0 | 0 |

Exact weights and totals: `NODE-scoring-framework.md`. The table above is for reference only; the framework node is authoritative.

### F2 — Product Breadth Dimension

In F2, product breadth (absolute width of range) and product trend (direction of change) are combined:

| Combination | Assessment |
|---|---|
| Wide range + RISING | Best — broad and growing |
| Wide range + STABLE | Good — broad and holding |
| Wide range + DECLINING | Warning — broad but narrowing; investigate whether strategic or structural |
| Narrow range + RISING | Positive — specialist but growing |
| Narrow range + STABLE | Neutral |
| Narrow range + DECLINING | Negative — concentrating into fewer products |

"Wide" vs "narrow" thresholds for F2 are framework-version specific — read from the active F2 framework node.

## Thin-data handling

| Situation | Label | Action |
|---|---|---|
| < 6 months of customs history in P1Y | INSUFFICIENT DATA | Enrichment queue, component: `product_trend` |
| P2Y entirely empty (new supplier) | INSUFFICIENT DATA | Enrichment queue; do not default to STABLE |
| 2–3 customs records in P1Y, P2Y has data | STABLE (conservative) | Note: `thin data — conservative stable label` |
| Only web/catalogue data, no customs or docs | STABLE (conservative) if catalogue appears unchanged | Note: `web only — unverified` |

## What to record

| Field | Value |
|---|---|
| `product_trend` | RISING / STABLE / DECLINING / INSUFFICIENT DATA |
| `product_trend_basis` | `customs_hs` / `trading_docs` / `web` |
| `product_trend_period` | e.g. `P1Y: 2025-08–2026-08 vs P2Y: 2024-08–2025-08` |
| `product_trend_note` | Required for INSUFFICIENT DATA or thin-data conservative label; optional otherwise |
| `product_trend_p1y_count` | Distinct product count in P1Y (if determinable) |
| `product_trend_p2y_count` | Distinct product count in P2Y (if determinable) |

## Links

- **←READS— [L1-trend-method]**: Reasoning layer for trend assessment
- **—FEEDS→ [NODE-scoring-framework]**: `trend` indicator band assignment (F1)
- **—FEEDS→ [NODE-performance-scorecard]**: Product breadth + trend dimension (F2)
- **—FEEDS_OVERLAY→ [NODE-rating-assembly]**: F2 trend overlay only — not included in composite score; affects `final_tier_flags` directionally
- **—READS_SOURCE→ [NODE-indicator]**: `trend` DB derivation rule (`yoy > +5% → RISING · < −5% → DECLINING · else → STABLE`) — note that the indicator's simplified DB derivation and this node's sourced assessment are complementary; when customs shipment data supports this node's full assessment, prefer this node's output
