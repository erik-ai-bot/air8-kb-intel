# NODE-regulatory-intelligence.md — Regulatory Intelligence Source Registry
**Layer:** L2 | **Note:** Full methodology is in L1/L1-regulatory-intelligence.md. This node holds the source registry as a reference table.

## Official Primary Sources (Tier 1)

| Source | URL | Covers | Update frequency |
|--------|-----|--------|-----------------|
| ECHA SVHC Candidate List | echa.europa.eu/candidate-list-table | REACH SVHC additions | ~Every 6 months (Feb + Jul) |
| EUR-Lex Official Journal | eur-lex.europa.eu | All EU regulations, entry into force + application dates | Real-time |
| EU Safety Gate | ec.europa.eu/safety-gate | Product enforcement alerts by category | Weekly |
| DHS UFLPA Entity List | dhs.gov/uflpa-entity-list | Xinjiang forced labor entity list | Monthly (irregular) |
| CPSC | cpsc.gov/Regulations-Laws | US product safety regulations + recalls | Real-time |
| OEHHA Prop 65 List | oehha.ca.gov/proposition-65/proposition-65-list | California chemical list | Quarterly |

## Curated Interpretation Services (Tier 2)

| Source | URL | Specialty | Cadence |
|--------|-----|-----------|---------|
| CIRS Group | cirs-group.com | China exporter perspective, EN+CN | Weekly alerts |
| REACH24H | reach24h.com | REACH specialist | On SVHC updates |
| SGS Safeguards | sgs.com/safeguards | Product-category sorted | Weekly newsletter |
| Eurofins Regulatory News | eurofins.com | Strong on PFAS + food contact | Monthly |
| TÜV SÜD Compliance Briefs | tuvsud.com | EU enforcement cases | Monthly |
| Intertek Regulatory News | intertek.com | US+EU combined | Weekly |

## Early Warning Sources (Tier 3)

| Source | URL | Lead time |
|--------|-----|-----------|
| ECHA SVHC Intention Registry | echa.europa.eu/registry-of-intentions | 6–18 months before listing |
| EU Commission Consultation Portal | ec.europa.eu/info/law/better-regulation | 6–12 months before adoption |
| MSC Meeting Minutes | echa.europa.eu/member-state-committee | Post-meeting, irregular |
| AAFA Industry Alerts | aafaglobal.org | 3–6 months ahead for apparel |

## Links
→ L1-regulatory-intelligence.md (full methodology for using these sources)
→ L1-compliance-scope.md (how new regulations update the routing table)
→ L1-compliance-gap-method.md (how new regulations create Type A gaps)
