# NODE · RATING-ASSEMBLY (Rating Assembly)

**What this is.** Rules for combining multiple scored components into a single supplier rating or tier. Used in F1 (CP4 final sort) and F2 (CP3 score assembly). This node defines the merge methodology, tie-breaking rules, override conditions, and tier label meanings.

**Where results go.** DB fields: `final_score`, `final_tier`, `final_tier_basis`, `final_tier_flags`, `rating_as_of`. One verdict per supplier per run. Verdicts always cite the framework version and assembly version that produced them — re-scoring under a new framework is a new verdict, not a correction.

**Score stability.** A supplier's tier from a previous run is not authoritative for the current run. Re-score on each run. Prior verdicts are informative for trend analysis; they are not inputs to the current run.

## F1 Rating Assembly (Lead Scoring)

### Components

| Component | Merge weight |
|---|---|
| Pattern Score (F1 scoring indicators) | 70% |
| Proxy B/S Scorecard Score (from NODE-bs-proxy, where available) | 30% |

**When B/S proxy is unavailable:** report score as `earned / available (B/S pending)`. Do not impute a B/S score. The 70% pattern score still applies; the total is partial.

### F1 Merge steps

1. **Normalize** Pattern Score to 0–1: `pattern_score ÷ framework_max_points`
2. **Normalize** B/S Proxy Score to 0–1: `bs_proxy_score ÷ bs_proxy_max`
3. **Weight and sum:** `(pattern_normalized × 0.70) + (bs_normalized × 0.30)`
4. **Scale:** `merged_normalized × 100` (for comparability as a percent-of-max)
5. **Apply tier cutoffs** from the active framework node (`NODE-scoring-framework.md`)

### F1 Tier cutoffs

Read from `NODE-scoring-framework.md` (Framework Instances section, `TierRule` rows). Do not hard-code tiers in this node — they are framework-version specific.

## F2 Rating Assembly (Supplier Scoring)

### Components

| Component | Merge weight |
|---|---|
| Performance Score (from NODE-performance-scorecard Dim 1) | **45%** |
| B/S Pair Score (from NODE-performance-scorecard Dim 2) | **40%** |
| QAQC Score (from NODE-performance-scorecard Dim 3) | **15%** |
| Trend Score (from NODE-product-trend / NODE-market-trend) | Overlay only — see note |

*Weights confirmed by Jerri Zhou (2026-08-25). Composite is computed inside NODE-performance-scorecard.md; this table documents the authoritative breakdown.*

**Trend weight:** Trend score is included directionally but its merge weight is not yet calibrated. Until calibration: (a) report trend as a directional overlay note, not as a numeric component in the merge; (b) trend affects the `final_tier_flags` field but does not shift the numeric score. This will be updated when F2 has sufficient onboarded data.

### F2 Merge steps

1. **Normalize** Performance to 0–1: `perf_score ÷ 6`
2. **Normalize** B/S Pair to 0–1: `bs_pair_score ÷ 8`
3. **QAQC** is already normalized (0–1 from weighted band formula)
4. **Weight and sum:** `(perf_norm × 0.45) + (bs_norm × 0.40) + (QAQC_raw × 0.15)`
5. **Scale:** `composite × 10` = `scorecard_total`
6. **Apply F2 tier cutoffs:** A ≥7.5 · B ≥5.0 · C ≥2.5 · D else (provisional — calibrate at n ≥ 20 per tier)

## Tie-breaking rules (F1 and F2)

When two suppliers have the same merged score and tier, apply in order:

| Priority | Tie-breaker | Rule |
|---|---|---|
| 1st | Total score | Higher score wins; descending order |
| 2nd | Region | India/Pakistan preferred within equal scores (higher strategic BD priority in current batch) |
| 3rd | Financing need | Higher need first — **sort only, never removes a lead from the list** |

**Region tie-breaking** applies within equal scores only; it does not promote a lower-scoring supplier above a higher-scoring one. Region preference is the current BD prioritisation (2026-08 decision log); it is not a permanent feature and will be revisited when BD coverage expands.

**Financing need as tertiary:** `NODE-financing-need.md` established that need is inferential and frequently unresolvable; it was downgraded from a filter to a tie-breaker (2026-08). It never removes a lead — LOW financing need goes to the Floor page, visible with evidence.

## Override conditions

These bypass the tier that the numeric score would produce:

| Condition | Effect | Rationale |
|---|---|---|
| MATERIAL adverse finding (from NODE-adverse-screen) | Maximum Tier C regardless of score | Cannot approach; MATERIAL gate is upstream of tier — score is preserved for model validation |
| `own_book = TRUE` | Label only (`ALREADY FINANCED`); retain tier for model validation | Do not call; the overlap between model top picks and existing book is validation, not waste |
| Enrichment pending (any named component) | Tier is provisional; label `PROVISIONAL — enrichment pending` | Cannot assign a final tier with missing components |
| `routing_signal = ENRICHMENT` | No tier; supplier is unscored | Cannot score without vertical assignment |

**MATERIAL finding note:** A MATERIAL adverse finding does not delete the record. The supplier appears on the `Gated Out` page with tier, score, and the adverse finding — a reviewer's first question is "why isn't the biggest one here?" The answer must be visible.

## Tier label definitions

| Tier | Meaning | Action |
|---|---|---|
| A | Highest modelled retention probability | Proceed to CP4.5 first; prioritise enrichment and adverse screen |
| B | Solid retention probability | Proceed after Tier A |
| C | Lower retention probability; proceed if Bench has capacity | Proceed after Bench; may be skipped in a bandwidth-constrained run |
| Bench | One band lower than the shortlist, better evidence required for promotion | Promotable by exception; exception written down in the run record |
| Enrichment | Cannot tier — missing named component | Wait for missing data; do not estimate |
| Floor | Tier assigned but financing need = LOW (published evidence of no need) | Do not call on receivables pitch; visible with evidence so reviewer understands absence |
| Gated Out | MATERIAL+ adverse finding | Do not call; visible with finding |
| Already Financed | `own_book = TRUE` | Do not schedule outreach; visible for model validation |

## Score-not-comparable reminder

F1 (max 11/15 depending on framework version) and F2 (0–10 normalized) scores are **not directly comparable**. Rank within framework. If a merged cross-framework view is required, use `score_pct` (percent of max) — but prefer tier for cross-framework comparison.

## Links

- **—READS→ [NODE-scoring-framework]**: Framework tier cutoffs, cap and gate rules, framework max points
- **—READS→ [NODE-performance-scorecard]**: F2 composite score (Performance 45% + B/S Pair 40% + QAQC 15%); computed inside that node, passed as `scorecard_total`
- **—READS→ [NODE-bs-proxy]**: F1 B/S proxy component score (30% of F1 merged score)
- **—READS→ [NODE-adverse-screen]**: Override trigger (MATERIAL+ → max Tier C)
- **—READS→ [NODE-financing-need]**: Tertiary tie-breaker; LOW → Floor
- **—READS→ [NODE-product-trend]**, **—READS→ [NODE-market-trend]**: F2 trend overlay only — not included in composite score; affects `final_tier_flags` directionally
- **—SCORES→ [EVENT-KB: SUPPLIER]**: One verdict per supplier per run written to DB
- Decision log entries relevant to assembly rules: `../layer1/L1-decision-log.md` (2026-08: region priority, already-financed labelling, financing need demotion, MATERIAL adverse bar)
