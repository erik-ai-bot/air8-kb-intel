# NODE-compliance-buyer-rsl.md
**Layer:** L2 — Product Knowledge | **Domain:** Buyer Compliance Programs & RSL Standards
**Last updated:** 2026-08-26 | **Covers:** RSL frameworks, audit programs, documentation requirements

> **Data note:** Individual buyer RSL data (specific chemical limits, approved lab lists, test panel requirements, and buyer-specific thresholds per buyer) is stored in `DB/buyer_rsl/` and retrieved on-demand. It is **not hardcoded in this node**. See §How to Get Buyer-Specific RSL Data below.

---

## FRAMEWORK: Why Buyer Requirements Exceed the Regulatory Floor

Regulations set **minimum legal standards** — the floor below which products cannot go. Major retailers operate their own Restricted Substances Lists (RSLs), audit programs, and supplier codes of conduct that are typically stricter, faster-moving, and more operationally demanding than law.

| Dimension | Regulatory floor | Major buyer requirement |
|---|---|---|
| Chemical limits | REACH Annex XVII / US CPSC | Buyer RSL (often 50–90% stricter thresholds) |
| Update frequency | Annually or less (legislative process) | Quarterly (buyers update RSLs based on NGO pressure, media, internal policy) |
| Consequence of failure | Market prohibition, fines | **Lost orders** — immediate shipment hold, delisting |
| Scope | Chemical safety only | Chemical + social + packaging + carbon footprint |
| Enforcement | State authority surveillance | Buyer's in-house compliance team + 3rd party audits |
| Documentation trigger | On request / market surveillance | **Proactive** — required before order placement |

### What buyer compliance programs typically cover

1. **Chemical RSL** — substance-specific limits (often more substances + lower limits than regulations)
2. **Social compliance audit** — labor standards, working hours, wages, child labor, OHS
3. **Packaging compliance** — recyclable materials, country of origin labeling, no excess packaging
4. **Carbon footprint / sustainability** — Scope 1–3 emissions, recycled content, organic certifications
5. **Traceability** — factory registration, tier 1–3 supply chain mapping
6. **Testing protocols** — mandatory accredited labs, specific test methods, test frequency

---

## AMFORI BSCI — Social Audit Framework

**Used by:** Major European and global retailers and brands (2,000+ brand members)

### Platform and process

| Element | Detail |
|---|---|
| Platform | amfori.org — factories register on the **amfori Platform** |
| Who audits | amfori-approved auditing companies (SGS, Bureau Veritas, Intertek, ELEVATE, etc.) |
| Scope | Child labor, forced labor, disciplinary practices, discrimination, working hours, remuneration, OHS, workplace facilities, environmental basics, business ethics |
| Rating scale | **A** = Outstanding \| **B** = Good \| **C** = Acceptable \| **D** = Needs improvement \| **E** = Unacceptable |
| Minimum buyer requirement | Most buyers require **C or better**; some require **B** for new suppliers |
| Report validity | **2 years** from audit date |
| Report sharing | Uploaded to amfori Platform; member buyers can access directly (no re-sharing needed) |
| CAPAR | Corrective Action Plan and Report required for any non-conformance |

### Most common BSCI audit failures (for decorative goods factories)

| Finding | Typical example | Risk level |
|---|---|---|
| Excessive overtime | >60 hours/week without documented consent | HIGH — D or E rating |
| Below minimum wage | Piece-rate pay structures that net below statutory minimum | HIGH |
| Missing OHS documentation | No chemical safety data sheets, no accident log | MEDIUM-HIGH |
| Blocked emergency exits | Storage in front of fire exits (extremely common in China factories) | HIGH — instant D/E |
| No worker contracts | Verbal employment arrangements | MEDIUM |
| Child labor suspicion | Workers with no age verification documents | CRITICAL — E rating, immediate notification |
| Lack of grievance mechanism | No worker hotline, suggestion box, or equivalent | MEDIUM |

---

## SMETA — Sedex Members Ethical Trade Audit

**Used by:** US, UK, and global retailers (broad acceptance across retail segments)

### Platform and process

| Element | Detail |
|---|---|
| Platform | **Sedex.com** — Sedex Advance portal |
| Factory registration | Factory creates a Sedex account; shares site with buyer members |
| Audit format | 2-pillar (Labor + Health & Safety) or **4-pillar** (+ Environment + Business Ethics) |
| Who audits | SMETA-approved auditing firms (same pool as BSCI) |
| Report sharing | Uploaded to Sedex Advance; buyer members access directly |
| CAPAR | Required for all non-conformances; due dates set by buyer |
| Validity | **1–3 years** depending on buyer and audit outcome |
| Cost | Audit cost: typically USD 800–2,500 depending on factory size and location |

### SMETA vs. BSCI — Key differences

| Factor | BSCI | SMETA |
|---|---|---|
| Rating system | A–E score | Non-conformance count by severity |
| Ownership | amfori (brand association) | Sedex (independent NGO-aligned) |
| Portability | amfori member buyers only | Broader acceptance (more US retailers use SMETA) |
| Cost to factory | Audit + amfori registration | Audit + Sedex site license |
| Best for | European-brand supply chains | US + UK retail supply chains |

---

## HOW TO DETERMINE WHICH BUYER RSL APPLIES

### Decision flow for Air8 client assessment

```
STEP 1: From financing/buyer records in Air8 CRM
         ↓
         Are named buyers identified? (e.g., BJ's Wholesale, Costco, Walmart)
         ↓ YES                          ↓ NO
STEP 2: Load that buyer's RSL           Flag as data gap — request from client
        from DB/buyer_rsl/<buyer>.md     (Type B data gap → L1-compliance-response.md)
         ↓
STEP 3: Does Air8 have the current RSL on file?
         ↓ YES                          ↓ NO
         Apply it directly               Request from client; use benchmark RSL
                                         in interim (see Step 4)
         ↓
STEP 4: OEM/ODM supplier (multiple brands)?
         → Use BROADEST applicable RSL as baseline
         → Recommended benchmark: IKEA MRSL or ZDHC MRSL Level 3
         → These represent the most comprehensive chemical coverage
```

### RSL benchmark hierarchy (most to least stringent)

1. **ZDHC MRSL Level 3** — most comprehensive, covers ~300+ chemicals; used in fashion/home textile
2. **IKEA MRSL** — covers furniture, home goods broadly; good for hardgoods and textiles
3. **H&M MRSL** — strong for fashion/soft goods, PFAS-free requirement
4. **BJ's / Costco RSL** — US retail focused, Prop 65 aligned
5. **EU REACH Annex XVII** — regulatory floor only

> **Important:** Specific thresholds, limits, and approved lab lists for each buyer are stored in `DB/buyer_rsl/` — not in this framework node. The hierarchy above is for routing only; do not use it as a substitute for the actual buyer RSL document.

---

## HOW TO GET BUYER-SPECIFIC RSL DATA

Individual buyer RSL documents change frequently (quarterly in some cases). There are three sources to obtain the current version:

### Source 1 — From the client directly
- Ask the client to provide the buyer's compliance manual or RSL document
- Clients typically receive this at onboarding from the buyer's compliance portal
- Request: "Please share the current [Buyer Name] RSL or compliance requirements document that was provided to you"

### Source 2 — From the buyer's supplier portal
Most major retailers publish RSL requirements in their supplier portals:
- Buyer portals are public-facing or login-gated for registered suppliers
- Air8 does not maintain active buyer portal logins — request the document from the client
- If the client does not have access, refer them to their buyer's compliance contact

### Source 3 — From Air8 relationship records
- Check `DB/buyer_rsl/` for on-file versions obtained from previous client relationships
- Check `DT/DT-internal-data-map.md` for the currency date of each stored RSL
- Flag any RSL file older than 12 months as potentially stale; request updated version before applying it

### When no RSL is available
Apply the RSL benchmark hierarchy above (ZDHC MRSL Level 3 as default broadest baseline) and document the gap as a Type B data gap per `L1-compliance-response.md`.

---

## BUYER COMPLIANCE DOCUMENT CHECKLIST

For any new client onboarding or product line addition. Use this to identify documentation gaps before Air8 issues financing. This checklist is generic — the buyer-specific document requirements (formats, portals, validity windows) are in `DB/buyer_rsl/<buyer>.md`.

### Mandatory documents

```
□ Factory social audit report
   - BSCI (amfori Platform) OR SMETA (Sedex) OR buyer-specific equivalent
   - Must be valid (within 2-year window for BSCI; 1-3 year for SMETA)
   - Rating: C or better (BSCI); no critical/major non-conformances outstanding (SMETA)

□ Third-party chemical test report
   - ISO 17025 accredited lab (SGS, Bureau Veritas, Intertek, etc.)
   - Covers current season's product (re-test if material changes)
   - Scope: buyer's RSL + applicable regulations (REACH, Prop 65, CPSC)

□ Prop 65 compliance statement
   - Required for any products sold in California
   - Covers: lead, cadmium, DEHP + other phthalates, flame retardants, formaldehyde

□ Country of Origin (CoO) certificate
   - Per shipment (or annual declaration where accepted)
   - Issued by factory (self-cert) or Chamber of Commerce (authenticated)

□ SVHC declaration
   - Factory's self-declaration that no SVHC >0.1% w/w in article
   - OR SCIP notification reference number if SVHC present

□ REACH compliance declaration
   - EU-bound products: covers Annex XVII restrictions + SVHC status

□ Bill of Materials (BOM)
   - Lists all materials, components, and their chemical composition
   - Needed for RSL mapping and SVHC screening
```

### Conditional documents (based on market + product type)

```
□ GPSR EU Authorized Representative appointment letter
   - Required: non-EU manufacturer + EU market
   - Must include EU AR name, address, registration number

□ CE Declaration of Conformity + Technical File
   - Required: products with electrical components (LED, motors, batteries)
   - Applicable directives listed; standards referenced

□ RoHS compliance declaration
   - Required: electrical/electronic components in product

□ ZDHC Gateway upload confirmation
   - Required by buyers aligned to ZDHC (check DB/buyer_rsl/ for specific buyers)
   - Factory chemical management system must be registered on ZDHC Gateway

□ Carbon/sustainability declaration
   - Some buyers request Scope 1–3 carbon data
   - Increasingly required for new supplier onboarding from 2025+

□ Buyer-specific factory questionnaire
   - Many major buyers have proprietary onboarding questionnaires
   - Must be completed and returned before first order
   - Specific questionnaire format: see DB/buyer_rsl/<buyer>.md
```

---

## LINKED FILES

- [DT/DT-internal-data-map.md](../DT/DT-internal-data-map.md) — Internal data sources, where buyer RSL files are stored
- [L1-compliance-scope.md](../L1/L1-compliance-scope.md) — What falls within compliance review scope
- [L1-compliance-response.md](../L1/L1-compliance-response.md) — How to handle data gaps and buyer-specific queries
- [L1-compliance-interpretation.md](../L1/L1-compliance-interpretation.md) — Grey-area product category decisions
- [NODE-compliance-social.md](./NODE-compliance-social.md) — Social compliance framework (BSCI/SMETA context)
