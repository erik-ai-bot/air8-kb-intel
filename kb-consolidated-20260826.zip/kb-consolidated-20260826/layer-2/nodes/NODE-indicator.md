# NODE · INDICATOR

**What this is.** The definition of each scorable signal: which DB field it comes from and how it is computed. The KB defines the indicators; the DB supplies the numbers — **indicator values are never stored in the KB**.

## Indicator Inventory

| Indicator (`code`) | Unit | How to derive from DB | Notes |
|---|---|---|---|
| Activity (`act_months`) | Months (max 12) | Count distinct months with ≥1 shipment in the trailing 12 | **The window is load-bearing** — a 24-month window invalidates all band thresholds |
| Shipments (`shipments_12m`) | Count | Row count, trailing 12 months | |
| Growth (`yoy_growth`) | Ratio | (trailing 12m − prior 12m) ÷ prior 12m | **null, not 0** when prior 12m = 0 |
| Density (`density`) | Shipments / buyer / active month | `shipments_12m ÷ n_buyers ÷ act_months` | Thresholds are percentile-remapped; changing units requires re-remapping |
| Category Spread (`category-spread`) | Distinct segments | HS codes → segment reference in NODE-scoring-framework | Not determinable → Enrichment; never award 0 |
| Product Breadth (`breadth`) | Distinct products | Count of distinct product descriptions / HS lines | Source field **censored at 10** — do not rescale |
| Buyer Quality (`buyer-quality`) | Yes / No | Buyer name matches US mass/discount retail list | |
| Category (`category`) | Mapped category | `PRODUCT_FAMILY` / `CATEGORY` column or description keywords | |
| Ticket (`ticket`) | USD | `amount_12m ÷ shipments_12m` | |
| Cadence (`cadence`) | Shipments / month | `shipments_12m ÷ act_months` | Used in hardgoods v2.1 |
| Trend (`trend`) | RISING / STABLE / DECLINING | yoy > +5% → RISING · < −5% → DECLINING · else → STABLE | Use `trend` field directly when available |
| Buyer Count (`n_buyers`) | Count | Distinct buyers in the trailing 12; floor of 1 | |
| Country (`country`) | Country | `country` column from leads table | Normalise before use: China / CHINA / China. → one value |
| Months Since Target (`months_since_target`) | Months | Reference date − date of last transaction with target buyer | Feeds the flow-stale gate |

## Explicitly Excluded from Scoring

These are auditable absences — the reason for each exclusion matters as much as the inclusions.

| Excluded input | Reason |
|---|---|
| Financing need | Inferential and frequently unresolvable; used only as the tertiary sort tie-breaker (downgraded from filter, 2026-08) |
| LF / own-book relationship | Changes who to call, not the ranking |
| Monthly USD amount / FOB value | Does not differentiate retention empirically — both groups average ≈$58–66K |
| Buyer credit limit (apparel) | Already matched at funnel top; scoring it again double-counts |
| Country (hardgoods v3.0) | China sample in the ledger too small to support the old penalty |

## Links

- **—VALUED_FROM→ [DB]**: Pull each indicator per the derivation rules above
- **←USES_INDICATOR— [NODE-scoring-framework]**: Weights and bands live in that node
- Full derivation contract (null rules, data quality checks): `../layer1/L1-db-field-contract.md`
