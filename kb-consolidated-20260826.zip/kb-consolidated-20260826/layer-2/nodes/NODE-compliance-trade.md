# NODE-compliance-trade.md
**Layer:** L2 — Product Knowledge | **Domain:** Trade Compliance
**Last updated:** 2026-08-26 | **Covers:** UFLPA, HS codes, COO, CPSC, China export controls, sanctions

---

## UFLPA — Uyghur Forced Labor Prevention Act (US)

**Enacted:** December 23, 2021 | **Effective enforcement:** June 21, 2022
**Administering agency:** CBP (U.S. Customs and Border Protection) + DHS (Department of Homeland Security)

### Core legal mechanism: Rebuttable Presumption

All goods mined, produced, or manufactured wholly or in part in the Xinjiang Uyghur Autonomous Region of China — or by entities on the UFLPA Entity List — are **presumed to be made with forced labor** under 19 U.S.C. § 1307 and are **denied entry** into the United States.

To overcome the presumption, the importer must demonstrate by **"clear and convincing evidence"** that:
1. The goods were not produced with forced labor
2. The supply chain has been fully traced (tier 1 through raw material origin)
3. Due diligence measures are in place and effective

> ⚠️ The standard is intentionally high. CBP officers have broad discretion. An importer cannot simply assert "we checked" — full documentary supply chain evidence is required.

---

### UFLPA Entity List (as of 2026)

| Status | Detail |
|---|---|
| Current entity count | **144 entities** (DHS-published list, updated through 2026) |
| Published by | Department of Homeland Security — dhs.gov/uflpa-entity-list |
| Effect | Goods from any entity on the list = automatically blocked at US port; rebuttable presumption cannot be overcome for listed entities |
| Sectors covered | Polysilicon, cotton, tomato/food products, PPE, electronics, chemicals |
| For decorative items | Check if any Tier 1–3 supplier (cotton, fabric, yarn, chemical suppliers) appears on the entity list |

### High-risk input categories for decorative articles

| Input | UFLPA risk | Why |
|---|---|---|
| Cotton / cotton yarn / fabric | **VERY HIGH** | Xinjiang produces ~85% of China's cotton; CBP targets cotton goods aggressively |
| Polysilicon / solar cells | HIGH | Less relevant for decorative items unless electronics |
| Tomato-derived inks / dyes | MEDIUM | Specialty risk for natural pigments |
| Wool | MEDIUM | Some Xinjiang wool sourcing |
| Aluminium / metal components | LOW-MEDIUM | Some Xinjiang smelting operations |
| Ceramic / clay | LOW | Not primary UFLPA target |
| Glass | LOW | Not primary UFLPA target |

### What happens at the port

```
CBP Officer Reviews Shipment Manifest
         ↓
Goods flagged (Xinjiang origin / entity list hit / targeting criteria)
         ↓
CBP issues Withhold Release Order (WRO)
         ↓
Importer notified — has 90 days to respond
         ↓ (if no response or evidence insufficient)    ↓ (if sufficient evidence provided)
Goods SEIZED + DESTROYED or returned to origin          Goods RELEASED for import
```

**Cost of non-compliance:** Shipment seized and destroyed; importer bears full cost including return freight, storage, and destruction fees. No duty refund.

---

### UFLPA Compliance Documentation — What an Importer Needs

Organized by supply chain tier:

#### Tier 1 — Direct supplier (factory)

| Document | Detail |
|---|---|
| Supplier identification | Full legal name, registered address, ownership structure (including UBO) |
| Factory audit report | BSCI/SMETA covering forced labor, child labor, wages, working hours |
| Supplier attestation | Notarized statement that no forced labor is used in production |
| Employment records | Sample payroll records, worker contracts, recruitment records |

#### Tier 2 — Sub-tier suppliers (fabric mills, yarn spinners, component makers)

| Document | Detail |
|---|---|
| Sub-supplier list | Name, address, and specific materials supplied |
| Sub-supplier attestation | Same notarized statement of no forced labor |
| Material traceability | How material flows from Tier 2 to Tier 1 (purchase orders, shipping records) |
| Sub-supplier audit | If BSCI/SMETA available — attach; otherwise risk-assess |

#### Tier 3 — Raw material origin (cotton farms, mines, material extractors)

| Document | Detail |
|---|---|
| Cotton origin | Country, province/state — ideally farm-level; at minimum non-Xinjiang origin certificate |
| Fiber certification | GOTS (organic), BCI (Better Cotton), Supima, or equivalent traceable origin scheme |
| Mill chain of custody | From fiber to fabric — Textile Exchange chain of custody or similar |
| Transaction records | Invoices showing purchase of non-Xinjiang raw materials |

#### Shipping documentation (required for all UFLPA responses)

| Document | Detail |
|---|---|
| Bill of Lading | Must show origin port, consignee, and cargo description |
| Commercial Invoice | Must reflect fair market value (anti-dumping relevance) |
| Packing List | Itemized contents by batch/lot |
| Bill of Materials (BOM) | Each component with country of origin |
| Country of Origin certificate | Per shipment |

---

## HS CODE COMPLIANCE

HS codes determine: **which regulations apply**, **duty rates**, **import quota categories**, and **export control classifications**. Misclassification is a customs fraud risk.

### Key HS codes for decorative articles

| HS Code | Description | Common articles | Notes |
|---|---|---|---|
| **9505.10** | Christmas decorations | Ornaments, baubles, tinsel, artificial trees | Most common for seasonal decor; 0% MFN duty from many sources |
| **9505.90** | Other festive, carnival, or other entertainment articles | Halloween decor, Easter items, generic party decorations | Same tariff chapter as 9505.10 |
| **6304.90** | Other made-up textile articles (not for bedding/furnishing) | Fabric-based wall hangings, textile decorations, wreaths with fabric | Textile regulations apply |
| **4420.10** | Statuettes and other ornaments of wood | Wooden figurines, carved decorative objects | Lower duty rates typically |
| **6913.10** | Porcelain/china ornamental ceramics | Porcelain figurines, decorative plates | |
| **6913.90** | Other ceramic ornamental articles | Earthenware, stoneware decorations | |
| **9405.41** | Lamps and lighting fittings — photovoltaic/LED | LED decorative string lights, lighted ornaments | **Triggers CE/LVD/EMC when imported to EU; CPSC rules in US** |
| **3926.40** | Decorative plastic articles | Plastic figurines, synthetic decorations | REACH Annex XVII may apply to PVC |

### HS code misclassification — risks and examples

| Misclassification | Consequence |
|---|---|
| Decorative lights classified as 9505 instead of 9405 | Wrong (lower) duty rate assessed; underpayment triggers penalty + future enhanced bond requirement; safety regulations (LVD/CPSC) not applied |
| Ceramic ornament classified as general merchandise (6999) instead of 6913 | Wrong duty rate; potential quota category error |
| Textile decoration classified as bedding (6302) instead of 6304 | Different duty rate; incorrect RSL standards applied |
| Toy classified as decorative item | Avoids toy safety regulation (EN 71 / ASTM F963-17) — creates major liability if child is injured |

### How to verify HS code

| Method | Resource |
|---|---|
| US tariff database | USITC.gov — HTS Online Reference Tool (hs.usitc.gov) |
| US binding ruling | CBP ruling database — rulings.cbp.gov |
| EU tariff database | EU Integrated Tariff (EZT) — ec.europa.eu/taxation_customs/dds2/taric |
| Customs broker | Preferred for complex articles or articles with electrical components |
| Buyer PO | Buyers often specify HS code in purchase order — cross-reference with own classification |
| China export | GACC cross-reference for China customs codes (HS-based) — hgj.customs.gov.cn |

---

## COUNTRY OF ORIGIN (COO) CERTIFICATES

### When COO is required

| Situation | COO required? | Why |
|---|---|---|
| US import under MFN (Most Favored Nation) rate | Yes — stated on commercial invoice | Mandatory customs declaration |
| US import with preferential duty (GSP, trade agreement) | Yes — COO certificate proving origin | Duty preference eligibility |
| EU import under EU trade agreement (e.g., EU-Vietnam FTA) | Yes — EUR.1 or REX declaration | Preferential rate eligibility |
| Buyer compliance pack | Yes — buyer requires for supply chain transparency | Non-regulatory but operationally mandatory |

### COO rules — "Substantially Transformed" test (US standard)

Under US law, country of origin is determined by the **substantial transformation** test: if a manufacturing process changes the article into a **new and different article with a distinct character and use**, the country where that transformation occurs is the country of origin.

| Process | Substantial transformation? | COO result |
|---|---|---|
| Cut fabric + sew + assemble decorative item | **YES** | COO = country of sewing/assembly |
| Import raw ceramic clay, shape, fire, paint | **YES** | COO = country of firing/painting |
| Import finished garland, add logo sticker, repackage | **NO** | COO = country of garland manufacture |
| Import components, hand-assemble by workers | Depends on complexity | Assess case-by-case |

### EU origin rules — "Sufficient Processing" (for preferential COO)

EU uses the specific rule per HS chapter. For decorative goods:
- Chapter 63 (textile goods): typically "fabric to article" (cutting and sewing sufficient)
- Chapter 69 (ceramics): firing/shaping is the determining process
- Chapter 94/95: significant processing of materials of non-origin required

### COO certificate formats

| Format | Used for | Issued by |
|---|---|---|
| Self-certification (invoice declaration) | Low-value shipments; some trade agreements | Exporter |
| Chamber of Commerce certificate | General US/EU imports; buyer compliance | Chamber of Commerce in exporting country |
| EUR.1 movement certificate | EU trade agreements (GSP, bilateral) | Customs authority in exporting country |
| Form A (GSP certificate) | US Generalized System of Preferences | Exporting country customs authority |
| REX (Registered Exporter) | EU GSP simplified declaration | Registered exporters only |

---

## US CUSTOMS / CPSC REQUIREMENTS

### CPSC — Consumer Product Safety Commission

| Requirement | Applies to | Detail |
|---|---|---|
| General Conformity Certificate (GCC) | Children's products — mandatory; adult consumer products — recommended | Manufacturer/importer certifies compliance with applicable CPSC rules |
| Lead in surface coatings (16 CFR 1303) | All consumer products | Lead in paint ≤ **90 ppm** — stricter than EU's 600 ppm |
| Phthalates (CPSC rule) | Children's toys and childcare articles | DEHP, DBP, BBP ≤ 0.1%; DIBP + 3 others ≤ 0.1% |
| Flammability (16 CFR 1610/1611/1500.44) | Fabric-based products | Test requirement; not relevant to hard ornaments |
| ASTM F963-23 | Toy safety standard | Applies if product is marketed or intended as a toy for children under 14 |
| ISF (Importer Security Filing) | All ocean freight to US | Filed **24 hours before vessel departure from last foreign port**; 10+2 data elements |
| Import bond | All formal entries (>$2,500) | **10% of estimated annual duties and fees**; minimum $100 |

### Prop 65 (California Safe Drinking Water and Toxic Enforcement Act)

| Element | Detail |
|---|---|
| Who is covered | Any seller of products in California (including online) |
| Trigger | Product contains listed chemical above No Significant Risk Level (NSRL) |
| Key substances for decorative items | Lead (≥ 0.5 µg/day exposure), cadmium, DEHP (≥ 5 µg/day), phthalates, formaldehyde |
| Warning requirement | Clear and reasonable warning on product/packaging before exposure occurs |
| Penalty for failure | Civil penalty up to $2,500 per day per violation |
| How to comply | Test below NSRL thresholds and document; OR place Prop 65 warning on product |

---

## CHINA EXPORT CONTROLS

**Governing law:** Export Control Law of the People's Republic of China (ECL), effective December 1, 2020

### Relevance for decorative goods manufacturers

| Export control category | Relevance to decorative items |
|---|---|
| Dual-use goods (chemicals, materials) | **Generally not applicable** to standard decorative articles |
| Rare earth elements | Relevant if products contain rare earth pigments, magnets, or specialty coatings |
| Certain metallic alloys | Tungsten, gallium, germanium compounds — uncommon in standard decorative items |
| Technology and data | R&D data, manufacturing processes — export control on know-how, not physical goods |

### China export license check

- For most decorative item manufacturers: no export license required
- **Exception check:** if product contains any component flagged by China's dual-use catalog (China Dual-Use Items and Technology Export Control List)
- Verify via: China Ministry of Commerce (MOFCOM) export licensing system

### China's countermeasure export restrictions (strategic response to US sanctions)

- China has restricted export of gallium, germanium, and graphite (since 2023)
- Indium, bismuth added (2024)
- **For decorative items:** not typically affected unless product contains electronic display components using these materials

---

## TRADE SANCTIONS — OFAC / EU

> ⚠️ This section provides a high-level summary only. For full sanctions screening and adverse party checks, do **not** duplicate logic here — route to the existing KB node:
> → [[Air8 main KB → NODE-adverse-screen.md — in air8-databases/SHI-KB/]]([Air8 main KB → NODE-adverse-screen.md — in air8-databases/SHI-KB/])

### Summary for context

| Sanctions program | Administering body | Relevance for decorative goods trade |
|---|---|---|
| SDN List (Specially Designated Nationals) | OFAC (US Treasury) | No transactions with listed entities — check buyer, freight forwarder, shipper, and bank |
| BIS Entity List | US Dept of Commerce | Export-focused; relevant if US technology is incorporated |
| EU Consolidated Sanctions List | EU (OFAC equivalent) | Covers entities in Russia, Belarus, Iran, etc. |
| UK OFSI | UK HM Treasury | Post-Brexit separate screening required for UK-bound goods |

- For Air8's core decorative goods client base: most factories not on sanctions lists
- Elevated risk: any supplier connected to Xinjiang (UFLPA overlap), Russian-controlled entities, or Iranian-connected intermediaries
- **All sanctions screening → [Air8 main KB → NODE-adverse-screen.md — in air8-databases/SHI-KB/]**

---

## ENFORCEMENT CASE STUDIES (2024–2025)

| # | Case | Year | Facts | Outcome |
|---|---|---|---|---|
| 1 | UFLPA — Cotton decorative pillow | 2025 | CBP detained shipment; importer provided complete Tier 1–3 cotton traceability (GOTS-certified cotton, non-Xinjiang farm) | Released after **6 weeks** review; importer incurred storage + legal fees ~$15,000 |
| 2 | UFLPA — Wooden ornaments | 2025 | Supplier was connected to Xinjiang-based component supplier; importer could not provide Tier 2 attestation | Held at port **90+ days**; eventually returned to origin; importer lost $280,000 order value |
| 3 | HS misclassification — LED ornaments | 2024 | Decorative items with LED lights classified as 9505 instead of 9405; discovered during CBP audit | Duties reassessed; **penalty assessed**; importer required to post increased customs bond; future shipments flagged for enhanced examination |
| 4 | COO fraud — "Made in China" mislabel | 2024 | Factory certified products as made in China but key cotton components from Xinjiang without disclosure; CBP cross-referenced with UFLPA data | Shipment seized; factory added to **CBP watch list**; importer received import alert; subsequent imports subject to 100% examination |
| 5 | Prop 65 failure — ceramic ornaments | 2024 | California retailer sold ceramic ornaments with lead at 0.8 µg/day (above 0.5 µg threshold) without Prop 65 warning | AG enforcement action; civil penalty **$450,000**; reformulation + relabeling required |

---

## LINKED FILES

- [[Air8 main KB → NODE-adverse-screen.md — in air8-databases/SHI-KB/]]([Air8 main KB → NODE-adverse-screen.md — in air8-databases/SHI-KB/]) — Sanctions screening and adverse party checks (do not duplicate here)
- [L1-compliance-interpretation.md](../L1/L1-compliance-interpretation.md) — Product category routing, grey-area classification
- [L1-compliance-response.md](../L1/L1-compliance-response.md) — How to handle trade compliance queries and data gaps
- [DT/DT-internal-data-map.md](../DT/DT-internal-data-map.md) — Internal data sources, buyer and shipment records
