# NODE · BS-PROXY (Buyer-Supplier Pair Scorecard Proxy)

**What this is.** A proxy scoring method used in F1 Lead Scoring (CP4.5) to estimate a supplier's full F2 scorecard score when only partial data is available. "B/S" = **Buyer-Supplier pair quality** — not balance sheet.

**Why it exists.** The full F2 Supplier Scorecard requires three dimensions: QAQC (inspection data) + Performance (trading docs / FR records) + B/S Pair (customs + CI + PulseLink). In F1 (lead scoring), QAQC and Performance data are unavailable for new leads — we only have customs, company profile, and PulseLink signals. The B/S Pair dimension can be computed alone, then extrapolated to approximate the full 100-point scorecard.

**Proxy math.** B/S Pair dimension max = 40 points. Full scorecard = 100 points.

```
Proxy rating = (B/S Pair score / 40) × 100
```

This proxy replaces a full F2 assessment for shortlisted leads at CP4.5. It is labelled as a proxy — never presented as a completed F2 scorecard.

---

## Data Sources

| Source | Role in B/S Pair scoring | Priority |
|---|---|---|
| Customs / 1688 | Buyer identity, shipment cadence, product breadth, flow trend | Primary |
| Company profile (CI) | Registered capital, employee count, factory vs trader distinction | Secondary |
| PulseLink | Existing Air8 relationship signals, group structure | Cross-check |

---

## B/S Pair Dimensions — Apparel vs Hardgoods

> **⚠️ Thresholds pending.** The sub-indicator structure below is confirmed; specific scoring bands for apparel and hardgoods to be supplied by Jerri. Once received, add as versioned rows (valid_from + evidence + n) and mirror in `scoring_config.json`.

### Shared sub-indicators (apply to both apparel and hardgoods)

| Sub-indicator | What it measures | Data source |
|---|---|---|
| Buyer concentration | What % of supplier's volume goes to this buyer / buyer type | Customs |
| Relationship continuity | Months of active shipments in trailing 24m | Customs / FR records |
| Flow trend | RISING / STABLE / DECLINING (same method as NODE-product-trend) | Customs (P1Y vs P2Y) |
| Buyer programme status | Is the buyer programme ACTIVE or DEAD? | DB buyer table / `_to_db/buyer_programme_status.csv` |

### Apparel-specific B/S signals

| Signal | Notes |
|---|---|
| Buyer type premium | US mass retail, EU fast fashion buyers carry different retention profiles than specialty |
| Category exposure | Multi-segment exposure vs single-segment concentration |
| *(Thresholds TBD)* | |

### Hardgoods-specific B/S signals

| Signal | Notes |
|---|---|
| Buyer quality (US mass) | Whether buyer is US mass/off-price — strongest hardgoods stickiness signal (56pp gap in calibration) |
| Category durability | HTB/Decor > Kitchen/Dining >> Furniture (per hardgoods v3.0 calibration) |
| Ticket structure | Within vs above category band — a proxy for order quality |
| *(Thresholds TBD)* | |

---

## Scoring Rules

> All threshold rows to be filled in once Jerri confirms. Format follows NODE-scoring-framework.md (valid_from · evidence · n columns required).

### Apparel B/S Pair — Bands

| Sub-indicator | Max pts | Bands | Valid from | Valid to |
|---|---|---|---|---|
| *(TBD)* | — | — | — | — |

**Apparel B/S Pair max: — pts (of 40 total)**

### Hardgoods B/S Pair — Bands

| Sub-indicator | Max pts | Bands | Valid from | Valid to |
|---|---|---|---|---|
| *(TBD)* | — | — | — | — |

**Hardgoods B/S Pair max: — pts (of 40 total)**

---

## Proxy Extrapolation

Once B/S Pair score is computed:

```
If B/S Pair max = 40 pts:
  Proxy rating (0–100) = (B/S Pair score / 40) × 100

Tier from proxy:
  A: ≥75  (equivalent to scoring 30/40 or better on B/S alone)
  B: ≥50  (equivalent to scoring 20/40 or better)
  C: else

Label all outputs: "B/S Proxy — partial scorecard only (F2 full scorecard not yet run)"
```

**Confidence levels:**
- HIGH: customs + PulseLink both available and consistent
- MEDIUM: customs only, no PulseLink cross-check
- LOW: company profile only (customs unavailable)

LOW-confidence proxy scores must be labelled as such and carry less weight in the CP4 sort.

---

## How This Connects to F2

When a lead converts to a confirmed buyer-supplier pair and enters the F2 workflow:
- The B/S Proxy from F1 is **not reused** — a fresh F2 scorecard is run
- The F2 scorecard adds QAQC and Performance dimensions for a full 100-point assessment
- The proxy score may be used as a "prior estimate" for comparison but does not set the F2 tier

---

## Links

- **—PROXIES→ [EVENT-KB: SUPPLIER]**: proxy result stored in DB: `bs_proxy_score`, `bs_proxy_tier`, `bs_proxy_confidence`, `bs_proxy_date`
- **—FOLLOWS_METHOD_FROM→ [NODE-performance-scorecard]**: B/S Pair dimension is the same calculation as the B/S Pair dim in the full F2 scorecard
- **—READS→ [NODE-product-trend]**: flow trend sub-indicator
- **—READS_BUYER_STATUS_FROM→ [DB / `_to_db/buyer_programme_status.csv`]**: dead programme check
- **—READS_SOURCE_HIERARCHY→ [NODE-evidence-source]**: source credibility for customs/CI/PulseLink
- Discipline: `../layer1/L1-evidence-discipline.md`

## Change Protocol

When thresholds are supplied:
1. Add rows with `valid_from`, `evidence`, `n`
2. Mirror in `scoring_config.json` under `bs_proxy.apparel` and `bs_proxy.hardgoods`
3. One line in `L1-decision-log.md`
4. Update the proxy tier cut thresholds if max points change
