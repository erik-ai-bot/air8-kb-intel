# NODE · RISK-CATEGORIES

**What this is.** The 9 SHI risk nodes. Each node defines what triggers it, its default risk level, who approves it, what evidence is required, and the pass/escalation criteria. Read by: SHI Validation Skill (SV2 — Detect; SV3 — Resolve).

**How to update:** Set `valid_to` on the old row, add new row with `valid_from` + evidence + n. Log in `ops/decision-log.md`.

Only rows with `valid_to = —` are active.

---

## Risk Node Instances

| Node ID | Risk Category | Risk Level | Default Approver | Valid from | Valid to |
|---------|--------------|------------|-----------------|------------|---------|
| R1 | Payment Terms / Due-Date / Tenor Risk | ⚡ MEDIUM | A8 Ops | 2026-08-13 | — |
| R2 | Quantity / Price / Amount Variance Risk | ⚡ MEDIUM | A8 Ops | 2026-08-13 | — |
| R3 | Late / Early / Partial Shipment Timing Risk | ⚡ MEDIUM | A8 Ops | 2026-08-13 | — |
| R4 | Transport Document / Shipment Evidence Risk | ⚠️ HIGH | G4 Review | 2026-08-13 | — |
| R5 | Third-Party Shipper / Consignee / Logistics Risk | ⚠️ HIGH | G4 Review | 2026-08-13 | — |
| R6 | PO / Invoice Format, Signature, Chop, Version Risk | ⚠️ HIGH | G4 Review | 2026-08-13 | — |
| R7 | Document Linkage / Identifier / Entity Name Risk | ⚠️ HIGH | G4 Review | 2026-08-13 | — |
| R8 | Payment Collection / Bank Account / A8 Payee Risk | ✅ LOW | Ops at FR stage | 2026-08-13 | — |
| R9 | Buyer Acceptance / Portal / Reconciliation / Sampling Risk | ⚠️ HIGH | G4 Review | 2026-08-13 | — |

---

## R1 — Payment Terms / Due-Date / Tenor Risk

**Definition:** Non-standard or changed payment term, tenor start date or buyer payment portal logic.

**Triggers:**
- Payment terms changed (e.g. 60 → 90 days)
- Payment terms inconsistent across PO, invoice, or system
- Due date calculated from non-standard date (delivery receipt, portal entry, cargo received, Ariba entry)
- Tenor > standard policy limit

**Evidence Pack:**
- PO / invoice / system due-date evidence
- Buyer payment schedule
- Portal screenshot (Transcepta, Ariba, buyer portal)
- SHI approval if non-standard tenor

**Pass Criteria:**
- Proceed if due-date basis is documented, internally consistent, and within policy/insurance tenor
- Escalate if unsupported, > policy limit, or conflicting across PO/invoice/system

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP1.1, AP1.2, AP1.3, AP1.5]

---

## R2 — Quantity / Price / Amount Variance Risk

**Definition:** Variance between PO, invoice, shipment or buyer accepted amount/quantity/price.

**Triggers:**
- Partial / short / over shipment
- Variance > 5% tolerance
- Unit price difference
- Additional amount with adjustment
- Amount mismatch

**Evidence Pack:**
- Line-level reconciliation
- Buyer acceptance confirmation
- Partial shipment proof
- BD confirmation
- SHI reference

**Pass Criteria:**
- Conditional pass if buyer accepts variance and financed amount is correctly adjusted
- Escalate if over-financing risk or buyer confirmation missing
- ⚠️ Tolerance is measured at **total shipment level**, not item-by-item (authority: Pranav email 10-Jul-2025, n=8 cases)

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP2.1, AP2.2, AP2.3]

---

## R3 — Late / Early / Partial Shipment Timing Risk

**Definition:** Timing or shipment split exception where shipment does not follow PO schedule or goods are shipped in parts.

**Triggers:**
- Late shipment (BL date after PO ship date)
- Early shipment
- Partial shipment

**Evidence Pack:**
- Buyer/BD written confirmation
- Nominated forwarder evidence
- Shipment date proof
- SHI reference

**Pass Criteria:**
- Conditional pass if accepted by buyer or implied by buyer-appointed logistics
- FOB + buyer-appointed forwarder → late shipment = buyer's responsibility
- Escalate if PO clearly prohibits and no evidence exists

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP3.1, AP3.2, AP3.3, AP3.4]

---

## R4 — Transport Document / Shipment Evidence Risk

**Definition:** Weak, alternative or non-standard transport evidence.

**Triggers:**
- Draft FCR / digital FCR
- Copy BL (not original)
- Draft BL / Telex-released / Surrendered BL
- Draft Air Waybill / Copy Seaway Bill
- No proof of delivery
- No vessel/container detail *(Air shipments: excluded — not an exception)*
- Missing shipping doc

**Evidence Pack:**
- Carrier/forwarder verification
- Cargo receipt
- Portal tracking
- Document copy + screenshot
- Proof of buyer-appointed logistics

**Pass Criteria:**
- Conditional pass ONLY with carrier/forwarder/portal verification AND buyer-appointed logistics evidence
- Reject/hold if transport evidence cannot prove shipment took place

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP4.1, AP4.2, AP4.3, AP4.4]
**Relation:** BLOCKED-BY → NODE-hard-stops [HS4]

---

## R5 — Third-Party Shipper / Consignee / Logistics Structure Risk

**Definition:** Shipment party differs from supplier/buyer due to manufacturer, nominated forwarder, consignee, warehouse or agent structure.

**Triggers:**
- Third-party shipper (shipper ≠ supplier and ≠ manufacturer)
- Third-party consignee (consignee ≠ buyer and ≠ buyer-nominated party)

**Evidence Pack:**
- Buyer appointment confirmation
- PO/email showing third-party relationship
- Consignee relationship/ownership evidence
- Buyer acceptance

**Pass Criteria:**
- Pass only when relationship is documented and buyer acceptance is clear
- Escalate if goods may be delivered to unrelated party

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP5.1, AP5.2, AP5.3]
**Relation:** BLOCKED-BY → NODE-hard-stops [HS3]

---

## R6 — PO / Invoice Format, Signature, Chop, Version Risk

**Definition:** Document source/format/authenticity issue around signature, chop, system-generated PO/invoice or Excel/email format.

**Triggers:**
- Draft PO / Draft Invoice
- PO not signed/stamped/chop
- Invoice not signed/stamped/chop
- Invoice is editable Excel
- Missing PO / Missing Invoice

**Evidence Pack:**
- System-generated evidence
- Email source confirmation
- Buyer portal screenshot
- Signed/stamped alternate doc if required

**Pass Criteria:**
- Conditional pass if system/portal/email origin is evidenced
- Reject if document is draft/unverifiable or key payable fields (amount, due date, payee) missing

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP6.1, AP6.2, AP6.3]
**Relation:** BLOCKED-BY → NODE-hard-stops [HS5]

---

## R7 — Document Linkage / Identifier / Entity Name Risk

**Definition:** Unable to directly link PO, invoice and transport document, or party/reference mismatch.

**Triggers:**
- No PO/invoice number on shipping doc
- Supplier/buyer name mismatch
- Missing vendor name
- Entity name incomplete

**Evidence Pack:**
- Cross-document linkage: any combination of PO + invoice + BL/FCR/AWB + packing list + container number + customs docs + buyer confirmation

**Pass Criteria:**
- Require direct or indirect linkage through at least one cross-document chain before release
- Indirect linkage (e.g. container number on invoice → BL) is sufficient

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP7.1, AP7.2]

---

## R8 — Payment Collection / Bank Account / A8 Payee Risk

**Definition:** Invoice/buyer payment route differs from expected Air8/PSP account, or bank detail is missing.

**Triggers:**
- No Air8 bank account on invoice
- PSP / Airwallex collection account

**Evidence Pack:**
- A8 bank/PSP master validation
- NoA / MNOA (Notice of Assignment / Master Notice of Assignment)
- Buyer account-change confirmation
- Portal/backend evidence

**Pass Criteria:**
- Hard stop until payment route is confirmed via one of: Air8 account on invoice, AR assignment clause (G4 approved), NoA/MNOA executed, or PSP arrangement pre-approved by management

**Relation:** BLOCKED-BY → NODE-hard-stops [HS1]
**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP8.1, AP8.2, AP8.3]

---

## R9 — Buyer Acceptance / Portal / Reconciliation / Sampling Risk

**Definition:** Buyer acceptance represented by portal data, reconciliation statement, API/exported report or sampling model rather than standard PO/delivery document.

**Triggers:**
- Buyer portal screenshot as delivery/acceptance proof
- Amazon / e-commerce buyer (no physical PO)
- Reconciliation statement ("duizhangdan" / buyer-issued recon statement) as PO/delivery substitute
- Special platforms (Infor Nexus, Transcepta)

**Evidence Pack:**
- Portal export (downloaded/retained)
- Buyer confirmation
- Sampling register
- Reconciliation file
- Audit trail
- Approval email

**Pass Criteria:**
- Proceed only under documented, pre-approved sampling protocol with retained audit trail
- Escalate if sampling scope not approved or data source not independently controlled

**Relation:** RESOLVES-VIA → NODE-auto-pass-rules [AP9.1, AP9.2]
**Relation:** BLOCKED-BY → NODE-hard-stops [HS2]
