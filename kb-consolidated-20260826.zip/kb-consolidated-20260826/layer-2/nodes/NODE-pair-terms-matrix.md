# NODE · PAIR-TERMS-MATRIX (Buyer Rating → Financing Terms)

**What this is.** The terms eligibility matrix for a confirmed buyer-supplier pair. Given a buyer tier (from F3 `NODE-buyer-scoring-framework.md`) and a supplier scorecard tier (from F2 `NODE-performance-scorecard.md`), this node defines what financing terms Air8 will consider offering on the pair.

**Why it exists.** Pair terms are not set by the supplier's quality alone — a T1 supplier paired with a T4 buyer faces different risk than the same supplier paired with a T1 buyer. This matrix captures that dependency so the two assessments are composed, not overridden.

**Status.** ⚠️ **Thresholds TBD.** Matrix structure is confirmed. Specific advance rates, tenors, and concentration limits to be calibrated by Jerri once F3 buyer scoring is live and enough pair data is available (n ≥ 20 per cell is the target).

---

## The Matrix

Rows = Buyer Tier (F3 output). Columns = Supplier Scorecard Tier (F2 output). Each cell = pair terms band.

> **⚠️ All values below are structural placeholders.** Fill `valid_from` + `evidence` + `n` when calibrated. Do not use these numbers for real decisions until validated.

| Buyer \ Supplier | F2 Tier A | F2 Tier B | F2 Tier C | F2 Tier D |
|---|---|---|---|---|
| **T1 (Strong buyer)** | Best terms | Standard+ | Standard | Restricted |
| **T2 (Adequate buyer)** | Standard+ | Standard | Restricted | Restricted |
| **T3 (Weak buyer)** | Standard | Restricted | Restricted | Ineligible |
| **T4 (Poor buyer)** | Restricted | Ineligible | Ineligible | Ineligible |
| **UNKNOWN (buyer)** | Provisional — flag for F3 run | Provisional | No terms | No terms |
| **UNKNOWN (supplier)** | Provisional — flag for F2 run | No terms | No terms | No terms |

---

## Terms Band Definitions (TBD — to be calibrated)

### Best terms
| Parameter | Value | Basis | Valid from | Valid to |
|---|---|---|---|---|
| Max advance rate | TBD% | — | TBD | — |
| Max tenor (days) | TBD | — | TBD | — |
| Concentration limit (as % of programme) | TBD% | — | TBD | — |
| Eligibility | Eligible | — | TBD | — |

### Standard+
| Parameter | Value | Basis | Valid from | Valid to |
|---|---|---|---|---|
| Max advance rate | TBD% | — | TBD | — |
| Max tenor (days) | TBD | — | TBD | — |
| Concentration limit | TBD% | — | TBD | — |
| Eligibility | Eligible | — | TBD | — |

### Standard
| Parameter | Value | Basis | Valid from | Valid to |
|---|---|---|---|---|
| Max advance rate | TBD% | — | TBD | — |
| Max tenor (days) | TBD | — | TBD | — |
| Concentration limit | TBD% | — | TBD | — |
| Eligibility | Eligible | — | TBD | — |

### Restricted
| Parameter | Value | Basis | Valid from | Valid to |
|---|---|---|---|---|
| Max advance rate | TBD% (reduced from standard) | — | TBD | — |
| Max tenor (days) | TBD (shorter than standard) | — | TBD | — |
| Concentration limit | TBD% (tighter) | — | TBD | — |
| Eligibility | Eligible with conditions — see Notes | — | TBD | — |
| Conditions | Collateral / personal guarantee / enhanced monitoring — TBD | — | TBD | — |

### Ineligible
| Parameter | Value |
|---|---|
| Eligibility | **Not eligible for pair financing** |
| Record | Pair record in DB with `pair_terms_eligibility = INELIGIBLE` and reason |
| Visibility | Visible in review with reason — a reviewer's first question is "why isn't this pair here?" |
| Promotable by exception? | Exception possible for Restricted→Standard only. Write exception down in run record. Not applicable for Ineligible. |

---

## Override Conditions

These bypass the matrix tier regardless of F2/F3 scores:

| Condition | Effect | Source |
|---|---|---|
| MATERIAL adverse finding on buyer | Maximum Restricted regardless of buyer tier | NODE-adverse-screen.md applied to buyer entity |
| MATERIAL adverse finding on supplier | Maximum Restricted regardless of supplier tier | NODE-adverse-screen.md applied to supplier entity |
| Buyer `programme_status = DEAD` | Maximum Ineligible — programme has ended | DB buyer table / `_to_db/buyer_programme_status.csv` |
| `buyer_worst_payment_event = DEFAULTED` | Maximum Ineligible — hard gate | NODE-buyer-scoring-framework override |
| Related-party receivable (supplier's counterparty is its own group entity) | INELIGIBLE — structural bar, not a pricing question | L1-evidence-discipline §5 WARNING tag |
| `own_book = TRUE` (pair already financed) | Label `ALREADY FINANCED` — do not issue new terms; retain for model validation | NODE-rating-assembly |

---

## Provisional State (F2 or F3 not yet run)

When one or both tiers are UNKNOWN:

- **F2 UNKNOWN, F3 complete:** Issue provisional terms one tier below what F3 buyer tier would imply at the top supplier tier. Label `PROVISIONAL — supplier scorecard (F2) pending`. Set `pair_terms_valid_until` = 90 days.
- **F3 UNKNOWN, F2 complete:** Issue provisional terms one band below what F2 supplier tier implies at T2 (adequate buyer). Label `PROVISIONAL — buyer assessment (F3) pending`. Set `pair_terms_valid_until` = 90 days.
- **Both UNKNOWN:** No terms issued. Label `PAIR UNSCORED — F2 and F3 both pending`.
- **Provisional terms expire** at `pair_terms_valid_until`. Re-run before expiry or demote to UNSCORED.

---

## DB Fields Written

| Field | Type | Notes |
|---|---|---|
| `pair_terms_band` | ENUM (best · standard+ · standard · restricted · ineligible) | Matrix cell output |
| `pair_terms_advance_rate_max` | DECIMAL | Null until TBD thresholds filled |
| `pair_terms_tenor_max_d` | INT | Null until TBD thresholds filled |
| `pair_terms_conc_limit_pct` | DECIMAL | Null until TBD thresholds filled |
| `pair_terms_basis` | TEXT | Buyer tier + supplier tier + override flags (if any) |
| `pair_terms_version` | TEXT | `pair-terms-v{version}` — from this node's version when calibrated |
| `pair_terms_valid_until` | DATE | 90 days for provisional; 12 months for calibrated terms |
| `pair_terms_eligibility` | ENUM (eligible · restricted · ineligible · provisional · unscored) | Summary field |

---

## Links

- **—READS→ [NODE-buyer-scoring-framework]**: buyer tier (F3 output) — row selection
- **—READS→ [NODE-performance-scorecard]**: supplier scorecard tier (F2 output) — column selection
- **—READS→ [NODE-adverse-screen]**: override conditions for buyer and supplier
- **—READS→ [NODE-rating-assembly]**: already-financed override
- **—READS→ [DB / `_to_db/buyer_programme_status.csv`]**: programme dead → ineligible override
- **—WRITES→ [DB pair table]**: `pair_terms_*` fields above
- Decision log: `../layer1/L1-decision-log.md`

## Change Protocol

When thresholds are calibrated:
1. Fill all TBD cells with `valid_from` + values + `evidence` + `n`
2. Increment version (e.g. `pair-terms-v1.0`)
3. Update `pair_terms_version` DB field on all affected pairs
4. One line in `L1-decision-log.md`

Prerequisite: n ≥ 20 confirmed pairs per matrix cell, or exception approval with reason documented.
