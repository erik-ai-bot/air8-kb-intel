# NODE · ADVERSE-SCREEN (Supplier Adverse Screening)

**What this is.** F1 (CP4.5) and F2 (CP3) adverse screening. Results graded CRITICAL â MATERIAL â SERIOUS â MINOR â NEGATIVE. Verdict written to DB and overrides tier.

**Severity ladder:**

| Label | Meaning | Effect |
|---|---|---|
| CRITICAL | Active enforcement, conviction, debarment, fraud | Hard exclude |
| MATERIAL | Significant regulatory breach, credible allegation | Max Tier C; pair terms Restricted |
| SERIOUS | Fine >= USD 10k, adverse audit | No override; disclosed in call prep |
| MINOR | Minor penalties, isolated complaints | No override |
| NEGATIVE | No adverse information | No action |
| NOT SCREENED | Search not run | Not same as NEGATIVE |

**DB fields:** adverse_verdict, adverse_source, adverse_finding, adverse_date, adverse_version

**Links:**
- âSCREENSâ [EVENT-KB: SUPPLIER]
- âUSES_SOURCEâ [NODE-evidence-source]
- âFEEDS_GATEâ [NODE-scoring-framework]
- âFEEDS_OVERRIDEâ [NODE-performance-scorecard]
- âFEEDS_OVERRIDEâ [NODE-pair-terms-matrix]
- âFEEDS_OVERRIDEâ [NODE-buyer-scoring-framework]
