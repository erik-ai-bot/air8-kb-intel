# NODE · OUTREACH-PROFILE (Outreach Profile)

**What this is.** The fourth determination mode, and the proper home for what used to be the buyer-types / supplier-types files — that content was never an entity **definition** (definitions belong in your event KB), but rather what a type **implies for this specific call**: who signs, what to pitch, what never to lead with, what makes the deal impossible.

```
SCORING-FRAMEWORK  —SCORES→    SUPPLIER   Will they stay?      (CP2)
ADVERSE-SCREEN     —SCREENS→   SUPPLIER   Can we approach?     (CP4.5)
FINANCING-NEED     —ASSESSES→  SUPPLIER   Worth approaching first? (CP4.5)
OUTREACH-PROFILE   —PROFILES→  SUPPLIER   How to approach?     (CP4.5)
```

**Where results go.** DB fields: supplier_type, who_signs, pitch_angle, watch_out; on each supplier×buyer edge: action_tag, buyer_confidence.

**When to run.** CP4.5, shortlist only. All identification features below come from **DB signals** — this does not redefine types in your event KB; identity definitions belong upstream; add missing types there, not here.

## Supplier Types → Approach

| Type | How to Identify from DB | Who Signs | What to Pitch | Notes / Never |
|---|---|---|---|---|
| Independent Factory | Own factory address, has employee count, HS concentrated in 1-2 chapters | Owner / CFO | Receivables purchase anchored to buyer flow | Cleanest deal — performance risk and credit risk are at the same entity |
| Trading Company / Export Agent | Very small registered capital vs very large turnover, HS spans **unrelated** chapters, no factory | Legal representative | Probe incremental uncommitted facility | **Never lead with price** — cheap domestic alternatives + export credit insurance exist; its high cadence aggregates volume from other factories, not a factory signal |
| Listed / SOE Group | Exchange ticker, only company secretary reachable, audited financials available | Board via CFO | True-sale off-balance-sheet treatment against stated deleveraging target, priced on buyer rating | **Never lead with liquidity** — large undrawn credit facilities end the call immediately |
| Partnership / Unincorporated | LEI form code A0PS, PAN 4th character F, named partners | **Partners personally** | Quick first transaction | Personal guarantees in scope; lock in signatories early; no public contact info ≠ no path — it means a referral is needed |
| Vertically Integrated | Own spinning/weaving/dyeing, industry association export rankings | CFO | Receivables + import payables on raw materials — two product lines | Capital intensity makes gearing look like distress; read assets before pitching |
| Parent-Fed Subsidiary | Interest-free holdco loans, near-zero borrowing rate, very short DSO | Parent treasury | Nothing today | **Goes to Floor with revisit trigger** (parent funding withdrawn/repriced); size illusion — looks like top target until you read the funding notes |
| Yarn / Fabric Mill | HS 50-60 | — | — | Park — receivables profile is different; do not occupy a list slot |
| **Own-book (already financed)** | `own_book = TRUE` in DB | — | — | **Do not schedule outreach — already a client.** Stays visible under "Already Financed" for model validation. Cross-sell or renewal is a separate portfolio track. |

## Own-book and LF-tag handling

Any supplier where `own_book = TRUE` is already financed by Air8 and **must not appear in the Call Now list**. Keep it visible with its score and tier under "Already Financed" — the overlap between the model's top picks and the existing book *is* the validation that the model works. Do not treat it as a wasted slot; backfill the call list from Bench.

LF-tagged (affiliate) suppliers: keep in the list with the LF label; treat as lower priority — introduce to the BD pipeline only after the clean Tier A Call Now list is exhausted.

## Buyer Edge → Interpretation

| Edge | Rule | Tag |
|---|---|---|
| Anchor buyer identification | The buyer on the list is often **not** the supplier's largest buyer — open the call with the anchor buyer (examples: Carter's, AEO, Aldi 65%, M&S 76%) | ANCHOR / LEAD WITH THIS / CROSS-SELL |
| Procurement intermediary | A purchasing agent / vendor-of-record is not the brand you are underwriting — identify the ultimate end-brand behind it; if not resolvable, mark concentration "unresolved" | |
| Related party | Counterparty shares group name / address / linked jurisdiction with the supplier → intra-group receivables; **however good the quality, may be undoable** | WARNING |
| Dead programme | Buyer programme_status = DEAD → that flow is never a selling point; attribute churn to buyer first before calling it a scoring miss (ledger: 64% churn is buyer-caused) | Locate in: DB buyer table; seed data `../_to_db/` |
| UK/EU buyer visibility | US customs data does not capture UK/EU-bound flows — **when ledger is active but customs is quiet, the customs record is wrong** | |
| Buyer evidence confidence | CONFIRMED / Self-stated / Our data only / Possibly stale / Unconfirmed / **CONTRADICTED** (buyer list conflicts with supplier's own statement = name collision alert, not a data error) | |

## Links

- **—PROFILES→ [EVENT-KB: SUPPLIER]**: Instance edge; results go to DB
- **—READS→ [EVENT-KB: BUYER]**, **—READS_TYPES_FROM→ [EVENT-KB type sub-files]**: Identity definitions belong in your event KB; add missing types there, not here
- **—USES→ [NODE-financing-need]**: Angle 5/6 output (funding pattern, legal form) feeds who_signs and Floor judgement
- Discipline: `../layer1/L1-evidence-discipline.md`
