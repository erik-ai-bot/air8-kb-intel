# NODE-compliance-social.md — Social Compliance Framework
**Layer:** L2 | **Status:** Stub — references BSCI/SMETA content in NODE-compliance-buyer-rsl.md

## Scope
Social compliance covers labor standards, OHS, wages, discrimination, working hours.
This is distinct from product/chemical compliance (NODE-compliance-product-eu.md) and trade compliance (NODE-compliance-trade.md).

## Primary frameworks covered in this KB
- BSCI (amfori) — see NODE-compliance-buyer-rsl.md §BSCI for full framework
- SMETA (Sedex) — see NODE-compliance-buyer-rsl.md §SMETA for full framework
- WRAP — Worldwide Responsible Accredited Production

## Key distinctions
Social compliance ≠ regulatory compliance.
- Social audits (BSCI/SMETA) assess labor conditions
- Regulatory compliance (REACH, GPSR, Prop 65) assesses product safety and chemical content
- Both may be required for the same client simultaneously
- Run independently, do not combine or confuse

## Links
→ NODE-compliance-buyer-rsl.md (BSCI/SMETA detail)
→ L1-compliance-scope.md (scope routing)
