# NODE · BUYER-INDICATOR (F3 Buyer Assessment — Data Points)

**What this is.** The data dictionary for F3 Buyer Assessment. Maps buyer-level signals to their source locations in the DB and external data. F3 assesses the buyer as an entity — not the pair, not the supplier. A buyer rating from F3 feeds into `NODE-pair-terms-matrix.md` (financing terms eligibility) and the B/S Pair dimension of `NODE-performance-scorecard.md`.

**Scope.** Buyers only — named end brands, retailers, mass market accounts. Intermediaries (HK sourcing agents, vendor-of-record entities) are resolved to their end brand before F3 runs per `L1-evidence-discipline §4`.

**Status.** ⚠️ F3 framework is a skeleton — scoring bands TBD. Structure and indicator list are confirmed; calibrated thresholds to be supplied by Jerri.

---

## Buyer Indicator Inventory

### Group A · Identity & Type

| Indicator | Field name | DB / Source | Notes |
|---|---|---|---|
| Buyer name (resolved) | `buyer_name` | DB buyer table | Must be resolved entity, not intermediary |
| Buyer type | `buyer_type` | DB buyer table | See `NODE-outreach-profile.md` for type taxonomy |
| Buyer geography (primary market) | `buyer_geo` | DB buyer table | ISO country code of primary sales market |
| Public / Private | `buyer_public` | DB buyer table · Bloomberg · 10-K | Listed status affects data availability |
| Annual revenue (est.) | `buyer_revenue_usd` | Public filings · Bloomberg · press | USD, trailing 12m. `NOT FOUND` if unavailable — do not estimate |
| Credit rating (public) | `buyer_credit_rating` | S&P / Moody's / Fitch · Bloomberg | Only public ratings accepted. `NOT RATED` if absent — do not extrapolate |

### Group B · Programme Health

| Indicator | Field name | DB / Source | Notes |
|---|---|---|---|
| Programme status | `buyer_programme_status` | DB buyer table · `_to_db/buyer_programme_status.csv` | ACTIVE / DEAD / WINDING DOWN / UNKNOWN |
| Programme age (months) | `programme_age_m` | DB: `programme_start_date` → today | Trailing months since first FR on this buyer |
| Active supplier count (Air8) | `buyer_air8_supplier_count` | DB: count of distinct suppliers with FRs for this buyer in trailing 24m | Proxy for programme breadth |
| FR volume (trailing 12m, USD) | `buyer_fr_volume_usd_t12` | DB FR table | Aggregate FR value across all Air8 pairs for this buyer |

### Group C · Payment Performance (our data)

| Indicator | Field name | DB / Source | Notes |
|---|---|---|---|
| Average payment delay (days) | `buyer_avg_payment_delay_d` | DB FR table: mean of `(payment_date - due_date)` across all FRs for this buyer | Positive = late; negative = early |
| Dispute rate | `buyer_dispute_rate` | DB FR table: disputed FRs / total FRs for this buyer | All Air8 pairs, not just this supplier-pair |
| Worst payment event | `buyer_worst_payment_event` | DB FR table | NONE / DELAYED / DISPUTED / DEFAULTED |

### Group D · Market Signals

| Indicator | Field name | DB / Source | Notes |
|---|---|---|---|
| Buyer market trend | `buyer_market_trend` | `NODE-market-trend.md` output | RISING / STABLE / DECLINING — from market-level data, not buyer-specific |
| SKU rationalization signal | `buyer_sku_signal` | Press · earnings calls · trade press | EXPANDING / STABLE / RATIONALIZING / UNKNOWN |
| Buyer concentration risk | `buyer_conc_risk` | DB: top-1 supplier share of buyer's FR volume | % of all Air8-financed volume concentrated in a single supplier |

---

## Missing Data Handling

| State | Label | Action |
|---|---|---|
| Indicator not found anywhere | `NOT FOUND` | Use `NOT FOUND`; do not impute. Record the source checked. |
| Indicator found but stale (> 18m) | `STALE (date)` | Flag. Use provisionally with label. Queue for refresh. |
| Intermediary resolved to brand | `RESOLVED: [brand name]` | Continue with resolved entity. |
| Intermediary unresolvable | `INTERMEDIARY UNRESOLVED` | Park. Do not score F3. Cannot assess buyer without confirmed end brand. |
| All Group C payment data missing | `OWN DATA: NONE` | No payment performance score. Not equivalent to zero disputes. |

---

## Links

- **—FEEDS→ [NODE-buyer-scoring-framework]**: indicator values → buyer score
- **—READS_CONTRACT_FROM→ [L1-db-field-contract]**: field mapping and null-handling rules; buyer fields follow the same contract as supplier fields
- **—READS→ [L1-evidence-discipline]**: entity resolution §3 (intermediary → end brand), evidence grades §4
- **—READS→ [NODE-outreach-profile]**: buyer type taxonomy
- **—READS→ [NODE-market-trend]**: market trend signal (Group D)
- **—READS→ [DB]**: buyer table, FR table
- **—READS→ [DB / `_to_db/buyer_programme_status.csv`]**: programme status lookup
