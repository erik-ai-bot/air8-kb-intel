# NODE · BUYER-STANDING

**What this is.** Buyer-specific standing rules that take precedence over general risk classification. Pre-negotiated with G4/management. Read by: SHI Validation Skill (SV3 — Resolve), checked before auto-pass rules.

Only rows with `valid_to = —` are active.

---

## TJX Group
*(includes Marshall, Newton, HomeGoods, Wiggle — all sub-entities)*

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| Due date basis | Due date = cargo received date (not BL date, not invoice date) | TJX universal SHI #74; Dynamic Decor case | 2026-08-13 | — |
| Payment batch split | Separate payment batch per sub-entity: Newton / Marshall / HomeGoods | Abhishek email 15-Oct-2025 | 2026-08-13 | — |
| Draft FCR | Transcepta invoice submission and acceptance record = buyer acceptance proof | TJX universal SHI #74 | 2026-08-13 | — |

**Relation:** APPLIES-TO → R1 [due date basis], R4 [draft FCR]

---

## Amazon (all entities: Amazon.com, Amazon EU, etc.)

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| No physical PO | E-commerce structure; API-based; no PO required | Management approval case-by-case | 2026-08-13 | — |
| Sampling protocol | Pre-approved scope required: top 5 FRs by amount OR 20% of invoices by number + amount descending | Management approval | 2026-08-13 | — |
| Air8 sub-account | Vendor opens Amazon sub-account to Air8 for data access | Erik/management one-off approval — NOT standard Ops approval | 2026-08-13 | — |
| Retain records | Portal reports + reconciliation files + sampled docs + audit trail must be kept per drawdown | Management requirement | 2026-08-13 | — |

**Relation:** APPLIES-TO → R6 [no PO], R9 [sampling], R8 [sub-account]

---

## Walmart HK

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| Maersk records | Maersk system records = buyer confirmation of goods acceptance | G4 approval; Hongkong Yongping case | 2026-08-13 | — |
| Non-standard shipping | G4 approval required for all non-standard shipping arrangements | G4 standing | 2026-08-13 | — |

**Relation:** APPLIES-TO → R4 [transport doc], R9 [buyer acceptance]

---

## C&A / Ariba

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| Due date basis | Due date = Ariba (SAP) system entry date | G4 pre-approved; Vamani/C&A case | 2026-08-13 | — |

**Relation:** APPLIES-TO → R1

---

## Kohl's / Infor Nexus

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| Special platform | Two-party operational flow: Infor Nexus + FCB Refactor Bank; different FR controls | Al-Karam/Kohl's SHI #77 | 2026-08-13 | — |
| Protocol | Refer to dedicated email: "INFOR NEXUS - KOHL'S INC Operation Flow" | SHI folder | 2026-08-13 | — |

**Relation:** APPLIES-TO → R9

---

## FEIT Electric

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| No unit price on PO | FEIT never includes unit cost on PO — standard practice | Surya Roshni/FEIT case; supplier confirmation | 2026-08-13 | — |
| No PO signature | System-generated PO; no signature required | Surya Roshni/FEIT case | 2026-08-13 | — |

**Relation:** APPLIES-TO → R6

---

## Dollar Tree Group
*(Dollar Tree, Family Dollar, all entities)*

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| Single buyer | All entities receive PO from poimport@dollartree.com — treat as single buyer entity | RD Infrastructure case | 2026-08-13 | — |

**Relation:** APPLIES-TO → R7 [entity linkage]

---

## Back-to-Back Structures
*(Trade Aid / BPC2 / Continental Light Leathers pattern)*

| Rule | Detail | Authority | Valid from | Valid to |
|------|--------|-----------|------------|---------|
| 1st leg | Ops approves FR release; NO payment release at this stage | Back-to-back SHI #1 | 2026-08-13 | — |
| 2nd leg | Ops approves FR + payment to manufacturer | Back-to-back SHI #2 | 2026-08-13 | — |
| Double-financing guard | Reject 1st leg FR once 2nd leg payment is released | Back-to-back SHI #2 | 2026-08-13 | — |
| NoA requirement | Ensure NoA properly executed to secure payment to Air8 account | Back-to-back SHI #1 | 2026-08-13 | — |

**Relation:** APPLIES-TO → R5 [3rd party consignee], R8 [payment route]
