# NODE-compliance-product-eu.md
**Layer:** L2 — Product Knowledge | **Domain:** EU Product Compliance
**Last updated:** 2026-08-26 | **Covers:** REACH, SVHC, PFAS, GPSR, CE, RoHS, PPWR

---

## REACH — BASICS & SCOPE

**Regulation:** EC No 1907/2006 (Registration, Evaluation, Authorisation and Restriction of Chemicals)

### Who is covered

| Actor | Definition | Primary duty |
|---|---|---|
| Manufacturer | Produces substance/article in EU | Register substances; communicate hazard info |
| Importer | Brings goods into EU from outside | Same registration duties as manufacturer; communicate SVHCs |
| Distributor | Buys and resells without altering | Pass SDS/SVHC info downstream |
| Downstream user | Uses substance in industrial/professional activity | Comply with restrictions; report SVHC use |

### Scope of "articles"

An **article** under REACH is an object with a specific shape, surface, or design that determines its function more than its chemical composition (e.g., ornaments, textiles, ceramics). Chemicals intentionally released from articles (e.g., fragrance from scented candles) are treated as **substances** and must be registered if >1 tonne/year.

### Duty to communicate SVHC information

- If an article contains an SVHC **>0.1% w/w**, the supplier must:
  1. Notify ECHA via the **SCIP database** (within 6 months of SVHC candidate list inclusion)
  2. Inform professional customers **free of charge, within 45 days** of receiving a request
  3. Inform consumers **free of charge, within 45 days** of receiving a request
- The 0.1% threshold applies **per article**, not per shipment or batch

---

## REACH SVHC — CANDIDATE LIST (253 substances as of Feb 2026)

### Most recent additions (Feb 4, 2026)

| Substance | CAS | Use in decorative articles | Threshold trigger |
|---|---|---|---|
| **n-Hexane** | 110-54-3 | Solvent in adhesives, cleaning agents, coatings, foam production | >0.1% w/w in article |
| **BPAF / Bisphenol AF** | 1478-61-1 | High-performance coatings, epoxy resins, optical polymers, surface treatments | >0.1% w/w in article |

**Practical implication for Feb 2026 additions:** SCIP notification deadline = **Aug 4, 2026** (6 months after listing). Downstream suppliers must also be informed by that date.

### Common substance categories in decorative items

| Category | Substances | Typical articles | Risk level |
|---|---|---|---|
| Phthalates | DEHP, DBP, BBP, DIBP | PVC decorations, synthetic ribbons, plastic ornaments | HIGH — some already restricted (see Annex XVII) |
| Lead compounds | Lead acetate, lead oxide | Painted ceramics, pigments, enamels | HIGH — hard limit in paints |
| Cadmium | Cadmium sulfide, cadmium pigments | Yellow/red pigments in ceramics, plastics | HIGH — restricted in metal articles |
| Chromium VI | Chromium trioxide, dichromates | Metal plating, leather tanning, pigments | HIGH — restricted |
| Azo dyes | Various (50+ listed amines) | Fabric decorations, printed textiles, dyed components | HIGH — prohibited if cleave to carcinogenic amines |
| Formaldehyde | CAS 50-00-0 | Foam, MDF, resins, pressed wood | MEDIUM — emission limits apply |
| PAHs | Benzo[a]pyrene + 7 others | Rubber parts, plastic handles, black components | MEDIUM — restricted in rubber/plastic |

### SCIP database — submission requirements

| Field | Description |
|---|---|
| **Article identifier** | Product name + version/batch |
| **Primary article category** | TARIC code or EWC code |
| **SVHC name** | From candidate list |
| **SVHC concentration** | % w/w in the article |
| **Safe use instructions** | If relevant |
| **Supplier details** | Legal entity name, address, DUNS or similar |

- **Portal:** ECHA's IUCLID Cloud — free to use (no fee for SCIP submissions)
- **Format:** IUCLID dossier or simplified SCIP submission wizard
- **Who submits:** Supplier of the article to the EU market (importer or EU manufacturer)
- **SVHC update cycles:** ECHA typically updates the candidate list **twice per year** — February and June/July

---

## REACH ANNEX XVII — RESTRICTED SUBSTANCES (Hard Bans and Limits)

Annex XVII restrictions are **legally binding limits**, not voluntary. Non-compliance = product cannot be placed on EU market.

### Restrictions relevant to decorative articles (HS 9505, 6304, 6913, 4420)

| Entry | Substance / Group | Restriction | Threshold | Notes |
|---|---|---|---|---|
| **Entry 4** | DEHP + DBP + BBP (phthalates) | Prohibited in toys and childcare articles | Any concentration | Not automatically extended to ALL decorative items — see interpretation note |
| **Entry 6** | Lead in paints and surface coatings | ≤ 600 ppm total lead | 600 ppm | Applies to painted surface; ASTM F963 equivalent |
| **Entry 23** | Cadmium and compounds | Limit on metal, plastic, synthetic textile articles | ≤ 100 ppm in plastic; ≤ 500 ppm in some alloys | Check article material type |
| **Entry 27** | Nickel release from articles inserted into pierced body parts | ≤ 0.2 µg/cm²/week | Per pierced article | Ornaments with metal pins, earring-style decorations |
| **Entry 27** | Nickel release from articles in prolonged contact with skin | ≤ 0.5 µg/cm²/week | Per article | Decorative items worn or held |
| **Entry 43** | Azo colorants releasing carcinogenic amines | Prohibited in textiles and leather in prolonged skin contact | 30 mg/kg of amine | Fabric ornaments, printed textile decorations |
| **Entry 50** | PAHs in rubber/plastic articles | ≤ 0.5–10 mg/kg depending on article type | Per PAH per article | Black plastic fittings, rubber components |
| **Entry 63** | CMR substances in consumer mixtures | Category 1A/1B restricted if >0.1% | Mixture-level | For cleaning/treatment products that accompany decorative items |

> ⚠️ **INTERPRETATION NOTE:** Decorative items that are **NOT children's products** may not automatically fall under Entry 4 phthalate prohibitions. Whether an article is considered a "toy" or "childcare article" depends on intended use, marketing, and product labeling. Route to → [L1-compliance-interpretation.md](L1-compliance-interpretation.md) for category determination.

---

## PFAS RESTRICTIONS

### EU Regulation 2025/464 — PFAS in consumer products

| Product category | PFAS limit | Effective date | Grace period end |
|---|---|---|---|
| Clothing, footwear, accessories | ≤ 50 mg F/kg total PFAS | **July 1, 2026** | Jan 1, 2027 (grandfathering of stock manufactured before July 1, 2026) |
| Textile articles (decorative fabrics, curtains, cushion covers) | ≤ 50 mg F/kg | July 1, 2026 | Jan 1, 2027 |
| Leather articles | ≤ 50 mg F/kg | July 1, 2026 | Jan 1, 2027 |

### REACH broad PFAS restriction (universal restriction proposal)

- ECHA received a universal PFAS restriction proposal (submitted by DE/NL/DK/SE/NO authorities)
- RAC (Risk Assessment Committee) opinion expected **Q3 2026**
- Covers essentially all PFAS above analytical detection limits across all consumer products
- Timeline to final restriction: earliest **2027**, likely phased

### POP Regulation PFOS/PFOA

- PFOS and PFOA already banned under EU POP Regulation (EU) 2019/1021
- Temporary exemptions for specific industrial uses **expired Dec 2025**
- PFOS/PFOA in any consumer product = immediate non-compliance

### PPWR PFAS in food-contact packaging

- **EU Regulation 2025/40** includes PFAS limit of **25 ppb** in food-contact packaging
- Applies to packaging of food-adjacent products (e.g., kitchen decor items sold with food, gift sets with food components)

### Product category routing for PFAS

| Article type | PFAS regulation applies? | Check |
|---|---|---|
| Fabric-based decorations (textile, felt, burlap) | YES — 50 mg F/kg limit from July 2026 | Test for total PFAS |
| Decorative hardgoods (ceramic ornaments, glass, metal statues) | **NO** — not in clothing/textile scope | Not subject to 2025/464 limits |
| Mixed articles (fabric + hard component) | Fabric component: YES; hard component: NO | Test fabric portion separately |
| Foam/stuffed decorative items | Depends on textile outer layer — if fabric: YES | Check material composition |

> ⚠️ Route product category questions to → [L1-compliance-interpretation.md](L1-compliance-interpretation.md)

---

## EU GPSR — General Product Safety Regulation (EU) 2023/988

**Effective:** December 13, 2024 (fully applicable — replaced GPSD 2001/95/EC)
**Applies to:** ALL consumer products sold in EU (online + offline, new + used, B2C)

### Key obligations for non-EU manufacturers / exporters to EU

#### 1. EU Authorized Representative (EU AR) — MANDATORY

| Requirement | Detail |
|---|---|
| Who needs it | Any non-EU manufacturer placing products on EU market |
| What it is | EU-based legal entity acting on behalf of manufacturer |
| Responsibilities | Maintain technical file; cooperate with market surveillance within 10 days; manage recalls/withdrawals |
| Label requirement | EU AR name, address, contact must appear **on product label or packaging** |
| Cost (via service firms) | €300–800/year typical; example providers: AR Services Europe, COFACE, Bureau Veritas EU AR service |
| Liability | EU AR can be held liable for product safety violations |

#### 2. Declaration of Conformity (DoC)

- Signed by **manufacturer**, countersigned or referenced by **EU AR**
- Must reference: applicable regulations, standards used, product description, model/batch identifier
- Kept for **10 years** from last date of manufacture

#### 3. Product Safety Assessment

- Risk analysis required for all consumer products
- Must assess: foreseeable use, foreseeable misuse, vulnerable consumers (children, elderly)
- Not required to be submitted to authorities proactively — but must be produced on request

#### 4. Traceability

- Batch/lot numbers or serial numbers on products or packaging
- Supplier records maintained for **10 years**
- Enables targeted recalls (batch-level, not full product line)

#### 5. Incident Reporting

- **Serious incidents** (injury, death) → reported to EU Safety Gate within **2 business days** of becoming aware
- EU Safety Gate: ec.europa.eu/safety-gate — public-facing portal for market surveillance notifications

#### GPSR vs. CE Marking

> ⚠️ **GPSR does NOT require CE marking.** CE marking is sector-specific (required only under specific EU directives such as LVD, EMC, Toy Safety). A general decorative ornament compliant with GPSR does not need CE marking.

---

## CE MARKING — When Required for Decorative Items

| Scenario | CE required? | Applicable directive |
|---|---|---|
| General decorative ornament (ceramic, glass, fabric, wood) — no electrical parts | **NO** | None |
| Decorative item with LED lighting, plug-in connection | **YES** | Low Voltage Directive (2014/35/EU) + EMC (2014/30/EU) |
| Battery-operated decorative lights | **YES** (if >50V AC or >75V DC) | LVD; EMC; confirm voltage threshold |
| Decorative item marketed as/sold as toy | **YES** | Toy Safety Directive (2009/48/EC) / EN 71 |
| Decorative candle or similar fire-risk item | NO (CE) | But covered by GPSR safety assessment |
| Outdoor lights for decoration | **YES** | LVD + EMC + potentially ErP Directive |

> ⚠️ **Selling without required CE marking = immediate prohibition from EU market**. Border authorities will detain shipment and notify market surveillance.

### CE marking steps (for electrical decorative items)

1. Identify applicable directives (LVD, EMC, RoHS at minimum)
2. Conduct conformity assessment (self-declaration acceptable for most decorative lighting)
3. Prepare technical file
4. Sign DoC
5. Affix CE mark (minimum 5mm height on product or packaging)

---

## RoHS DIRECTIVE — 2011/65/EU + Amendment (EU) 2015/863 (RoHS 3)

**Applies to:** Electrical and Electronic Equipment (EEE) — products that **require electric current or electromagnetic field to function**

### When does RoHS apply to decorative items?

| Article | RoHS applies? | Reason |
|---|---|---|
| Ceramic ornament with no electrical parts | **NO** | Not EEE |
| LED-lit Christmas ornament (battery or plug) | **YES** | Contains EEE |
| Music box with motor | **YES** | EEE |
| Painted wooden figure | **NO** | Not EEE |
| Scented candle with electronic timer | **YES** | Contains EEE |

### RoHS restricted substances

| Substance | Max concentration (homogeneous material) |
|---|---|
| Lead (Pb) | 0.1% (1,000 ppm) |
| Mercury (Hg) | 0.1% |
| Cadmium (Cd) | **0.01% (100 ppm)** — stricter |
| Hexavalent Chromium (Cr VI) | 0.1% |
| PBB (Polybrominated biphenyls) | 0.1% |
| PBDE (Polybrominated diphenyl ethers) | 0.1% |
| DEHP | 0.1% |
| BBP | 0.1% |
| DBP | 0.1% |
| DIBP | 0.1% |

> ⚠️ **Note:** Coatings or paints applied to non-EEE decorative items (e.g., paint on a ceramic figure) do **not** trigger RoHS. RoHS substance limits apply to the **homogeneous material** of the EEE components themselves.

---

## EU PPWR — Packaging and Packaging Waste Regulation (EU) 2025/40

**Published:** January 22, 2025 | **Entry into force:** February 11, 2025 | **Full application:** August 12, 2026

### Key supplier obligations

| Requirement | Detail | Effective |
|---|---|---|
| Packaging minimization | No unnecessary packaging (no nested empty space >40% volume) | Aug 12, 2026 |
| Recyclability labeling | Numeric material codes (1–7 plastics; paper; glass; metal) on packaging | Aug 12, 2026 |
| PFAS in food-contact packaging | ≤ 25 ppb | From Feb 2025 (immediate) |
| Recycled content targets | Varies by packaging type (plastic bottles: 30% recycled by 2030) | Phased to 2030 |
| Reusability standards | For transport packaging above threshold volumes | Aug 12, 2026 |

### For suppliers shipping to EU buyers

- Ask buyer: **which PPWR-aligned packaging label they require** (some EU markets require "Triman" symbol for France; Point Vert for other markets)
- Ensure packing list and invoice state **packaging material composition** for buyer's records
- For high-volume suppliers: PPWR compliance may require redesigning master cartons and inner packs

---

## REGULATORY TIMELINE TABLE

| Regulation | Event | Effective / Milestone date | Status (as of Aug 2026) |
|---|---|---|---|
| REACH SVHC — n-Hexane + BPAF | Added to candidate list | Feb 4, 2026 | ✅ Active — SCIP notification due Aug 4, 2026 |
| PFAS in clothing/textile ban (EU 2025/464) | Effective date | **July 1, 2026** | ✅ Now in force — grace period to Jan 1, 2027 |
| GPSR (EU) 2023/988 | Full application | Dec 13, 2024 | ✅ Already in force — enforcement ongoing |
| PPWR (EU) 2025/40 | Full application | Aug 12, 2026 | ✅ Fully in force as of this month |
| REACH broad PFAS universal restriction | RAC opinion | **Q3 2026** | ⏳ Pending — decision ~2027 |
| PFAS grace period end | Grandfathered stock ban | Jan 1, 2027 | ⏳ Upcoming |

---

## ENFORCEMENT CASE STUDIES (Real Examples 2024–2025)

| # | Jurisdiction / Year | Product | Violation | Outcome |
|---|---|---|---|---|
| 1 | EU Safety Gate 2025 | Christmas decorations (China) | DEHP at 5–12% w/w — phthalate restriction | EU-wide recall; distributor fined; importer blacklisted by several retailers |
| 2 | EU Safety Gate 2025 | Painted ceramic ornaments | Lead at 800 ppm — above 600 ppm Annex XVII limit | Destruction ordered at border; batch seized |
| 3 | Germany market surveillance 2025 | Nickel-plated decorative items | Nickel release 3× legal limit (>0.5 µg/cm²/week) | Nationwide sales ban; recall ordered; supplier audit triggered |
| 4 | US CPSC 2024 | Holiday ornaments (China) | Lead paint at 90 ppm (US limit) — indicates China-source quality issues | Recall + import alert; factory flagged for future CBP inspection |
| 5 | Netherlands 2025 | Foam decorative articles | Formaldehyde emissions above EU limit | Destroyed at border; shipper responsible for return/destruction costs |

---

## LINKED FILES

- [L1-compliance-scope.md](../L1/L1-compliance-scope.md) — What falls within compliance review scope
- [L1-compliance-interpretation.md](../L1/L1-compliance-interpretation.md) — Product category routing and grey-area decisions
- [L1-compliance-response.md](../L1/L1-compliance-response.md) — How to respond to compliance queries
- [L1-regulatory-intelligence.md](../L1/L1-regulatory-intelligence.md) — Regulatory monitoring and update process
- [DT/DT-internal-data-map.md](../DT/DT-internal-data-map.md) — Internal data sources, buyer RSL files
