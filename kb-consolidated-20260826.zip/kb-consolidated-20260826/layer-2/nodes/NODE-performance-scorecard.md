# NODE · PERFORMANCE-SCORECARD (Supplier Scorecard — F2)

**What this is.** F2's core scoring instrument. Distinct from the F1 lead scoring framework — F1 predicts whether a new lead will convert and stay; this scorecard assesses a *confirmed* supplier we already have a relationship with. Two dimensions are live. A third (QAQC ← inspection data) is deferred until inspection thresholds are calibrated.

**Where results go.** DB fields: `perf_score`, `bs_pair_score`, `scorecard_total`, `scorecard_tier`, `scorecard_version`, `scorecard_date`.

**When to run.** F2 CP2, after coverage check (L1-performance-coverage) confirms the data is available.

**How these numbers execute:** `../layer1/L1-scoring-method.md`. Only rows with a blank `valid_to` are active.

**Dimensions:** Performance (Dim 1) · B/S Pair (Dim 2) · QAQC (Dim 3 — now live as of 2026-08-25). All three normalize to 0–1 before the composite merge. QAQC uses weighted band scoring (see Dimension 3 below).

---

## Dimension 1 · Performance ← Trading Documents / FR Records

How well does the supplier execute on confirmed orders?

| Sub-indicator | Max | Bands | Data source | Valid from | Valid to |
|---|---|---|---|---|---|
| On-time delivery rate | 3 | ≥95% → 3 · 85–94% → 1 · <85% → 0 | FR records / trading documents | 2026-08-25 | — |
| Document accuracy rate | 2 | ≥95% → 2 · 80–94% → 1 · <80% → 0 | FR records / trading documents | 2026-08-25 | — |
| Discrepancy rate | ±1 | <1% → +1 · 1–5% → 0 · >5% → −1 (penalty) | FR records | 2026-08-25 | — |

**Performance max: 6 points.** Tiers within this dimension: 5–6 STRONG · 3–4 ADEQUATE · 0–2 WEAK.

*Evidence: Jerri Zhou (confirmed 2026-08-25). Calibrate valid_from with n when FR ledger data is pulled.*

**Missing data policy:** If fewer than 3 completed FRs on file → label INSUFFICIENT DATA, do not score, send to Enrichment. Do not award 0 — zero asserts poor performance; null means unknown.

---

## Dimension 2 · B/S Pair ← Buyer-Supplier Pair Quality (Company Profile + PulseLink + Customs)

How strong is the buyer-supplier relationship as a unit — not the supplier alone, not the buyer alone, but the *pair*?

Proxy rules (when direct pair data is thin): `../layer2/NODE-bs-proxy.md`

| Sub-indicator | Max | Bands | Data source | Valid from | Valid to |
|---|---|---|---|---|---|
| Buyer concentration (% of supplier volume in this buyer) | 3 | ≥50% → 3 · 25–49% → 2 · <25% → 1 | Customs / PulseLink / trading docs | 2026-08-25 | — |
| Relationship tenure (months with active FRs) | 2 | ≥24m → 2 · 12–23m → 1 · <12m → 0 | FR records | 2026-08-25 | — |
| Flow stickiness signal | 2 | RISING or STABLE → 2 · DECLINING → 0 | Customs (P1Y vs P2Y) / NODE-product-trend | 2026-08-25 | — |
| Buyer programme status | ±1 | Programme ACTIVE → +1 · DEAD or UNKNOWN → 0 · DEAD + no replacement buyer → −1 | DB buyer table / `_to_db/buyer_programme_status.csv` | 2026-08-25 | — |

**B/S Pair max: 8 points.** Tiers within this dimension: 6–8 STRONG · 3–5 ADEQUATE · 0–2 WEAK.

*Evidence: Jerri Zhou (confirmed 2026-08-25).*

**Missing data policy:** If buyer cannot be resolved → label B/S PAIR UNRESOLVED, do not score this dimension. If customs data unavailable → use MEDIUM-confidence proxy per NODE-bs-proxy.md and label accordingly.

---

## Score Assembly

| Component | Max points | Merge weight |
|---|---|---|
| Performance | 6 | **45%** |
| B/S Pair | 8 | **40%** |
| QAQC | 1.0 (normalized) | **15%** |

**Method:** Normalize each dimension to 0–1 (score / max), apply merge weights, sum → composite 0–1, multiply by 10 for display.

**Composite tier (provisional):**

| Tier | Composite (0–10) | Meaning |
|---|---|---|
| A | ≥7.5 | Strong on both dimensions — high-confidence pair |
| B | ≥5.0 | Adequate — proceed to limit decision with normal scrutiny |
| C | ≥2.5 | Weak — limit decision needs additional justification |
| D | <2.5 | Poor — pair terms restricted; escalate |

> Provisional thresholds. Calibrate against first cohort of F2 financed pairs once data accumulates (n ≥ 20 per tier).

**Merge formula:**
```
composite = (perf_score/6 × 0.45) + (bs_pair_score/8 × 0.40) + (QAQC_raw × 0.15)
scorecard_total = composite × 10
```

**When QAQC data unavailable:** revert to 2-dim weights (Performance 56% / B/S Pair 44% — scaled proportionally) and label `SCORECARD: 2-DIM (QAQC pending)`. *Evidence: Jerri Zhou (weights confirmed 2026-08-25).*

---

---

## Dimension 3 · QAQC ← Inspection Records

How strong is the supplier's quality control track record as measured through inspection data?

**Scoring method.** Each metric returns a band score ∈ {0, 0.33, 0.5, 0.67, 1}. Multiply by the metric's weight; sum to get QAQC_raw (0–1). QAQC_raw is already normalized — no further division needed.

```
QAQC_raw = (ProductRisk × 0.125) + (OrderVol × 0.125) + (Defect × 0.25) + (Reinsp × 0.05) + (FinalPass × 0.45)
```

**Source:** Inspection records / quality management system. **Valid from:** 2026-08-25. **Evidence:** Jerri Zhou (screencap, direct).

---

### Metric weights (apply to BOTH apparel and H&H)

| Metric | Weight | Rationale |
|---|---|---|
| Product Risk Category | 12.5% | Intrinsic quality risk by material/manufacturing complexity and safety requirements |
| Order Volume | 12.5% | Estimates potential exposure from quality-related commercial disputes |
| Defect Type/Ratio | 25% | Tracks spectrum and frequency of defects — flags clients barely meeting minimums |
| Re-Inspection Ratio | 5% | Re-inspection adds operational cost and shipment delay risk |
| 1st Final Inspection Pass Ratio | 45% | Paramount indicator of past quality control efficacy; directly correlates with on-time delivery |

---

### Apparel QAQC — band tables

**Product Risk Category** (weight 12.5%)

| Category | Band score | Valid from | Valid to |
|---|---|---|---|
| Children & Baby (High Risk) | 0 | 2026-08-25 | — |
| Loungewear & Sleepwear / Costume / Festive (High Risk) | 0 | 2026-08-25 | — |
| Other (Low Risk) | 1 | 2026-08-25 | — |

**Order Volume** (weight 12.5%)

| Band | Condition | Band score | Valid from | Valid to |
|---|---|---|---|---|
| Small | ≤ USD 20K | 1 | 2026-08-25 | — |
| Mid | USD 20K < X ≤ USD 60K | 0.5 | 2026-08-25 | — |
| Large | > USD 60K | 0 | 2026-08-25 | — |

**Defect Type/Ratio** (weight 25%)

Same bands as H&H (Jerri confirmed 2026-08-25):

| Band | Condition | Band score | Valid from | Valid to |
|---|---|---|---|---|
| 1 | ≤ 0.5% | 1 | 2026-08-25 | — |
| 2 | 0.5% < X ≤ 2% | 0.67 | 2026-08-25 | — |
| 3 | 2% < X ≤ 4% | 0.33 | 2026-08-25 | — |
| 4 | > 4% | 0 | 2026-08-25 | — |

**Re-Inspection Ratio** (weight 5%)

| Band | Condition | Band score | Valid from | Valid to |
|---|---|---|---|---|
| Low | ≤ 5% | 1 | 2026-08-25 | — |
| Mid | 5% < X ≤ 10% | 0.5 | 2026-08-25 | — |
| High | > 10% | 0 | 2026-08-25 | — |

**1st Final Inspection Pass Ratio — Apparel** (weight 45%)

Thresholds vary by risk category (High Risk = Children/Baby, Loungewear/Costume/Festive; Low Risk = Other):

| Band | High Risk condition | Low Risk condition | Band score | Valid from | Valid to |
|---|---|---|---|---|---|
| 1 | ≥ 99% | ≥ 99% | 1 | 2026-08-25 | — |
| 2 | 98% ≤ X < 99% | 97% ≤ X < 99% | 0.67 | 2026-08-25 | — |
| 3 | 92% ≤ X < 98% | 90% ≤ X < 97% | 0.33 | 2026-08-25 | — |
| 4 | < 92% | < 90% | 0 | 2026-08-25 | — |

---

### H&H QAQC — band tables

(H&H = Home goods & Hardgoods)

**Product Risk Category** (weight 12.5%)

| Category | Band score | Valid from | Valid to |
|---|---|---|---|
| Electronics / Furniture / Toys (High Risk) | 0 | 2026-08-25 | — |
| Other (Low Risk) | 1 | 2026-08-25 | — |

**Order Volume** (weight 12.5%)

| Band | Condition | Band score | Valid from | Valid to |
|---|---|---|---|---|
| Small | ≤ USD 20K | 1 | 2026-08-25 | — |
| Mid | USD 20K < X ≤ USD 60K | 0.5 | 2026-08-25 | — |
| Large | > USD 60K | 0 | 2026-08-25 | — |

**Defect Type/Ratio** (weight 25%)

| Band | Condition | Band score | Valid from | Valid to |
|---|---|---|---|---|
| 1 | ≤ 0.5% | 1 | 2026-08-25 | — |
| 2 | 0.5% < X ≤ 2% | 0.67 | 2026-08-25 | — |
| 3 | 2% < X ≤ 4% | 0.33 | 2026-08-25 | — |
| 4 | > 4% | 0 | 2026-08-25 | — |

**Re-Inspection Ratio** (weight 5%)

| Band | Condition | Band score | Valid from | Valid to |
|---|---|---|---|---|
| Low | ≤ 1% | 1 | 2026-08-25 | — |
| Mid | 1% < X ≤ 5% | 0.5 | 2026-08-25 | — |
| High | > 5% | 0 | 2026-08-25 | — |

**1st Final Inspection Pass Ratio — H&H** (weight 45%)

| Band | Condition | Band score | Valid from | Valid to |
|---|---|---|---|---|
| 1 | ≥ 99.5% | 1 | 2026-08-25 | — |
| 2 | 99% ≤ X < 99.5% | 0.67 | 2026-08-25 | — |
| 3 | 95% ≤ X < 99% | 0.33 | 2026-08-25 | — |
| 4 | < 95% | 0 | 2026-08-25 | — |

---

### QAQC Dimension tiers

| QAQC_raw | Tier | Meaning |
|---|---|---|
| ≥ 0.75 | STRONG | High quality control track record |
| ≥ 0.50 | ADEQUATE | Meets requirements; some exposure |
| ≥ 0.25 | WEAK | Notable quality vulnerabilities |
| < 0.25 | POOR | Significant quality risk |

**Missing data:** If inspection records unavailable → `QAQC: NO DATA`. Do not score; do not award 0. Revert to 2-dim scorecard and label `SCORECARD: 2-DIM (QAQC pending)`. If partial inspection data (some metrics missing): score available metrics only, weight them proportionally (re-normalize weights of available metrics to sum to 1.0), and label `QAQC: PARTIAL (n metrics of 5 available)`.

---

## Links

- **—GATED_BY→ [L1-performance-coverage]**: CP1 coverage check must pass before this node runs; defines FR minimums, buyer lookup, QAQC routing
- **—READS_METHOD_FROM→ [L1-scoring-method]**: banded additive scoring method; `valid_to IS NULL` filter
- **—READS→ [L1-evidence-discipline]**: entity resolution (buyer identity §3), evidence grades (§4)
- **—READS→ [EVENT-KB: SUPPLIER / BUYER]**: pair data (FRs, buyer programme status) — individual pair data; never stored in KB
- **—READS_PROXY_FROM→ [NODE-bs-proxy]**: when direct pair data is unavailable, use proxy rules here
- **—READS→ [NODE-product-trend]**: flow stickiness signal (P1Y vs P2Y customs trend)
- **—READS→ [NODE-adverse-screen]**: MATERIAL adverse finding overrides scorecard tier regardless of score
- **—FEEDS→ [NODE-rating-assembly]**: scorecard composite total → final F2 tier
- **—FEEDS→ [NODE-pair-terms-matrix]**: F2 supplier scorecard tier → column selection in pair terms matrix
- Discipline: `../layer1/L1-evidence-discipline.md`
- Decision log: `../layer1/L1-decision-log.md`
- Discipline: `../layer1/L1-evidence-discipline.md`
