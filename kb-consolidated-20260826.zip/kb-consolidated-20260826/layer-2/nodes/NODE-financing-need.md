# NODE · FINANCING-NEED (Financing Need Assessment)

**What this is.** A third determination mode: six angles, each with its own data source, producing a banded conclusion. Need is **inferred, not asserted**, and its role is fixed: **sort tertiary tie-breaker only; never removes a lead from the list** (downgraded from filter in 2026-08: often unreliable, often unresolvable).

**Where results go.** DB fields: need_band, need_evidence (**must include numbers** — a band without numbers is opinion, not judgement), need_as_of.

**Context.** Scoring predicts retention, not need — roughly 1 in 4 high-scoring suppliers is investment-grade with low leverage. Tier A + need LOW is the system working correctly, not a contradiction.

## Six Angles

| # | Angle | What to Look For | Data Source |
|---|---|---|---|
| 1 | Rating and limit utilization | **Strongest single signal**: Under Review / Watch = the supplier's own bank is repricing. Read the rationale, not just the rating level | Country rating agencies → NODE-evidence-source |
| 2 | Receivables growth vs revenue growth | Receivables outpacing revenue = visible working capital gap (example: PKR 11.3→48.4→59.3B, gearing 1.77→2.96x = provable VERY HIGH); pair with DSO, operating cash flow | Audited financial statements |
| 3 | Borrowing cost and currency structure | Cheap domestic-currency policy funding = that leg is unbeatable — look for the foreign-currency leg (RMB 2.18-2.31% alongside USD 3.85-5.46%, USD is the wedge); pair with cash cycle drift, DSCR trend | Borrowing notes in financial statements |
| 4 | Collateral registry and encumbered assets | **Collateral exhaustion is a demand signal independent of cash** — when 37.2% of assets are pledged (including plant and land), unsecured receivables purchase has value even to a cash-sufficient company | MCA collateral registry / Companies House charges |
| 5 | Parent funding pattern | Interest-free holdco loans = no receivables gap **and** the negotiation is at parent level; development bank loans to the group = the price you need to beat | Related-party notes in financial statements; walk SUPPLIER→GROUP |
| 6 | Legal form | Partnership/unincorporated = narrower bank channels = positive demand signal; personal guarantees are in scope, lock in the signing partner early | GLEIF LEI legal form code (A0PS = partnership), India PAN 4th character F |

## Bands

| Band | Characteristics | Effect |
|---|---|---|
| VERY HIGH | Receivables outpacing revenue, gearing over ~2.5x, thin cash, rating Under Review | Sort weighting applied |
| VERY HIGH but NOT BANKABLE | Need is real but receivables are intra-group, or entity unresolved | Flagged, cannot be done |
| HIGH | Already discounting invoices, cash cycle lengthening, DSCR declining, shareholder loans | Sort weighting applied |
| MEDIUM | Structural working-capital dependence, no distress signals | — |
| **LOW** | Net cash, minimal short-term borrowing, interest-free parent funding, very short DSO, or publicly stated policy of not discounting receivables | **Goes to Floor page, evidence visible** — Floor answers "why isn't the largest one here?"; never quietly removed |
| UNKNOWN | Nothing can be found | Report honestly; do not guess based on size |

For companies holding large undrawn credit facilities, **never open with liquidity** — the pitch there is true-sale off-balance-sheet treatment against a stated deleveraging target, priced on buyer rating.

## Links

- **—ASSESSES→ [EVENT-KB: SUPPLIER]**: Instance edge; results go to DB
- **—ROUTES_SOURCE_BY→ [EVENT-KB: COUNTRY]**: Route to country-specific institution → coverage table in NODE-evidence-source
- **—TIEBREAKS→ [NODE-scoring-framework]**: Sort tertiary key; LOW → Floor
- Discipline: `../layer1/L1-evidence-discipline.md`
