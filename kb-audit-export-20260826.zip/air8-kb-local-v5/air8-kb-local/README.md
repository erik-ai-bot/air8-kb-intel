# Air8 AI Knowledge Base

Agent-queryable knowledge graph for Air8 BD intelligence.
Designed to be consumed by AI agents for: BD prep, risk review, supplier onboarding, compliance checks.

## Architecture — Two-Layer Design

This KB uses a **two-layer architecture** separating reasoning logic from entity data.
See `ARCHITECTURE.md` for the full reasoning engine specification including weight calculation,
event routing, entity location algorithms, and the end-to-end Cypher query.

```
layer-1-reasoning/   ← How to reason (event types, principles, solutions, pain points, regulations)
layer-2-entities/    ← What the entities are (personas, countries, products, ESG standards)
linkage/             ← Bridge tables connecting both layers (stays at root)
dimensions/          ← Dimension definitions (taxonomy)
data-entities/       ← Raw data entity schemas
```

**Key design constraint:** Entities never point to principles. Principles never point to entities.
The event is the only node holding both sets of keys. See `ARCHITECTURE.md` for details.

## How to Navigate

- **Understand a supplier:** `layer-2-entities/personas/COMBO-*.md` — find the matching archetype
- **Understand a risk event:** `layer-1-reasoning/EVENT-TYPES.md` — find the event type and principles activated
- **Find the right product:** `layer-1-reasoning/SOLUTIONS.md` — event × persona → product recommendation
- **Check compliance:** `layer-1-reasoning/regulations/` — regulation definitions
- **Cross-reference:** `linkage/` — 4 traversal tables for full graph queries

## File Structure

| Location | Contents |
|----------|----------|
| `ARCHITECTURE.md` | Master architecture doc — two-layer engine, weight calculation, Cypher query |
| `layer-1-reasoning/` | Event types, principles, solutions, pain points, regulations, compliance |
| `layer-2-entities/` | Personas (15), countries (8), product categories (2), financing products (9), ESG standards (7), traceability (3) |
| `linkage/` | 4 traversal tables: persona-full, regulation-affected, event-propagation, product-reverse |
| `dimensions/` | 8 dimension definitions (DIM-*.md) + subdimension folders |
| `data-entities/` | 11 data entity schemas (ENTITY-*.md) |

## Source
Air8 KB v3.0 — Two-Layer Architecture
