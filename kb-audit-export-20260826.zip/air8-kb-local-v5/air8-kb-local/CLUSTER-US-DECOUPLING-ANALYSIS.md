---
type: cluster-analysis
id: CLUSTER-US-DECOUPLING
version: 1.0
date: 2026-07-16
author: KB Engine — Subagent
cluster_events: [EVT-REGULATION:forced_labor_uflpa, EVT-TARIFF:section_301/ieepa_decree]
domain: apparel_only (Alice's domain)
combos_scored: [COMBO-004, COMBO-006, COMBO-002, COMBO-009, COMBO-012]
---

# CLUSTER-US-DECOUPLING — Combined Analysis (Events D + F)
## Apparel / Soft Goods Only

> **Cluster purpose:** US strategic decoupling from Chinese supply chains operates through two simultaneous, INDEPENDENT policy levers. Running them as separate events misses the compounding effect on suppliers and buyers who must navigate both simultaneously. This combined analysis scores each apparel combo against BOTH levers and derives a net signal.

---

## Step 1 — Event Understanding

### Combined Event Fields

| Field | Value |
|---|---|
| event_type | EVT-REGULATION + EVT-TARIFF (combined cluster) |
| subtype | forced_labor_uflpa + section_301 + ieepa_decree |
| affected_countries | CN, VN, BD, KH, PK |
| affected_buyer_types | USMassMarket, USGlobalBrand |
| triage_level | HIGH |
| cliff_date_D | ⚡ July 6 (UFLPA/S301 comment deadline — NOW ACTIVE) |
| cliff_date_F | ⚡ Late July 2026 (Federal Register publication — structural break moment) |

### The Two Levers — Mechanism and Independence

| Lever | Mechanism | What It Blocks | Reversibility |
|---|---|---|---|
| **UFLPA** (EVT-REGULATION) | Access denial — import ban | Blocks goods where forced labour in supply chain cannot be ruled out; requires factory-level traceability to gin/raw material | Structural (legislation, not executive order) |
| **IEEPA → Section 301** (EVT-TARIFF) | Cost penalty — tariff on goods by country of origin | Makes listed-country goods price-uncompetitive regardless of factory compliance | S301 = structural once Federal Register (5-10+ yr); IEEPA = cyclical (reversible by executive order) |

**CRITICAL ENGINE NOTE:** These two mechanisms are COMPLETELY INDEPENDENT.
- A factory can be fully UFLPA-compliant (clean traceability documentation) and STILL face Section 301 cost penalties.
- A factory can have ZERO UFLPA exposure (non-cotton product, non-Xinjiang origin) and STILL face Section 301 tariffs on its goods.
- Air8 must have SEPARATE protocols for each lever. They cannot be conflated.

**Also note:** Brand compliance certifications (Nike/Adidas supplier programs, HIGG FEM, Better Work) do **NOT** substitute for factory-level UFLPA documentation. CBP requires the factory to demonstrate cotton origin traceability to gin/raw material level, independently of any brand program.

---

## Step 2 — L0/Principles Matched

### Principles Activated — Combined Event

| Principle | Lever | Weight | What It Checks |
|---|---|---|---|
| PRIN-COUNTRY-EXPOSURE | S301 lever (EVT-TARIFF) | 0.50 | Which countries are tariff targets; country-of-origin exposure by combo |
| PRIN-COMPLIANCE-COST | UFLPA lever (EVT-REGULATION) | 0.50 | Cost and burden of factory-level traceability documentation |
| PRIN-BUYER-GEO-EXPOSURE | Both levers | 0.30 | US buyer jurisdiction — import regulations enforced here; buyer_geo = US |
| PRIN-SUPPLIER-RESILIENCE | Both levers | 0.20 | Persona tag overlap — which combos are significantly impacted by both events |
| PRIN-PRODUCT-TARIFF | S301 lever | 0.30 | HS code tariff exposure by product category (cotton apparel, home textiles) |

### Overlay Rules — ALL Apply

| Overlay | Trigger | Application |
|---|---|---|
| **RP-STRUCTURAL-CHANGE** | Both levers | S301 = structural once Federal Register; IEEPA = potentially cyclical. Treat differently in signal horizon. Must run on every signal before finalizing. |
| **RP-WINDOW** | Cliff dates active | July 6 comment deadline; late-July Federal Register publication. Pre-cliff vs post-cliff signals differ materially. |
| **RP-CONCENTRATION** | Portfolio-level | Air8 simultaneous exposure across BD/VN/KH combos; US-buyer-facing book under systematic pressure if S301 confirmed on multiple countries. |
| **RP-PEER-FAILURE** | COMBO-004 (CN) | If CN factories are closing, check whether Air8's CN clients face same structural forces as peers that closed. Do NOT auto-EXPAND survivors. |

---

## Step 3 — Combo Routing

### Tag Overlap Scoring — Combined Cluster

Event tag set (union of both events):
```
eventTags = [
  "CN", "VN", "BD", "KH", "PK",   ← supplier_country candidates
  "US",                              ← buyer_geo
  "woven", "knit", "home_textiles", "cotton",  ← product + material
  "USMassMarket", "USGlobalBrand"    ← buyer profile
]
```

| Combo | Key Tags | Overlap Count | Combined Score | Impact Band | S3 Eligible? |
|---|---|---|---|---|---|
| **COMBO-004** (CN Medium Woven) | CN, woven, cotton, US buyer | ≥ 4 tags | ~0.85 | HIGH | ✅ |
| **COMBO-006** (VN FDI Knit) | VN, knit, US primary (0.90), USGlobalBrand | ≥ 4 tags | ~0.75 | HIGH | ✅ |
| **COMBO-012** (KH) | KH, knit/woven, EU+US dual, cotton | 3 tags | ~0.62 | MEDIUM | ✅ |
| **COMBO-002** (BD CMT) | BD, knit/woven, EU primary/US secondary, cotton | 3 tags | ~0.57 | MEDIUM | ✅ |
| **COMBO-009** (PK Home Textile) | PK, home_textiles, US+EU, cotton, bank_LC | 3 tags | ~0.48 | MEDIUM | ✅ |

All 5 combos: overlap ≥ 2 AND signal ≠ MONITOR → All 5 included in S3.

**Note:** COMBO-009 is included specifically because it carries a CONDITIONAL POSITIVE signal from the same event — Pakistan's non-Xinjiang cotton origin is a UFLPA compliance advantage. Filtering to top 2 by score would miss this asymmetric upside.

---

## Step 4 — Signal Computation

### COMBO-004: China Medium Woven FOB

**UFLPA Signal (EVT-REGULATION lever):**
- Chinese cotton supply chain → UFLPA rebuttable presumption ACTIVE
- Factory-level documentation to gin/raw material level required (not just brand certifications)
- Chinese cotton sector has known Xinjiang supply chain exposure risk
- Clean documentation pathway exists but requires significant traceability investment
- RP-STRUCTURAL-CHANGE: UFLPA = structural legislation (not reversible by executive order)
- **UFLPA Signal: DO_NOT_EXPAND US-bound** — Compliance block until factory-level documentation package confirmed

**S301 Signal (EVT-TARIFF lever):**
- CN is the primary and original S301 target
- Tariff applies to ALL CN-origin goods regardless of factory compliance status
- IEEPA → S301 replacement: once published in Federal Register, becomes 5-10+ year structural measure
- RP-STRUCTURAL-CHANGE: CONFIRMED structural — S301 on CN is the archetype of a long-duration tariff measure
- RP-PEER-FAILURE check:
  - Why are CN factories closing? Structural causes: US buyer diversion, tariff cost pass-through failure, rising coastal wages
  - Does Air8's COMBO-004 survivor face same structural causes? YES — same tariff exposure, same wage escalation, same US buyer pressure
  - Is new PO inflow from buyers staying in CN durable? Check: multi-season written contracts vs spot orders
  - Margin on new inflow vs existing book? If margin declining while volume grows → classic pre-failure pattern
  - **RP-PEER-FAILURE verdict: Do NOT auto-EXPAND CN survivors.** Volume growth without margin improvement = "not-yet-failed" pattern
- **S301 Signal: DO_NOT_EXPAND US-bound** (structural, confirmed)

**Combined Signal:**
```
COMBO-004: DO_NOT_EXPAND (US-bound, both levers)
PER_AXIS:
  US-bound receivables: DO_NOT_EXPAND (UFLPA docs absent) / CAUTION (UFLPA docs confirmed, S301 still applies)
  EU-bound receivables: CONDITIONAL — maintain ARP on EU-facing buyers (EU-bound ≠ US-bound)
  Hengqin ARP structure: relevant for cross-border cashflow management

AND_IF [UFLPA factory-level documentation confirmed]:
  US-bound signal upgrades from DO_NOT_EXPAND to CAUTION
  (UFLPA risk managed, but S301 cost penalty persists)

RP-STRUCTURAL-CHANGE overlay:
  S301 = structural → do not treat as temporary disruption; rebalance portfolio assumption
  UFLPA = structural → compliance investment is not optional; it is permanent operating cost

RP-PEER-FAILURE overlay:
  Require differentiation evidence from COMBO-004 survivors before any advance expansion:
  (a) Margin per unit stable or improving on new inflows
  (b) Multi-season written buyer commitment (not trial order)
  (c) Specific cost structure advantage vs closed CN peers
```

---

### COMBO-006: Vietnam FDI Knit (US Primary)

**UFLPA Signal (EVT-REGULATION lever):**
- VN activewear typically uses cotton inputs — origin of cotton matters for UFLPA
- If cotton sourced from China (Xinjiang exposure risk) → UFLPA rebuttable presumption active
- Nike/Adidas supplier compliance programs ≠ UFLPA factory-level documentation
- Parent company (Korean/Taiwanese FDI) may have existing compliance infrastructure
- RP-STRUCTURAL-CHANGE: UFLPA structural
- **UFLPA Signal: CONDITIONAL** — AND_IF [factory-level cotton origin documentation confirmed → CAUTION; not confirmed → COMPLIANCE_BLOCK US-bound]

**S301 Signal (EVT-TARIFF lever):**
- VN was the primary China+1 beneficiary; now itself facing potential S301 tariffs
- US market = primary exposure (buyer_geo weight: 0.90) — maximum S301 impact
- Parent company (Korean/Taiwanese FDI) has demonstrated ability to shift production within 6-12 months when tariff economics change
- RP-STRUCTURAL-CHANGE: If S301 on VN publishes in Federal Register → structural; parent relocation trigger activated
- TIME_SLICED:
  - Pre-Federal Register publication: CAUTION (prepare; verify UFLPA docs)
  - Post-Federal Register: CAUTION → reduce advance ratio; trigger parent HQ conversation
  - Post-parent relocation announcement: orderly wind-down; no new facilities
- **S301 Signal: CAUTION** AND_IF [S301 confirmed on VN]

**Combined Signal:**
```
COMBO-006: CAUTION (combined both levers)
PER_AXIS:
  UFLPA: CONDITIONAL (compliance_block until docs confirmed)
  S301: CAUTION → structural reduction once Federal Register published

TIME_SLICED:
  NOW → Federal Register publication:
    ACTION REQUIRED: Verify UFLPA cotton origin documentation BEFORE any US-bound advance
    Hold US-bound advances without confirmation
    Maintain EU-bound ARP (EU shipments unaffected)
  Post-publication:
    Reduce advance ratio on US-bound facilities
    Trigger parent HQ conversation on production strategy
  Post-relocation announcement:
    Exit orderly; no new facilities; liquidate existing positions

RP-STRUCTURAL-CHANGE overlay:
  IEEPA (temporary mindset) → reframe as S301 (structural) — parent company needs correct framing
```

---

### COMBO-002: Bangladesh CMT (Bank-LC Dependent)

**UFLPA Signal (EVT-REGULATION lever):**
- BD yarn sourcing: approximately 60% from India (structural nuance from COMBO-002 KB)
- Indian cotton ≠ Xinjiang cotton → UFLPA rebuttable presumption CAN be met with Indian origin documentation
- This is a HIDDEN BD ADVANTAGE: BD factories sourcing Indian yarn have a UFLPA compliance pathway that BD factories sourcing Chinese yarn do not
- Factory-level documentation still required: Indian gin/field-level origin traceability
- The 60% India yarn share is an industry default — actual % must be confirmed per supplier (AC-02)
- RP-STRUCTURAL-CHANGE: UFLPA structural; BD Indian yarn advantage durable as long as supply chain documented
- **UFLPA Signal: CONDITIONAL POSITIVE** AND_IF [Indian yarn origin documented at factory + gin level]
  - BD Indian yarn origin documentation = competitive ADVANTAGE vs BD factories using Chinese yarn
  - BD factories with Chinese yarn: same COMPLIANCE_BLOCK risk as COMBO-004

**S301 Signal (EVT-TARIFF lever):**
- BD is a SECONDARY S301 target (forced labor framing, not pure competitiveness framing)
- BD government historically responds conciliatorily to US labour pressure (reform pledges, BGMEA engagement)
- US is secondary market for BD CMT (buyer_geo weight: 0.45); EU is primary (0.85)
- Forced labor framing = different legal basis from standard competitiveness S301 → may narrow or delay BD's tariff implementation
- RP-STRUCTURAL-CHANGE: IF S301 on BD confirmed → structural; BD framing may delay confirmation
- **S301 Signal: CAUTION** (US-buyer-facing only); EU-bound = NEUTRAL

**Combined Signal:**
```
COMBO-002: LOW-MEDIUM risk; BD has structural advantages vs CN/VN on UFLPA lever

PER_AXIS:
  US-bound shipments:
    UFLPA: CONDITIONAL POSITIVE (document Indian yarn origin → compliance advantage)
    S301: CAUTION (conditional on whether BD gets listed; lower probability than VN/KH)
  EU-bound shipments:
    NEUTRAL (unaffected by UFLPA/S301)

AND_IF [Indian yarn origin documented]:
  Signal = CONDITIONAL POSITIVE for US-bound (BD has compliance moat vs CN competitors)

AND_IF [BD S301 confirmed]:
  US-bound signal = CAUTION (reduce US-bound advance ratio; maintain EU-bound)

RP-STRUCTURAL-CHANGE overlay:
  Indian yarn UFLPA advantage: structural (Indian cotton origin is durable, documentable)
  BD S301 risk: CONDITIONAL (lower probability; forced labor framing ≠ standard S301)

Net direction: BD is BETTER POSITIONED than CN or VN on UFLPA lever.
Air8 BD talking point: BD's Indian yarn origin is a commercial differentiator for US buyers.
```

---

### COMBO-009: Pakistan Home Textile (POSITIVE CONDITIONAL)

**UFLPA Signal (EVT-REGULATION lever):**
- PK Punjab cotton = clearly non-Xinjiang origin; documentable at field level
- Home textiles (towels, bed sheets) = cotton-intensive product → UFLPA documentation highly relevant
- Walmart, Target and other US mass market buyers need supply chain compliance certainty post-UFLPA
- PK Punjab cotton documentation creates a competitive ADVANTAGE vs China-sourced home textiles
- RP-STRUCTURAL-CHANGE: UFLPA structural; PK non-Xinjiang advantage is durable
- Note: PK is NOT a Xinjiang-origin risk; it faces scrutiny as a cotton-producing country generally, but this is separately manageable
- **UFLPA Signal: CONDITIONAL POSITIVE** AND_IF [Punjab origin documented at gin/field level]
  - With documentation: PK has COMPLIANCE MOAT vs Chinese home textile competitors

**S301 Signal (EVT-TARIFF lever):**
- PK is less likely to be listed as primary S301 target vs BD/VN/KH
- US market is primary for PK home textiles (buyer_geo weight: 0.85), but S301 lower probability
- PK macro risk (energy crisis, SBP FX controls) = independent stress on top of S301 scenario
- RP-STRUCTURAL-CHANGE: IF S301 on PK confirmed → structural; but lower probability scenario
- **S301 Signal: MONITOR** (low probability of direct S301 targeting; maintain current monitoring)

**Combined Signal:**
```
COMBO-009: CONDITIONAL POSITIVE — strongest net signal of all 5 combos

PER_AXIS:
  UFLPA: CONDITIONAL POSITIVE (strongest non-Xinjiang documentation advantage)
  S301: MONITOR (lower probability; not primary S301 target)

AND_IF [Punjab cotton origin documented to gin level AND ELS/Pima quality certified]:
  Signal = CONDITIONAL → EXPAND for US-buyer-facing facilities
  Rationale: PK has compliance moat (UFLPA) + quality differentiation (ELS) vs China competitors

AND_IF [S301 imposed on PK simultaneously]:
  Signal drops from CONDITIONAL POSITIVE to CONDITIONAL
  Macro stress (energy + SBP FX + S301) = triple pressure

RP-STRUCTURAL-CHANGE overlay:
  PK UFLPA advantage: structural (Punjab origin is durable)
  PK S301 risk: MONITOR (cyclical/conditional — lower probability scenario)

Net: PK is the NET POSITIVE combo in the CLUSTER-US-DECOUPLING context for apparel.
Pre-position Air8 ARP for documented PK home textile suppliers as diversion beneficiary.
```

---

### COMBO-012: Cambodia (Dual-Threat — MOST NEGATIVE)

**UFLPA Signal (EVT-REGULATION lever):**
- KH factories depend on cotton fabric sourcing — if cotton sourced from China → Xinjiang exposure risk
- EU primary (0.80 weight); any US-bound shipments carry UFLPA risk
- Low CSDDD compliance readiness = also likely low documentation infrastructure
- **UFLPA Signal: CONDITIONAL** AND_IF [has US buyers AND cotton origin documented]
  - Without documentation: COMPLIANCE_BLOCK on US-bound (likely scenario given low compliance readiness)

**S301 Signal (EVT-TARIFF lever):**
- KH faces DUAL THREAT: US S301 + EU EBA graduation risk (cross-cluster)
- KH is a small, highly trade-dependent economy with limited policy response options
- EU EBA graduation: once enacted, EU tariff applies → existential for KH garment sector
- S301 adds additional market access threat on top of EU EBA risk
- RP-STRUCTURAL-CHANGE: BOTH risks are structural once enacted (EBA graduation + S301)
- **S301 Signal: DO_NOT_EXPAND** (dual threat activated)

**Combined Signal:**
```
COMBO-012: DO_NOT_EXPAND — most negative signal of all 5 combos

PER_AXIS:
  US-bound: COMPLIANCE_BLOCK (UFLPA) + DO_NOT_EXPAND (S301 dual threat)
  EU-bound: Cross-cluster risk (EBA graduation — see CLUSTER-EU-MARKET-ACCESS)

AND_IF [BOTH S301 and EBA graduation confirmed]:
  KH garment sector faces dual market access loss (US tariff + EU tariff)
  Existing Air8 positions: CAUTION; review advance quality immediately
  New facilities: DO NOT open; wait for dual-threat resolution

RP-STRUCTURAL-CHANGE overlay:
  Both risks are STRUCTURAL — no cyclical path back without structural policy change

Note: KH appears in BOTH cluster analyses as the highest-risk apparel combo overall.
Cross-cluster signal is consistent: DO_NOT_EXPAND in all dimensions.
```

---

## Step 5 — Air8 Product Mapping

### Two-Protocol Framework

**UFLPA Protocol:** Documentation check BEFORE any US-bound advance.
**S301 Protocol:** Advance ratio decision based on US revenue exposure.

| Combo | UFLPA Protocol | S301 Protocol | Combined Air8 Action |
|---|---|---|---|
| **COMBO-004** (CN Woven) | COMPLIANCE_BLOCK — suspend US-bound advances until factory-level cotton origin documentation package confirmed | Reduce or eliminate US-buyer-facing advance ratio; maintain EU-bound ARP (Hengqin structure) | Hold US-bound; maintain EU-bound; Hengqin ARP for CN cross-border; SmartWallet for buyer visibility |
| **COMBO-006** (VN FDI) | Verify UFLPA cotton origin documentation NOW — brand cert alone is insufficient; if not confirmed, COMPLIANCE_BLOCK US-bound | CAUTION on US-bound advance ratio post-Federal Register; trigger parent HQ conversation on relocation contingency | ARP maintenance (EU-bound); HOLD US-bound; PayGuard for new buyer onboarding risk |
| **COMBO-002** (BD CMT) | Surface Indian yarn UFLPA advantage — document yarn origin (India gin-level) as commercial differentiator for US buyers; EU-bound unaffected | CAUTION US-bound IF S301 on BD confirmed; maintain current advance ratio; EU-bound = normal | ARP split by buyer geography (EU-bound normal; US-bound flag); RT2C for EU-facing pre-shipment |
| **COMBO-009** (PK Home Textile) | Develop Punjab cotton origin documentation as commercial differentiator — position with Walmart/Target as UFLPA-safe alternative to China | MONITOR only — lower probability S301 targeting; maintain current ARP | ARP + Pool pre-position (conditional on ELS documentation); PayGuard for new US buyer onboarding |
| **COMBO-012** (KH) | COMPLIANCE_BLOCK on US-bound; CSDDD compliance gap also limits EU-bound defensibility | DO_NOT_EXPAND — dual threat; existing MiniARP positions only; no upgrade | MiniARP maintain (existing only); no new facilities; dual-threat review required |

---

## Step 6 — BD Pain Angles

### COMBO-004 (CN Medium Woven) — Defensive + Structural Pivot

**Pain hook:** CN factories face the most acute combined pressure — both UFLPA access denial AND S301 cost penalty apply simultaneously. Cash cycle disruption from delayed US buyer POs compounds margin squeeze.

**BD conversation angle:**
> "You face two simultaneous pressures on your US business — UFLPA requires you to document your cotton supply chain to the gin level, which is separate from your brand compliance programs. And Section 301 tariffs will apply to all your CN-origin goods regardless of how clean your documentation is. We need to understand your EU-bound vs US-bound receivable split before we structure any advance. Air8's ARP via the Hengqin structure is relevant here — it addresses the cross-border friction while S301 plays out."

**Signal differentiation question:** Are remaining US buyers price-protecting you against tariff, or are they asking you to absorb it? (If absorb → margin accelerating negative → CAUTION signal confirmed)

---

### COMBO-006 (VN FDI Knit) — Parent Company Decision Point

**Pain hook:** VN FDI factories face an existential question: is VN a long-term home for their operations, or is it a temporary China+1 position that needs to shift again? Parent company's answer determines Air8's entire exposure strategy.

**BD conversation angle:**
> "Your UFLPA documentation needs to be at the factory level — your Nike or Adidas brand certification doesn't substitute for CBP's requirement. Before we advance on any US-bound receivables, we need your cotton origin documentation package. Separately, once Section 301 tariffs publish in the Federal Register, they become structural — your parent company's contingency planning should reflect a multi-year horizon, not a temporary disruption. Is Air8 more important to your working capital now relative to what parent credit lines can provide? Have any parent-level credit limits changed?"

---

### COMBO-002 (BD CMT) — Hidden UFLPA Advantage

**Pain hook:** BD CMT factories have a UFLPA advantage that most buyers and many factories don't recognize — Indian yarn origin is documentable and clearly non-Xinjiang. This is a commercial differentiator, not just a compliance issue.

**BD conversation angle:**
> "Your yarn comes from India — not Xinjiang. That's actually a UFLPA compliance advantage vs your Chinese competitors. The question is whether you have the documentation to prove it to CBP. Do you have your Indian yarn origin certificates tracing back to the spinner and gin? If yes, we can help you position this with your US buyers as a supply chain compliance differentiator. Your EU-bound shipments are unaffected by UFLPA and Section 301 — let's make sure our advance structure reflects where your risk actually sits."

---

### COMBO-009 (PK Home Textile) — UFLPA Positive Position

**Pain hook:** PK home textile factories are in a rare position — the same regulatory pressure (UFLPA) that is hurting Chinese competitors is a competitive advantage for PK. Punjab cotton is non-Xinjiang, documentable, and creates a genuine compliance moat for Walmart/Target.

**BD conversation angle:**
> "Pakistan's Punjab cotton is the answer Walmart and Target are looking for on UFLPA — it's clearly non-Xinjiang and documentable at the field level. If you have this documentation, you have something your Chinese home textile competitors cannot offer. Are you surfacing this proactively to your US buyers? Air8 can fund your receivables while you develop this compliance positioning."

---

### COMBO-012 (KH) — Dual Threat Warning

**Pain hook:** KH garment factories face the harshest combined signal — UFLPA access risk on US shipments, S301 tariff threat on US exports, AND EU EBA graduation risk. There is no offsetting advantage on any dimension.

**BD conversation angle:**
> "We need to understand your US vs EU revenue split. Your EU business depends on EBA access which is under review, and your US business faces both UFLPA documentation requirements and potential Section 301 tariffs. Which market are you primarily defending? What is your strategy if both access pathways deteriorate simultaneously?"

---

## Step 7 — S3 Inclusion

| Combo | Combined Score | Signal | Included? | Rationale |
|---|---|---|---|---|
| COMBO-004 (CN Woven) | ~0.85 | DO_NOT_EXPAND (US-bound) / CONDITIONAL (EU-bound) | ✅ | Highest combined exposure; both levers fully apply |
| COMBO-006 (VN FDI Knit) | ~0.75 | CAUTION | ✅ | US primary market; highest S301 impact if confirmed; parent relocation risk |
| COMBO-012 (KH) | ~0.62 | DO_NOT_EXPAND | ✅ | Dual-threat; highest negative combined signal |
| COMBO-002 (BD CMT) | ~0.57 | CONDITIONAL POSITIVE (UFLPA lever) | ✅ | Hidden UFLPA advantage via Indian yarn; BD S301 framing different |
| COMBO-009 (PK Home Textile) | ~0.48 | CONDITIONAL POSITIVE | ✅ | Key addition — positive UFLPA signal; filtering to top 4 by score would miss this asymmetric upside |

**S3 rationale note:** Excluding COMBO-009 on score grounds alone would miss the only positive signal in the cluster. CLUSTER-US-DECOUPLING creates both threats (CN, KH) and beneficiaries (PK, BD via Indian yarn). Including both directions gives Air8 BD a complete portfolio action — not just what to reduce, but what to pre-position.

---

## Step 8 — Assessment Questions

**CRITICAL RULES applied throughout:**
- Reasoning-path questions ONLY — no specific figures, no percentages, no exact timelines
- Each question references which KB principle it serves
- Questions distinguish UFLPA lever vs S301 lever where relevant
- Alice's correction applied: do NOT assert "Air8 is the only liquidity source" — ask whether Air8's importance has grown relative to banks

---

### COMBO-004 — China Medium Woven (4 Questions)

**Q1 — UFLPA DOCUMENTATION STATUS (lever: UFLPA; signal reversal risk)**
QUESTION: "Your buyers may have their own compliance programs, but CBP's UFLPA requires your factory — not your buyer — to document your cotton's origin all the way to the gin and raw material level. Do you have this factory-level documentation package separate from your brand certifications? When was it last audited by an external party?"
KB ANCHOR: PRIN-COMPLIANCE-COST (UFLPA compliance cost + documentation infrastructure); EVENT-CLUSTERS.md note: "factory-level documentation required, not brand certification"
COLLECT: UFLPA traceability package; T4S or equivalent cotton-to-gin chain of custody documents; external audit date
SIGNAL IMPACT:
  If factory-level documentation confirmed and audited → UFLPA risk managed; signal upgrades from DO_NOT_EXPAND to CAUTION (S301 still applies)
  If documentation absent or brand-cert only → COMPLIANCE_BLOCK on US-bound advances; documentation development is pre-condition for any US-bound ARP

**Q2 — S301 ABSORPTION: FACTORY VS BUYER (lever: S301; signal direction)**
QUESTION: "Section 301 tariffs apply to all goods from China regardless of how clean your compliance documentation is. When US buyers are factoring in potential tariff costs, are they asking you to absorb the cost increase in your FOB price, or are they discussing price adjustment mechanisms? Which direction does that push your margin per unit?"
KB ANCHOR: PRIN-COUNTRY-EXPOSURE (S301 country-level tariff); RP-STRUCTURAL-CHANGE (S301 = structural once Federal Register); SOLUTIONS.md (PP-002 financing cost activated)
COLLECT: Any buyer correspondence on tariff pricing; current vs prior year margin per unit on US-buyer programmes
SIGNAL IMPACT:
  If factory absorbing S301 cost → margin declining → CAUTION confirmed; maintain not expand; RP-PEER-FAILURE pattern active
  If buyer absorbing S301 → factory margin protected → CONDITIONAL (S301 not yet fully impacting factory P&L); monitor buyer health for next 2 quarters

**Q3 — RP-PEER-FAILURE: SURVIVOR BIAS CHECK (overlay; signal reversal risk)**
QUESTION: "We're seeing other CN apparel factories closing or reducing US operations. For the buyers who are staying with you instead of shifting to Vietnam or India — what specifically is it about your factory that they're choosing to stay? Is this a capability advantage you have, or is it mainly about transition cost for the buyer while they search for alternatives?"
KB ANCHOR: RP-PEER-FAILURE: "check whether survivor faces same structural causes as closed peers; volume growth masking margin deterioration = classic pre-failure pattern"
COLLECT: Buyer retention reason (capability vs transition cost); any multi-season written programme commitments from US buyers; headcount and utilisation trend
SIGNAL IMPACT:
  If documented capability advantage (unique product, lead time, compliance) → CONDITIONAL (survivability case exists; monitor margin)
  If primarily buyer transition cost (temporary) → CAUTION; new inflow likely not durable; maintain not expand

**Q4 — EU-BOUND RECEIVABLE SEPARATION (lever: Both; Air8 structure)**
QUESTION: "What percentage of your total receivables are from US-headquartered vs EU-headquartered buyers? And do your US buyers place orders for goods shipped to US destinations, or do they sometimes have EU subsidiary programmes? How clearly can your invoice documentation separate US-origin demand from EU-origin demand?"
KB ANCHOR: PRIN-BUYER-GEO-EXPOSURE (buyer_geo separation required); SOLUTIONS.md (ARP via Hengqin for CN cross-border); PRIN-FINANCING-MATCH (EU-bound vs US-bound = different products)
COLLECT: Revenue split by buyer geography; invoice documentation structure; Hengqin entity registration status
SIGNAL IMPACT:
  If EU >40% of receivables and clearly separated → EU-bound ARP (Hengqin) can be structured independently of US-bound compliance block
  If receivables commingled or EU <20% → US-bound COMPLIANCE_BLOCK applies to majority of book; significant exposure reduction needed

---

### COMBO-006 — Vietnam FDI Knit (4 Questions)

**Q1 — UFLPA COTTON ORIGIN DOCUMENTATION (lever: UFLPA; compliance block or clear)**
QUESTION: "Your factory's compliance certifications from Nike or Adidas cover your manufacturing practices — but CBP's UFLPA requires your factory to document separately where your cotton comes from, all the way to the gin and raw material. This is a factory obligation, not a buyer certification. Do you have this separate factory-level cotton origin documentation package?"
KB ANCHOR: PRIN-COMPLIANCE-COST (UFLPA); EVENT-CLUSTERS.md: "brand compliance certifications do NOT substitute for factory-level UFLPA documentation"
COLLECT: Factory-level cotton origin documentation; cotton sourcing records by country of origin; T4S or equivalent
SIGNAL IMPACT:
  If factory-level docs confirmed → UFLPA risk managed; signal = CAUTION (S301 still live)
  If brand cert only, no factory-level docs → COMPLIANCE_BLOCK US-bound immediately; documentation is pre-condition

**Q2 — PARENT COMPANY STRATEGIC HORIZON (lever: S301; structural break)**
QUESTION: "Section 301 tariffs, unlike IEEPA, cannot be removed by a presidential executive order — once published in the Federal Register, they typically remain in place for years. Has your parent company communicated a view on Vietnam as a long-term production base under that scenario, or are they evaluating a production strategy review? Has the parent changed any capital allocation decisions for the Vietnam facility?"
KB ANCHOR: RP-STRUCTURAL-CHANGE (S301 = structural; IEEPA = cyclical); COMBO-006 nuance: "Korean/Taiwanese FDI parents demonstrated ability to rapidly shift production countries when tariff risk materializes"
COLLECT: Parent company communication on Vietnam strategy; any capex review signals; headcount plans for 2027-2028
SIGNAL IMPACT:
  If parent committed to Vietnam long-term (capex continuing) → CAUTION but not exit; advance ratio maintained with monitoring
  If parent evaluating production restructuring → immediate advance ratio reduction; no new pre-shipment facilities; exit planning initiated

**Q3 — US REVENUE CONCENTRATION AND BUFFER (lever: S301; magnitude)**
QUESTION: "If Section 301 tariffs caused your US buyers to reduce orders or shift production to another country over the next four to six quarters, how would that affect your total revenue position? Do you have EU-buyer programmes that would partially offset a US revenue reduction?"
KB ANCHOR: PRIN-BUYER-GEO-EXPOSURE (buyer_geo US weight 0.90 for VN); RP-CONCENTRATION (portfolio-level US exposure)
COLLECT: Revenue split US buyers vs EU buyers vs other; EU programme details; any EU buyer development underway
SIGNAL IMPACT:
  If EU revenue >30% and growing → partial buffer exists; CAUTION manageable
  If US > 80% with limited EU diversification → US order reduction = existential liquidity event; advance ratio must be reduced pre-emptively

**Q4 — AIR8 IMPORTANCE VS OTHER FINANCING SOURCES (lever: Both; Alice correction)**
QUESTION: "In terms of your working capital — has Air8's role become more important, less important, or about the same relative to your parent company credit lines and local bank facilities over the past year? Have any of those other sources reduced their available credit or tightened their conditions?"
KB ANCHOR: PRIN-FINANCING-MATCH (financing access); COMBO-006: parent_company as primary financing source; Alice correction applied: do NOT assert "Air8 is only liquidity source"
COLLECT: Parent credit line status; local bank credit conditions; Air8 utilisation % vs prior year
SIGNAL IMPACT:
  If parent lines reduced and banks tightening → Air8 role growing; CAUTION (high demand for Air8 = also higher risk if receivables deteriorate)
  If parent lines stable or growing → Air8 supplementary; price and service differentiation narrative more important than liquidity urgency

---

### COMBO-002 — Bangladesh CMT (4 Questions)

**Q1 — UFLPA: YARN ORIGIN DOCUMENTATION — THE HIDDEN ADVANTAGE (lever: UFLPA; signal confirmation)**
QUESTION: "Bangladesh sources a significant portion of its yarn from India. Indian cotton is clearly not Xinjiang-origin — and that is a UFLPA compliance advantage for factories that can document it. Do you know what percentage of your yarn comes from India vs China vs Pakistan vs local mills? And for the India-sourced portion, do you have documentation tracing it to the Indian spinner and gin?"
KB ANCHOR: COMBO-002 structural nuance: "BD industry imports ~60% yarn from India; Indian cotton ≠ Xinjiang = UFLPA rebuttable presumption CAN be met"; PRIN-COMPLIANCE-COST (UFLPA)
COLLECT: Yarn sourcing origin declaration by country (last 12 months); Indian yarn gin-level origin certificates; any buyer requests for UFLPA supply chain documentation
SIGNAL IMPACT:
  If Indian yarn >50% AND documented to gin level → CONDITIONAL POSITIVE: BD has UFLPA compliance advantage vs CN competitors; surface with US buyers
  If Chinese yarn component significant and undocumented → US-bound COMPLIANCE_BLOCK applies to that portion; urgency to document or substitute

**Q2 — US vs EU SHIPMENT SEPARATION (lever: S301; protocol)**
QUESTION: "Your primary market is EU buyers, with US as a secondary market. If Section 301 tariffs were applied to Bangladesh, they would affect only your US-bound shipments — not your EU programmes. Are your US-buyer programmes separate from your EU programmes in terms of production lines and invoice documentation? How much of your total revenue and receivables comes from US-headquartered buyers?"
KB ANCHOR: PRIN-COUNTRY-EXPOSURE (S301 country-level); PRIN-BUYER-GEO-EXPOSURE (EU primary vs US secondary); SOLUTIONS.md COMBO-002 ARP protocol
COLLECT: Revenue split US buyers vs EU buyers; invoice documentation structure; whether US and EU orders are separately tracked
SIGNAL IMPACT:
  If US revenue <30% and clearly separated → EU-bound ARP unaffected; signal = CONDITIONAL on US-bound only; EU-bound = normal
  If US and EU programmes commingled or US revenue growing toward majority → CAUTION across broader book; structure advances to separate by destination

**Q3 — BANGLADESH S301 FRAMING: GOVERNMENT RESPONSE (lever: S301; signal direction)**
QUESTION: "The Section 301 investigation into Bangladesh is framed specifically around forced labor concerns — which is a different legal basis than the competitiveness-focused S301 actions against China. Bangladesh government and BGMEA have historically engaged constructively with US labour compliance requirements. Is your factory part of any Better Work, ILO, or BGMEA compliance programme that documents your labour practices? Has your factory had any direct engagement with US government or buyer-side compliance reviewers?"
KB ANCHOR: COMBO-002 sub-scenario: "BD government response may be conciliatory (reform pledges) vs retaliatory"; PRIN-COMPLIANCE-COST (compliance program as signal modifier)
COLLECT: Better Work programme membership; any ILO, BGMEA, or US government compliance engagement records; current compliance programme status
SIGNAL IMPACT:
  If documented compliance programme + BGMEA/Better Work → BD S301 risk lower than VN/KH; framing distinction matters; signal = CONDITIONAL rather than CAUTION
  If no compliance documentation → treat BD S301 risk as similar to VN; CAUTION on US-bound

**Q4 — LDC GRADUATION CROSS-SIGNAL (cross-cluster; structural horizon)**
QUESTION: "Your EU EBA duty-free access has a specific horizon — there is a known LDC graduation date that would bring EU tariffs into effect on your EU exports. Given that EU is your primary market, are your major EU buyers aware of this timeline, and have they signalled anything about future programme allocation? Are you preparing for post-graduation tariff costs through any trade association engagement or diversification?"
KB ANCHOR: PP-BD-003-ldc-graduation; COMBO-002: "moat_horizon: 2026-2029 protected by EBA; competitive erosion post-2029"; cross-cluster signal (also in CLUSTER-EU-MARKET-ACCESS)
COLLECT: EU buyer communication on sourcing strategy; any buyer RFQ changes or programme review signals; trade association engagement
SIGNAL IMPACT:
  If EU buyers already signalling programme review or shift → LDC graduation risk is materialising early; CAUTION signal broadens beyond US-bound
  If EU buyers stable and LDC risk not yet buyer-communicated → normal advance; begin ESG compliance positioning for post-2029 defensibility

---

### COMBO-009 — Pakistan Home Textile (3 Questions)

**Q1 — UFLPA: PUNJAB COTTON DOCUMENTATION AS COMMERCIAL MOAT (lever: UFLPA; signal confirmation)**
QUESTION: "Pakistan's Punjab cotton is clearly not Xinjiang-origin — and that is a significant UFLPA compliance advantage compared to suppliers sourcing from China. Do you currently have documentation tracing your cotton to the Punjab field and gin level? Are your US buyers like Walmart or Target asking for this kind of supply chain transparency? Are you surfacing this as a differentiator in buyer conversations?"
KB ANCHOR: COMBO-009 structural nuance: "UFLPA: PK cotton is clearly non-Xinjiang and documentable; defensible advantage for US buyers"; PRIN-COMPLIANCE-COST (UFLPA documentation); PRIN-BUYER-GEO-EXPOSURE (US mass market buyers)
COLLECT: Cotton origin certificates (field/gin level); any Walmart/Target UFLPA compliance requests; ELS/Pima certification if applicable
SIGNAL IMPACT:
  If documentation confirmed AND US buyers requesting → CONDITIONAL POSITIVE: develop PK UFLPA moat as commercial differentiator; EXPAND eligible
  If documentation absent → missed commercial opportunity; urgent remediation; documentation investment is the unlock for positive signal

**Q2 — QUALITY DIFFERENTIATION: ELS / PIMA (lever: Both; signal durability)**
QUESTION: "Pakistan's ELS (Extra-Long Staple) cotton produces measurably different quality in home textiles. Does your factory produce ELS or Pima-certified lines? Is there buyer premium documented for your ELS products vs commodity cotton lines? Can you demonstrate the quality story to US buyers in a way that's defensible against Indian competition?"
KB ANCHOR: COMBO-009: "ELS/Pima quality story: PK competitive moat — defensible 5-8% premium vs commodity"; RP-STRUCTURAL-CHANGE (quality moat = more durable signal than price advantage)
COLLECT: ELS/Pima certification; product spec with staple length; buyer price differential documentation
SIGNAL IMPACT:
  If ELS certified + buyer premium documented → CONDITIONAL EXPAND: two-moat position (UFLPA + quality); Air8 ARP on premium-buyer receivables
  If commodity cotton only → MONITOR only: no differentiation vs Indian competition; positive signal weaker

**Q3 — AIR8 IMPORTANCE AND MACRO STRESS BUFFER (lever: Both; Alice correction + risk calibration)**
QUESTION: "Pakistan's energy costs and SBP foreign exchange conditions create operating pressure independent of any US trade policy questions. Has Air8's role in your working capital grown, stayed the same, or become less central relative to your bank facilities and other financing sources? What is your current bank credit line utilisation — how much headroom do you have to absorb shocks?"
KB ANCHOR: PRIN-FINANCING-MATCH; COMBO-009: "energy crisis +10-20% production cost; SBP FX controls; bank rates 15-22%"; Alice correction: do NOT assert "Air8 is only liquidity source"
COLLECT: Bank facility utilisation; SBP FX availability status; energy cost trend vs prior year; Air8 utilisation vs bank utilisation
SIGNAL IMPACT:
  If bank lines >80% utilised + energy cost rising → macro stress high; ARP pre-condition = stable receivable quality (ELS buyers, not commodity); CONDITIONAL only
  If bank lines <60% utilised → headroom exists; UFLPA documentation development is the primary unlock; proceed with CONDITIONAL EXPAND once docs confirmed

---

### COMBO-012 — Cambodia (3 Questions)

**Q1 — US MARKET EXPOSURE: HOW REAL IS THE S301 THREAT? (lever: S301; dual-threat sizing)**
QUESTION: "Cambodia's primary market is EU — your EU revenue and EU EBA access are the foundation of your business. How much of your total revenue comes from US-headquartered buyers specifically? If Section 301 tariffs were applied to Cambodia alongside EU EBA pressure, which market access threat creates more near-term financial pressure?"
KB ANCHOR: COMBO-012: "EU primary (0.80 weight); US secondary but dual threat"; RP-CONCENTRATION (dual-threat portfolio risk)
COLLECT: Revenue split EU buyers vs US buyers; any US buyer programme details; EU buyer concentration
SIGNAL IMPACT:
  If US revenue <10% → S301 is secondary risk; EU EBA graduation is the primary threat; focus analysis on CLUSTER-EU-MARKET-ACCESS
  If US revenue growing toward 20%+ → dual threat is real; DO_NOT_EXPAND signal confirmed across both clusters

**Q2 — UFLPA COTTON DOCUMENTATION CAPABILITY (lever: UFLPA; infrastructure check)**
QUESTION: "If any of your US-bound shipments involve cotton — in the fabric or garment — CBP requires factory-level documentation of that cotton's origin to the gin level. Given your current compliance infrastructure, do you have the documentation systems to meet that requirement? Who in your factory manages supply chain documentation for US-bound shipments?"
KB ANCHOR: PRIN-COMPLIANCE-COST (UFLPA); COMBO-012: "low domestic financing options; compliance infrastructure limited"
COLLECT: Compliance documentation status; supply chain documentation capability; any existing UFLPA package
SIGNAL IMPACT:
  If documentation infrastructure absent → COMPLIANCE_BLOCK on any US-bound advance; documentation development = pre-condition
  If partial documentation → CONDITIONAL on completion; timeline to complete?

**Q3 — DUAL-THREAT CONTINGENCY: WHAT IS THE BACKUP PLAN? (lever: Both; survivability)**
QUESTION: "Your business depends on EU duty-free access via EBA. If that access were reduced or ended, and simultaneously US buyers faced tariff pressure that reduced US-bound orders — what is your factory's financial runway, and what alternatives have you considered? Are there product categories or markets that would remain viable under that scenario?"
KB ANCHOR: COMBO-012 key risk: "EBA graduation risk: existential if EBA withdrawn; revenue concentration on EU market"; RP-STRUCTURAL-CHANGE (both threats structural once enacted)
COLLECT: Revenue diversification plans; product category mix; factory financial runway; any non-EU, non-US market development
SIGNAL IMPACT:
  If no diversification and full EU EBA dependency → DO_NOT_EXPAND confirmed; existing positions only; reduce if advance quality deteriorates
  If credible diversification underway (non-EU buyers, product pivot) → CONDITIONAL: contingency plan exists; re-evaluate signal if diversification delivers

---

## Step 9 — Final Insight Card + Signal Derivation

### Root Cause Narrative

US strategic decoupling from Chinese supply chains is not a single event — it is a sustained policy direction applied through two **simultaneously active but independent policy levers**. The UFLPA lever targets supply chain integrity through access denial (documentation-based); the S301 lever targets economic competitiveness through cost penalty (tariff-based). A supplier can navigate one and still face the full impact of the other.

### Two-Lever Signal Derivation

```
CLUSTER-US-DECOUPLING Signal Derivation

Lever 1 — UFLPA:
  Input: Forced labor access denial mechanism
  Signal logic: cotton origin documentable? → UFLPA rebuttable presumption manageable
  RP-STRUCTURAL-CHANGE: UFLPA = structural (legislation); permanent compliance investment required

Lever 2 — S301:
  Input: Country-level tariff (IEEPA → S301 replacement)
  Signal logic: country of origin listed? → tariff applies regardless of compliance quality
  RP-STRUCTURAL-CHANGE check:
    IEEPA = cyclical (executive order, reversible) → CONDITIONAL horizon
    S301 (Federal Register) = structural (5-10+ year) → permanent horizon
  Critical moment: Federal Register publication date = structural break moment

Combined signal per combo:
  COMBO-004 (CN): DO_NOT_EXPAND (both levers HIGH; RP-PEER-FAILURE applied; CN = structural break confirmed)
  COMBO-006 (VN): CAUTION (S301 structural once confirmed; UFLPA conditional on docs; parent relocation risk)
  COMBO-012 (KH): DO_NOT_EXPAND (dual-threat: S301 + EU EBA; no offsetting advantage)
  COMBO-002 (BD): CONDITIONAL POSITIVE (hidden UFLPA advantage via Indian yarn; S301 secondary/conditional)
  COMBO-009 (PK): CONDITIONAL POSITIVE (UFLPA advantage via Punjab cotton; S301 lower probability)
```

### Net Positive vs Net Negative

| Direction | Combos | Why |
|---|---|---|
| **Net Positive (conditional)** | COMBO-009 (PK), COMBO-002 (BD) | Non-Xinjiang cotton documentation advantage; UFLPA compliance moat; S301 lower probability or secondary |
| **Neutral/Caution** | COMBO-006 (VN) | UFLPA conditional on docs; S301 structural risk if confirmed; parent relocation as amplifier |
| **Net Negative** | COMBO-004 (CN), COMBO-012 (KH) | Both levers apply at maximum intensity; no offsetting advantage; structural signals confirmed |

### Portfolio Action

1. **Reduce:** US-buyer-facing advance ratios for COMBO-004 (CN) and COMBO-012 (KH) — dual-lever exposure with no mitigation
2. **Hold with conditions:** COMBO-006 (VN) — verify UFLPA documentation before any US-bound advance; monitor parent HQ signal
3. **Pre-position:** COMBO-009 (PK) — Punjab cotton documentation development enables UFLPA moat positioning with Walmart/Target
4. **Surface advantage:** COMBO-002 (BD) — Indian yarn origin documentation as commercial UFLPA differentiator for US buyers

### Gaps for Runtime Web Search

The following facts should be fetched at runtime — they are NOT stored in the KB:

| Gap | Why Needed | Runtime Search |
|---|---|---|
| S301 Federal Register publication date (actual) | Cliff date — once published, structural break confirmed | US Federal Register + USTR announcements |
| Which countries are listed in S301 investigation | Determines which combos face confirmed S301 exposure | USTR investigation listing |
| Current UFLPA entity list | Identifies if any supplier or their input partner is directly listed | CBP UFLPA entity list (current) |
| Bangladesh government response to S301 forced labor framing | Determines BD tariff probability | BGMEA announcements, US State Dept communications |
| VN parent company capex announcements | FDI relocation signal | Korean/Taiwanese investment authority announcements |
| Pakistan S301 investigation status | Confirm PK not primary S301 target | USTR investigation scope |
