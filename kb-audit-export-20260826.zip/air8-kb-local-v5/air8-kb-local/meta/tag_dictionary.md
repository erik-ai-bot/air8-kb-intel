# Tag Dictionary — Controlled Vocabulary

> Version: 2.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> All tags must be registered here before use. No synonyms. Lowercase with underscores.

---

## Event Types (2-Level Taxonomy)

### Regulation
| Sub-type | Description |
|---|---|
| `import_export_duty` | Tariff changes, customs duty revisions |
| `environmental_compliance` | REACH, ZDHC, chemical bans |
| `traceability` | UFLPA, Digital Product Passport, chain of custody |
| `labor_standards` | Minimum wage, CSDDD social clauses, factory audits |
| `trade_agreement` | FTA, EBA/GSP+ changes, preferential access |
| `product_safety` | GPSR, flammability, ESPR, REACH SVHC |

### Financial
| Sub-type | Description |
|---|---|
| `fx_rate` | Currency pair moves (TRY/EUR, INR/USD, etc.) |
| `interest_rate` | Central bank rate changes, credit market shifts |
| `buyer_credit_event` | Buyer downgrade, insolvency, payment term extension |
| `buyer_payment_term` | Buyer extending OA days unilaterally |
| `supplier_distress` | Supplier cash crisis, over-leverage, bank freeze |

### Market
| Sub-type | Description |
|---|---|
| `product_trend_change` | Product category growing or declining structurally in buyer demand (athleisure rising, formal declining, sustainability premium growing) |
| `product_technology_disruption` | New production technology changes competitive landscape (3D knitting, laser finishing, automation disrupting cut-and-sew) |
| `demand_shift` | General consumer demand shifting across geographies or segments |
| `new_trade_flow_pattern` | New sourcing or trade flow patterns emerging between countries |
| `competitor_capacity_change` | Competitor entering or exiting a product/country segment |

### Commodity
| Sub-type | Description |
|---|---|
| `raw_material_price` | Cotton, yarn, indigo, cashmere, wool price moves |
| `raw_material_shortage` | Supply disruption, allocation constraints |
| `energy_price` | Electricity, gas, diesel — production cost impact |
| `freight_rate` | Ocean freight rate spikes or drops |

### Geopolitical
| Sub-type | Description |
|---|---|
| `sanctions` | OFAC, EU sanctions, country/entity designations |
| `trade_war` | Tariff escalation, retaliatory measures |
| `political_instability` | Country-level disruption (hartal, coup, election chaos) |
| `route_disruption` | Suez/Panama blockage, port closure |

### Buyer
| Sub-type | Description |
|---|---|
| `sourcing_strategy_shift` | China+1, nearshoring, diversification announcements |
| `market_entry_exit` | Buyer entering/exiting a geography |
| `supplier_consolidation` | Buyer reducing supplier count |
| `compliance_mandate` | Buyer adding new compliance requirement |
| `ma_ownership` | Buyer M&A changing sourcing priorities |
| `nearshoring` | Buyer moving volume closer to end market |

### Supply Chain
| Sub-type | Description |
|---|---|
| `factory_capacity_change` | Factory expansion, closure, capacity overhang |
| `lead_time_change` | Production or shipping lead time shift |
| `logistics_disruption` | Port congestion, inland transport delays |
| `allocation_constraint` | Raw material allocation limits from suppliers |

---

## Material Tags
| Tag | Coverage |
|---|---|
| `material:cotton` | Raw cotton, cotton yarn, cotton woven/knit fabrics |
| `material:denim` | Denim fabric, washed denim garments |
| `material:polyester` | PSF, PET, recycled polyester |
| `material:viscose` | Viscose, rayon, modal |
| `material:wool` | Merino, lambswool, cashmere, alpaca |
| `material:synthetic_blend` | Polyester-cotton, nylon blends |
| `material:home_textile` | Bed linen, bath linen, kitchen textile |
| `material:hardgoods` | Cookware, decor, furniture, seasonal |

## Country Tags
| Tag | Country |
|---|---|
| `country:BD` | Bangladesh |
| `country:CN` | China |
| `country:IN` | India |
| `country:TR` | Turkey |
| `country:VN` | Vietnam |
| `country:PK` | Pakistan |
| `country:ID` | Indonesia |
| `country:KH` | Cambodia |
| `country:multi` | Multi-country group |

## Company Type Tags
| Tag | Type |
|---|---|
| `company_type:CMT` | Cut-Make-Trim (no sourcing control) |
| `company_type:FOB` | Full Package (sourcing + production) |
| `company_type:vertical` | Farm-to-fashion, fully integrated |
| `company_type:trader` | No factory, intermediary |
| `company_type:FDI` | Foreign-owned factory |

## Revenue Band Tags
| Tag | Range |
|---|---|
| `revenue:small` | $5–20M |
| `revenue:mid` | $20–50M |
| `revenue:large` | $50M+` |
| `revenue:micro` | <$5M |

## Buyer Geography Tags
| Tag | Coverage |
|---|---|
| `buyer_geo:EU` | European Union buyers |
| `buyer_geo:US` | United States buyers |
| `buyer_geo:APAC` | Asia-Pacific buyers |
| `buyer_geo:mixed` | Diversified across regions |

## Scenario Tags
| Tag | Scenario |
|---|---|
| `scenario:S1` | Event trigger (forward cascade) |
| `scenario:S2` | BD outreach (reverse path) |
| `scenario:S3` | Individual supplier assessment |
| `scenario:S4` | Portfolio monitoring |

## Domain Tags
| Tag | Domain |
|---|---|
| `domain:compliance` | Regulatory and compliance matters |
| `domain:finance` | Financing, cash flow, credit |
| `domain:operations` | Production, logistics, QC |
| `domain:persona` | Supplier identity and characteristics |
| `domain:risk` | Air8 portfolio risk |
| `domain:esg` | ESG credentials and requirements |
| `domain:hardgoods` | Hardgoods-specific (Josephine's domain) |

---

## Tag Ranking Rules

- Every node must have at least one `event_type:*` tag and one `country:*` tag
- **Primary tag**: the single most relevant tag for routing — used first
- **Secondary tags**: top 2 processed in cascade; rest logged for future use
- No more than 8 tags total per node (prevents over-tagging)
- Tags must be exact matches — no fuzzy matching at routing stage
