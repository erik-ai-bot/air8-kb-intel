# Signal Decision Rules — Priority Hierarchy & Grammar

> Version: 1.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> This file governs how conflicting signals are resolved and how composed signals are expressed.
> Cross-reference: _reasoning/primitives.md (for RP-INFORMATION-DEFICIT when MONITOR signal is triggered)

---

## 1. Priority Hierarchy (4 Tiers)

When multiple signals are triggered by a single event, the hierarchy below governs which signal wins and what is surfaced to BD.

### Tier 1 — Compliance (Always Overrides)
**Triggers that always override commercial or risk signals:**
- UFLPA / Xinjiang cotton detection in supply chain
- Active US or EU sanctions (OFAC, UK OFSI) affecting buyer or supplier entity
- Third-party payment prohibition triggered (trader/agent with no factory assets)

**Effect:** Tier 1 compliance signals HALT commercial recommendations. No commercial or risk signal (EXPAND, CONDITIONAL, CAUTION, DO_NOT_EXPAND, NEUTRAL, MONITOR, RESTRUCTURE, EXPAND_WITH_HEDGE, WATCH_HEDGE_GAP) can override a Tier 1 trigger. BD receives a compliance flag first; commercial discussion only after compliance is resolved.

### Tier 2 — Risk (Overrides Commercial)
**Triggers that override any Tier 3 or Tier 4 commercial signal:**
- Single buyer revenue share > 60%
- Buyer distress signals: payment lengthening >15d, credit downgrade, M&A uncertainty
- Air8 bank facility utilisation > 90%
- Concentration cap breach (single commodity >30%, country cap exceeded)

**Effect:** Tier 2 risk signals suppress EXPAND signals. If Tier 2 is active, output CAUTION or DO_NOT_EXPAND regardless of commercial opportunity. Risk signal must appear in output WITH tier label.

### Tier 3 — Structural (Overrides Fact-Based Commercial)
**Business model facts that override raw-data commercial signals:**
- Buyer-nominated input share > 80% (raw material event savings do NOT reach factory)
- All-organic sourcing with GOTS certification (import duty savings irrelevant to certified lines)
- No factory assets (trader/agent model — third-party payment prohibition risk)
- Country eligibility block (factory country not eligible for target buyer program)

**Effect:** Tier 3 structural conditions modify or reverse the default commercial signal before it reaches the output. These are permanent architectural facts — not event-dependent.

### Tier 4 — Commercial (Lowest; No Override Authority)
**Pure commercial opportunity signals:**
- Buyer geography mix uplift (event improves factory's competitive position in a buyer geo)
- Margin improvement threshold (cost event directly benefits factory margin)
- Competitive repositioning opportunity (factory gains relative to peer origins)

**Effect:** Tier 4 signals are the "default" recommendation absent Tier 1-3 triggers. They are displayed but can be overridden by any higher tier.

---

## 2. Conflict Resolution Rule

> **"Most restrictive signal wins WITHIN the same tier. Higher tier always overrides lower tier."**

**Within-tier conflict example:**
- Tier 2 triggered by both: buyer_concentration >60% AND bank_utilisation >90%
- Resolution: Surface BOTH signals in output. The most restrictive output signal wins (DO_NOT_EXPAND beats CAUTION).

**Cross-tier conflict example:**
- Tier 3 structural: buyer_nominated >80% → NEUTRAL
- Tier 4 commercial: cotton duty cut → EXPAND
- Resolution: Tier 3 wins. Output: NEUTRAL. BUT: Tier 4 signal must still appear in output with tier label so BD understands the underlying opportunity for OTHER combos.

---

## 3. Visibility Rule

> **"All triggered signals must appear in output with tier label — not just the winner. BD must see the full picture."**

Format for output:
```
Tier 1 [COMPLIANCE]: UFLPA — Xinjiang exposure detected. All commercial signals suppressed.
Tier 3 [STRUCTURAL]: Buyer-nominated >80% → raw material savings do not reach factory.
Tier 4 [COMMERCIAL]: India cotton duty cut → EXPAND signal (suppressed by Tier 3).
FINAL SIGNAL: DO_NOT_EXPAND (Tier 3 structural override)
```

This visibility rule ensures BD can:
1. Understand why the commercial signal was suppressed
2. Identify which combos might benefit (where Tier 3 doesn't apply)
3. Correct structural assumptions if the client provides new information

---

## 4. Extended Signal Vocabulary

### Primary Signals
| Signal | Meaning |
|---|---|
| `EXPAND` | Clear net benefit; recommend increasing exposure or new position |
| `CONDITIONAL` | Benefit exists but requires specific condition to be verified first |
| `CAUTION` | Risk factor present; maintain but monitor closely; no new expansion |
| `DO_NOT_EXPAND` | Net risk outweighs benefit; hold existing positions, no new |
| `NEUTRAL` | Event does not materially affect this combo |
| `MONITOR` | Signal uncertain; add to watch list; trigger RP-INFORMATION-DEFICIT check (see _reasoning/primitives.md) |
| `RESTRUCTURE` | Current facility structure needs revision to fit changed conditions; maps to RP-STRUCTURAL-CHANGE primitive |
| `EXPAND_WITH_HEDGE` | Precondition: expand ONLY IF hedge confirmed in place (e.g., FX forward contract, buyer credit insurance). BD must confirm hedge exists before proceeding. |
| `WATCH_HEDGE_GAP` | Risk monitoring state: proceed with current exposure but flag active hedge gap to client and credit team. Does not block action. |
| `BUYER_SPLIT` | Buyer concentration risk; recommend splitting facility across 2+ buyers |

### EXPAND_WITH_HEDGE vs WATCH_HEDGE_GAP — Usage Guidance
```
EXPAND_WITH_HEDGE — use when: hedge is required for the deal to be safe
  (e.g., EUR-denominated supplier needs FX confirmation for non-EUR markets,
  post-cliff stockpile needs WC plan confirmed)

WATCH_HEDGE_GAP — use when: existing position has unhedged exposure that should be
  monitored but doesn't block current action
  (e.g., TRY volatility on existing ARP position)

BD conversation difference:
- EXPAND_WITH_HEDGE: "We can proceed once we confirm [X hedge] is in place.
    What's your current FX/insurance coverage?"
- WATCH_HEDGE_GAP: "We can proceed. I want to flag that [X exposure] is unhedged —
    let's discuss whether that's intentional."
```

### 9-Signal Complete Vocabulary (reference)
Primary signals: EXPAND | CONDITIONAL | CAUTION | DO_NOT_EXPAND | NEUTRAL | MONITOR | RESTRUCTURE | EXPAND_WITH_HEDGE | WATCH_HEDGE_GAP
- MONITOR maps to RP-INFORMATION-DEFICIT primitive (see _reasoning/primitives.md)
- RESTRUCTURE maps to RP-STRUCTURAL-CHANGE primitive (see _reasoning/primitives.md)

### Composition Operators
| Operator | Meaning | Example |
|---|---|---|
| `AND_IF` | Signal applies only if secondary condition is true | `EXPAND AND_IF buyer_PO_confirmed` |
| `OR` | Either condition triggers the signal | `CAUTION OR RESTRUCTURE` (use most restrictive) |
| `PER_AXIS` | Signal varies by dimension | `EXPAND (EU axis) | NEUTRAL (US axis)` |
| `TIME_SLICED` | Signal changes over time window | `EXPAND (Jun-Sep) | CAUTION (Oct)` |
| `PRECEDES` | Action must complete before secondary | `EXPAND PRECEDES cliff_date` |

### Composed Signal Examples
```
# India cotton duty event — Turkey denim factory (COMBO-005)
CAUTION AND_IF india_denim_mills_upgrade_finishing (competitive threat, not direct benefit)

# Bangladesh CMT — India cotton event with buyer-nominated fabric
NEUTRAL (Tier 3 structural override: buyer_nominated >80%; savings stay with buyer)
Underlying Tier 4 signal: EXPAND (suppressed)

# India Vertical — cliff event approaching
EXPAND AND_IF buyer_PO_confirmed (Jun-Sep) | CAUTION AND_IF tenor > 90d (Sep-Oct) | RESTRUCTURE (Nov+)

# Pakistan home textile — India cotton duty cut
CAUTION PER_AXIS [competitive threat: Indian home textile mills gain cost advantage in US buyers]
```

### Confidence Per Signal
Each emitted signal must include a confidence score. Confidence is assigned PER SIGNAL, not overall.

```
{
  "signal": "EXPAND",
  "confidence": 0.85,
  "tier": 4,
  "condition": "buyer_PO_confirmed",
  "operator": "AND_IF",
  "basis": "India cotton duty cut → direct benefit to domestic procurement blend"
}
```

---

## 5. Conflict Resolution Worked Examples

### Example 1: BD CMT Factory — India Cotton Duty Cut
**Situation:** India reduces import cotton duty by 10%. BD CMT factory (COMBO-002) identified.

**Signals triggered:**
- Tier 4 [COMMERCIAL]: Cotton cost reduction → EXPAND (India yarn prices may fall)
- Tier 3 [STRUCTURAL]: Buyer-nominated fabric >90% → savings do not reach BD CMT factory

**Resolution:** Tier 3 overrides Tier 4.
**Output:** NEUTRAL. Tier 4 EXPAND signal shown with explanation: "Underlying EXPAND signal exists for India Vertical (COMBO-003) where sourcing is own-managed."

---

### Example 2: India Vertical + Approaching Cliff Date
**Situation:** India cotton duty window ends Oct 31. Currently 18 days remaining.

**Signals triggered:**
- Tier 4 [COMMERCIAL]: Active duty benefit → EXPAND
- Tier 2 [RISK]: Tenor >18d → disbursements past cliff date risk
- Tier 1 [COMPLIANCE]: None triggered

**Resolution:** Tier 2 overrides Tier 4.
**Output:** DO_NOT_EXPAND for new positions. Existing positions flagged for cliff review.
**Formula applied:** latest_safe_disbursement = cliff_date - tenor - 5d = Oct 31 - 90d - 5d = Jul 27. Today is beyond that date.

---

### Example 3: China FOB Factory — US Tariff Event
**Situation:** US announces additional 15% tariff on Chinese cotton apparel.

**Signals triggered:**
- Tier 4 [COMMERCIAL]: China cost competitiveness in US → negative commercial signal
- Tier 3 [STRUCTURAL]: EU revenue >70% for this factory → US tariff is LOW materiality
- Tier 4 [COMMERCIAL]: EU buyer demand for CN speed/complexity unaffected → EXPAND (EU axis)

**Resolution:** PER_AXIS resolution.
**Output:** `EXPAND PER_AXIS [EU: EXPAND] | DO_NOT_EXPAND [US: structural trend — shrinking book]`
**BD note:** "This factory has already de-emphasized US buyers by design. EU book benefits from CN speed advantage; US book should not be expanded further."
