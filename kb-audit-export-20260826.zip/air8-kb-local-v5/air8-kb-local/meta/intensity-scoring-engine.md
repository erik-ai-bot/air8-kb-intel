# Intensity Scoring Engine — Air8 KB

> Applies to: all Pain Points (PP-*.md) and all Event Triggers (S1 event taxonomy)
> Purpose: consistent, automated intensity computation at runtime from factory profile
> Updated: 2026-07-13

---

## Design Principle

Intensity is NOT a static label in the KB.
It is a score computed at runtime from two inputs:
1. **KB (static):** base_score + driver definitions per PP or event
2. **Factory profile (runtime):** assessment dimension answers from R1/R2

The KB stores WHEN a pain becomes critical.
The scenario determines IF it is critical for this specific factory.

---

## Score Scale

| Score Range | Intensity Level | Meaning |
|------------|----------------|---------|
| 80–100 | CRITICAL | Existential or near-term severe threat; lead opener |
| 60–79 | HIGH | Significant active pain; strong pitch material |
| 35–59 | MEDIUM | Present but manageable; qualifying question trigger |
| 15–34 | LOW | Watch only; not pitch material yet |
| 0–14 | INACTIVE | Dormant; skip in output |

---

## Scoring Formula

```
computed_score =
  base_score                    # inherent severity for this archetype (KB-defined)
  + exposure_score              # how exposed is this factory? (0–20)
  - capacity_discount           # does factory have capacity to absorb? (0–20)
  + urgency_bonus               # is there a near-term deadline? (0–15)
  + compound_bonus              # other high/critical PPs also active? (0–15 per co-active PP, max 30)

computed_score = min(100, max(0, computed_score))
intensity_level = map computed_score → scale above
```

---

## Driver Definitions

### exposure_score (0–20)
Measures how directly the factory intersects with the pain.
Each PP defines its primary exposure dimension and mapping:

| Exposure level | Score |
|---------------|-------|
| Factory is fully exposed (e.g., 100% EU revenue for an EU-tariff PP) | +20 |
| Highly exposed (e.g., >70% EU revenue) | +15 |
| Moderately exposed (e.g., 40–70%) | +10 |
| Low exposure (e.g., 20–40%) | +5 |
| Minimal / not exposed | 0 |

### capacity_discount (0–20)
Measures how well the factory can absorb or has already mitigated the pain.

| Capacity level | Discount |
|---------------|---------|
| Pain fully mitigated (e.g., factory already on GSP+ track, or using Air8 ARP) | -20 |
| Partially mitigated (e.g., some reserves, partial hedging) | -10 |
| No mitigation, but margin is healthy (>15%) | -5 |
| No mitigation, margin thin (<8%) | 0 |
| Pain actively worsening | +0 (use compound_bonus instead) |

### urgency_bonus (0–15)
Measures time pressure — is there a deadline driving action now?

| Urgency | Bonus |
|---------|-------|
| Deadline < 6 months | +15 |
| Deadline 6–18 months | +10 |
| Deadline 18–36 months | +5 |
| No specific deadline / structural pain | 0 |

### compound_bonus (0–30 max)
Each additional PP or event trigger that is simultaneously HIGH or CRITICAL for this factory:
- +15 per co-active PP that shares an exposure dimension (compound risk)
- Max cap: +30 (two or more co-active compounds)

Example: PP-BD-003 (LDC graduation) + PP-003 (buyer concentration) both HIGH for a 72% EU-revenue factory → compound_bonus = +15 each compound interaction = PP-BD-003 gets +15 compound bonus from PP-003 co-active

---

## PP File Standard Structure

Every PP-*.md file must use this structure (replacing the old static `intensity:` label):

```yaml
# PP-XXX — [Name]

## Identity
id: PP-XXX
type: pain_point | event_trigger
category: universal | country | esg | expansion
scope: [BD | IN | TR | VN | etc. | all]
updated: YYYY-MM-DD

## Angle / Logic / View (KB — static)
angle: [1–2 sentences: WHY this matters structurally]
logic: [the mechanism — HOW the pain works]
view:  [Air8's perspective — what this means for BD/credit/risk]

## Intensity Scoring (KB — static parameters)
base_score: [0–100]
# Rationale: [why this base score — what's the default severity for the target archetype]

primary_exposure_dimension: [field name from assessment dimensions]
exposure_mapping:
  high:   { condition: "[dimension] > [threshold]", score: 20 }
  medium: { condition: "[dimension] > [lower threshold]", score: 10 }
  low:    { condition: "[dimension] > [minimal]", score: 5 }
  none:   { condition: "default", score: 0 }

capacity_dimensions:
  - dimension: [field name]
    fully_mitigated:   { condition: "[state]", discount: 20 }
    partly_mitigated:  { condition: "[state]", discount: 10 }
    healthy_buffer:    { condition: "[state]", discount: 5 }

urgency_source: [what creates time pressure — deadline, event, regulatory cycle]
urgency_mapping:
  critical: { condition: "[e.g., deadline_months < 6]", bonus: 15 }
  high:     { condition: "[e.g., deadline_months 6–18]", bonus: 10 }
  medium:   { condition: "[e.g., deadline_months 18–36]", bonus: 5 }
  none:     { condition: "no deadline", bonus: 0 }

compound_triggers:
  - with: [PP-id or event type]
    condition: [when does this compound apply]
    bonus: 15

## Live Data (web_lookup — resolve at runtime)
# [Only for DATA_FIGURE fields — rates, counts, policy statuses, market figures]
# Structural ranges that define the archetype stay above as angles/logic
web_lookup:
  - field: [field_name]
    query: "[search query with [year] placeholder]"
    freshness: quarterly | annual | stable
    fallback: "[last known value with date]"

## Air8 Connection
products: [list of PROD-ids that address this pain]
bd_hook: [one-sentence opener for BD conversation]
qualifying_question: [the key question to surface this pain in R1/R2]
```

---

## What Stays in KB vs Web Lookup

### Stays in KB (structural — defines the archetype, does not expire quickly)
- gross_margin_band (e.g., 5–12%) — structural characteristic of archetype
- cash_cycle_days ranges — structural operational pattern
- revenue_band — segmentation characteristic
- concentration_pattern (e.g., top 2 buyers = 40–65%) — behavioral pattern
- eligibility thresholds (Air8 internal rules — $1M min, 2yr ops, 6mo ARP track record)
- dilution rates by buyer type — structural buyer behavior pattern
- GST/VAT refund cycle days — structural mechanics of tax system (changes rarely)

### Moves to web_lookup (live market data — changes periodically)
- Bank OD rates / financing rates (any country) — quarterly
- Minimum wage figures — annual
- Tariff rates — annual
- Convention counts (e.g., GSP+ requirements) — annual
- Government ratification status — quarterly
- Currency depreciation % — quarterly
- Commodity prices — quarterly

### Computed at runtime (never stored)
- Actual computed_score for a specific factory
- Actual intensity_level for a specific factory
- Compound_bonus values

---

## Event Trigger Scoring

Event triggers (S1 taxonomy: A–F + sub-types) use the same scoring model.
Additional driver: **relevance_score** instead of exposure_score.

```
event_computed_score =
  base_score                    # how severe is this event type for the archetype
  + relevance_score             # does this factory's supply chain intersect? (0–20)
  - capacity_discount           # factory's ability to absorb the event impact
  + urgency_bonus               # how soon does the event take effect?
  + compound_bonus              # other active events or PPs compounding?
```

relevance_mapping (event-specific):
- For supply-side events: intersection with factory's material sourcing
- For demand-side events: intersection with factory's buyer geo/type
- For regulatory events: intersection with factory's export market
- For cost events: intersection with factory's cost structure

---

## Runtime Computation Step

Added to S2 between R2-1 (instance match) and R2-2 (load data):

```
Step R2-1b: COMPUTE INTENSITY
  For each active PP for this archetype:
    1. Read base_score from PP file
    2. Read factory dimensions from R1/R2 answers
    3. Apply exposure_mapping → exposure_score
    4. Apply capacity_dimensions → capacity_discount
    5. Apply urgency_mapping → urgency_bonus (use web_lookup for deadline if needed)
    6. Check compound_triggers → compound_bonus
    7. computed_score = base + exposure - capacity + urgency + compound (cap 100)
    8. Map to intensity_level
  Sort PPs by computed_score descending
  → Output: ranked pain list with computed intensity (not KB base intensity)
```

Same step added to S1 for event impact scoring.

---

## Worked Example: PP-BD-003 for two factories

**Factory A:** eu_revenue_pct=72%, gsp_plus_preparedness=none, deadline=Nov 2026 (4mo away)
```
base_score:        55  (moderate default — not existential for all BD factories)
exposure_score:   +20  (eu_revenue_pct=72% > 50% → high)
capacity_discount:  0  (gsp_plus_preparedness=none → no mitigation)
urgency_bonus:    +15  (deadline_months=4 < 6 → critical urgency)
compound_bonus:   +15  (PP-003 buyer concentration also HIGH for this factory)
─────────────────────
computed_score:   105  → capped at 100 → CRITICAL
```

**Factory B:** eu_revenue_pct=25%, gsp_plus_preparedness=active_programme, deadline=Nov 2026
```
base_score:        55
exposure_score:    +5  (eu_revenue_pct=25% → low)
capacity_discount:-20  (gsp_plus_preparedness=active → fully mitigated)
urgency_bonus:    +15  (same deadline, but mitigation in progress)
compound_bonus:     0  (no co-active compound PPs)
─────────────────────
computed_score:    55  → MEDIUM
```

Same PP — CRITICAL vs MEDIUM — because the factory profile is different.
