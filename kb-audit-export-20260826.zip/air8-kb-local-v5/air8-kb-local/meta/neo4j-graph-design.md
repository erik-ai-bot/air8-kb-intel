# Air8 KB — Neo4j Graph Design
> Owner: Jerri Zhou | Version: 2026-07-15
> For data team setup. Read MASTER-FLOW.md first for context.

---

## 1. The Core Problem Jerri Identified

Current state: Knowledge layer (Scenario, Principle) and Entity layer (Persona, Country, Product) are connected **only through tag string matching inside flat files**. There's no explicit edge in the graph. The LLM has to figure out the connection at runtime.

Target state: Tags become **explicit nodes** that both layers reference. Traversal is graph-native.

---

## 2. Two-Layer + Bridge Model

```
┌─────────────────────────────────────────────────────────────────────┐
│  KNOWLEDGE LAYER — "how to reason"                                  │
│                                                                     │
│  (:EventType)──[:TRIGGERS]──>(:Scenario)──[:GOVERNED_BY]──>(:Principle) │
│       │                                         │                   │
│       │                                         │                   │
│  [:ACTIVATES]                              [:APPLIES_WHEN]          │
│       │                                         │                   │
│       ▼                                         ▼                   │
│  (:Tag {scope:"event_subtype", value:"demand_shift"})               │
│  (:Tag {scope:"event_type",    value:"financial"})                  │
└─────────────────────────────┬───────────────────────────────────────┘
                              │
                    BRIDGE: (:Tag) nodes
                    shared between both layers
                              │
┌─────────────────────────────┴───────────────────────────────────────┐
│  ENTITY LAYER — "what to reason about"                              │
│                                                                     │
│  (:Persona)──[:TAGGED_WITH]──>(:Tag {scope:"country", value:"TR"}) │
│  (:Persona)──[:TAGGED_WITH]──>(:Tag {scope:"material",value:"denim"})│
│  (:Persona)──[:LOCATED_IN]──>(:Country)                            │
│  (:Persona)──[:HAS_PAIN]──>(:PainPoint)──[:ADDRESSED_BY]──>(:Product) │
│  (:Persona)──[:RECOMMENDS]──>(:Product)                             │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. Full Traversal Path — When an Event Arrives

```
INPUT EVENT:
  event_type = "financial"
  event_subtype = "demand_shift"
  country = ["TR"]
  material = ["denim"]

──────────────────────────────────────────────────────────────────
STEP 1  Event → EventType
  MATCH (et:EventType {value: "demand_shift"})
  → This is the entry point into the Knowledge Layer.

──────────────────────────────────────────────────────────────────
STEP 2  EventType → Scenario
  MATCH (et:EventType)-[:TRIGGERS]->(s:Scenario)
  WHERE et.value = "demand_shift"
  RETURN s.id  // → "S1"

──────────────────────────────────────────────────────────────────
STEP 3  EventType → Principles
  MATCH (et:EventType)-[:ACTIVATES]->(p:Principle)
  WHERE et.value IN p.applies_when_subtypes
  RETURN p.id, p.file
  // → ["RP-EVT-SOURCSHIFT-01", "RP-EVT-CORRELATED-PAIR", ...]

──────────────────────────────────────────────────────────────────
STEP 3b  Active Event Cache Check (MANDATORY)
  MATCH (cached:CachedEvent)-[:TAGGED_WITH]->(t:Tag)
  WHERE t.scope IN ["country","material","buyer_geo"]
    AND t.value IN ["TR", "denim", "EU"]
    AND cached.state = "active"
  RETURN cached, COUNT(DISTINCT t) AS overlap_count
  ORDER BY overlap_count DESC

  IF overlap_count >= 2 → correlated event found
  → Classify: AMPLIFYING / REFRAMES / OFFSETS / INDEPENDENT
  → Generate COMBINED card instead of standalone

──────────────────────────────────────────────────────────────────
STEP 4  Event Tags → Persona Match (TAG is the bridge)
  event_tags = [Tag("country:TR"), Tag("material:denim"), Tag("buyer_geo:EU")]
  MATCH (p:Persona)-[:TAGGED_WITH]->(t:Tag)
  WHERE t.value IN ["TR", "denim", "EU"]
  RETURN p.id, COUNT(t) AS tag_overlap
  ORDER BY tag_overlap DESC
  // overlap >= 3 → PRIMARY; overlap = 2 → secondary

──────────────────────────────────────────────────────────────────
STEP 5  Persona → Country, Structural Nuances
  MATCH (p:Persona)-[:LOCATED_IN]->(c:Country)
  WHERE p.id = "COMBO-005"
  RETURN p, c
  // Load: structural_nuances, llm_directives, assessment_dimensions

──────────────────────────────────────────────────────────────────
STEP 6  Principles + Persona → Signal Computation
  For each matched Persona:
    - Apply Principle.assessment_logic to Persona.assessment_dimensions
    - Apply mandatory checks: P0-6, P0-7, P0-8
    - Compute Signal: EXPAND / CONDITIONAL / CAUTION / NEUTRAL / DO_NOT_EXPAND
  OUTPUT: (:Signal {persona_id, value, confidence})

──────────────────────────────────────────────────────────────────
STEP 7  Persona → PainPoint → Product
  MATCH (p:Persona)-[:HAS_PAIN]->(pp:PainPoint)-[:ADDRESSED_BY]->(prod:Product)
  WHERE p.id = "COMBO-005"
  RETURN pp.id, prod.id, prod.name

──────────────────────────────────────────────────────────────────
STEP 8  OUTPUT → Event Card + Cache Write
  Compose S1 Event Card
  Write CachedEvent node to Active Event Cache
```

---

## 4. Node Types — Complete Definition

### Knowledge Layer Nodes

```cypher
(:EventType {
  value: "demand_shift",
  event_type: "financial",
  triggers_scenario: "S1",
  activates_principle_ids: ["RP-EVT-SOURCSHIFT-01", "RP-EVT-CORRELATED-PAIR"]
})

(:Scenario {
  id: "S1",
  name: "Event Insights",
  file: "scenarios/S1-event-insights.md",
  template: "templates/S1-event-card.md",
  chains_to: ["S5", "S3"],
  steps: 8
})

(:Principle {
  id: "RP-EVT-CORRELATED-PAIR",
  layer: "L0_event",
  file: "layer-1-reasoning/EVENT-PRINCIPLES.md",
  applies_when_subtypes: ["ANY"],
  mandatory: true,
  description: "Multi-event combined read when >=2 tag overlap in cache"
})

(:Primitive {
  id: "RP-DEPENDENCY",
  file: "layer-1-reasoning/PRIMITIVES.md",
  use_when: "no L0 principle matches event_type",
  description: "Input dependency -> pass-through analysis"
})
```

### Bridge: Tag Nodes

```cypher
(:Tag {scope: "country",        value: "TR", label: "Turkey"})
(:Tag {scope: "material",       value: "denim"})
(:Tag {scope: "event_subtype",  value: "demand_shift"})
(:Tag {scope: "buyer_geo",      value: "EU"})
(:Tag {scope: "domain",         value: "apparel"})
(:Tag {scope: "company_type",   value: "FOB"})
```

### Entity Layer Nodes

```cypher
(:Persona {
  id: "COMBO-005",
  name: "Turkey Denim Specialist",
  archetype: "FullPackage-MidMargin",
  domain: "apparel",
  country_code: "TR",
  revenue_band: "mid $20-50M",
  product_type: "denim",
  company_type: "FOB",
  cash_cycle_days_min: 60,
  cash_cycle_days_max: 90,
  advance_ratio_normal: 0.85,
  advance_ratio_alert: 0.75,
  file: "layer-2-entities/personas/COMBO-005-turkey-denim-specialist.md"
})

(:Country {
  code: "TR",
  name: "Turkey",
  region: "Europe/MENA",
  currency: "TRY",
  currency_risk: "HIGH",
  air8_entity: "none",
  file: "layer-2-entities/countries/Turkey.md"
})

(:PainPoint {
  id: "PP-001-cashflow-gap",
  title: "Cash Flow Gap",
  scope: "universal",
  file: "layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap.md"
})

(:Product {
  id: "PROD-ARP",
  name: "Accounts Receivable Purchase",
  tenor_max_days: 180,
  requires_buyer_anchor: true,
  requires_confirmed_po: true,
  self_liquidation: "invoice → buyer payment → Air8 repaid",
  file: "layer-2-entities/financing-products/PROD-ARP.md"
})

(:CachedEvent {
  trigger_id: "T-2026-MMDD-TR-DENIM",
  title: "Turkey EU Apparel Volume Contraction -17.83%",
  state: "active",
  ttl_days: 90,
  expires_at: "2026-10-01"
})

(:Signal {
  id: "SIG-COMBO005-EVENTE-20260715",
  value: "CONDITIONAL",
  confidence: 0.82,
  generated_at: "2026-07-15"
})
```

---

## 5. Edge Types — Complete Definition

```cypher
// ── Knowledge Layer ───────────────────────────────────────────────
(et:EventType)-[:TRIGGERS]->(s:Scenario)
(s:Scenario)-[:GOVERNED_BY]->(p:Principle)
(et:EventType)-[:ACTIVATES {when: "event_subtype=demand_shift"}]->(p:Principle)

// ── Bridge (Tag nodes) ───────────────────────────────────────────
(p:Principle)-[:APPLIES_WHEN]->(t:Tag)
(persona:Persona)-[:TAGGED_WITH]->(t:Tag)
(e:Event)-[:TAGGED_WITH]->(t:Tag)
(ce:CachedEvent)-[:TAGGED_WITH]->(t:Tag)

// ── Entity Layer ─────────────────────────────────────────────────
(persona:Persona)-[:LOCATED_IN]->(c:Country)
(persona:Persona)-[:HAS_PAIN {rank:"primary", pp_id:"PP-001"}]->(pp:PainPoint)
(pp:PainPoint)-[:ADDRESSED_BY]->(prod:Product)
(persona:Persona)-[:RECOMMENDS {weight:0.90, rank:"primary"}]->(prod:Product)

// ── Signal outputs ────────────────────────────────────────────────
(s:Signal)-[:COMPUTED_FOR]->(persona:Persona)
(s:Signal)-[:TRIGGERED_BY]->(e:Event)
(ce1:CachedEvent)-[:CORRELATED_WITH {type:"AMPLIFYING"}]->(ce2:CachedEvent)
```

---

## 6. What Goes IN Neo4j vs What Stays in Files

| Content | Neo4j | File |
|---|---|---|
| Node identity (id, name, archetype, tags) | ✅ | ✅ source |
| Edges (located_in, has_pain, recommends) | ✅ | ❌ |
| Tag nodes (country:TR, material:denim, etc.) | ✅ | ❌ |
| Structural Nuances (long text bullets) | ❌ | ✅ |
| LLM Directives (runtime lookup questions) | ❌ | ✅ |
| Assessment Dimensions | ❌ | ✅ |
| Principle text | ❌ | ✅ |
| Active Event Cache entries | ✅ runtime | schema in file |
| Signal outputs | ✅ audit | ✅ in Event Card |

**Rule:** Neo4j = the ROUTER. Files = the CONTENT. LLM Skill = the EXECUTOR.

---

## 7. Tag Taxonomy (canonical values)

```
scope: "country"        values: BD, CN, TR, IN, VN, PK, ID, KH, multi
scope: "material"       values: cotton, denim, synthetic_blend, home_textile,
                               brass, copper, zamak, aluminum, steel, LED, hardgoods
scope: "event_type"     values: financial, regulation, commodity, geopolitical,
                               buyer, supply_chain
scope: "event_subtype"  values: demand_shift, import_export_duty,
                               environmental_compliance, fx_rate, buyer_credit_event,
                               sourcing_strategy_shift, political_instability,
                               raw_material_shortage, market_entry_exit,
                               logistics_disruption, supplier_consolidation,
                               product_trend_change
scope: "buyer_geo"      values: EU, US, APAC, ME, AU, mixed
scope: "company_type"   values: CMT, FOB, Vertical, Trader, FDI
scope: "domain"         values: apparel, hardgoods
scope: "scenario"       values: S1, S2, S3, S4, S5
scope: "signal"         values: EXPAND, CONDITIONAL, CAUTION, NEUTRAL, DO_NOT_EXPAND
scope: "relationship"   values: AMPLIFYING, REFRAMES, OFFSETS, INDEPENDENT
```

---

## 8. Phase 1 Minimum Viable Setup

```cypher
// Test: Event → Scenario → Principles → Personas
MATCH (et:EventType {value: "demand_shift"})
  -[:TRIGGERS]->(s:Scenario)
MATCH (et)-[:ACTIVATES]->(prin:Principle)
MATCH (persona:Persona)-[:TAGGED_WITH]->(t:Tag)
WHERE t.value IN ["TR", "denim", "EU"]
RETURN s.id, collect(prin.id), collect(persona.id)
// Expected: S1, [RP-EVT-SOURCSHIFT-01, ...], [COMBO-005, COMBO-002, COMBO-012]
```
