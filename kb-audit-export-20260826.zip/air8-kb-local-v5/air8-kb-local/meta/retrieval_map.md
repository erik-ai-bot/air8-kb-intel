# Retrieval Map — Minimum File Chain per Trigger

> Purpose: Tells the LLM exactly which files to read, in which order, for each trigger pattern.
> Rule: Never read the whole KB. Every query touches 8-15 files max (~60-80KB).
> Owner: Jerri Zhou + Snowman | Updated: 2026-07-01

---

## The Core Principle

```
Trigger → [Step 1: 2 meta files] → [Step 2: 2-4 combo files] → [Step 3: 2-3 principle sections]
       → [Step 4: 1-2 product files] → [Step 5: 1-2 pain point files] → OUTPUT
```

Each step uses what the previous step returned — never load blindly.

---

## Step 1: Always-First Reads (Every Scenario)

These two files are always loaded first. They are small and determine everything else.

```
Read 1: _meta/tag_dictionary.md        (~3KB) → standardise tags from raw trigger
Read 2: _meta/scenario_routing.md      (~2KB) → determine active modules + entry combos
```

After Step 1 you have:
- Structured trigger payload (event_type, event_subtype, country[], material[])
- Ordered list of which combo files to read next (by country tag + edge walk)

---

## Step 2: Combo Files (Load Only What Routes to)

Load 2-4 combo files based on routing output. Do NOT load all 15.

**Primary match rule:** `country tag → direct combo list`
```
country:IN  → personas/instances/COMBO-003-india-vertical.md
               personas/instances/COMBO-008-india-organic.md
               personas/instances/COMBO-014-india-small-woven.md

country:BD  → personas/instances/COMBO-002-bd-cmt.md
               personas/instances/COMBO-001-sa-small-knit.md

country:TR  → personas/instances/COMBO-005-turkey-denim.md

country:CN  → personas/instances/COMBO-004-china-woven.md

country:PK  → personas/instances/COMBO-009-pakistan-home-textile.md

country:VN  → personas/instances/COMBO-006-vietnam-fdi.md

country:ID  → personas/instances/COMBO-007-indonesia-family.md

country:KH  → personas/instances/COMBO-012-cambodia-eba.md
```

**Edge walk rule:** After direct match, check `_links/cross-module-edges.md` for 1-hop indirect:
```
material:cotton + country:IN → also load COMBO-002 (BD, sources_from:IN weight 0.85)
                                also load COMBO-009 (PK, competitive threat)

buyer event for EUFastFashion → also load COMBO-002, COMBO-004, COMBO-005 (sells_to weight ≥0.6)
```

After Step 2 you have from each combo file:
- `structural_nuances` → the constraints LLM must apply
- `assessment_dimensions` → what variables to check
- `signal_flip_conditions` → where signal reverses
- `pain_hooks[]` → which pain files to load next
- `air8_products[]` → which product files to load next
- `llm_directives` → what facts to retrieve at runtime

---

## Step 3: L0 Principles (Load Only Relevant Sections)

Do NOT load all 4 principle files. Load only the sections matching event_type.

```
event_type:Commodity            → L0-principles/persona-principles.md (RP-MATERIAL-01)
                                   L0-principles/event-principles.md (RP-EVT-CMDTYSHORT-01 if shortage)
                                   L0-principles/risk-principles.md (RP-RISK-CONC-01)

event_type:Regulation/import_duty → L0-principles/persona-principles.md (RP-MATERIAL-01, RP-TARIFF-CLIFF-01)
                                     L0-principles/event-principles.md (RP-EVT-DUTY-01)
                                     L0-principles/risk-principles.md (RP-RISK-POSTCLIFF-01 if cliff)

event_type:Financial/fx_rate    → L0-principles/persona-principles.md (RP-FX-01)
                                   L0-principles/event-principles.md (RP-EVT-FX-01)

event_type:Financial/buyer_credit → L0-principles/persona-principles.md (RP-BUYER-FIN-01)
                                     L0-principles/event-principles.md (RP-EVT-BUYERCREDIT-01)
                                     L0-principles/risk-principles.md (RP-RISK-BUYER-ANCHOR-01)

event_type:Buyer/sourcing_shift → L0-principles/persona-principles.md (RP-COMPETITIVE-01)
                                   L0-principles/event-principles.md (RP-EVT-SOURCSHIFT-01)
                                   L0-principles/risk-principles.md (RP-RISK-COUNTRY-01)

event_type:Regulation/trade_agreement → L0-principles/persona-principles.md (RP-GRADUATION-01)
                                         L0-principles/risk-principles.md (RP-RISK-COUNTRY-01)

event_type:Geopolitical         → L0-principles/event-principles.md (RP-EVT-POLINSTAB-01)
                                   L0-principles/risk-principles.md (RP-RISK-COUNTRY-01)
```

After Step 3 you have:
- Reasoning checklist (what dimensions to evaluate)
- LLM directive templates (what to retrieve and calculate)

---

## Step 4: Product Files (Load from Combo's air8_products Field)

Each combo file specifies which products apply. Load only those.

```
COMBO-002 (BD CMT) primary:PROD-ARP → load products/PROD-ARP.md
COMBO-003 (IN Vertical) primary:PROD-PRESHIP-OBF → load products/PROD-PRESHIP-OBF.md
COMBO-005 (TR Denim) primary:PROD-ARP, secondary:PROD-PAYGUARD → load both
```

From product file you get:
- `risk_reduction_narrative` → WHY Air8 risk is low (required in S1 card)
- `eligibility` → gate check before recommending
- `bd_talking_points` → ready language for S2

---

## Step 5: Pain Point Files (Load from Combo's pain_hooks Field)

Each combo specifies pain hooks. Load primary + any situationally relevant.

```
COMBO-002 pain_hooks → pain-points/universal/PP-001-cashflow-gap.md (always)
                        pain-points/country/PP-BD-001-wage-hike.md (always for BD)
                        pain-points/country/PP-BD-003-ldc-graduation.md (if EU event)

COMBO-003 pain_hooks → pain-points/universal/PP-005-preshipment-capital.md (always)
                        pain-points/country/PP-IN-002-bank-od-cost.md (always for IN)

COMBO-005 pain_hooks → pain-points/universal/PP-001-cashflow-gap.md (always)
                        pain-points/country/PP-TR-001-lira-inflation.md (always for TR)
```

---

## Complete Read Chains by Common Trigger Pattern

### Pattern A: Commodity Price Event (e.g. India cotton duty cut)

```
Step 1:  _meta/tag_dictionary.md
         _meta/scenario_routing.md
         _links/cross-module-edges.md          ← edge walk for sources_from:IN

Step 2:  personas/instances/COMBO-003-india-vertical.md     ← direct hit (country:IN)
         personas/instances/COMBO-008-india-organic.md      ← direct hit (country:IN)
         personas/instances/COMBO-002-bd-cmt.md             ← indirect via sources_from:IN
         personas/instances/COMBO-009-pakistan-home-textile.md  ← competitive threat

Step 3:  L0-principles/persona-principles.md    ← RP-MATERIAL-01, RP-TARIFF-CLIFF-01
         L0-principles/event-principles.md      ← RP-EVT-DUTY-01
         L0-principles/risk-principles.md       ← RP-RISK-CONC-01, RP-RISK-POSTCLIFF-01

Step 4:  products/PROD-PRESHIP-OBF.md           ← COMBO-003 primary product
         products/PROD-ARP.md                   ← COMBO-002, COMBO-009 primary

Step 5:  pain-points/universal/PP-005-preshipment-capital.md
         pain-points/country/PP-IN-002-bank-od-cost.md
         pain-points/country/PP-BD-001-wage-hike.md

Runtime: LLM executes directives from combo files → retrieves blend ratios, cost parity data

OUTPUT:  S1 Event Card → write to _runtime/active_events.json
Total reads: 14 files (~90KB)
```

---

### Pattern B: Buyer Sourcing Strategy Shift (e.g. China+1)

```
Step 1:  _meta/tag_dictionary.md
         _meta/scenario_routing.md
         _links/cross-module-edges.md          ← sells_to edge walk

Step 2:  personas/instances/COMBO-004-china-woven.md        ← direct hit (country:CN)
         personas/instances/COMBO-006-vietnam-fdi.md        ← beneficiary (sells_to US)
         personas/instances/COMBO-003-india-vertical.md     ← beneficiary
         personas/instances/COMBO-002-bd-cmt.md             ← beneficiary (EU space opens)

Step 3:  L0-principles/persona-principles.md    ← RP-BUYER-FIN-01, RP-COMPETITIVE-01
         L0-principles/event-principles.md      ← RP-EVT-SOURCSHIFT-01
         L0-principles/risk-principles.md       ← RP-RISK-COUNTRY-01

Step 4:  products/PROD-ARP.md
         products/PROD-SMARTWALLET.md           ← COMBO-004 expansion tool

Step 5:  pain-points/universal/PP-003-buyer-concentration.md
         pain-points/country/PP-CN-001-safe-complexity.md

OUTPUT:  S1 Event Card
Total reads: 13 files (~80KB)
```

---

### Pattern C: S2 BD Outreach (Cold Start — company name only)

```
Step 1:  _meta/tag_dictionary.md
         _meta/scenario_routing.md

Step 2:  personas/archetypes/CMT-LowMargin.md   ← match archetype from country + estimated size
         personas/instances/COMBO-002-bd-cmt.md ← match instance

Step 3:  L0-principles/product-principles.md    ← RP-PROD-SELFLIC-01, RP-PROD-ELIGIB-01

Step 4:  products/PROD-ARP.md                   ← primary product for CMT
         products/PROD-MINIARP.md               ← if small revenue

Step 5:  pain-points/universal/PP-001-cashflow-gap.md
         pain-points/universal/PP-002-financing-cost.md
         pain-points/country/PP-BD-001-wage-hike.md
         pain-points/country/PP-BD-003-ldc-graduation.md

Step 6:  _runtime/active_events.json            ← check Why Now hook

OUTPUT:  S2 R1 Card + qualifying questions
Total reads: 10 files (~55KB)
```

---

### Pattern D: S3 Individual Supplier Assessment (named supplier, active event)

```
Step 1:  _runtime/active_events.json            ← load active signal for this combo
         personas/instances/COMBO-XXX.md        ← already known from S1/S2

Step 2:  personas/instances/COMBO-XXX.md        ← load assessment_dimensions
                                                    load signal_flip_conditions
                                                    load qualifying_questions R2→R3

Step 3:  L0-principles/persona-principles.md    ← only principle matching event_type

Step 4:  products/PROD-XXX.md                   ← from combo's air8_products field

OUTPUT:  Individual Supplier Assessment card
Total reads: 5-7 files (~35KB)
```

---

### Pattern E: S4 Portfolio Monitoring (scheduled run)

```
Step 1:  _runtime/active_events.json            ← all active events
         _links/cross-module-edges.md           ← for indirect exposure check

Step 2:  Only load combo files for ACTIVE CLIENTS in portfolio
         (do not load non-client combos unless Tier C opportunity check)

Step 3:  L0-principles/risk-principles.md       ← RP-RISK-CONC-01, RP-RISK-POSTCLIFF-01

Step 4:  No product files needed (monitoring, not recommending)

OUTPUT:  Portfolio Action Report (Tier A/B/C)
Total reads: varies by portfolio size, ~8-12 files
```

---

## What Never Gets Loaded (Unless Specifically Needed)

```
❌ All 15 combo files at once — load only matched 2-4
❌ All 4 L0 principle files at once — load only relevant sections
❌ All 24 pain point files — load from combo's pain_hooks field
❌ All 9 product files — load from combo's air8_products field
❌ hardgoods/ — only if material:hardgoods tag present
❌ regulations/ — only if event_type:Regulation or compliance flag raised
❌ personas/archetypes/ — only for S2 Round 1 cold start
```

---

## Linkage Traversal Logic (Step-by-Step)

The cascade does not scan — it follows pointers. Every read produces pointers to the next read.

```
tag_dictionary.md
    ↓ produces: structured tags
scenario_routing.md
    ↓ produces: module priority list + entry combo candidates
cross-module-edges.md (if indirect)
    ↓ produces: additional combo candidates via sources_from / sells_to
COMBO-XXX.md (matched combos)
    ↓ produces: structural_nuances (apply as constraints)
               assessment_dimensions (generate questions from)
               signal_flip_conditions (check before finalising signal)
               pain_hooks → [PP files]
               air8_products → [PROD files]
               llm_directives → [runtime fact retrieval]
L0-principles/[relevant section]
    ↓ produces: reasoning checklist + directive templates
PROD-XXX.md
    ↓ produces: risk_reduction_narrative (for S1 card)
               eligibility (gate check)
               bd_talking_points (for S2)
PP-XXX.md
    ↓ produces: pain quantification + Air8 solution mapping
```

---

## Retrieval Failure Modes (What to Avoid)

| Failure | Cause | Prevention |
|---|---|---|
| Too many reads | Loading all combos, all principles | Strict: follow routing → match → load only matched |
| Wrong signal | Skipping signal_flip_conditions | Always check after computing initial signal |
| Shallow WHY | Not loading structural_nuances | structural_nuances is mandatory read in Step 2 |
| Missing indirect impact | Not running edge walk | Always run 1-hop edge walk after direct match |
| Stale Why Now hook | Using expired cache entry | Check expires_at before using S1 cache in S2 |
| Wrong product recommendation | Skipping eligibility check | Load PROD file eligibility section before recommending |
