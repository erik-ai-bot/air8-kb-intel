# Active Event Combinations — CORRELATED-PAIR Definitions

> Purpose: Documents expert-reviewed event pairs/triples that must run as combined analyses under RP-EVT-CORRELATED-PAIR
> Created: 2026-07-15 | Source: Alice expert review (Jerri relay 2026-07-15)

---

## Combination 1: India-UK FTA + BD EU Duty-Free

**Status:** PENDING — needs formal S1 run
**Recommended by:** Alice (expert review, 2026-07-15)

### Event Pair
- India-UK FTA: India gains preferential UK market access
- BD EU Duty-Free: Bangladesh EU duty-free access under EBA/GSP

### Why Combine?
Alice: "combine to look at the duty free to EU out from BD instead of only focus in India. Reason — this gives more insight on observable sourcing shifts, buyer behavior, and financing demand."

Both are EU buyer sourcing diversification policy signals — they affect which origins gain preferential EU/UK access and therefore which face displacement.

### Combined Read Approach
1. Run as ONE event: "EU/UK Buyer Sourcing Policy Shifts — which origins gain access, which lose it, what is the financing demand signal?"
2. Compare COMBO-003 (India woven) and COMBO-002 (BD CMT) simultaneously
3. Reference Cambodia CSDDD as counterpoint (KH losing EBA preferential access = negative comparator)
4. Apply RP-EVT-SEGMENT-BIFURCATE — verify same segment or bifurcation

### Relationship Type: AMPLIFYING
- India gains UK market access + BD retains EU duty-free → both push EU buyer diversification from CN
- Combined = faster buyer sourcing shift away from CN toward alternatives
- Air8 signal: China apparel (COMBO-004, COMBO-005) face accelerated EU buyer off-shoring pressure

---

## Combination 2: Event D (UFLPA) + Event F (IEEPA/Section 301)

**Status:** PENDING — needs combined S1 run + combined questions
**Recommended by:** Alice (expert review, 2026-07-15)

### Event Pair
- Event D: UFLPA — US import ban on goods with China-linked forced labor inputs
- Event F: IEEPA/Section 301 — US tariff on China-origin goods as cost penalty

### Why Combine?
Alice: "Both UFLPA and IEEPA/Section 301 have the same root cause: US decoupling from Chinese supply chains, just through two different policy levers."
- IEEPA/Section 301 = cost penalty (tariff)
- UFLPA = access denial (import ban)

### Combined Read: "US Decoupling — Dual Policy Lever (Tariff + Import Ban)"

Combined questions set (per Alice):
- Q1: For US-bound CN factories — have buyers signaled origin shift intent, or locked in by certification barriers?
- Q2: For BD/VN/KH factories with US exposure — are buyers using both levers simultaneously to pressure sourcing shift?
- Q3: For US buyers — are S301 and UFLPA treated as SEPARATE compliance tracks requiring separate documentation?
- Q4: For Air8 — does UFLPA detention create disputed/unpayable receivable? What is the advance risk protocol?

### Relationship Type: AMPLIFYING
- S301 raises cost: CN factories lose price competitiveness
- UFLPA creates access risk: CN factories face border detention even for compliant production
- Combined = no rebuttal available — tariff cannot be absorbed AND ban cannot be cleared if documentation gaps exist

### Key Difference from Standalone
- Standalone S301: cost problem only
- Standalone UFLPA: access problem only
- Combined: cost + access simultaneously

### Air8 Protocol (from COMBO-002 nuances)
> "US Section 301 and UFLPA operate as SEPARATE legal tracks — a shipment can face both simultaneously. BD/VN/KH factories must have SEPARATE documentation for each. Air8 must NOT advance on US-bound shipments without both clearances confirmed."

---

## Combination 3: Event B (CSDDD) + Event C + BD EU Trade

**Status:** PENDING — needs combined S1 run
**Recommended by:** Alice (expert review, 2026-07-15)

### Event Triple
- Event B: CSDDD — EU buyer compliance demands on supply chain
- Event C: [EU regulatory — to be confirmed from KB event taxonomy]
- BD EU Trade: Bangladesh EU duty-free access

### Why Combine?
Alice: "Event B + C + BD EU Trade — these all affect EU apparel sourcing policy; combined shows cumulative compliance + trade access effect."

All three create stacked EU buyer sourcing policy environment: CSDDD + Event C = regulatory burden stack; BD EU Trade = competitive advantage for BD. Combined: EU buyers face increased regulatory burden while BD retains market access advantage.

### Relationship Type: AMPLIFYING (stacked regulatory + trade policy)
- CSDDD + Event C = regulatory burden increase
- BD EU Trade = competitive advantage retention
- Net: EU buyer reliance on BD increases despite compliance cost

---

## Metadata

| Combination | Relationship | Status | Priority |
|---|---|---|---|
| India-UK FTA + BD EU Duty-Free | AMPLIFYING | PENDING | HIGH |
| Event D (UFLPA) + Event F (IEEPA/S301) | AMPLIFYING | PENDING | HIGH |
| Event B (CSDDD) + Event C + BD EU Trade | AMPLIFYING (stacked) | PENDING | MEDIUM |
