# Web Lookup Directives — Master List

> All `web_lookup` directives across KB files.
> DATA_FIGURE claims are never hardcoded in KB — they resolve via these directives at runtime.
> Updated: 2026-07-13

---

## PP-BD-003 — LDC Graduation

| Field | Query | Freshness | Fallback |
|-------|-------|-----------|---------|
| `eu_mfn_tariff_rate` | EU MFN tariff rate HS 6105 6109 T-shirts knit garments Bangladesh post-LDC [year] | annual | 9.6–12% (as of 2024 EU tariff schedule) |
| `gsp_plus_convention_count` | EU GSP+ required conventions count updated regulation 2024 2025 | annual | 32 conventions (updated EU GSP regulation 2023) |
| `bd_ratification_status` | Bangladesh ILO UN convention ratification progress GSP+ status [current year] | quarterly | Active progress — cleared major milestone November 2025 (first in Asia) |
| `buyer_preposition_signals` | EU buyers Bangladesh sourcing shift RFQ changes LDC graduation 2025 2026 | quarterly | Monitor buyer RFQ patterns as leading indicator |

---

## COMBO-002 — Bangladesh CMT LLM Directives

| Field | Query | Freshness | Fallback |
|-------|-------|-----------|---------|
| `bd_bank_od_rate` | current Bangladesh garment factory bank overdraft interest rate [year] | quarterly | 13.5–18% (as of 2024) |
| `air8_pricing_vs_bank` | Air8 SCF receivable purchase pricing SOFR spread vs Bangladesh bank OD rate | quarterly | Air8 ~SOFR+4% vs bank OD 13.5–18% |
| `bd_minimum_wage` | Bangladesh garment worker minimum wage current Taka per month [year] | annual | BDT 12,500/mo (Dec 2023 hike, +56% from BDT 8,000) |
| `wage_fob_share` | Bangladesh garment factory labour cost as percentage of FOB price CMT basics [year] | annual | ~12% of FOB (CMT basics, as of 2024) |
| `buyer_fob_wage_adjustment` | EU buyers FOB price adjustment Bangladesh wage hike sharing 2024 2025 2026 | quarterly | No confirmed FOB adjustment; factory absorbs full increase (verify with expert) |
| `india_yarn_price` | India cotton yarn price current USD per kg [year] | quarterly | See latest commodity data |

---

## How to Add New Directives

When a hardcoded DATA_FIGURE is found in any KB file during expert review:
1. Remove the hardcoded value from the KB file
2. Add a `web_lookup` block in the relevant KB file's "Live Data" section
3. Add a row to this master list
4. Set a fallback value (last known good value with date)
5. Log the change in `_meta/kb-change-log.md`
