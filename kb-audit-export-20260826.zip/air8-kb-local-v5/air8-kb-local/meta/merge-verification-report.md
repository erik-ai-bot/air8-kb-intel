# Merge Verification Report
> Generated: 2026-07-16 | Verifier: Subagent diff check
> Method: Line-by-line content verification across 4 merges

---

## Verification Summary

| Merge | Source Files | Target File | Status |
|---|---|---|---|
| Merge 1 | tag_dictionary.md + terminology.md | EVENT-TYPES.md | ⚠️ 7 ISSUES |
| Merge 2 | signal-decision-rules.md + intensity-scoring-engine.md | REASONING-FLOW.md | ⚠️ 7 ISSUES |
| Merge 3 | web-lookup-directives.md | BRAIN-CHAIN.md | ✅ CLEAN |
| Merge 4 | correlated-event-combinations.md | EVENT-CLUSTERS.md | ⚠️ 2 ISSUES |

---

## Merge 1: tag_dictionary.md + terminology.md → EVENT-TYPES.md

### Section Titles
All source section headers present in target (promoted one heading level). ✓

### tag_dictionary.md Row Verification

**Event Type Tags — Regulation, Financial, Commodity, Geopolitical, Buyer, Supply Chain:**
All rows match exactly. ✓

**Event Type Tags — Market section: 2 DIFFS**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| EVENT-TYPES.md | `product_trend_change` description | **TRUNCATED** — Source: "Product category growing or declining structurally in buyer demand (athleisure rising, formal declining, sustainability premium growing)" → Target drops the examples in parentheses |
| EVENT-TYPES.md | `product_technology_disruption` description | **TRUNCATED** — Source: "New production technology changes competitive landscape (3D knitting, laser finishing, automation disrupting cut-and-sew)" → Target drops the examples in parentheses |

**Material Tags, Country Tags, Company Type Tags, Buyer Geography Tags, Scenario Tags, Domain Tags:**
All rows match exactly. ✓

**Revenue Band Tags:**
Source has a typo: `` `revenue:large` | $50M+` `` (stray backtick). Target correctly has `$50M+`. Fix, not a loss. ✓

**Tag Ranking Rules:**
All 5 bullet points match exactly. ✓

---

### terminology.md Row Verification

**Canonical Terms table — 4 DIFFS**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| EVENT-TYPES.md | **Signal Flip** definition | **CONTENT DROP** — Source definition ends with "Defined in Persona's `Signal Flip Conditions` section." → Target drops this cross-reference entirely |
| EVENT-TYPES.md | **Cliff Date** definition | **CONTENT DROP** — Source: "A hard deadline after which an event's benefit window closes (e.g., a tariff exemption expiry)." → Target drops "(e.g., a tariff exemption expiry)" |
| EVENT-TYPES.md | **Principle** definition (Stored in field) | **PATH UPDATE** — Source: "Stored in L0-principles/" → Target: "Stored in layer-1-reasoning/" — intentional path update, not content loss |
| EVENT-TYPES.md | **Scenario** definition (Each has one... field) | **PATH UPDATE** — Source: "Each has one .md file in _scenarios/." → Target: "Each has one skill file in skills/." — intentional path update |

**Claim Labels — Usage Rules: 1 DIFF**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| EVENT-TYPES.md | [PENDING DATA] label rule | **CONTENT DROP** — Source ends: "Do NOT cite as fact. Must be followed up." → Target drops "Must be followed up." |

**Signal Values — Definitions:**
All 5 signal rows match exactly. ✓

**Relationship Types (for Correlated Event Pairs):**
All 4 relationship type rows match exactly. ✓

**File Naming Conventions: 1 DIFF**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| EVENT-TYPES.md | Scenario flow naming convention | **CONVENTION CHANGED** — Source: `Scenario flow | S[N]-[slug].md | S1-event-insights.md` → Target: `Skill flow | S[N]-[slug]-skill.md | S1-event-insights-skill.md` — The original convention and example are replaced; both the File Type name and the filename pattern changed. Appears intentional but original is not preserved. |

**Pending Standardization table: 1 DIFF**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| EVENT-TYPES.md | "dim:" shorthand row | **ROW MISSING** — Source has: `| "dim:" shorthand | OK to keep as shorthand within Persona files | No change needed |` → Target: row entirely absent from Pending Standardization table |

**Other Pending Standardization rows:**
Remaining rows present with updated file path references (intentional updates). ✓

**Additional target-only additions (not losses):**
- **Correlated Event Pair** definition now includes "See EVENT-CLUSTERS.md § Reviewed Correlated Pairs." — additive improvement. ✓

---

### Merge 1 Verdict: ⚠️ 7 Issues Found

**Fixable content drops (5):**
1. `product_trend_change` description examples dropped
2. `product_technology_disruption` description examples dropped
3. **Signal Flip** — cross-reference to Persona's `Signal Flip Conditions` section dropped
4. **Cliff Date** — "(e.g., a tariff exemption expiry)" dropped
5. **[PENDING DATA]** — "Must be followed up." dropped

**Missing row (1):**
6. "dim: shorthand" row in Pending Standardization table

**Changed convention (1):**
7. "Scenario flow" naming convention row — both file type label and filename pattern changed (may be intentional but source convention not preserved)

---

## Merge 2: signal-decision-rules.md + intensity-scoring-engine.md → REASONING-FLOW.md

### signal-decision-rules.md Verification

**Priority Hierarchy — All 4 Tiers:**
All trigger conditions and effects match exactly. ✓

**Conflict Resolution Rule + within-tier/cross-tier examples:**
Match exactly. ✓

**Visibility Rule + 3-bullet format explanation:**
Match exactly. ✓

**Primary Signals table: 1 DIFF**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| REASONING-FLOW.md | `EXPAND_WITH_HEDGE` signal description | **CONTENT DROP** — Source: "Precondition: expand ONLY IF hedge confirmed in place (e.g., FX forward contract, buyer credit insurance). BD must confirm hedge exists before proceeding." → Target drops "(e.g., FX forward contract, buyer credit insurance)" |

**EXPAND_WITH_HEDGE vs WATCH_HEDGE_GAP Usage Guidance: 2 DIFFS**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| REASONING-FLOW.md | EXPAND_WITH_HEDGE BD conversation example | **TRUNCATED** — Source: `"We can proceed once we confirm [X hedge] is in place. What's your current FX/insurance coverage?"` → Target drops "What's your current FX/insurance coverage?" |
| REASONING-FLOW.md | WATCH_HEDGE_GAP BD conversation example | **TRUNCATED** — Source: `"We can proceed. I want to flag that [X exposure] is unhedged — let's discuss whether that's intentional."` → Target drops "— let's discuss whether that's intentional." |

**9-Signal Complete Vocabulary:**
All 9 signals listed. "Primary signals:" label prefix dropped — minor cosmetic. ✓

**Composition Operators table:**
All 5 operator rows match exactly. ✓

**Composed Signal Examples: 1 DIFF**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| REASONING-FLOW.md | COMBO-005 composed signal example | **CONTENT DROP** — Source: `CAUTION AND_IF india_denim_mills_upgrade_finishing (competitive threat, not direct benefit)` → Target drops "(competitive threat, not direct benefit)" rationale annotation |

**Confidence Per Signal JSON block:**
Matches exactly. ✓

**Worked Examples 1, 2, 3:**
All situations, signals triggered, resolution, output, formula, and BD notes match exactly. ✓

---

### intensity-scoring-engine.md Verification

**Design Principle:**
Matches exactly. ✓

**Score Scale table:**
All 5 rows (CRITICAL/HIGH/MEDIUM/LOW/INACTIVE) match exactly. ✓

**Scoring Formula:**
Matches exactly. ✓

**Driver Definitions — exposure_score:**
Numerical values all match. Source has "e.g.," qualifiers in percentage rows which target drops — minor. ✓

**Driver Definitions — capacity_discount: 3 DIFFS**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| REASONING-FLOW.md | capacity_discount "Pain fully mitigated" row | **EXAMPLES DROPPED** — Source: "Pain fully mitigated (e.g., factory already on GSP+ track, or using Air8 ARP)" → Target: "Pain fully mitigated" |
| REASONING-FLOW.md | capacity_discount "Partially mitigated" row | **EXAMPLES DROPPED** — Source: "Partially mitigated (e.g., some reserves, partial hedging)" → Target: "Partially mitigated" |
| REASONING-FLOW.md | capacity_discount "Pain actively worsening" row | **ROW MISSING** — Source has: `\| Pain actively worsening \| +0 (use compound_bonus instead) \|` → Target: row entirely absent |

**Driver Definitions — urgency_bonus:**
All 4 rows match exactly. ✓

**Driver Definitions — compound_bonus: 1 DIFF**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| REASONING-FLOW.md | compound_bonus worked example | **EXAMPLE MISSING** — Source includes: "Example: PP-BD-003 (LDC graduation) + PP-003 (buyer concentration) both HIGH for a 72% EU-revenue factory → compound_bonus = +15 each compound interaction = PP-BD-003 gets +15 compound bonus from PP-003 co-active" → Target: entirely absent |

**PP File Standard Structure (YAML):**
All fields match exactly. ✓

**What Stays in KB vs Web Lookup: 1 DIFF (significant)**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| REASONING-FLOW.md | "Stays in KB" section — all items | **EXAMPLES AND EXPLANATIONS STRIPPED** — Source provides concrete detail for each item (e.g., "gross_margin_band (e.g., 5–12%) — structural characteristic of archetype", "eligibility thresholds (Air8 internal rules — $1M min, 2yr ops, 6mo ARP track record)", "concentration_pattern (e.g., top 2 buyers = 40–65%) — behavioral pattern"). Target compresses all to bare names without examples or explanations. Critical operational details lost (the $1M min, 2yr ops, 6mo ARP track record thresholds are particularly important). |

**Event Trigger Scoring formula + relevance_mapping:**
Match exactly. ✓

**Runtime Computation Step (8 steps):**
All 8 steps match exactly. ✓

**Worked Example — Factory A:**
Values match. Comments slightly shortened ("moderate default — not existential for all BD factories" dropped) — minor. ✓

**Worked Example — Factory B:**
Values match. "but mitigation in progress" qualifier dropped from urgency_bonus comment — minor. ✓

---

### Merge 2 Verdict: ⚠️ 7 Issues Found

**Fixable content drops (6):**
1. `EXPAND_WITH_HEDGE` — hedge examples "(e.g., FX forward contract, buyer credit insurance)" dropped
2. EXPAND_WITH_HEDGE BD conversation example truncated (follow-up question dropped)
3. WATCH_HEDGE_GAP BD conversation example truncated (discussion prompt dropped)
4. COMBO-005 composed signal — "(competitive threat, not direct benefit)" dropped
5. capacity_discount — examples dropped from "fully mitigated" and "partially mitigated" rows
6. compound_bonus — PP-BD-003/PP-003 worked example missing

**Missing row (1):**
7. capacity_discount "Pain actively worsening" row entirely absent

**Significant simplification (noted separately):**
- "What Stays in KB" section: concrete examples and explanations stripped — the $1M/2yr/6mo eligibility thresholds and concentration pattern example are operationally important and should be restored.

---

## Merge 3: web-lookup-directives.md → BRAIN-CHAIN.md

### Section Structure
All 3 section headers present (PP-BD-003, COMBO-002, How to Add New Directives). ✓

### PP-BD-003 — LDC Graduation table
All 4 rows (eu_mfn_tariff_rate, gsp_plus_convention_count, bd_ratification_status, buyer_preposition_signals) with Field, Query, Freshness, and Fallback values: Match exactly. ✓

### COMBO-002 — Bangladesh CMT LLM Directives table
All 6 rows (bd_bank_od_rate, air8_pricing_vs_bank, bd_minimum_wage, wage_fob_share, buyer_fob_wage_adjustment, india_yarn_price) with all columns: Match exactly. ✓

### How to Add New Directives — 5-step instruction
All 5 steps present. Minor wording changes:
- Step 3: "Add a row to this master list" → "Add a row to this section" — acceptable paraphrase
- Step 5: "Log the change in `_meta/kb-change-log.md`" → "Log the change in kb-change-log" — path simplified

Both are editorial adjustments, not content loss. ✓

---

### Merge 3 Verdict: ✅ CLEAN
No content loss found. All table rows and instruction steps verified present.

---

## Merge 4: correlated-event-combinations.md → EVENT-CLUSTERS.md

### Section Structure
All 3 Combination sections + Metadata table present (renamed as "Correlated Pair 1/2/3" and "Correlated Pair Metadata"). ✓

### Correlated Pair 1: India-UK FTA + BD EU Duty-Free

**Status, Recommended by:** ✓
**Event Pair (both events):** ✓
**Why Combine (Alice quote + explanation):** ✓
**Combined Read Approach (all 4 steps):** ✓
**Relationship Type: AMPLIFYING (all 3 bullets):** ✓

### Correlated Pair 2: Event D (UFLPA) + Event F (IEEPA/Section 301)

**Status, Recommended by:** ✓
**Event Pair (both events):** ✓
**Why Combine (Alice quote + IEEPA/UFLPA mechanism bullets):** ✓
**Combined Read title:** ✓
**Combined questions set — all 4 Q1–Q4:** ✓
**Relationship Type: AMPLIFYING (all 3 bullets):** ✓
**Key Difference from Standalone (all 3 bullets):** ✓
**Air8 Protocol blockquote:** ✓

Note: "(from COMBO-002 nuances)" attribution in the section header dropped — minor cosmetic. ✓

### Correlated Pair 3: Event B (CSDDD) + Event C + BD EU Trade

**Status:** ✓
**Event Triple:** Source had "Event C: [EU regulatory — to be confirmed from KB event taxonomy]" → Target: "Event C: EU regulatory (confirmed from KB event taxonomy)" — status updated to confirmed, brackets removed. Intentional. ✓

**Why Combine: 1 DIFF**

| FILE | SOURCE LINE | ISSUE |
|---|---|---|
| EVENT-CLUSTERS.md | Combination 3 "Why Combine" paragraph | **SENTENCE MISSING** — Source last sentence: "Combined: EU buyers face increased regulatory burden while BD retains market access advantage." → Target paragraph ends one sentence early; this synthesis conclusion is dropped |

**Relationship Type: AMPLIFYING — all 3 bullets:** ✓

### Correlated Pair Metadata table
All 3 rows match exactly. ✓

---

### Merge 4 Verdict: ⚠️ 2 Issues Found

1. Combination 3 "Why Combine" — synthesis conclusion sentence dropped
2. Air8 Protocol header note "(from COMBO-002 nuances)" dropped — minor

---

## Final Summary

| File | Verdict | Issues | Fix Priority |
|---|---|---|---|
| **EVENT-TYPES.md** | ⚠️ NEEDS FIXES | 7 issues (5 content drops, 1 missing row, 1 changed convention) | HIGH — missing row + content drops |
| **REASONING-FLOW.md** | ⚠️ NEEDS FIXES | 7 issues (6 content drops, 1 missing row) | HIGH — missing row + eligibility thresholds loss |
| **BRAIN-CHAIN.md** | ✅ CLEAN | 0 content issues | None |
| **EVENT-CLUSTERS.md** | ⚠️ NEEDS FIXES | 2 issues (1 sentence drop, 1 minor note drop) | LOW — minor synthesis sentence missing |

---

## Fixes Required (Prioritized)

### P0 — Critical: Missing Rows

1. **REASONING-FLOW.md § Driver Definitions — capacity_discount**
   Add back row: `| Pain actively worsening | +0 (use compound_bonus instead) |`

2. **EVENT-TYPES.md § Pending Standardization**
   Add back row: `| "dim:" shorthand | OK to keep as shorthand within Persona files | No change needed |`

### P1 — Important: Operational Detail Lost

3. **REASONING-FLOW.md § What Stays in KB**
   Restore concrete examples:
   - `gross_margin_band (e.g., 5–12%) — structural characteristic of archetype`
   - `concentration_pattern (e.g., top 2 buyers = 40–65%) — behavioral pattern`
   - `eligibility thresholds (Air8 internal rules — $1M min, 2yr ops, 6mo ARP track record)` ← MOST CRITICAL
   - Add back "(changes rarely)" for GST/VAT refund cycle

4. **REASONING-FLOW.md § Driver Definitions — capacity_discount**
   Restore examples in "fully mitigated" and "partially mitigated" rows.

5. **REASONING-FLOW.md § compound_bonus**
   Restore worked example: PP-BD-003 + PP-003 co-active compound calculation.

### P2 — Standard: Content Drops

6. **EVENT-TYPES.md § Canonical Terms — Signal Flip**
   Add back: "Defined in Persona's `Signal Flip Conditions` section."

7. **EVENT-TYPES.md § Canonical Terms — Cliff Date**
   Add back: "(e.g., a tariff exemption expiry)"

8. **EVENT-TYPES.md § Claim Labels — [PENDING DATA]**
   Add back: "Must be followed up."

9. **EVENT-TYPES.md § Market tags**
   Restore parenthetical examples in `product_trend_change` and `product_technology_disruption` descriptions.

10. **REASONING-FLOW.md § EXPAND_WITH_HEDGE**
    Restore "(e.g., FX forward contract, buyer credit insurance)" and full BD conversation examples.

11. **REASONING-FLOW.md § Composed Signal Examples — COMBO-005**
    Restore "(competitive threat, not direct benefit)" annotation.

### P3 — Minor

12. **EVENT-CLUSTERS.md § Combination 3 Why Combine**
    Add back sentence: "Combined: EU buyers face increased regulatory burden while BD retains market access advantage."

13. **EVENT-TYPES.md § File Naming Conventions**
    Verify: "Skill flow | S[N]-[slug]-skill.md" change vs original "Scenario flow | S[N]-[slug].md" — confirm intentional or restore original.

---

*Report complete. BRAIN-CHAIN.md is the only fully clean merge. The other three targets need targeted fixes as listed above.*
