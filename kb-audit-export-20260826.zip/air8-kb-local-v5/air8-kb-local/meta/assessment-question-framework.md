# Assessment Question Framework
# Event-Type Directed + KB-Anchored Question Generation

> File: `_meta/assessment-question-framework.md`  
> Owner: Yeti / KB Team  
> Updated: 2026-07-01  
> Purpose: Tell the LLM how to generate better, more specific questions for each event type, using the KB's existing structural nuances as anchors.

---

## Overview: Two-Layer Framework

### Layer 1 — Event Type Question Angles
For each major event type, defines the angles (categories of dimensions) that must be probed.  
Angle sets: RM · Regulation · Buyer · Financial · Geopolitical · Supply Chain · Market/Product Trend

### Layer 2 — KB Cross-Reference Instruction
Before generating questions, read the relevant KB data to make angle questions specific, not generic.

**All events — always read:**
- Combo's `structural_nuances[]` — durable structural truths that make generic angles specific
- Combo's `assessment_dimensions[]` — the pre-authored dims and signal_impact rules

**Regulation events — additionally read (this is why compliance/regulation belongs in Layer 2):**
- `regulations/REG-XXX.md` — the specific regulation file (scope, applicability, effective date, enforcement mechanism, certification gap mapping). Without this, compliance angles are generic and will miss critical jurisdiction/cert nuance.
- `identity.buyer_geo` — determines whether the regulation even applies (EU reg = EU-selling suppliers only)
- `identity.revenue_band` — determines compliance capacity (small CMT cannot absorb $100K+ remediation)
- `structural_nuances` for existing certifications — BSCI ≠ GOTS ≠ CSDDD; each covers different scope. The KB stores which certs the combo currently holds. Never assume from archetype alone.

> **Design rationale:** Compliance and regulation generate questions that are HEAVILY driven by what the KB already knows about the combo (certifications, buyer geography, company size). These are not generic event angles — they must be KB-grounded first. Hence compliance/regulation is PRIMARILY a Layer 2 concern, and Layer 1 provides only the angle taxonomy.

### Layer 3 — Question Quality Standard
For each angle, defines: what a GENERIC question looks like vs what a GOOD question looks like (using KB nuances).

---

## ⛔ MANDATORY READ REQUIREMENT

Before generating ANY assessment question, the LLM MUST read these files IN ORDER:

```
1. COMBO-XXX.md → assessment_dimensions[] field
   (contains: dim name, why, r1_question, r2_deep, collect, signal_impact)

2. _meta/assessment-question-framework.md → matching event_type angle set
   (this file — find the section matching the trigger event_type)

3. COMBO-XXX.md → structural_nuances[] field
   (use these to make angle questions specific, not generic)

4. IF event_type = Regulation → ALSO read regulations/REG-XXX.md
   (scope, applicability geo, effective date, enforcement mechanism, certification gap mapping)
   Identify which REG file matches from: REG-CSDDD / REG-GPSR / REG-NYFASHION /
   REG-REACH / REG-S211 / REG-TARIFF / REG-UFLPA
   Without this read, compliance questions will miss jurisdiction and certification nuance — REJECTED.
```

**If any of these files are skipped → questions will fail the quality gate.**
Generic questions like "How exposed are you?" or "Do you have alternative suppliers?" 
that don't cite a specific structural_nuance and assessment_dimension are REJECTED.  
Compliance questions that don't cite the specific REG file and existing certifications are REJECTED.

---

## HOW LLM USES THIS FRAMEWORK

### QUESTION GENERATION PROCESS (3 steps)

**Step A — Select angles from framework:**
```
Load _meta/assessment-question-framework.md
Match event_type → select the relevant angle set:
RM · Regulation · Buyer · Financial · Geopolitical · Supply Chain · Market/Product Trend
For compound events (multiple sub-types): combine angle sets, remove duplicates
```

**Step B — KB cross-reference:**
```
Read the combo's structural_nuances
For each angle, check: does the combo have a specific nuance that makes this question more specific?

Example:
  Angle: "What % is imported vs domestic?"
  COMBO-003 nuance: "blend: 40-60% domestic + imported; duty saving on imported ONLY"
  Better question: "What % of your cotton is imported from [US/AU] vs domestic MSP cotton?
                   Specifically — your conventional lines, not your GOTS organic lines."
```

**Step C — Order questions by signal-flip potential:**
```
1. Questions that would completely reverse the signal → ask first
2. Questions that quantify magnitude → ask second
3. Questions that affect Air8 structure (tenor, product) → ask third
4. Questions for monitoring → ask last
```

### QUALITY BAR: Every question must meet ALL criteria:
1. Can be answered by BD in a single supplier call
2. The answer materially changes either the signal or the Air8 recommendation
3. Has a specific KB anchor (which nuance or principle triggered this question?)
4. Has defined signal_impact (what changes if answer is A vs B)

---

## OUTPUT FORMAT for Generated Questions

Each question must follow this structure:

```
Q[N] — [Angle Name] ([Event type relevance])
QUESTION: "[Specific question — using KB nuances to be precise]"
KB ANCHOR: "[Which structural_nuance or L0 principle triggered this question]"
COLLECT: "[Specific documents or data to request]"
SIGNAL IMPACT:
  If [answer A] → signal stays [X] because [reason]
  If [answer B] → signal changes to [Y] because [structural nuance reference]
```

---

## ANGLE SETS BY EVENT TYPE

---

### 1. RAW MATERIAL (RM) EVENT ANGLES

**Applies when:** `event_type = Commodity` OR `event_subtype ∈ {import_export_duty, raw_material_price, raw_material_shortage}`

---

#### Angle 1 — SOURCING STRUCTURE

| | |
|---|---|
| **Generic question** | "Where do you source your cotton?" |
| **KB cross-reference** | Check `structural_nuances` for: import %, domestic blend, buyer-nominated flag |
| **Better question (with KB)** | "What % of your [material] is imported vs domestic [MSP/support-price cotton]? Which specific origins — and are any of these buyer-nominated so you can't switch?" |

---

#### Angle 2 — PRODUCT LINE SPECIFICITY

| | |
|---|---|
| **Generic question** | "Does this affect your products?" |
| **KB cross-reference** | Check for organic/conventional split, product line segmentation, certification constraints |
| **Better question (with KB)** | "Do any of your product lines use [certified cotton / organic / specialty fiber] that has different sourcing rules from your conventional lines? What % of revenue is each?" |

---

#### Angle 3 — COST PASS-THROUGH

| | |
|---|---|
| **Generic question** | "Can you pass cost savings to buyers?" |
| **KB cross-reference** | Check `buyer_passthrough_terms` dimension |
| **Better question (with KB)** | "Are your supply contracts fixed-price seasonal or cost-plus? If input costs change, who keeps the saving/bears the loss — you or the buyer?" |

---

#### Angle 4 — TIMING & CLIFF

| | |
|---|---|
| **Generic question** | "When does this affect you?" |
| **KB cross-reference** | Check if cliff date present; check factory's procurement cycle |
| **Better question (with KB)** | "How far ahead do you typically book [material] purchases? If you pre-buy now at [duty-free/lower price], when would that material be consumed — before or after [cliff date]?" |

---

#### Angle 5 — SUBSTITUTION FEASIBILITY

| | |
|---|---|
| **Generic question** | "Can you use a different material?" |
| **KB cross-reference** | Check material dependency level |
| **Better question (with KB)** | "If [material] prices spike by [X%], is there a substitute you can use without product/certification impact? What's the timeline to switch and which buyers accept it?" |

---

### 2. REGULATION EVENT ANGLES

**Applies when:** `event_type = Regulation`  
**Subtypes covered:** `environmental_compliance`, `traceability`, `labor_standards`, `trade_agreement`, `product_safety`

---

#### Angle 1 — APPLICABILITY (production country + sell-to geography)

| | |
|---|---|
| **Generic question** | "Does this regulation affect you?" |
| **KB cross-reference** | Check `combo identity.country`, `buyer_geo`, `sells_to` edges |
| **Better question (with KB)** | "Where is your factory located? What % of your revenue comes from [EU/US/UK] buyers — the markets where [regulation] applies? Do you also sell to markets where it doesn't apply?" |
| **Why this matters** | Regulation applicability = production country × buyer geography × product type. All three matter. |

---

#### Angle 2 — PRODUCT SCOPE

| | |
|---|---|
| **Generic question** | "Are your products covered?" |
| **KB cross-reference** | Check `product_type`, `material`, HS code |
| **Better question (with KB)** | "Which specific product categories and materials does this regulation cover? What % of your revenue comes from those categories vs exempt categories?" |
| **Note** | Many regulations are product-specific (REACH = chemicals; UFLPA = cotton; GPSR = consumer products). The factory may be partially exposed, not fully. |

---

#### Angle 3 — COMPLIANCE GAP

| | |
|---|---|
| **Generic question** | "Are you compliant?" |
| **KB cross-reference** | Check existing certifications in `structural_nuances` |
| **Better question (with KB)** | "What compliance certifications do you currently hold — [BSCI/Sedex/GOTS/ZDHC/HIGG]? Have any of your EU buyers already asked you to complete [specific regulation] questionnaires or audits?" |
| **Note** | BSCI ≠ CSDDD ≠ UFLPA ≠ REACH — each has different scope. Factory may be compliant with one but not others. |

---

#### Angle 4 — FACTORY SCALE AND CAPACITY TO COMPLY

| | |
|---|---|
| **Generic question** | "Can you comply?" |
| **KB cross-reference** | Check `revenue_band`, `identity.company_type` |
| **Better question (with KB)** | "Compliance for [regulation] typically costs [range] in audit + remediation. Is that within your annual budget? Or would you need to pass the cost to buyers?" |
| **Why this matters** | Small CMT factories ($5–20M) cannot absorb $100K+ remediation; large verticals ($50M+) can. Scale determines response options. |

---

#### Angle 5 — BUYER MANDATE VS LEGAL REQUIREMENT

| | |
|---|---|
| **Generic question** | "Do you have to do this?" |
| **KB cross-reference** | Check buyer type and `buyer_geo` |
| **Better question (with KB)** | "Has any of your buyers — specifically [H&M/Zara/Primark] — already sent you a questionnaire or audit request related to this? Or are you waiting for the legal deadline?" |
| **Why this matters** | Large EU buyers cascade compliance requirements 2–3 years before the legal deadline. The operative deadline may be buyer contract renewal (2026–2027), not the legal date (2029). |

---

#### Angle 6 — TIMELINE TO COMPLY

| | |
|---|---|
| **Generic question** | "When do you need to be compliant?" |
| **KB cross-reference** | Check regulation effective date, buyer mandate signals |
| **Better question (with KB)** | "If a buyer programme comes up for renewal in [year], will they require [regulation] compliance as a condition? What's your realistic timeline to close the gap?" |

---

### 3. BUYER EVENT ANGLES

**Applies when:** `event_type = Buyer`  
**Subtypes covered:** `sourcing_strategy_shift`, `market_entry_exit`, `supplier_consolidation`, `compliance_mandate`, `M&A`, `nearshoring`, `buyer_credit_event`

---

#### Angle 1 — BUYER RELIANCE & CONCENTRATION

| | |
|---|---|
| **Generic question** | "Do you sell to this buyer?" |
| **KB cross-reference** | Check `sells_to` edges, `buyer_concentration` pattern |
| **Better question (with KB)** | "What % of your revenue comes from [affected buyer]? Is that a growing or shrinking share over the last 2 years? What would your business look like if you lost that programme?" |
| **Why this matters** | 20% buyer = manageable; 60% buyer = existential. The assessment must quantify the dependency. |

---

#### Angle 2 — PRODUCT COVERAGE

| | |
|---|---|
| **Generic question** | "Are your products affected?" |
| **KB cross-reference** | Check `product_type`, `buyer_geo`, `material` |
| **Better question (with KB)** | "Which specific product categories does [buyer] source from you? Is [buyer's new strategy/shift] affecting all categories or only specific ones — e.g., basics vs fashion, cotton vs synthetic?" |
| **Why this matters** | A buyer exiting cotton basics may still want denim or knitwear. Product-level granularity matters. |

---

#### Angle 3 — MARGIN IMPACT (can they afford it?)

| | |
|---|---|
| **Generic question** | "What's the financial impact?" |
| **KB cross-reference** | Check `structural_nuances` for margin range, financing cost |
| **Better question (with KB)** | "What is your approximate gross margin on [buyer's] orders? If you lost [X%] of that revenue, how many months could you sustain operations at current fixed costs before needing to restructure?" |
| **Why this matters** | A factory with 15% margins can absorb buyer loss better than one at 5%. The survivability question is about margin, not just revenue. |

---

#### Angle 4 — BUYER'S OTHER SUPPLIERS & THEIR STRATEGY

| | |
|---|---|
| **Generic question** | "Who else does the buyer use?" |
| **KB cross-reference** | Check same `sell_to` buyer type edge weights across combos |
| **Better question (with KB)** | "Do you know which other factories [buyer] is sourcing from for similar products — particularly in [other countries like BD/VN/IN]? Have they told you anything about their consolidation plans?" |
| **Why this matters** | RP-PEER-FAILURE applies here too — if buyer consolidating suppliers, who specifically is being cut vs retained? Factory may be overconfident about retention. |

---

#### Angle 5 — ALTERNATIVE BUYER PIPELINE

| | |
|---|---|
| **Generic question** | "Do you have other buyers?" |
| **KB cross-reference** | Check `buyer_concentration`, `buyer_geo` |
| **Better question (with KB)** | "If [buyer] reduces or exits your programme, which other buyers are you actively developing? What's your realistic timeline to replace that revenue — 6 months, 12 months, 24 months?" |
| **Why this matters** | Replacement timeline determines Air8 risk horizon. If factory can replace in 6 months, CAUTION is appropriate. If 24+ months, DO_NOT_EXPAND. |

---

#### Angle 6 — NEW MARKET REQUIREMENT FULFILLMENT
*(for `compliance_mandate` sub-type only)*

| | |
|---|---|
| **Generic question** | "Can you meet the new requirement?" |
| **KB cross-reference** | Check existing certifications, compliance gap |
| **Better question (with KB)** | "The buyer is now requiring [specific compliance — HIGG FEM Level 2 / ZDHC MRSL / digital product passport]. Do you currently have this? If not, what's your timeline and budget to achieve it?" |
| **Why this matters** | Buyer compliance mandates are often harder to meet than legal ones — buyers set higher standards on shorter timelines. This determines whether the supplier retains or loses the programme. |

---

### 4. FINANCIAL / FX EVENT ANGLES

**Applies when:** `event_type = Financial`  
**Subtypes covered:** `fx_rate`, `interest_rate`, `buyer_credit_event`, `buyer_payment_term`, `supplier_distress`

---

#### Angle 1 — CURRENCY STRUCTURE

| | |
|---|---|
| **Generic question** | "Are you affected by FX?" |
| **KB cross-reference** | Check `EUR_invoice_pct` (TR denim), INR vs USD exposure |
| **Better question (with KB)** | "What % of your invoices are in EUR vs USD vs [local currency]? And what % of your costs are in [local currency] vs USD? Does the mismatch create open FX exposure?" |

---

#### Angle 2 — NATURAL HEDGE

| | |
|---|---|
| **Generic question** | "Do you hedge?" |
| **KB cross-reference** | Check country (TRY/EUR = natural hedge for TR; INR/USD = open exposure for IN) |
| **Better question (with KB)** | "Does your Air8 facility denominated in EUR/USD actually help you — because your buyers pay in EUR/USD — or does it create additional currency mismatch vs your local costs?" |

---

#### Angle 3 — BUYER PAYMENT BEHAVIOUR
*(for `buyer_credit_event` or `buyer_payment_term` sub-types)*

| | |
|---|---|
| **Generic question** | "Are buyers paying on time?" |
| **KB cross-reference** | Check DSO trend, buyer anchor quality |
| **Better question (with KB)** | "Has [buyer] extended payment terms in the last 6 months — from e.g. 60 days to 90 days? Or have you seen any delays beyond contracted terms?" |
| **Why this matters** | DSO extension precedes payment default. Behaviour change is the early warning. |

---

#### Angle 4 — BANK FACILITY HEALTH

| | |
|---|---|
| **Generic question** | "How's your cash situation?" |
| **KB cross-reference** | Check `bank_od_utilisation`, `credit_line_status` |
| **Better question (with KB)** | "Has your bank communicated any changes to your credit line — rate increase, limit reduction, or additional collateral requirement? Is your OD currently at what % of limit?" |

---

### 5. GEOPOLITICAL EVENT ANGLES

**Applies when:** `event_type = Geopolitical` (sub-types: sanctions, trade_war, political_instability, route_disruption)

> Geopolitical events = external political forces affecting market access, trade flows, or country stability.
> Key distinction from Supply Chain: the CAUSE is political/governmental, not operational.

---

#### Angle 1 — DIRECT COUNTRY EXPOSURE

| | |
|---|---|
| **Generic question** | "Does this affect your factory?" |
| **KB cross-reference** | Check `identity.country` vs affected country; check `buyer_geo` for market-side impact |
| **Better question (with KB)** | "Is your factory in the country directly affected by [sanctions/trade war/instability]? Or are you in a neighbouring country where the disruption affects your buyer markets or input supply?" |
| **Signal impact** | Direct = immediate CAUTION; adjacent = indirect, assess magnitude |

---

#### Angle 2 — TRADE ACCESS & SANCTIONS EXPOSURE

| | |
|---|---|
| **Generic question** | "Are you under sanctions?" |
| **KB cross-reference** | Check `sells_to` buyer geographies; check material origin (Xinjiang for UFLPA) |
| **Better question (with KB)** | "Do any of your input materials originate from sanctioned regions — specifically [Xinjiang cotton for UFLPA / Russian inputs for EU sanctions]? Can you provide chain-of-custody documentation to the gin/raw material level?" |
| **Signal impact** | If sanctioned input confirmed → COMPLIANCE BLOCK immediately; if no exposure → MONITOR only |

---

#### Angle 3 — BUYER MARKET DISRUPTION

| | |
|---|---|
| **Generic question** | "Do your buyers still want your products?" |
| **KB cross-reference** | Check `sells_to` buyer types and buyer geography; check if buyer's home market is affected |
| **Better question (with KB)** | "Are your EU/US buyers themselves being affected by this geopolitical event — e.g., is their domestic demand falling, or are they facing boycott/political pressure that changes their sourcing decisions?" |
| **Signal impact** | If buyer home market disrupted → compound risk; buyer may reduce orders regardless of factory performance |

---

#### Angle 4 — GOVERNMENT POLICY RISK (TARIFFS / TRADE WAR)

| | |
|---|---|
| **Generic question** | "Are there new tariffs?" |
| **KB cross-reference** | Check `sells_to:USMassMarket` weight, `buyer_geo:US` — highest tariff exposure |
| **Better question (with KB)** | "What % of your revenue is from US buyers? Have any of them communicated price adjustment requests or sourcing review signals since [tariff announcement]? Are your contracts fixed-price or do buyers have tariff adjustment clauses?" |
| **Signal impact** | If US > 50% AND tariff > 15% → CAUTION; if EU-dominant → lower impact |

---

#### Angle 5 — STRUCTURAL BREAK VS CYCLICAL (RP-STRUCTURAL-CHANGE)

| | |
|---|---|
| **Generic question** | "Is this temporary?" |
| **KB cross-reference** | Apply RP-STRUCTURAL-CHANGE primitive |
| **Better question (with KB)** | "Is this geopolitical event part of a recurring pattern — like US-China trade friction — or does it represent a permanent structural shift in market access? If permanent, which parts of your business model need to change?" |
| **Signal impact** | Cyclical = CONDITIONAL (wait and see); Structural = RESTRUCTURE signal, re-evaluate combo classification |

---

### 6. SUPPLY CHAIN EVENT ANGLES

**Applies when:** `event_type = Supply Chain` (sub-types: factory_capacity_change, lead_time_change, logistics_disruption, allocation_constraint)

> Supply Chain events = operational disruptions affecting production, logistics, or material availability.
> Key distinction from Geopolitical: the CAUSE is operational/structural, not political.
> RP-PEER-FAILURE applies here: when competitor capacity exits, check if survivor faces same forces.

---

#### Angle 1 — INPUT AVAILABILITY & ALLOCATION

| | |
|---|---|
| **Generic question** | "Can you still get your materials?" |
| **KB cross-reference** | Check `sources_from` edges; check material dependency in structural_nuances |
| **Better question (with KB)** | "Is [material] available from your current suppliers, or are there allocation constraints? If allocation is limited — who gets priority: vertically integrated mills, long-term contracted buyers, or spot buyers? Which category are you in?" |
| **Signal impact** | If spot buyer with no contract → CAUTION (last in allocation queue); if vertically integrated → lower risk |

---

#### Angle 2 — LEAD TIME IMPACT & TENOR ADJUSTMENT

| | |
|---|---|
| **Generic question** | "How long will this delay things?" |
| **KB cross-reference** | Check typical cash cycle in `identity.cash_cycle_days`; check Air8 tenor constraints |
| **Better question (with KB)** | "By how many days is your production or delivery lead time extending due to this disruption? Your normal cycle is [X] days — will the extended cycle push your Air8 repayment past the scheduled maturity date?" |
| **Signal impact** | If new lead time pushes tenor past 90-120d → require tenor extension or restructure; if within existing band → no change |

---

#### Angle 3 — ALTERNATIVE SOURCING / ROUTING

| | |
|---|---|
| **Generic question** | "Do you have alternatives?" |
| **KB cross-reference** | Check `sources_from` secondary edges; check substitution feasibility from RM framework |
| **Better question (with KB)** | "Do you have qualified alternative suppliers for [material] in a different origin — e.g., if Indian yarn is disrupted, can you qualify Chinese or Pakistani yarn within 30-60 days? What's the quality and cost differential?" |
| **Signal impact** | If alternatives exist and qualified → CONDITIONAL; if no alternatives → CAUTION or DO_NOT_EXPAND until resolved |

---

#### Angle 4 — BUYER TOLERANCE FOR DELAY

| | |
|---|---|
| **Generic question** | "What do your buyers say?" |
| **KB cross-reference** | Check `buyer_relationship_stability`; check if buyer has tight replenishment model (e.g., Zara 14-day reorder) |
| **Better question (with KB)** | "Have any buyers communicated force majeure or penalty waiver for this disruption? Or are they holding you to original delivery terms? For [Zara/fast fashion buyers], a 2-week delay often results in cancellation — have they indicated flexibility?" |
| **Signal impact** | If buyer inflexible → receivable risk (goods rejected = unpayable ARP); if buyer flexible with documentation → lower risk |

---

#### Angle 5 — SURVIVOR BIAS (RP-PEER-FAILURE)

| | |
|---|---|
| **Generic question** | "Are you gaining from competitors' problems?" |
| **KB cross-reference** | Apply RP-PEER-FAILURE primitive from `_reasoning/primitives.md` |
| **Better question (with KB)** | "If competitors in your cluster are facing the same disruption — is your factory genuinely better positioned, or are you also exposed to the same constraints? What's your specific structural advantage over the factories that are struggling?" |
| **Signal impact** | Same exposure as struggling peers → CONDITIONAL "not-yet-failed"; genuine differentiation confirmed → EXPAND |

---


---

### 7. MARKET / PRODUCT TREND EVENT ANGLES

**Applies when:** `event_type = Market` (sub-types: product_trend_change, product_technology_disruption, demand_shift)

> Product trend events = structural shifts in what products buyers want or how they're made.
> Key distinction: not a regulatory mandate (Regulation) and not a buyer behaviour change (Buyer) — it's about the PRODUCT CATEGORY itself changing in demand or production method.
> These are often slow-moving but structurally significant — easy to miss until too late.

---

#### Angle 1 — CATEGORY TRAJECTORY (growing vs declining)

| | |
|---|---|
| **Generic question** | "Is your product category growing?" |
| **KB cross-reference** | Check `identity.product_type`; check `sells_to` buyer type (fast fashion buyers drive category trends fastest) |
| **Better question (with KB)** | "What % of your revenue comes from [specific product category — denim / basics / athleisure / home textile]? Is that category growing or declining in your buyers' assortments over the last 2-3 years? Have any buyers specifically told you they're reducing or expanding this category?" |
| **Signal impact** | Declining category + specialist factory = CAUTION (structural revenue erosion); growing category + capable factory = CONDITIONAL EXPAND |

---

#### Angle 2 — REVENUE CONCENTRATION IN AFFECTED CATEGORY

| | |
|---|---|
| **Generic question** | "How exposed are you?" |
| **KB cross-reference** | Check `identity.product_type` and whether factory is single-product or multi-product |
| **Better question (with KB)** | "Is [affected product category] your primary revenue — over 70%? Or do you have diversification across product types? If [category] declines 20%, what happens to your total revenue and your ability to service financing?" |
| **Signal impact** | >70% concentration in declining category = DO_NOT_EXPAND; <30% concentration = MONITOR; mixed = CONDITIONAL |

---

#### Angle 3 — CAPABILITY TO PIVOT

| | |
|---|---|
| **Generic question** | "Can you make different products?" |
| **KB cross-reference** | Check `identity.company_type` (CMT vs FOB vs Vertical — vertical has most flexibility); check structural nuances for specialist equipment |
| **Better question (with KB)** | "If you wanted to shift [X%] of your production to [trending product], what equipment, certifications, or skills would you need that you don't currently have? What is the realistic investment cost and timeline — and do any of your current buyers buy the trending product too?" |
| **Signal impact** | Pivot feasible + buyer overlap confirmed = EXPAND (early mover); pivot requires 2yr+ = CONDITIONAL; no pivot path = CAUTION or RESTRUCTURE |

---

#### Angle 4 — BUYER SIGNALS (leading indicator)

| | |
|---|---|
| **Generic question** | "What are your buyers saying about trends?" |
| **KB cross-reference** | Check `sells_to` buyer types — fast fashion buyers (Zara/H&M) signal trends 2-4 seasons ahead; mass market buyers lag by 1-2 years |
| **Better question (with KB)** | "Have any of your EU fast fashion buyers (H&M, Zara) added new product programmes in [trending category] or sent you requests for quotes in categories you don't currently supply? Buyers often signal demand shifts in RFQs before they're public." |
| **Signal impact** | Buyer RFQ in trending category = strong early signal; buyer cutting existing programme = decline confirmed; no signal = MONITOR |

---

#### Angle 5 — SPECIALIST VS GENERALIST POSITIONING

| | |
|---|---|
| **Generic question** | "Are you focused on one product type?" |
| **KB cross-reference** | COMBO-005 (TR Denim) = specialist; COMBO-004 (CN FOB) = generalist. Check structural nuances for specialist equipment (laser/ozone = moat) |
| **Better question (with KB)** | "Is your factory's competitive advantage tied specifically to [current product category] — e.g., specialist denim finishing, organic cotton expertise, home textile weaving? Or could you realistically produce [trending category] without major retooling? Is your moat product-specific or capability-specific?" |
| **Signal impact** | Product-specific moat in growing category = EXPAND (defensible); product-specific moat in declining category = CAUTION (locked in); capability moat = more flexible |

---

#### Angle 6 — TECHNOLOGY ADOPTION (for product_technology_disruption)

| | |
|---|---|
| **Generic question** | "Do you have the new technology?" |
| **KB cross-reference** | COMBO-005 nuance: laser/ozone in-house vs outsourced = key moat signal; check equipment in structural_nuances |
| **Better question (with KB)** | "Do you currently have [new technology — 3D knitting / laser finishing / automated cutting] in-house, or do you outsource it? What % of your styles already use it? Among your direct competitors in [city/cluster], how many have adopted it — are you ahead, at parity, or behind?" |
| **Signal impact** | In-house + ahead of peers = EXPAND (competitive moat); outsourced = CONDITIONAL (moat fragile); behind peers + buyer requires it = CAUTION |

---

## COMPOUND EVENT HANDLING

When a trigger activates multiple event sub-types simultaneously:

```
1. Collect all angle sets for each matching event_type
2. Deduplicate angles with shared dimensions (e.g., buyer_geo appears in both Regulation and Buyer angles)
3. Keep the MORE SPECIFIC version — the one that references the actual event detail
4. Reorder combined set by signal-flip potential before generating questions
5. Cap at 6-8 questions total for a single assessment call; flag remaining as "follow-up if needed"
```

**Example compound trigger:** Bangladesh GST renegotiation + H&M vendor consolidation
- Event 1 = Trade Agreement (Regulation angles: Applicability, Product Scope, Timeline)
- Event 2 = Buyer/supplier_consolidation (Buyer angles: Buyer Reliance, Compliance Gap, Alternative Pipeline)
- Merge: Compliance Gap appears in both → keep Buyer version (more specific to H&M scorecard)
- Result: 5 combined questions covering both events

---

## QUICK LOOKUP: ANGLE → EVENT TYPE MAPPING

| Angle | RM | Regulation | Buyer | Financial | Geo | Supply Chain | Market |
|---|:---:|:---:|:---:|:---:|:---:|
| Sourcing Structure | ✅ | |
| Product Line Specificity | ✅ | ✅ | ✅ | |
| Cost Pass-Through | ✅ | | ✅ | |
| Timing & Cliff | ✅ | |
| Substitution Feasibility | ✅ | |
| Applicability (geo + product) | | ✅ | |
| Product Scope | | ✅ | ✅ | |
| Compliance Gap | | ✅ | ✅ | |
| Scale / Capacity to Comply | | ✅ | |
| Buyer Mandate vs Legal | | ✅ | |
| Timeline to Comply | | ✅ | ✅ | |
| Buyer Reliance & Concentration | | | ✅ | ✅ | |
| Margin Impact | | | ✅ | ✅ | |
| Buyer's Other Suppliers | | | ✅ | |
| Alternative Buyer Pipeline | | | ✅ | |
| New Market Requirement | | | ✅ | |
| Currency Structure | | | | ✅ | |
| Natural Hedge | | | | ✅ | |
| Buyer Payment Behaviour | | | | ✅ | |
| Bank Facility Health | | | | ✅ | |
| Direct Production Exposure | | | | | ✅ | |
| Logistics & Route Dependency | | | | | ✅ | |
| Buyer Tolerance | | | | | ✅ | |
| Input Supply Chain | | | | | ✅ | |

---

## WORKED EXAMPLE: Framework in Action

**Scenario:** India cotton import duty cut (11% → 0%), cliff Oct 31  
**Combo:** COMBO-003 (IN Vertical — integrated cotton-to-garment, buys raw cotton)  
**Event type match:** RM / import_export_duty  
**Angles selected:** Sourcing Structure, Product Line Specificity, Cost Pass-Through, Timing & Cliff, Substitution Feasibility

**Step B — KB cross-reference for COMBO-003:**
- `structural_nuances.blend` = "40–60% domestic MSP + imported; duty saving on imported ONLY"
- `structural_nuances.organic_split` = "GOTS organic lines use domestic certified cotton — duty irrelevant for these lines"
- `structural_nuances.passthrough` = "buyer_passthrough_terms: fixed-price seasonal typical; saving likely retained"
- `structural_nuances.cliff_risk` = "over-stockpiling risk if pre-buy > 2x normal cycle"

**Resulting questions (Step C ordered):**

```
Q1 — Sourcing Structure (signal reversal risk)
QUESTION: "Do you buy raw cotton directly from farmers/traders, or do you purchase 
           pre-spun yarn or finished fabric?"
KB ANCHOR: "Duty saving only applies to raw cotton purchases, not yarn or fabric"
COLLECT: Cotton purchase orders (last 12 months)
SIGNAL IMPACT:
  If buys raw cotton → formula activates; proceed to Q2
  If buys yarn/fabric → duty saving = ZERO; signal flips EXPAND → NEUTRAL

Q2 — Product Line Specificity (magnitude)
QUESTION: "What % of your production is GOTS organic certified vs conventional?"
KB ANCHOR: "structural_nuances.organic_split: GOTS lines use domestic certified cotton only"
COLLECT: GOTS certificate scope, revenue by line
SIGNAL IMPACT:
  If 100% organic → duty irrelevant; signal → NEUTRAL
  If 70% conventional → apply formula to conventional COGS only; partial saving

Q3 — Product Line Specificity (magnitude)
QUESTION: "Of your conventional cotton lines, what % is imported vs domestic MSP?"
KB ANCHOR: "structural_nuances.blend: 40–60% domestic + imported; saving on imported ONLY"
COLLECT: Procurement breakdown by origin (% volume)
SIGNAL IMPACT:
  If 100% imported → full 11% saving on conventional COGS
  If 50% imported → recalculate: 11% × 50% × COGS%

Q4 — Cost Pass-Through (Air8 structure)
QUESTION: "Are your buyer contracts fixed-price seasonal or cost-plus/variable?"
KB ANCHOR: "L0 principle RP-MATERIAL-01: buyer_passthrough quantification required"
COLLECT: Contract pricing clause or buyer correspondence
SIGNAL IMPACT:
  If fixed-price → factory retains full saving; EXPAND confirmed
  If cost-plus → calculate net saving after passthrough%

Q5 — Timing & Cliff (Air8 tenor)
QUESTION: "How far ahead do you typically book cotton purchases? If pre-buying before 
           Oct 31 cliff, how many months above normal procurement?"
KB ANCHOR: "L0 principle RP-TARIFF-CLIFF-01: over-stockpiling = post-cliff WC stress"
COLLECT: Forward procurement plan (Sep–Oct); bank OD headroom
SIGNAL IMPACT:
  If 1–2x normal → manageable; OBF tenor ≤ 90d, front-load Jun–Aug
  If 3–5x normal → CAUTION; require WC plan before expanding
```

---

*End of assessment-question-framework.md*  
*Cross-referenced by: S3-individual-assessment.md (Step 3)*
