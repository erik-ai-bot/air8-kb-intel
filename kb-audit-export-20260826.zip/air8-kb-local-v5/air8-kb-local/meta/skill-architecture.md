# Air8 KB Skill Architecture

> Updated: 2026-07-13
> Design principle: each skill has ONE responsibility. They link by name only.
> Enhancing one skill never requires changing another.

---

## Skill Map

```
┌─────────────────────────────────────────────────────────────┐
│                    kb-management                            │
│  KB maintenance: ingest sources, evolve entries,            │
│  fix tables, audit completeness, update indexes             │
│  Location: ~/.openclaw/workspace/skills/kb-management/      │
└─────────────────────────────────────────────────────────────┘
         ↑ maintains
         │
┌─────────────────────────────────────────────────────────────┐
│                    kb-llm-flow                              │
│  Scenario execution: S0 news intake, S1 event insights,     │
│  S2 pain→BD advice, S3 individual assessment,               │
│  S4 portfolio monitoring                                    │
│  Location: air8-kb-v2-LLM-SKILL.md (to be promoted)        │
│  References:                                                │
│    invoke: kb-expert-review  ← validation after output      │
│    reads:  air8-kb-v2/       ← KB source files              │
└─────────────────────────────────────────────────────────────┘
         ↓ calls after every result generation
         │
┌─────────────────────────────────────────────────────────────┐
│                  kb-expert-review  ✅ LIVE                  │
│  Validation pipeline: confidence scoring, expert routing,   │
│  web-check, KB update decision, Jerri sign-off queue        │
│  Location: ~/.openclaw/workspace/skills/kb-expert-review/   │
│  Config:   air8-kb-v2/_meta/expert-review-config.json       │
│  No knowledge of: scenario logic, KB structure, personas    │
└─────────────────────────────────────────────────────────────┘
```

---

## Interface Contract

### kb-llm-flow → kb-expert-review

```yaml
invoke: kb-expert-review
input:
  result_type: pain_point | event_insight | bd_card | risk_assessment
  archetype: [COMBO-id]
  claims: [list of {claim_id, text, claim_type, kb_source_ref}]
  threshold: [read from _meta/expert-review-config.json, default 90]
output:
  validated_result      # original result enriched with confidence scores
  kb_updates_applied    # list of KB changes made in this run
  pending_items         # items awaiting expert/Jerri response
```

This is the ONLY interface. kb-llm-flow knows nothing else about kb-expert-review internals.

---

## What Each Skill Owns

| Concern | Owned By |
|---------|---------|
| KB file structure, ingestion, indexes | kb-management |
| Scenario flows (S1–S4), intensity computation, BD cards | kb-llm-flow |
| Confidence scoring algorithm | kb-expert-review |
| Expert routing (who gets what) | kb-expert-review (via config) |
| Telegram message format to experts | kb-expert-review |
| Web-check logic | kb-expert-review |
| KB update decision tree (figure vs logic) | kb-expert-review |
| Jerri sign-off queue | kb-expert-review |
| Confidence threshold value | `_meta/expert-review-config.json` (config only) |
| web_lookup directives | KB files + `_meta/web-lookup-directives.md` |

---

## Enhancement Rules

| If you want to... | Change this |
|------------------|-------------|
| Lower confidence threshold | `_meta/expert-review-config.json` only |
| Add a new expert (e.g., new domain) | `_meta/expert-review-config.json` only |
| Change how experts are messaged | kb-expert-review SKILL.md only |
| Add a new scenario (S5, S6) | kb-llm-flow (new scenario file) only |
| Add a new pain point | KB PP file + kb-management indexes |
| Change intensity scoring weights | `_meta/intensity-scoring-engine.md` + kb-llm-flow |
| Add a web_lookup directive | KB source file + `_meta/web-lookup-directives.md` |
| Change KB update decision rules | kb-expert-review SKILL.md only |

Nothing in this table requires changing more than one skill.
