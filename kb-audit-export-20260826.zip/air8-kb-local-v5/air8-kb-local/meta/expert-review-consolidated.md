# Air8 KB v2 — Expert Review Consolidated
> Generated: 2026-07-01 | Status: PENDING REVIEW
> Author: Snowman (AI-inferred) | Source: air8-kb-news-validation.md (6-event analysis)
> Route to: Alice Wong · Josephine Cheung · Jerri Zhou

---

## How to Review

Mark each item with one of:
- ✅ **APPROVED** — correct as written; include in KB
- ❌ **REJECTED** — wrong; add correction note below item
- ✏️ **EDIT** — needs change; write corrected version inline
- ⏭ **DEFER** — not urgent; revisit next quarter
- 🔴 **EXCLUDE** — do not include; AI overreach

**Return marked file to Jerri/Snowman.** Only ✅ items will be committed to combo files.

---

## 🚨 URGENT — By July 6 (Jerri)

> Cliff: USTR public comment deadline July 6, 2026. 5,160 CBP shipment denials already confirmed.

### J-U1 · US UFLPA/S301 Dual Mechanism Critical Nuance
**Applies to:** COMBO-002, COMBO-006, COMBO-012 (already added to all three)

> "⚠️ US Section 301 forced labor investigations and UFLPA operate as SEPARATE legal tracks — a shipment can face both simultaneously: UFLPA creates a rebuttable presumption of detention at CBP, while S301 adds tariff liability. BD/VN/KH factories with US buyers must have SEPARATE documentation for each: UFLPA traceability + S301 country-of-origin compliance. Air8 must NOT advance on US-bound shipments from these origins without both clearances confirmed." (source: Events D+F, freshness: annual)

**Expert review:** [ ]

**Notes:**
___

---

### J-U2 · BD Signal Flips — US Buyer + No UFLPA Docs
**Applies to:** COMBO-002

> IF has_us_buyers AND no_uflpa_documentation → flag COMPLIANCE risk; do NOT advance on US-bound shipments until UFLPA documentation confirmed ⚠️ PENDING REVIEW

> IF section_301_tariff_imposed_on_BD → assess impact on US buyer competitiveness; BD US revenue may decline; flip any EXPAND (US-buyer-based) to CAUTION ⚠️ PENDING REVIEW

**Expert review:** [ ]

**Notes (Jerri: is this threshold correct? Should BD S301 tariff trigger full CAUTION or just US-bound CAUTION?):**
___

---

### J-U3 · VN Signal Flips — S301 + Parent Relocation
**Applies to:** COMBO-006

> IF section_301_tariff_imposed_on_VN → immediately reduce advance ratio to alert level (70%); trigger parent HQ conversation about production shift timeline ⚠️ PENDING REVIEW

> IF parent_company_announces_VN_capacity_reduction → exit orderly; do not extend new facilities ⚠️ PENDING REVIEW

**Expert review:** [ ]

**Notes:**
___

---

### J-U4 · Air8 Receivable Protocol for UFLPA-Detained Shipments
**Applies to:** COMBO-002 (structural nuance)

> "⚠️ Air8 receivable quality protocol for UFLPA-detained shipments: if a client's US-bound shipment is detained by CBP, the buyer receivable becomes disputed or unpayable; Air8 advance on that specific shipment is at risk; Air8 should implement a 'US-bound shipment compliance check' gate before advancing on any BD factory with US buyer exposure" (source: Event D, freshness: stable)

**Expert review (Jerri: does an internal protocol exist? If not, flag for risk team):** [ ]

**Notes:**
___

---

## 🔴 HIGH PRIORITY (Jerri + Alice) — Review This Week

> Cliff: Late July 2026 — IEEPA tariffs replaced by Section 301 tariffs.

### J-H1 · BD S301 Structural Nature Nuance
**Applies to:** COMBO-002

> "⚠️ Section 301 tariffs, unlike IEEPA, require a formal investigation finding and cannot be removed by presidential executive order alone — once S301 tariffs on Bangladesh are published in the Federal Register, they become structural and long-lived (typical S301 tariffs have lasted 5-10+ years); any Air8 expansion into BD factories with US buyer concentration should be paused pending S301 investigation outcome" (source: Event F, freshness: quarterly)

**Expert review:** [ ]

**Notes:**
___

---

### J-H2 · BD S301 LDC Status Response
**Applies to:** COMBO-002

> "⚠️ Bangladesh has historically avoided US tariff action due to LDC status and goodwill diplomacy; the USTR S301 forced labor framing is a different legal basis than competitiveness — BD government response may be more conciliatory (labor law reform pledges) than retaliatory, which may narrow or delay tariff implementation for BD specifically" (source: Event F, freshness: quarterly)

**Expert review:** [ ]

**Notes (Alice: is this historically accurate? Has BGMEA engaged USTR on this?):**
___

---

### J-H3 · Cambodia Dual-Market Threat (EBA + S301)
**Applies to:** COMBO-012

> "⚠️ Cambodia faces simultaneous threats: EU EBA graduation/risk (primary market) AND US Section 301 tariff investigation (secondary market) — this dual-market access risk makes KH the highest-risk country in Air8's portfolio for 2026-2029; any EXPAND signal for COMBO-012 should be reviewed against this dual-threat context" (source: Event F, freshness: quarterly)

> IF us_s301_tariff_on_KH_confirmed AND factory_has_us_buyers → COMPLIANCE_BLOCK on US-bound shipments; dual EBA+S301 threat = exit US buyer exposure immediately ⚠️ PENDING REVIEW

**Expert review (Jerri: how many current KH clients have US buyers? Are any at risk?):** [ ]

**Notes:**
___

---

### J-H4 · Indonesia GSP + S301 Compounding
**Applies to:** COMBO-007

> "⚠️ Indonesia's GSP (Generalized System of Preferences) with US was under review before IEEPA; Section 301 investigation adds a new tariff mechanism on top of existing GSP uncertainty — Indonesian garment exporters face potential loss of ALL US market preferential access simultaneously" (source: Event F, freshness: quarterly)

> "⚠️ IDR (Indonesian rupiah) is sensitive to US trade policy uncertainty — if S301 tariffs materially reduce Indonesian exports, IDR may depreciate 5-10% vs USD; for a factory earning USD from exports but paying IDR wages, the net effect is mixed (USD revenue drops from lower orders, but IDR cost competitiveness improves slightly)" (source: Event F, freshness: quarterly)

**New dimension:**
> - dim: us_market_exposure | why: COMBO-007 has US + EU buyer mix; S301 tariff on Indonesia directly affects US-bound orders | r1_question: "What % of your revenue comes from US buyers? Which US buyers?" | signal_impact: US revenue >40% AND S301 tariff confirmed → CAUTION; reduce advance on US-bound; EU-bound remains clean ⚠️ PENDING REVIEW

**Expert review (Josephine: is Indonesia's GSP currently suspended or under review? Is 5-10% IDR depreciation estimate reasonable?):** [ ]

**Notes:**
___

---

### J-H5 · VN Parent Company Relocation Risk
**Applies to:** COMBO-006

> "⚠️ VN FDI factory parent company (Korean/Taiwanese) may respond to rising labor costs by shifting production investment to lower-cost countries (Indonesia, India) rather than absorbing locally — this creates an Air8 client attrition risk that is invisible until the parent announces the shift" (source: Event A, freshness: annual)

> "⚠️ Korean/Taiwanese FDI parent companies have demonstrated ability to rapidly shift production countries when tariff risk materializes (e.g., China → VN shift 2018-2020); if S301 tariffs on VN are implemented, parent company may relocate orders to ID or IN within 6-12 months — Air8 VN facility could become stranded; advance ratio should be reduced immediately upon S301 tariff confirmation" (source: Events D+F, freshness: quarterly)

**New dimension:**
> - dim: parent_relocation_risk | why: If VN labor costs are rising 15%/year, parent company may shift capex to other countries | r1_question: "Is your parent company investing in new production capacity in Vietnam, or are they exploring other countries?" | signal_impact: Parent actively investing in VN → EXPAND. Parent evaluating relocation → CAUTION; reduce advance ratio trajectory ⚠️ PENDING REVIEW

**Expert review:** [ ]

**Notes:**
___

---

## 🟡 MEDIUM PRIORITY (Alice — Apparel/India/BD)

### A-M1 · BD Factory Closure Paradox (Event A)
**Applies to:** COMBO-002

> "⚠️ When competing BD factories close, surviving Air8-financed factories face a paradox: they gain new buyer PO inflow (market share uplift) while simultaneously losing access to peer sub-contracting capacity — net effect on WC is non-linear and context-dependent" (source: Event A, freshness: annual)

> "⚠️ Bangladesh garment labor force is not a captive pool — workers migrate to other sectors (construction, informal) during political instability; labor shortage can persist even as factories close, because the type of workers available (stitching operators vs finishing specialists) mismatches the surviving factories' needs" (source: Event A, freshness: annual)

> "⚠️ Air8 advance ratio must be reviewed if Air8 client factory shows: (a) PO volume declining >15% QoQ, (b) buyer concentration rising (fewer buyers, more dependence), (c) workforce headcount dropping YoY — these are early distress signals that predate formal default" (source: Event A, freshness: stable)

**New dimension:**
> - dim: factory_closure_exposure | why: When BD industry contracts, Air8 must distinguish: (a) client factory gaining share from closures = EXPAND, vs (b) client factory itself showing closure risk = CAUTION/exit | r1_question: "How is your factory doing vs your peers — are you gaining new buyers or losing orders?" | signal_impact: Gaining share → WC need urgent (EXPAND). Own orders declining → CAUTION; reduce advance ratio ⚠️ PENDING REVIEW

**Expert review (Alice: is 15% annual labor cost the right BD figure? Confirm labor flight phenomenon vs wage pressure):** [ ]

**Notes:**
___

---

### A-M2 · BD Yarn India Origin = UFLPA Compliance Advantage
**Applies to:** COMBO-002

> "⚠️ BD yarn sourcing from India (~60% of yarn inputs) does NOT create UFLPA risk — Indian cotton is not subject to UFLPA Xinjiang rebuttable presumption; a BD factory documenting its yarn as 'Indian origin' may actually have a compliance ADVANTAGE vs BD factories using Chinese yarn — Air8 should flag this positively in BD client assessment" (source: Event D, freshness: annual)

**Expert review (Alice: is this correct? Does Air8 currently communicate this to BD clients?):** [ ]

**Notes:**
___

---

### A-M3 · India-UK FTA: M&S Sourcing Post-FTA
**Applies to:** COMBO-003

> "⚠️ Marks & Spencer (M&S) UK sources ~15-20% of its garments from India; post-FTA, M&S sourcing of India could increase to 25-30%+ as duty removal closes cost gap with Bangladesh; Air8-financed Indian verticals with M&S programs should anticipate order acceleration — and corresponding WC needs — within 12 months of ratification" (source: Event C, freshness: annual)

**Expert review (Alice: please verify or adjust the M&S India sourcing % figure; is 15-20% current % accurate?):** [ ]

**Notes:**
___

---

### A-M4 · India-UK FTA: Rules of Origin Clause
**Applies to:** COMBO-003

> "⚠️ The India-UK FTA is specifically expected to include a 'rules of origin' clause requiring substantial transformation in India — factories that source fabric from Bangladesh or China and process in India may NOT benefit from FTA duty reduction; only factories with domestic Indian fabric sourcing (vertically integrated) fully capture the FTA upside" (source: Event C, freshness: stable)

**Expert review (Alice: what is your understanding of the substantial transformation requirement for India-UK FTA?):** [ ]

**Notes:**
___

---

### A-M5 · UK DCTS vs India Duty Disadvantage
**Applies to:** COMBO-003, COMBO-014

> "⚠️ UK operates its own DCTS (Developing Countries Trading Scheme) post-Brexit — Bangladesh and Cambodia retain 0% duty on garments in UK; India's 8-12% duty disadvantage vs BD specifically in UK market suppresses M&S and ASOS sourcing from India; FTA ratification = structural shift in UK-India sourcing economics" (source: Event C, freshness: annual)

> "⚠️ India-UK FTA (in negotiation 2026): if enacted, removes India's 8-12% duty disadvantage in UK market. UK imports ~$20bn apparel annually; India currently holds only 6% share. FTA completion = India EXPANDS into UK market at scale, creating a new buyer market signal. Air8 should monitor FTA progress and prepare S2 UK-buyer outreach for IN Vertical and IN Small Woven combos." (source: Event C, freshness: annual)

**New dimension (COMBO-003):**
> - dim: uk_buyer_revenue_pct | why: UK most directly impacted by India-UK FTA; existing UK buyers = immediate duty saving | r1_question: "What % of your revenue is from UK-headquartered buyers (M&S, Next, ASOS, Tesco F&F, Primark UK)?" | signal_impact: UK buyers >20% revenue → FTA ratification = immediate margin uplift; EXPAND strengthens. No UK buyers → BD outreach opportunity ⚠️ PENDING REVIEW

**Signal flip additions (COMBO-014):**
> IF india_uk_fta_ratified AND has_uk_buyers → signal flips from NEUTRAL to EXPAND ⚠️ PENDING REVIEW
> IF india_uk_fta_ratified AND no_uk_buyers → BD opportunity trigger ⚠️ PENDING REVIEW

**Expert review (Alice: does Air8 currently track UK vs EU revenue separately for IN clients?):** [ ]

**Notes:**
___

---

### A-M6 · India S301 Unprecedented Impact
**Applies to:** COMBO-014

> "⚠️ Section 301 tariffs on India would be unprecedented (India has not faced S301 tariffs since the 2019 GSP revocation for different reasons); if implemented, the 15-25% additional tariff on Indian woven cotton garments would significantly erode India's cost competitiveness in US market — exactly at the moment when India was expected to gain share from China+1 and the India-UK FTA momentum" (source: Event F, freshness: quarterly)

> "⚠️ Small Indian woven FOB exporters (COMBO-014) have less political clout than large verticals (COMBO-003) to navigate US trade negotiations; COMBO-014 factories may be the first to lose US buyer orders if tariff uncertainty grows — US buyers will consolidate with fewer, larger suppliers in a high-tariff environment" (source: Event F, freshness: annual)

> IF us_s301_tariff_on_IN_confirmed → CAUTION on US-bound order expansion; consolidation risk = small FOB exporters lose orders to larger verticals first ⚠️ PENDING REVIEW

**Expert review (Alice: is India historically non-S301 accurate? Does Air8 currently have an IN COMBO-014 client protocol for US buyer concentration?):** [ ]

**Notes:**
___

---

### A-M7 · UK Organic Fashion Market (Event C)
**Applies to:** COMBO-008

> "⚠️ UK sustainable/organic fashion market (est. £2.5bn, growing 15-20% annually) is structurally different from EU: UK consumers pay premium for GOTS/FAIRTRADE certifications AND have high willingness to pay for farmer-story brands (People Tree, Patagonia UK) — India organic knit with direct farmer narrative is uniquely positioned for UK post-FTA" (source: Event C, freshness: annual)

**Expert review:** [ ]

**Notes:**
___

---

## 🟡 MEDIUM PRIORITY (Jerri — Compliance + Turkey)

### J-M1 · CSDDD Omnibus Buyer Cascade Critical Nuance
**Applies to:** COMBO-002, COMBO-004, COMBO-005, COMBO-012 (already added to all four)

> "⚠️ CSDDD compliance is demanded from suppliers by EU buyers BEFORE the regulation formally applies to the supplier — large EU retailers (H&M, Zara, Primark) are already requiring supplier due diligence data as contract condition for 2027+ programmes. This means CSDDD compliance pressure arrives 2-3 years before the 2029 formal deadline. BD/CN/TR/KH factories with EU buyer revenue >30% face de facto 2026-2027 compliance requirements through buyer contracts, not just 2029 law." (source: Event B, freshness: annual)

**Expert review (Jerri: is this consistent with your buyer conversations? Are H&M/Zara still pushing compliance timelines despite regulatory delay?):** [ ]

**Notes:**
___

---

### J-M2 · CSDDD Scope + False Relief Window
**Applies to:** COMBO-002

> "⚠️ CSDDD Omnibus scope reduction (>5,000 employees, >€1.5bn) exempts all BD CMT factories from DIRECT legal obligation — but EU buyers who remain in scope (H&M, Primark/ABF, Lidl) will continue to cascade supply chain due diligence requirements via their own supplier codes of conduct, independent of what the CSDDD regulation formally requires of factories" (source: Event B, freshness: annual)

> "⚠️ The CSDDD 2029 extension creates a 'false relief' window — BD factories that pause CSDDD preparation now will face compressed timelines in 2027-2028 when implementation guidance firms up; factories that maintain compliance investment through the window will have a 24-month head start when buyers re-activate supplier questionnaires" (source: Event B, freshness: annual)

> "⚠️ CSDDD consultation deadline 24 July 2026 is the window for industry to submit commentary on implementation guidelines — any BD-specific concerns (traceability at yarn mill level, audit fatigue from overlapping buyer codes) should be surfaced via BGMEA or buyer industry associations now, not in 2028" (source: Event B, freshness: quarterly)

> IF buyer_is_csddd_in_scope (H&M, Zara, Primark parent) AND factory has no supply chain traceability documentation → signal = COMPLIANCE risk regardless of CSDDD scope narrowing ⚠️ PENDING REVIEW

**Expert review (Jerri: please verify both threshold criteria for key EU buyers; are any EU mid-market buyers such as C&A or Primark above both >5,000 AND >€1.5bn thresholds?):** [ ]

**Notes:**
___

---

### J-M3 · CSDDD Turkey-Specific Nuances
**Applies to:** COMBO-005

> "⚠️ Zara/Inditex and H&M both exceed the CSDDD Omnibus threshold (>5,000 employees AND >€1.5bn turnover) and remain DIRECTLY in scope under the amended timeline — their compliance demands on Turkish denim suppliers will not relax; the CSDDD amendment cuts bureaucratic burden for mid-market buyers, not Tier-1 fast fashion" (source: Event B, freshness: annual)

> "⚠️ The CSDDD timeline extension to 2029 reduces NEAR-TERM urgency for Air8's ESG-Finance pitch to Turkey clients — factories that were considering CSDDD-readiness investment for 2027 may defer to 2028-2029; Air8 must reframe the pitch around ESPR (2027) and voluntary buyer requirements rather than CSDDD deadline urgency" (source: Event B, freshness: annual)

**Expert review (Jerri: is this consistent with your buyer conversations? Are Zara/H&M still requiring supplier compliance data regardless of regulatory delay?):** [ ]

**Notes:**
___

---

### J-M4 · CSDDD KH Cascade Readiness
**Applies to:** COMBO-012

**New dimension:**
> - dim: buyer_csddd_cascade_readiness | why: KH factories' EU buyers (H&M, Primark) remain in CSDDD scope even post-amendment; their supplier requirements will flow to KH regardless of KH factory's own regulatory threshold | r1_question: "Have any EU buyers recently sent you supply chain questionnaires about your subcontractors, chemical use, or labor practices beyond standard BSCI/Sedex audits?" | signal_impact: Buyer-mandated CSDDD questionnaire received → CSDDD compliance pathway active; ESG-Finance pitch relevant. No buyer requests yet → monitor ⚠️ PENDING REVIEW

**Expert review (Jerri: how many current KH clients have received buyer CSDDD questionnaires?):** [ ]

**Notes:**
___

---

### J-M5 · Turkey EU Exports Contraction Nuances (Event E)
**Applies to:** COMBO-005

> "⚠️ Volume-led contraction (-17.83% volume) with stable unit price (+1.49%) is a bifurcated market signal: Istanbul premium denim factories (Zara/H&M direct, laser/ozone finishing) likely retained volume better (price premium still valued); Interior Turkey basic denim (no finishing moat) likely experienced the full brunt of the contraction or worse — always segment by factory tier before reading macro Turkey statistics" (source: Event E, freshness: annual)

> "⚠️ EU apparel market contraction affects Turkey, but also Bangladesh (-3% in EU) and other Asian origins simultaneously — this is a EU consumer demand signal, not just a Turkey-specific share loss; Air8 should apply macro demand caution across ALL EU-facing combos (COMBO-002, COMBO-005, COMBO-012) not just COMBO-005" (source: Event E, freshness: quarterly)

> "⚠️ A TR factory experiencing -17% revenue decline while simultaneously facing TRY bank credit lines being cut = acute cash crisis probability; Air8 ARP EUR-denominated facility may be the ONLY liquidity source available to the factory; this creates both opportunity (desperate demand for Air8) and risk (advance quality deteriorates if buyers also slow down)" (source: Event E, freshness: quarterly)

> "⚠️ Turkey EU apparel volume contracted -17.83% in Jan-Apr 2026 (value -16.60%) — unit price rose +1.49%, confirming volume-led contraction not price competition. This structural demand reduction likely reflects EU buyer consolidation away from Turkey during TRY instability period. Air8 should NOT expand COMBO-005 facilities during a volume contraction phase — CAUTION until EU demand recovers 2+ consecutive months." (source: Event E, freshness: quarterly)

**New dimension:**
> - dim: revenue_qoq_trend | why: Existing Air8 TR clients need proactive advance ratio review when revenue declines sharply within-year; annual YoY trigger is too slow for -17% in 4 months | r1_question: "What is your production volume in Q1 2026 compared to Q1 2025? Are buyers placing fewer orders or smaller orders?" | signal_impact: Revenue decline >15% in any single quarter → immediate advance ratio review; reduce 85% to 70%; 2 consecutive quarters → alert level ⚠️ PENDING REVIEW

**Signal flips:**
> IF eu_apparel_market_contracting AND factory_revenue_declining_qoq → reduce advance ratio immediately ⚠️ PENDING REVIEW
> IF eu_demand_contraction_confirmed AND factory_is_interior_turkey → flip to DO_NOT_EXPAND ⚠️ PENDING REVIEW

**Expert review (Jerri: do you have client data that confirms Istanbul premium factories held up better during contraction? Should advance ratio trigger be 15% quarterly decline or different threshold?):** [ ]

**Notes:**
___

---

### J-M6 · VN Nike/Adidas Compliance Programs vs UFLPA
**Applies to:** COMBO-006

> "⚠️ Nike and Adidas maintain their own supply chain compliance programs (VF Supplier Compliance Standards, FLA accreditation) — these create a compliance documentation layer that reduces but does NOT eliminate UFLPA detention risk; UFLPA presumption is rebuttable but requires factory-level documentation of cotton origin, not just brand compliance certification" (source: Event D, freshness: annual)

> "⚠️ Section 301 country-level tariff on Vietnam (if imposed) would apply to ALL Vietnamese exports to US regardless of individual factory compliance — a VN FDI factory with perfect labor practices would still pay the tariff; the parent company's decision to maintain or shift VN production would then depend on tariff-adjusted cost competitiveness vs alternative countries" (source: Event D, freshness: quarterly)

**Expert review (Jerri: are Air8's VN clients currently using Nike/Adidas brand compliance certs as their UFLPA defense? What documentation is actually required at CBP?):** [ ]

**Notes:**
___

---

### J-M7 · VN Annual Wage Adjustment Schedule
**Applies to:** COMBO-006

> "⚠️ Vietnam government implements annual minimum wage adjustments (typically Jan 1 effective) — FDI factories in Zone 1 (HCMC, Hanoi metro) face the highest minimum wage tier; 2025-2026 trajectory suggests continued 8-12% annual wage increases even without labor shortages" (source: Event A, freshness: annual)

**Expert review:** [ ]

**Notes:**
___

---

## 📊 New Event Expansions by Combo — Summary

| Combo | Events Applied | Nuances Added | Dims Added | Signal Flips Added |
|---|---|---|---|---|
| COMBO-002 | A, B, D, F + Crit.1 + Crit.2 | 13 | 1 (factory_closure_exposure) | 3 |
| COMBO-003 | C | 4 | 1 (uk_buyer_revenue_pct) | 0 |
| COMBO-004 | Crit.2 only | 1 | 0 | 0 |
| COMBO-005 | B, E + Crit.2 | 7 | 1 (revenue_qoq_trend) | 2 |
| COMBO-006 | A, D, F + Crit.1 | 7 | 1 (parent_relocation_risk) | 2 |
| COMBO-007 | F | 2 | 1 (us_market_exposure) | 1 |
| COMBO-008 | C | 1 | 0 | 0 |
| COMBO-012 | B, D, F + Crit.1 + Crit.2 | 3 | 2 (buyer_csddd_cascade_readiness, us_uflpa_compliance_status) | 1 |
| COMBO-014 | C, F | 3 | 0 | 3 |

**Total items added across all combo files: ~43 nuances/dims/flips**

---

## Previously Pending (from original KB build)

The following items were already in `pending-expert-review.md` before today's expansion. They remain PENDING and are not duplicated here. Review them alongside new items above.

### Alice Wong (previously pending)
- COMBO-002: buyer-nominated ~90% validation (HIGH)
- COMBO-002: India yarn dependency edge weight=0.85 (HIGH)
- COMBO-002: ~60% India yarn sourcing % (HIGH)
- COMBO-003: domestic vs imported blend 50/50 default (HIGH)
- COMBO-003: signal_flip organic lines logic (HIGH)
- COMBO-005: Istanbul vs Interior Turkey client split (HIGH)
- All 26 L0 principles review (HIGH)
- COMBO-001, 004, 008 assessment dimensions (MEDIUM)

### Josephine Cheung (previously pending)
- Hardgoods COMBO nodes — MISSING (HIGH)
- Hardgoods event type routing (HIGH)
- WIP categories completeness (HIGH)
- Buyer event L0 principles (MEDIUM)
- Hardgoods geo-SWOT accuracy (MEDIUM)

### Jerri Zhou (previously pending)
- Signal flip conditions — all combos (HIGH)
- Active Event Cache TTL defaults (HIGH)
- Risk principles concentration caps (HIGH)
- Product eligibility thresholds (HIGH)
- COMBO-010, 013 assessment dims (MEDIUM)
- S4 portfolio monitoring thresholds (MEDIUM)

### Both Alice + Jerri (previously pending)
- S2 3-round qualifying questions for all 15 combos (HIGH)
- S3 question ordering principle (MEDIUM)

---

## GAP: COMBO-004 (China Woven) — Partial

China (CN) is named in Events D (forced labor) and F (S301 tariff replacement). COMBO-004 was NOT fully evaluated in the 6-event validation pass. Only Critical Nuance 2 (CSDDD cascade) was added. Recommend a separate review pass for COMBO-004 against Events D and F given China is the primary S301 and UFLPA target.

---

*End of Consolidated Expert Review File*
*Generated: 2026-07-01 by Snowman | Air8 KB v2*
*Send review markups to: Jerri Zhou (primary coordinator) → Snowman for KB commit*
