# Node Schema — 4 Types

> Version: 2.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> All KB nodes must conform to one of the 4 schemas below.

---

## Schema A: Persona Instance Node (4-Field Structure)

The canonical persona node uses exactly 4 fields. Cut everything else.

```markdown
# COMBO-XXX: [Name]

## Identity
- archetype: [CMT-LowMargin | FullPackage-MidMargin | Vertical-HighMargin]
- country: [BD | CN | TR | IN | VN | PK | ID | KH | multi]
- revenue_band: [micro <$5M | small $5-20M | mid $20-50M | large $50M+]
- product_type: [knit | woven | denim | home_textile | hardgoods | organic_knit]
- company_type: [CMT | FOB | Vertical | Trader | FDI]
- buyer_geo: [EU | US | APAC | mixed]
- cash_cycle_days: [e.g. 90-120]
- tags: [country:BD, material:cotton, company_type:CMT, ...]

## Structural Nuances
*(What LLM would miss — 5–10 bullets max. Each one a durable structural truth.)*
*(Tier 2 only: "true for 1-3 years, LLM might get wrong or miss")*
*(Do NOT store numbers here unless they are internal-only Air8 data)*
- "..."
- "..."

## Buyer Edges
- sells_to: [buyer_type: GlobalFastFashion, weight: 0.85]
- sells_to: [buyer_type: USMassMarket, weight: 0.60]
- concentration_pattern: "..."
- typical_payment_terms: OA X days

## Assessment Dimensions
*(Stable variables that always matter for this combo — LLM generates event-specific questions from these at runtime)*
*(Many-to-many format: one dim can be answered by multiple questions; one question can answer multiple dims)*
*(Note: Question IDs (Q-BUYER-NOM-01 etc.) are for cross-referencing only at this stage — full question library to be formalized in Phase 2.)*

# Assessment Dimensions — Many-to-Many Format
# One dim can be answered by multiple questions; one question can answer multiple dims
- dim: buyer_nominated_pct
  why: "determines if raw material events benefit the factory"
  answered_by_questions: [Q-BUYER-NOM-01, Q-SOURCING-DEEP-01]
  primary_question: Q-BUYER-NOM-01
  r1_question: "What % of your fabric/yarn is buyer-nominated vs own-sourced?"
  r2_deep: "Which specific buyers dictate fabric source, and do any allow substitution?"
  collect: "Procurement orders showing nominated vs own-sourced split (last 12 months)"
  signal_impact: "If >80% nominated → flip raw material event from BENEFIT to NEUTRAL"

# Further dims follow same pattern:
- dim: [name]
  why: "[reason it matters]"
  answered_by_questions: [Q-ID-01]
  primary_question: Q-ID-01
  r1_question: "[Round 1 qualifying question]"
  r2_deep: "[Round 2 deep-dive question]"
  collect: "[Evidence to collect]"
  signal_impact: "[How this dim affects the signal]"

## Signal Flip Conditions
*(Pre-authored edge cases where the signal completely reverses from default)*
- IF [condition] → signal flips from [X] to [Y] because [reason]

## Pain Hooks
- [PP-001-cashflow-gap] primary
- [PP-BD-003-ldc-graduation] high
- [...]

## Air8 Products
- primary: [PROD-ARP]
- secondary: [PROD-MINIARP]
- condition: "[when/why to use which]"

## LLM Directives
*(Instructions to LLM at runtime — NOT stored facts. Tell LLM what to retrieve and calculate.)*
- sourcing_dependency: "Quantify [country] [material] sourcing origin breakdown (% by country). Cite year and source."
- competitive_context: "After this event, how does [country] compare to peer origins on [material] cost per unit?"
- [...]
```

### What to CUT from persona nodes:
- Owner demographics (age, gender, education)
- Daily tools (WhatsApp, ERP specifics)
- Location details (specific city/district names)
- Mindset quotes ("Keep the lines running")
- Full buyer fit tables with emoji
- Port stats and specific shipping logistics
- Scenario narratives (extract to assessment_dimensions instead)
- Specific supplier company names
- Numbers that LLM can retrieve (percentages, prices, rates)

---

## Schema B: Product Node

```markdown
# PROD-[ID]: [Full Name]

## What It Solves
- solves: [PP-001, PP-005]

## Risk Reduction Narrative
- self_liquidating: true/false
- chain: "[raw material → production → receivable]"
- typical_days: [120-180]
- risk_label: "[low/medium/high]_air8_risk"
- key_caveat: "..."

## Eligibility
- revenue_min: $XM
- buyer_PO_anchor: required/optional
- tenor_band: [30-180d]
- other: [...]

## BD Talking Points
- PP-001: "..."
- PP-005: "..."

## Best Fit Combos
- [COMBO-003, COMBO-008] — primary
- [COMBO-001, COMBO-002] — secondary
```

---

## Schema C: L0 Principle Node

```markdown
## [RP-MODULE-NN]: [Principle Name]
**When applies:** [condition — event_type, material, country, combo_type]
**Must consider:**
- [dimension 1 — include the nuance, not just the headline]
- [dimension 2]
- [second-order effect — the thing people forget]
**LLM directive template:** "[Specific prompt to LLM — what to retrieve, calculate, compare, cite]"
**Freshness:** stable / annual / quarterly
```

---

## Schema D: Pain Point Node

```markdown
# PP-[ID]: [Name]

## Description
[1-2 sentences: what the pain is and why it exists structurally]

## Trigger Conditions
- [when this pain is active]

## Intensity Factors
- [what makes it worse]

## Quantification
`formula: ...`

## Air8 Products That Solve This
- [PROD-ARP] — primary
- [PROD-MINIARP] — secondary

## Affected Combos
- [COMBO-001, COMBO-002, ...]
```

---

## Common Fields (All Nodes)

Every node should include at minimum:
- `id`: unique identifier
- `tags`: controlled vocabulary (see tag_dictionary.md)
- `freshness`: stable | annual | quarterly | daily
- `last_updated`: YYYY-MM-DD
- `source`: expert | llm_generated | derived

---

## Edge Weight Semantics

### Weight semantics for `sells_to` edges:
```
weight = "typical upper-bound revenue share for this archetype's exposure to this buyer segment"
Example: COMBO-002 sells_to EUDiscountRetail weight:0.85 means
  'up to 85% of this combo's revenue typically comes from EU discount retail buyers'
```

### Weight semantics for `sources_from` edges:
```
weight = "estimated dependency level — % of this material typically sourced from this origin"
Example: COMBO-002 sources_from country:IN weight:0.85 means
  '~85% of this combo's cotton/yarn input is typically sourced from India'
```

### Weight semantics for `product_combo` edges:
```
weight = "fit score — how strongly this product addresses this combo's primary pain at this stage"
Example: PROD-ARP product_combo COMBO-002 weight:0.95 means
  'ARP is a near-perfect fit for this combo; addresses primary pain directly'
  0.90+ = primary fit, strong recommendation
  0.70-0.89 = good fit, secondary recommendation
  0.50-0.69 = moderate fit, conditional recommendation
  <0.50 = weak fit, tertiary or future consideration
```

---

## Archetype Extension Syntax (A8)

Combo instances that extend an archetype should declare their extension relationship using one of two formats:

### Standard Full Extension (all fields inherited)
```yaml
extends: Vertical-HighMargin
inherited_confidence: 1.0
```

### Partial Extension (overrides specific fields)
Use when the combo diverges from the archetype on specific dimensions:
```yaml
extends: Vertical-HighMargin
inherited_confidence: 0.75
overrides:
  - path: identity.revenue_band
    new_value: "mid ($20-50M)"
  - path: identity.worker_count
    new_value: "300-1200"
```

**Example (COMBO-008 India Organic):**
```yaml
extends: Vertical-HighMargin
inherited_confidence: 0.85
overrides:
  - path: identity.revenue_band
    new_value: "mid $10-30M"
  - path: identity.cash_cycle_days
    new_value: "120-180 days (shorter than large Vertical)"
  - path: behavioral_profile.financing_sophistication
    new_value: "basic"
```

**Rules:**
- `inherited_confidence: 1.0` = full extension; all archetype structural nuances apply without modification
- `inherited_confidence: <1.0` = partial extension; specified overrides apply; remaining fields inherited
- Any override must specify both `path` and `new_value`
- Overridden fields must be noted in the combo's `## Identity` section as well

---

## Cut Rules (Applied Ruthlessly)

**Keep if:** Fails the cascade without it. LLM would get it wrong. Internal Air8 data.
**Cut if:** LLM can retrieve from public data. Changes more than quarterly. Is narrative/story. Is a specific number LLM can find. Is a mindset quote. Is owner biography.

**The test:** Would removing this nuance cause a materially wrong insight in the S1 card or S2 BD conversation? If no → cut.
