# Content Guidelines — What to Keep, What to Cut

> Version: 2.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01
> These rules are applied ruthlessly to every node in air8-kb-v2/.

---

## The Master Rule

**Store it only if the cascade produces a materially wrong or shallow insight without it.**

If LLM can retrieve it reliably → write an LLM directive, not the fact.
If it changes more than quarterly → it's Tier 3 (fact) or Tier 4 (live) — do not store.
If it's a story or mindset quote → cut entirely.
If it's a number → almost always cut (write directive instead).

---

## The 4-Tier Framework

| Tier | What It Is | Lives In | Written By |
|---|---|---|---|
| **T1 Frame** | "What to think about" — stable reasoning dimensions | L0 principles | Expert |
| **T2 Structural** | "What LLM would miss" — 1-3 year truths | `structural_nuances` field | Expert |
| **T3 Fact (public)** | Volatile number, LLM retrieves at runtime | LLM directive | Auto-generated |
| **T3 Fact (internal)** | Air8-only data (limits, caps, rates) | L2 node with freshness tag | Jerri/risk team |
| **T4 Live** | Real-time signal | API / LLM runtime | Never stored |

---

## Cut Rules by Content Type

### ALWAYS CUT:
- Owner demographics (age, gender, education level)
- Specific tool names used by factory (WhatsApp, ERP brand, SAP)
- City/district location details unless essential to a structural nuance
- Mindset quotes ("Keep the lines running", "We are denim craftsmen")
- Full buyer fit tables with emoji ratings
- Port statistics and shipping logistics specifics
- Scenario narratives in full (extract the decision rule, cut the story)
- Specific company names (bank names, supplier names, buyer names unless essential for compliance)
- Numbers that LLM can retrieve: percentages, current prices, interest rates, exchange rates
- Historical case studies (move to `_archive/`)

### ALWAYS KEEP:
- Structural constraints that change slowly (buyer-nominated fabric % for CMT)
- Second-order effects LLM would skip (MSP price floor, over-stockpiling risk post-cliff)
- Internal Air8 operational rules (advance ratios, KYC requirements, entity caps)
- Signal flip conditions (when default signal reverses)
- Cascading impact logic (what happens downstream when X occurs)
- Assessment dimensions (what variables always matter for this combo)

### KEEP IF IT FAILS THE TEST:
- Anything where removing it causes the cascade to produce the wrong signal
- Anything where removing it causes BD to miss a critical conversation point
- Anything where removing it causes a compliance gap to be missed
4. Keep if: this number is a critical input variable to a reasoning primitive AND the client segment is stable enough to make it reliable for 6-12 months.
   - Tag with: freshness_required: annual (not quarterly)
   - Examples of numbers to KEEP: dependency % (input to RP-DEPENDENCY), buyer share % (input to RP-CONCENTRATION), passthrough ratio (input to RP-PASSTHROUGH), cash cycle days (input to RP-WINDOW)
   - Examples of numbers to CONVERT to LLM directive: specific bank rates, specific commodity prices, specific tariff percentages (these are tier 3/4 volatile facts)
   - Rule: if removing this number would make a primitive unable to produce a meaningful output → keep it

---

## Persona Node Specific Rules

**The 4-Field Rule**: Persona nodes have exactly 4 fields:
1. `Identity` — the who (archetype, country, revenue, product, company type, buyer geo, cash cycle)
2. `Structural Nuances` — what LLM would miss (5-10 bullets max)
3. `Buyer Edges` — sells_to weights + concentration pattern
4. `Assessment Dimensions` — stable variables that generate runtime questions

**Plus supporting fields**: Signal Flip Conditions, Pain Hooks, Air8 Products, LLM Directives.

**Structural Nuances must be:**
- Written as statements of durable fact, not stories
- Free of specific numbers (LLM retrieves those)
- Triggered by a structural mechanism, not an anecdote
- Actionable: removing them would cause a wrong or shallow insight

**Good structural nuance examples:**
- "BD CMT factories receive buyer-nominated fabric ~90% of the time — cheaper raw cotton does NOT directly reduce their input cost"
- "MSP price floor means domestic cotton in India cannot fall below government support price even when global prices drop"
- "PSF self-liquidates: cotton → production → buyer receivable, typically within 120-180 days"

**Bad structural nuance examples** (cut these):
- "Owner checks bank balance on phone 2-3 times per day" → cut (mindset/tool detail)
- "BD cotton = 80% from India" → cut (number LLM retrieves)
- "Factory has 300-800 workers" → cut (company size detail)

---

## L0 Principle Rules

- Principles are reasoning frames, not facts
- Each principle triggers on a condition and specifies what dimensions to consider
- The LLM directive template must be specific enough to surface nuance
- Do NOT write principles that just say "check the market" — specify what to calculate
- 30-40 total across all modules is the target
- Freshness = stable unless there's a specific reason otherwise

---

## Product Node Rules

- Risk Reduction Narrative is the most important field — fills the "why is Air8 risk low" gap
- BD Talking Points are per-pain — must be ready-to-use language, not descriptions
- Eligibility is internal data — always store, never redact
- Do not store current pricing/rates — write LLM directive for market rate comparison

---

## Hardgoods Module Rules (Josephine's Domain)

- Different from apparel: QC gate pass/fail is a financing eligibility signal
- WIP approval milestones are stored as facts (internal process rules)
- Defect classification is stored (expert-authored, stable)
- Country/category SWOTs are stored as structural nuances
- Specific chemical compliance requirements are stored (REACH, PROP65, EN71 — stable regulations)

---

## When to Stop — Sufficiency Criteria

### Structural Nuances per Combo
- Minimum: 5 nuances (below this = underspecified)
- Target: 8-12 nuances
- Maximum: 15 nuances (above this = should split into archetype + instance override)
- Stop when: adding another nuance would be retrievable by LLM from public data

### Assessment Dimensions per Combo
- Minimum: 3 dimensions
- Target: 4-6 dimensions
- Maximum: 8 dimensions (above this = too granular for S2 qualifying questions)
- Stop when: dimension would only activate for <5% of events affecting this combo

### L0 Principles per Module
- Target: 6-10 per module
- Maximum: 15 per module (above this = principles are too narrow, merge into meta-principles)
- Stop when: new principle only adds coverage for 1 specific sub-event-type

### Signal Flip Conditions per Combo
- Minimum: 2 conditions
- Target: 3-5 conditions
- Maximum: 8 conditions (above this = combo may need splitting into sub-combos)
- Stop when: flip condition is already covered by a higher-tier condition in signal-decision-rules.md
