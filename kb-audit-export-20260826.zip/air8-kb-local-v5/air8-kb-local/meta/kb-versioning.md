# KB Versioning & Migration Strategy

> Version: 1.0 | Owner: Jerri Zhou + Snowman | Created: 2026-07-01

---

## Version Numbering
- Format: vMAJOR.MINOR.PATCH
- MAJOR: breaking schema change (new field required in all nodes, signal vocabulary change)
- MINOR: new nodes added, new principles, new country files
- PATCH: content corrections, nuance updates, number refreshes

**Current version: v2.1.0**

---

## When to Bump Version
- Signal vocabulary additions → MAJOR (all test cases and downstream consumers need update)
- New combo added → MINOR
- Structural nuance correction → PATCH
- Number refresh (annual) → PATCH

---

## Migration Rules
- When old signal (e.g., CONDITIONAL) becomes new signal (e.g., EXPAND AND_IF):
  1. Keep old signal in a `_deprecated/` note for 1 wave cycle
  2. Update all test cases to new format
  3. Update active_events.json cache entries
  4. Notify data team of schema change before DB ingestion
- Never delete a signal primitive without a migration path

---

## Rollback Protocol
- All changes tracked in git (air8-kb-v2 folder should be git-initialized)
- Tag each wave completion: `git tag wave-1-complete`
- Rollback: `git checkout wave-1-complete -- _meta/ _scenarios/`
- Data team: DB schema changes are additive only in first year (no destructive migrations)

---

## Historical Case Backfill
- When signal vocabulary changes, historical cases in `_tests/sample_triggers.jsonl` must be updated
- Use dry_run.py to verify no broken routing after major version bump
- Expert re-validation required for any case where signal type changed (not just wording)

---

## Wave Change Log

| Version | Date | Change | Type |
|---|---|---|---|
| v2.0.0 | 2026-07-01 | Initial v2 KB with 4-field persona schema | MAJOR |
| v2.1.0 | 2026-07-01 | Signal vocabulary expanded: HEDGE_REQUIRED split into EXPAND_WITH_HEDGE + WATCH_HEDGE_GAP; MONITOR/RESTRUCTURE mapped to primitives; 4th criterion added to content guidelines; KB versioning + health metrics added | MINOR |
