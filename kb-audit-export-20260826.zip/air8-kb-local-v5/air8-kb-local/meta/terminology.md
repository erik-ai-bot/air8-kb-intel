# Air8 KB v2 — Canonical Terminology
> Owner: Jerri Zhou | Version: 2026-07-15
> ALWAYS check this file before writing new KB content.
> If a term isn't here, add it here first, then use it.

---

## Canonical Terms (Use ONLY these)

| Canonical Term | Definition | Banned Synonyms |
|---|---|---|
| **Persona** | A supplier archetype node in the KB. Identified by COMBO-xxx prefix. | ~~combo~~, ~~archetype~~, ~~profile~~, ~~factory type~~ |
| **Assessment Dimension** | A stable variable that determines the magnitude of a signal for a given Persona. Used in S3. | ~~qualifying question~~, ~~key variable~~, ~~evaluation criteria~~ |
| **Structural Nuance** | A durable truth about a Persona that an LLM would miss without KB knowledge. Max 5–10 bullets per Persona. | ~~structural note~~, ~~nuance~~, ~~context~~ |
| **LLM Directive** | A runtime instruction for the LLM to perform a web lookup or computation. Executed at Step 5. | ~~web lookup~~, ~~runtime check~~, ~~live query~~, ~~dynamic lookup~~ |
| **Principle** | A named L0 reasoning rule (prefix: RP-EVT-*, RP-RISK-*, RP-PERSONA-*). Stored in L0-principles/. | ~~rule~~, ~~logic~~, ~~guideline~~, ~~heuristic~~ |
| **Primitive** | A first-principles reasoning construct (prefix: RP-DEPENDENCY, RP-CLIFF, etc.). Stored in _reasoning/primitives.md. Different from Principle — broader, not named to an event type. | ~~fallback rule~~, ~~base principle~~, ~~generic rule~~ |
| **Signal** | The output recommendation for a Persona × Event combination. One of: EXPAND · CONDITIONAL · CAUTION · NEUTRAL · DO_NOT_EXPAND | ~~recommendation~~, ~~call~~, ~~verdict~~, ~~Air8 signal~~, ~~output signal~~ |
| **Signal Flip** | When a Signal reverses from its default value due to a specific Condition being met. Defined in Persona's `Signal Flip Conditions` section. | ~~signal change~~, ~~override~~, ~~exception~~, ~~reversal~~ |
| **Event Card** | The output document produced by S1. Contains: WHY + SIGNAL + WHAT TO DO + QUALIFYING QUESTIONS + IF branches. | ~~S1 card~~, ~~event insight card~~, ~~output card~~, ~~insight card~~ |
| **Assessment** | The output document produced by S3 for a specific supplier. | ~~S3 card~~, ~~assessment card~~, ~~evaluation~~ |
| **Active Event Cache** | Runtime state file listing events currently within their TTL window. Written by S1. Read by S2/S3/S5. | ~~event cache~~, ~~active events~~, ~~cache~~, ~~event registry~~ |
| **Claim Label** | Inline confidence tag applied to every factual claim in WHY/INSIGHT sections. One of: [VERIFIED] · [EXPERT] · [HYPOTHESIS] · [PENDING DATA] | ~~confidence label~~, ~~certainty tag~~, ~~source tag~~, ~~evidence tag~~ |
| **Pain Point** | A supplier problem that creates an Air8 BD opportunity. Stored in pain-points/. | ~~pain~~, ~~problem~~, ~~issue~~, ~~friction~~ |
| **Correlated Event Pair** | Two or more Events linked by RP-EVT-CORRELATED-PAIR because they share ≥2 overlapping tags and affect the same Personas. | ~~related events~~, ~~combined events~~, ~~linked events~~, ~~event cluster~~ |
| **Scenario** | A named reasoning flow (S0 through S5). Each has one .md file in _scenarios/. | ~~use case~~, ~~mode~~, ~~track~~, ~~workflow~~ |
| **Domain** | A subject-matter classification for Personas and events. Currently: apparel · hardgoods. | ~~category~~, ~~sector~~, ~~vertical~~, ~~industry~~ |
| **Buyer Edge** | A weighted relationship from a Persona to a Buyer Type. Defined in `Buyer Edges` section. | ~~buyer relationship~~, ~~buyer link~~, ~~client type~~ |
| **Archetype** | The base template a Persona extends. One of: CMT-LowMargin · FullPackage-MidMargin · Vertical-HighMargin. | ~~template~~, ~~base type~~, ~~persona type~~ |
| **Compound Bonus** | An intensity score modifier applied when multiple Pain Points or Events co-occur for a Persona. Defined in intensity-scoring-engine.md. | ~~stacking bonus~~, ~~compounding effect~~, ~~multiplier~~ |
| **Cliff Date** | A hard deadline after which an event's benefit window closes (e.g., a tariff exemption expiry). Triggers cliff-playbook.md. | ~~deadline~~, ~~expiry~~, ~~cutoff~~ |
| **Self-Liquidation Chain** | The sequence by which an Air8 disbursement is repaid without the supplier needing to refinance. Required in every Product recommendation. | ~~repayment chain~~, ~~repayment path~~, ~~liquidation path~~ |
| **Signal Derivation** | The structured block in an Event Card that traces how the Signal was produced (principles fired, flips applied). | ~~signal explanation~~, ~~reasoning trace~~, ~~derivation block~~ |
| **Pending Expert Review** | A tag applied to a Structural Nuance or claim that has not yet been validated by a named domain expert. Format: `PENDING EXPERT REVIEW: [Expert Name]`. | ~~to be reviewed~~, ~~unvalidated~~, ~~draft claim~~ |

---

## Claim Labels — Usage Rules

| Label | When to Use |
|---|---|
| [VERIFIED] | Sourced from published, named data (Eurostat, USTR, official trade body, buyer announcement). Must name source. |
| [EXPERT] | From a KB Structural Nuance that has been reviewed and approved by a named domain expert. |
| [HYPOTHESIS] | Logical inference from known Structural Nuances. Not directly sourced. Directionally correct but not proven. |
| [PENDING DATA] | Claim direction is plausible, but specific figure/fact not yet sourced. Do NOT cite as fact. Must be followed up. |

**Rule:** Every factual claim in WHY and INSIGHT sections of an Event Card must carry exactly one Claim Label. Cards without labels → G7 quality gate fails → not emitted.

---

## Signal Values — Definitions

| Signal | Definition |
|---|---|
| EXPAND | Clear positive signal. Increase Air8 exposure; new facility or limit increase recommended. |
| CONDITIONAL | Positive signal but depends on one or more unconfirmed Assessment Dimensions. Expand only after verification. |
| CAUTION | Mixed or deteriorating signal. Maintain current exposure; do not increase; monitor closely. |
| NEUTRAL | Event does not meaningfully affect this Persona. No Air8 action. |
| DO_NOT_EXPAND | Negative signal. Hold or reduce exposure. Do not increase facility under any condition. |

---

## Relationship Types (for Correlated Event Pairs)

| Type | Definition |
|---|---|
| AMPLIFYING | Both events push the Signal in the same direction for the same Persona. Urgency and magnitude increase. |
| REFRAMES | New event changes the correct interpretation of the cached event. The cached event's Signal must be revised. |
| OFFSETS | Events partially cancel each other for a specific Persona. Net Signal is muted. |
| INDEPENDENT | Overlap in tags but different mechanisms and Personas. Emit separately. |

---

## File Naming Conventions

| File Type | Convention | Example |
|---|---|---|
| Persona instance | COMBO-[NNN]-[country]-[product].md | COMBO-005-turkey-denim.md |
| Hardgoods persona | COMBO-HG-[NNN]-[country]-[product].md | COMBO-HG-001-china-outdoor-furniture.md |
| Pain point | PP-[COUNTRY]-[NNN]-[slug].md | PP-BD-001-wage-hike.md |
| Product | PROD-[NAME].md | PROD-ARP.md |
| Country | [ISO2].md | TR.md |
| Scenario flow | S[N]-[slug].md | S1-event-insights.md |
| Template | S[N]-[output-type].md | S1-event-card.md |
| Principle | Use RP- prefix in content; stored in event-principles.md, risk-principles.md, etc. | RP-EVT-DOUBLE-COMPRESS |

---

## Pending Standardization (Items Needing Update Across Files)

The following are known inconsistencies to fix in the next KB update pass:

| Current (inconsistent) | Target | Files Affected |
|---|---|---|
| "qualifying questions" | "Assessment Dimensions" | COMBO-002, COMBO-009 (older format) |
| "Air8 signal" in Persona headers | "Signal" | Multiple COMBO files |
| "dim:" shorthand | OK to keep as shorthand within Persona files | No change needed |
| "recommendation signal" | "Signal" | _meta/signal-decision-rules.md |
| "event cache" | "Active Event Cache" | _runtime/active_event_cache_schema.md header |
| "Correlated event" vs "CORRELATED-PAIR" | Use "Correlated Event Pair" as noun; RP-EVT-CORRELATED-PAIR as principle ID | _meta/correlated-event-combinations.md |
