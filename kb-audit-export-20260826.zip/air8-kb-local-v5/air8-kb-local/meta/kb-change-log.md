# KB Change Log

> Append-only. Every change via expert review must be logged here.
> Format: date | file | change_type | summary | expert | approver

---

## 2026-07-16

| File | Change Type | Summary | Expert | Approver |
|------|-------------|---------|--------|----------|
| `layer-1-reasoning/BRAIN-CHAIN.md` | NEW FILE | Master navigation guide — single authoritative chain mapping every Layer 1 file to its exact step in the reasoning pipeline. Replaces scattered README with explicit HOW chain. | — | Jerri Zhou |
| `layer-1-reasoning/README.md` | RESTRUCTURE | Updated to lead with BRAIN-CHAIN.md as first-read entry. File index now shows step numbers for every file. | — | Jerri Zhou |
| `layer-1-reasoning/REASONING-FLOW.md` | RESTRUCTURE | Redirects to BRAIN-CHAIN.md for navigation; retains weight formulas and scoring detail for depth reference. | — | Jerri Zhou |
| `meta/kb-health-metrics.md` | NEW FILE | Copied from V2 _meta/kb-health-metrics.md. Tracks 6 operational health metrics for monthly/quarterly review. | — | Jerri Zhou |
| `meta/kb-change-log.md` | NEW FILE | Copied from V2 _meta/kb-change-log.md. Append-only change log for expert review changes. | — | Jerri Zhou |
| `meta/neo4j-graph-design.md` | NEW FILE | Copied from V2 _meta/neo4j-graph-design.md. Graph schema design for data team setup. | — | Jerri Zhou |
| `layer-1-reasoning/runtime/active_events.json` | NEW FILE | Copied from V2 _runtime/active_events.json. Runtime event cache for S1 cascade and S2/S3 consumption. | — | Jerri Zhou |
| `layer-1-reasoning/pain-points/` | COVERAGE EXPANSION | 30 files total — all V2 universal + country + esg + expansion pain-points covered. LOCAL adds 4 compliance-category pain-points (PP-REG-*) that V2 lacked. | — | Jerri Zhou |

---

## 2026-07-13

| File | Change Type | Summary | Expert | Approver |
|------|-------------|---------|--------|----------|
| `pain-points/country/PP-BD-003-ldc-graduation.md` | VIEW SHIFT | BD govt posture updated from "passive / unclear" to "active — cleared major milestone Nov 2025 (first in Asia)". Risk downgraded from existential → HIGH-watch. | Web search (triggered by Jerri review) | Jerri Zhou |
| `pain-points/country/PP-BD-003-ldc-graduation.md` | STRUCTURE FIX | Hardcoded figures (tariff rate, convention count) removed; replaced with web_lookup directives. KB now stores angles/logic/views only. | — | Jerri Zhou |
| `personas/instances/COMBO-002-bd-cmt.md` | STRUCTURE FIX | LDC graduation nuance now references PP-BD-003 directives, not hardcoded text. Wage hike nuance reframed as angle (factory absorbs full cost, no FOB offset mechanism) — live % figures moved to web_lookup. | — | Jerri Zhou |
| `_scenarios/S2-supplier-pain-bd.md` | SKILL INTEGRATION | Added `invoke: kb-expert-review` block at end of Quality Gates. S2 now calls expert review skill after each round output without duplicating routing/scoring logic. | — | Jerri Zhou |
| `_meta/expert-review-config.json` | NEW FILE | Expert routing config + threshold (default 90%). Change threshold here only — no skill edits needed. | — | Jerri Zhou |
| `_meta/web-lookup-directives.md` | NEW FILE | Master list of all web_lookup directives. PP-BD-003 (4 directives) and COMBO-002 (6 directives) populated. | — | Jerri Zhou |

## 2026-07-13 (batch 2)

| File | Change Type | Summary | Expert | Approver |
|------|-------------|---------|--------|----------|
| `pain-points/country/PP-IN-001-gst-refund.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: gst_refund_processing_days_current, gst_refund_backlog_status (2 directives). | — | Subagent |
| `pain-points/country/PP-IN-002-bank-od-cost.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: india_bank_od_rate_current, india_rbi_repo_rate_current, personal_guarantee_requirement_prevalence (3 directives). | — | Subagent |
| `pain-points/country/PP-IN-003-inr-depreciation.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: inr_usd_ytd_depreciation_pct, india_sme_fx_hedging_adoption_pct, inr_usd_forward_rate_90d (3 directives). | — | Subagent |
| `pain-points/country/PP-IDN-001-rupiah.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: idr_usd_ytd_depreciation_pct, bank_indonesia_benchmark_rate, idr_usd_bank_conversion_spread (3 directives). | — | Subagent |
| `pain-points/country/PP-TR-001-lira-inflation.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: turkey_cpi_annual_pct, try_eur_ytd_depreciation_pct, tcmb_policy_rate_current, turkey_bank_try_credit_rate_sme (4 directives). | — | Subagent |
| `pain-points/country/PP-TR-002-bank-contraction.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: turkey_sme_credit_growth_yoy, turkey_domestic_factoring_rate, turkey_domestic_factoring_settlement_days, bddk_sme_credit_regulation_update (4 directives). | — | Subagent |
| `pain-points/country/PP-VN-001-fdi-authority.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: vietnam_fdi_garment_factory_pct, vietnam_korean_taiwanese_factory_count (2 directives). | — | Subagent |
| `pain-points/country/PP-PK-001-energy-crisis.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: pakistan_industrial_electricity_rate_kwh, india_industrial_electricity_rate_kwh, bangladesh_industrial_electricity_rate_kwh, pakistan_loadshedding_hours_daily_current (4 directives). | — | Subagent |
| `pain-points/esg/PP-ESG-002-buyer-esg-escalating.md` | STRUCTURE CONVERSION | Converted to new PP standard structure. web_lookup: csddd_implementation_timeline, espr_textile_milestone_dates, higg_index_audit_cost_range, sedex_smeta_audit_cost_range, eu_buyer_esg_supplier_delist_rate (5 directives). | — | Subagent |
| `_scenarios/S1-event-insights.md` | ENHANCEMENT | Added Step S1-Xb (COMPUTE EVENT IMPACT INTENSITY) after Step 6, applying intensity-scoring-engine.md framework to event impact scoring. Added Expert Validation invoke block after Quality Gates, calling kb-expert-review skill. | — | Subagent |
