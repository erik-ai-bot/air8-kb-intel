# Live Skill Test — kb-management + kb-expert-review
**Date:** 2026-07-16 23:12 GMT+8
**Tester:** subagent (agent:main:subagent)
**Run:** First attempt (retry after timeout)

---

## 1. kb-management Skill

**SKILL.md location:** `~/.openclaw/workspace/skills/kb-management/SKILL.md`

### Triggers
"update KB", "add to knowledge base", "new data source", "KB ingest", "evolve KB", "audit KB", "fix KB tables", "add domain to KB"

### Main Actions / Flows
| Flow | Description |
|------|-------------|
| **INGEST FLOW** | New source file (xlsx/spec/PDF) → place in `raw/` → run ingest script → verify tables → identify domain coverage → write/update domain page → update ER map (KB.009) → update logical→physical mapping → update all indexes |
| **DOMAIN CREATION FLOW** | New domain → write domain page → update KB.009 + indexes |
| **EVOLUTION FLOW** | Update existing KB entry → propagate changes to all referencing pages |
| **AUDIT FLOW** (Step 8) | Full completeness check: xlsx sheets → generated files, domain coverage, join paths in KB.009, memory index sync, index/log currency |
| **TABLE FIX FLOW** (Step 9) | Manual extraction when ingest script fails (blank `as_of`, alternate sheet layouts) |

**Hard rules:** Raw sources immutable · Every table needs domain home · Every metric needs formula · Every cross-domain link needs join fields · KB.009 must stay current · Memory index must match wiki · Log every change

**Expected KB location:** `/tmp/knowledge_base/` (skill assumption)
**Current KB location:** `/Users/erikkwok/.openclaw/workspace/air8-kb-local/` (actual)

### Live Action Run — AUDIT FLOW

Ran adapted audit against actual KB at `air8-kb-local/`:

| Check | Result |
|-------|--------|
| Total `.md` files | **216 files** |
| Top-level structure | `Index.md`, `ARCHITECTURE.md`, `MASTER-FLOW.md`, `README.md`, `AIR8-KB-COMPLETE.md` |
| Sub-directories | `data-entities/` (11 files), `dimensions/` (8 root + 4 sub-dirs), `layer-1-reasoning/`, `layer-2-entities/`, `linkage/`, `meta/`, `scenarios/`, `templates/` |
| `layer-1-reasoning/` | `BRAIN-CHAIN.md`, `EVENT-CLUSTERS.md`, `EVENT-PRINCIPLES.md`, `EVENT-TYPES.md`, `PRINCIPLES.md`, `SOLUTIONS.md`, `PERSONA-SYNTHESIS.md`, `PERSONA-PRINCIPLES.md`, `PRIMITIVES.md`, `PRODUCT-PRINCIPLES.md`, `REASONING-FLOW.md`, `RISK-PRINCIPLES.md`, + `compliance/`, `pain-points/`, `playbooks/`, `runtime/` |
| Pain points | Universal (PP-001–PP-007), Country-specific (BD×3, CN×3, IN×3, TR×2, VN×1, IDN×1, PK×1), Compliance (UFLPA, REACH, CSDDD, TARIFF) |
| `meta/` | 21 files including `kb-change-log.md`, `web-lookup-directives.md`, `expert-review-consolidated.md`, `kb-health-metrics.md`, `skill-architecture.md` |
| `Index.md` | Present, v3.0, links to all major sections |

**⚠️ Notable gap vs. skill expectation:**
- The skill assumes KB at `/tmp/knowledge_base/` with `wiki/domains/` and `wiki/concepts/` structure (KB.001–KB.011 domain pages, KB.009 join map)
- The actual KB has a **two-layer architecture** (`layer-1-reasoning/` + `layer-2-entities/`) with a different folder naming convention
- The `kb-management` skill would need **adaptation** to work against this KB structure — specifically its AUDIT FLOW checks (KB.009 join paths, domain page structure, generated table references) are calibrated for the old schema

---

## 2. kb-expert-review Skill

**SKILL.md location:** `~/.openclaw/workspace/skills/kb-expert-review/SKILL.md`
**Status:** `proposal` (v1, 2026-07-13)

### What It Does
Automated confidence-gated expert validation pipeline for any Air8 KB-generated result — pain points, event insights, BD cards, risk assessments.

### Pipeline Steps
| Step | Action |
|------|--------|
| **1 — Classify claims** | DATA_FIGURE → skip scoring, route to web_lookup; LOGIC_ANGLE_VIEW → score; FORMULA → score source quality |
| **2 — Confidence score** | Weighted: Factual Accuracy 40% + Data Currency 40% + Source Quality 20% → 0–100 |
| **3 — Route** | score ≥ threshold → auto-approve; score < threshold → queue for expert |
| **4 — Telegram to expert** | Session opener + per-claim full-context blocks with KB source ref and flag reason |
| **5 — Handle response** | ✅ Confirm → mark validated; ❌ Concern → classify (DATA FIGURE → Step 6a, LOGIC → Step 6b), run web search, reply to expert |
| **6a — DATA FIGURE fix** | Replace hardcoded figure with `web_lookup` directive; add to `_meta/web-lookup-directives.md` |
| **6b — LOGIC/VIEW fix** | Assess: wrong logic → KB update; context changed (figure) → web_lookup only; context changed (structural) → KB update |
| **7 — Jerri sign-off** | Telegram message with OLD/NEW diff → ✅ Confirm / ✏️ Edit / ❌ Reject |
| **8 — Final summary** | Counts: auto-approved / expert-confirmed / web_lookup fixes / KB updates / skipped |

### Config (`_meta/expert-review-config.json`)
- Confidence threshold: **90** (adjustable without skill changes)
- Expert routing: Apparel/softgoods → Alice, Hardgoods → Josephine (Telegram: 8274330198), Finance/BD → Jerri (8711597868)
- Staging approver: Jerri

### KB Philosophy (enforced)
- KB stores: angles, logic, structural views, behavioral patterns
- KB does NOT store: live figures, rates, %, dates, counts, policy statuses → those go to `web_lookup`

### How to Invoke
```yaml
invoke: kb-expert-review
input:
  result_type: pain_point | event_insight | bd_card | risk_assessment
  archetype: [COMBO-id or scenario id]
  claims: [list of claims with KB source field refs and claim_type]
  threshold: [read from _meta/expert-review-config.json]
```

### Files Maintained
- `_meta/expert-review-config.json` — threshold + routing
- `_meta/kb-change-log.md` — append-only log of KB updates
- `_meta/pending-reviews.json` — queue of awaiting items
- `_meta/web-lookup-directives.md` — master list of web_lookup directives

**⚠️ Note:** This skill is a `proposal` (status: pending), not yet applied/installed.

---

## 3. Zip Integrity Check

```
unzip -l /Users/erikkwok/.openclaw/workspace/air8-kb-v20260716.zip | head -20
```

**Result:** ✅ Zip is intact and readable.

```
Archive:  /Users/erikkwok/.openclaw/workspace/air8-kb-v20260716.zip
Length      Date    Time    Name
---------  ---------- -----   ----
        0  07-16-2026 19:09   air8-kb-local/
        0  07-16-2026 21:57   air8-kb-local/layer-1-reasoning/
    44362  07-16-2026 20:09   air8-kb-local/layer-1-reasoning/PRINCIPLES.md
    15207  07-16-2026 12:13   air8-kb-local/layer-1-reasoning/SOLUTIONS.md
     5782  07-16-2026 19:07   air8-kb-local/layer-1-reasoning/PERSONA-SYNTHESIS.md
     7308  07-16-2026 19:07   air8-kb-local/layer-1-reasoning/PERSONA-PRINCIPLES.md
    46446  07-16-2026 22:53   air8-kb-local/layer-1-reasoning/REASONING-FLOW.md
    14183  07-16-2026 22:54   air8-kb-local/layer-1-reasoning/EVENT-CLUSTERS.md
        0  07-16-2026 19:25   air8-kb-local/layer-1-reasoning/runtime/
     7272  07-16-2026 20:18   air8-kb-local/layer-1-reasoning/runtime/active_event_cache_schema.md
     4495  07-16-2026 19:25   air8-kb-local/layer-1-reasoning/runtime/active_events.json
    28241  07-16-2026 22:53   air8-kb-local/layer-1-reasoning/BRAIN-CHAIN.md
        0  07-16-2026 19:08   air8-kb-local/layer-1-reasoning/playbooks/
     7630  07-16-2026 19:08   air8-kb-local/layer-1-reasoning/playbooks/cliff-playbook.md
     1920  07-16-2026 19:08   air8-kb-local/layer-1-reasoning/playbooks/china-operations.md
    27362  07-16-2026 20:52   air8-kb-local/layer-1-reasoning/EVENT-PRINCIPLES.md
        0  07-16-2026 12:13   air8-kb-local/layer-1-reasoning/compliance/
    [... truncated ...]
```

Zip created 07-16-2026, last file 22:53 (BRAIN-CHAIN.md), consistent with live session activity.

---

## 4. Summary & Recommendations

| Item | Status | Notes |
|------|--------|-------|
| `kb-management` SKILL.md | ✅ Read OK | Well-documented, 5 flows, hard rules clear |
| `kb-management` AUDIT FLOW live | ✅ Ran (adapted) | 216 .md files found; Index.md v3.0 present |
| `kb-management` vs actual KB | ⚠️ Gap noted | Skill expects `/tmp/knowledge_base/` + `wiki/domains/` + KB.001–KB.011 schema; actual KB is `air8-kb-local/` with two-layer architecture |
| `kb-expert-review` SKILL.md | ✅ Read OK | 8-step pipeline, config-driven, Telegram routing |
| `kb-expert-review` status | ⚠️ `proposal` (pending) | Not yet applied/installed |
| Zip integrity | ✅ Intact | 216 files, dated 07-16-2026 |
| Output file written | ✅ | `/Users/erikkwok/.openclaw/workspace/air8-kb-local/meta/live-skill-test.md` |

### Recommendations
1. **Adapt `kb-management`** AUDIT FLOW to the actual two-layer KB schema (`layer-1-reasoning/`, `layer-2-entities/`, `data-entities/`, `dimensions/`) — the existing Step 8 checklist items (KB.009 join paths, domain page structure, generated tables) need translation to this structure
2. **Apply `kb-expert-review`** — it's a proposal status; needs `skill_workshop action=apply` to become operational
3. **Align KB location** in skill with actual location: either copy/mount actual KB to `/tmp/knowledge_base/` or update skill's KB location variable
