# KB Health Metrics

> Version: 1.0 | Owner: Jerri Zhou + Snowman | Created: 2026-07-01

---

## Purpose
Track KB operational health after POC enters production. Review monthly.

---

## 6 Core Metrics

### M1 — Combo Hit Rate
Definition: % of real client triggers that match a known combo instance (score ≥ 0.7) vs require synthesis
Target: >80% direct match (synthesis = fallback, not default)
How to measure: log combo_match_score per S1/S2/S3 run; count ≥0.7 vs <0.7
Red flag: <60% direct match → new combos need to be added

### M2 — Primitive Dependency Rate
Definition: % of S1 output signals that required reasoning primitives (vs purely L0 principles)
Target: <20% primitive-only (most events should match L0 principles)
How to measure: log whether S1 Step 4 activated L0 only, primitives only, or both
Red flag: >40% primitive-only → L0 principles are too narrow for actual event variety

### M3 — Expert Verification Pass Rate
Definition: % of ⚠️ AI-inferred items that pass expert review without modification
Target: >70% pass rate (if <70%, structural nuances are too speculative)
How to measure: track _review/pending-expert-review.md status updates
Red flag: <50% pass rate → KB quality is poor; increase expert involvement earlier

### M4 — Dead Node Rate
Definition: % of combo nodes that have never been activated in real cascade runs (after 3 months operational)
Target: <20% dead nodes
How to measure: log which COMBO-ids are activated per run; flag those with 0 activations after 90 days
Red flag: >30% dead nodes → over-engineered; prune or merge underused combos

### M5 — Signal Flip Rate
Definition: % of S3 individual assessments where specific supplier signal differs from generic combo signal
Target: 30-60% flip rate (if too low → assessment adds no value; if too high → combo signals are wrong)
How to measure: log generic vs specific signal per S3 run; count deltas
Red flag: <15% flip rate → S3 is redundant; >70% flip rate → combo baselines need recalibration

### M6 — LLM Directive Cache Hit Rate (future)
Definition: % of LLM directive retrievals that return consistent results on re-run (proxy for fact stability)
Target: >85% consistency on re-run within 24h
How to measure: spot-check 10% of directive outputs daily
Red flag: <70% → directives are too broad; facts are too volatile to cache

---

## Review Cadence
- Monthly: M1, M2, M3
- Quarterly: M4, M5, M6 + archetype evolution review
- Annual: full KB structural audit + signal vocabulary review
