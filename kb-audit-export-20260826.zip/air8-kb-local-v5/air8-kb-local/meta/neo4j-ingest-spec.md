# Air8 KB — Neo4j Ingest Spec
> Owner: Jerri Zhou | Version: 2026-07-17
> **给 data 同事看的操作手册。** 照这份做，不要自己猜。
> 读之前先看 ARCHITECTURE.md 了解整体结构。

---

## 0. 黄金法则（先读）

| Neo4j 放什么 | 文件保留什么 |
|---|---|
| 节点 ID、名称、标签、枚举值 | 长文字（原则、指令、分析说明） |
| 节点之间的关系（边） | LLM 推理指令 |
| Tag 节点（country/material/buyer_geo 等） | 模板、场景描述 |
| 运行时产生的 Signal / CachedEvent | 所有 layer-1-reasoning/ 内容 |

**一句话：Neo4j = 路由器。文件 = 内容。不要把文件内容搬进 Neo4j。**

---

## 1. 文件 → Neo4j 映射总表

| 源文件夹 | 进 Neo4j？ | Node Label | 备注 |
|---|---|---|---|
| `layer-2-entities/personas/COMBO-*.md` | ✅ | `Persona` | 主体节点，每文件一个节点 |
| `layer-2-entities/personas/hardgoods/COMBO-HG-*.md` | ✅ | `Persona` | domain="hardgoods" |
| `layer-2-entities/regulations/REG-*.md` | ✅ | `Regulation` | 每文件一个节点 |
| `layer-2-entities/financing-products/PROD-*.md` | ✅ | `Product` | 每文件一个节点 |
| `layer-2-entities/product-categories/APPAREL.md` | ✅ | `ProductCategory` | 一个节点 id="apparel" |
| `layer-2-entities/product-categories/HARDGOODS.md` | ✅ | `ProductCategory` | 一个节点 id="hardgoods" |
| `dimensions/` | ✅ | `Tag` | Enum 值，见第 3 节 |
| `linkage/linkage-persona-full.md` | ✅ (提取边) | — | 边来源，见第 5 节 |
| `linkage/cross-module-edges.md` | ✅ (提取边) | — | 边来源 |
| `layer-1-reasoning/` | ❌ | — | 全部留在文件，打包进 agent |
| `scenarios/` | ❌ | — | 留在文件 |
| `templates/` | ❌ | — | 留在文件 |
| `meta/` | ❌ | — | 留在文件 |
| `data-entities/ENTITY-*.md` | ❌ | — | Schema 定义文档，留在文件 |

---

## 2. Persona 节点

### 2.1 从哪些文件提取
```
layer-2-entities/personas/COMBO-001-*.md  → COMBO-015-*.md
layer-2-entities/personas/hardgoods/COMBO-HG-001-*.md  → COMBO-HG-004-*.md
layer-2-entities/personas/archetypes/CMT-LowMargin.md（可选，低优先）
```

### 2.2 提取字段（frontmatter + 正文）

| Neo4j Property | 从哪取 | 例子 |
|---|---|---|
| `id` | frontmatter `id:` | `COMBO-001` |
| `name` | 正文 H1 标题 | `"South Asian Small Knit Manufacturer"` |
| `domain` | frontmatter 或 path | `"apparel"` / `"hardgoods"` |
| `country_code` | Dimensions → Country | `"BD"` / `"IN,PK,KH"` (多国用逗号) |
| `revenue_band` | Dimensions → Revenue | `"$5-20M"` |
| `company_type` | Dimensions → Type | `"FOB"` / `"CMT"` / `"Vertical"` |
| `product_type` | Dimensions → Product | `"knit"` / `"denim"` / `"home_textile"` |
| `target_market` | Dimensions → Market | `"US+EU"` |
| `current_financing` | Dimensions → Financing | `"bank_LC"` |
| `growth_stage` | Dimensions → Growth | `"expanding"` |
| `buyer_profile` | Dimensions → Buyer | `"fast_fashion,mass_market"` |
| `cash_cycle_days_min` | Structural Nuances 段落，找数字 | `120` |
| `cash_cycle_days_max` | Structural Nuances 段落，找数字 | `150` |
| `file` | 相对路径 | `"layer-2-entities/personas/COMBO-001-south-asian-small-knit.md"` |

### 2.3 不要放进 Neo4j 的字段
- `Structural Nuances` 段落（长文字，留文件）
- `LLM Directives`（留文件）
- `Assessment Dimensions`（留文件）
- `Signal Flip Conditions`（留文件）

### 2.4 Cypher 建节点示例
```cypher
MERGE (p:Persona {id: "COMBO-001"})
SET p.name = "South Asian Small Knit Manufacturer",
    p.domain = "apparel",
    p.country_code = "BD,IN,PK,KH",
    p.revenue_band = "$5-20M",
    p.company_type = "FOB",
    p.product_type = "knit",
    p.target_market = "US+EU",
    p.current_financing = "bank_LC",
    p.growth_stage = "expanding",
    p.buyer_profile = "fast_fashion,mass_market",
    p.cash_cycle_days_min = 120,
    p.cash_cycle_days_max = 150,
    p.file = "layer-2-entities/personas/COMBO-001-south-asian-small-knit.md"
```

---

## 3. Tag 节点

Tag 是 Persona / Event / Principle 之间的桥接节点。所有 Tag 必须先建好，再建边。

### 3.1 Tag 全量清单（必须完整建）

```cypher
// ── Country Tags ──────────────────────────────────────────────────
MERGE (:Tag {scope:"country", value:"BD", label:"Bangladesh"})
MERGE (:Tag {scope:"country", value:"CN", label:"China"})
MERGE (:Tag {scope:"country", value:"TR", label:"Turkey"})
MERGE (:Tag {scope:"country", value:"IN", label:"India"})
MERGE (:Tag {scope:"country", value:"VN", label:"Vietnam"})
MERGE (:Tag {scope:"country", value:"PK", label:"Pakistan"})
MERGE (:Tag {scope:"country", value:"ID", label:"Indonesia"})
MERGE (:Tag {scope:"country", value:"KH", label:"Cambodia"})
MERGE (:Tag {scope:"country", value:"multi", label:"Multi-country"})

// ── Material Tags ─────────────────────────────────────────────────
MERGE (:Tag {scope:"material", value:"cotton"})
MERGE (:Tag {scope:"material", value:"denim"})
MERGE (:Tag {scope:"material", value:"knit"})
MERGE (:Tag {scope:"material", value:"woven"})
MERGE (:Tag {scope:"material", value:"synthetic_blend"})
MERGE (:Tag {scope:"material", value:"home_textile"})
MERGE (:Tag {scope:"material", value:"organic_cotton"})
MERGE (:Tag {scope:"material", value:"brass"})
MERGE (:Tag {scope:"material", value:"copper"})
MERGE (:Tag {scope:"material", value:"zamak"})
MERGE (:Tag {scope:"material", value:"aluminum"})
MERGE (:Tag {scope:"material", value:"steel"})
MERGE (:Tag {scope:"material", value:"LED"})
MERGE (:Tag {scope:"material", value:"hardgoods"})

// ── Buyer Geo Tags ────────────────────────────────────────────────
MERGE (:Tag {scope:"buyer_geo", value:"EU"})
MERGE (:Tag {scope:"buyer_geo", value:"US"})
MERGE (:Tag {scope:"buyer_geo", value:"APAC"})
MERGE (:Tag {scope:"buyer_geo", value:"ME"})
MERGE (:Tag {scope:"buyer_geo", value:"AU"})
MERGE (:Tag {scope:"buyer_geo", value:"mixed"})

// ── Company Type Tags ─────────────────────────────────────────────
MERGE (:Tag {scope:"company_type", value:"CMT"})
MERGE (:Tag {scope:"company_type", value:"FOB"})
MERGE (:Tag {scope:"company_type", value:"Vertical"})
MERGE (:Tag {scope:"company_type", value:"Trader"})
MERGE (:Tag {scope:"company_type", value:"FDI"})

// ── Domain Tags ───────────────────────────────────────────────────
MERGE (:Tag {scope:"domain", value:"apparel"})
MERGE (:Tag {scope:"domain", value:"hardgoods"})

// ── Signal Tags ───────────────────────────────────────────────────
MERGE (:Tag {scope:"signal", value:"EXPAND"})
MERGE (:Tag {scope:"signal", value:"CONDITIONAL"})
MERGE (:Tag {scope:"signal", value:"CAUTION"})
MERGE (:Tag {scope:"signal", value:"NEUTRAL"})
MERGE (:Tag {scope:"signal", value:"DO_NOT_EXPAND"})

// ── Event Type Tags ───────────────────────────────────────────────
MERGE (:Tag {scope:"event_type", value:"financial"})
MERGE (:Tag {scope:"event_type", value:"regulation"})
MERGE (:Tag {scope:"event_type", value:"commodity"})
MERGE (:Tag {scope:"event_type", value:"geopolitical"})
MERGE (:Tag {scope:"event_type", value:"buyer"})
MERGE (:Tag {scope:"event_type", value:"supply_chain"})

// ── Event Subtype Tags ────────────────────────────────────────────
MERGE (:Tag {scope:"event_subtype", value:"demand_shift"})
MERGE (:Tag {scope:"event_subtype", value:"import_export_duty"})
MERGE (:Tag {scope:"event_subtype", value:"environmental_compliance"})
MERGE (:Tag {scope:"event_subtype", value:"fx_rate"})
MERGE (:Tag {scope:"event_subtype", value:"buyer_credit_event"})
MERGE (:Tag {scope:"event_subtype", value:"sourcing_strategy_shift"})
MERGE (:Tag {scope:"event_subtype", value:"political_instability"})
MERGE (:Tag {scope:"event_subtype", value:"raw_material_shortage"})
MERGE (:Tag {scope:"event_subtype", value:"market_entry_exit"})
MERGE (:Tag {scope:"event_subtype", value:"logistics_disruption"})
MERGE (:Tag {scope:"event_subtype", value:"supplier_consolidation"})
MERGE (:Tag {scope:"event_subtype", value:"product_trend_change"})
```

---

## 4. Regulation 节点

### 4.1 从哪些文件提取
```
layer-2-entities/regulations/REG-UFLPA.md
layer-2-entities/regulations/REG-CSDDD.md
layer-2-entities/regulations/REG-REACH.md
layer-2-entities/regulations/REG-GPSR.md
layer-2-entities/regulations/REG-S211.md
layer-2-entities/regulations/REG-NYFASHION.md
layer-2-entities/regulations/REG-TARIFF.md
```

### 4.2 提取字段

| Neo4j Property | 从哪取 | 例子 |
|---|---|---|
| `id` | frontmatter `id:` | `"REG-UFLPA"` |
| `name` | 正文 H1 | `"Uyghur Forced Labor Prevention Act"` |
| `jurisdiction` | 正文 **Jurisdiction:** | `"United States"` |
| `effective_date` | 正文 **Effective:** | `"2022-06-21"` |
| `domain` | 判断：apparel/hardgoods/both | `"apparel"` |
| `file` | 相对路径 | `"layer-2-entities/regulations/REG-UFLPA.md"` |

### 4.3 Cypher 示例
```cypher
MERGE (r:Regulation {id: "REG-UFLPA"})
SET r.name = "Uyghur Forced Labor Prevention Act",
    r.jurisdiction = "United States",
    r.effective_date = "2022-06-21",
    r.domain = "apparel",
    r.file = "layer-2-entities/regulations/REG-UFLPA.md"
```

### 4.4 不要放进 Neo4j 的内容
- Trigger Conditions 段落（文字描述，留文件）
- Required Documents 表格（留文件）
- Enforcement Data 数字（留文件，动态更新）

---

## 5. Product 节点

### 5.1 从哪些文件提取
```
layer-2-entities/financing-products/PROD-ARP.md
layer-2-entities/financing-products/PROD-MINIARP.md
layer-2-entities/financing-products/PROD-OBF.md
layer-2-entities/financing-products/PROD-POOL.md
layer-2-entities/financing-products/PROD-PAYGUARD.md
layer-2-entities/financing-products/PROD-SMARTWALLET.md
layer-2-entities/financing-products/PROD-PRESHIP-OBF.md
layer-2-entities/financing-products/PROD-PRESHIP-RT2C.md
```

### 5.2 提取字段

| Neo4j Property | 从哪取 | 例子 |
|---|---|---|
| `id` | frontmatter `id:` | `"PROD-ARP"` |
| `name` | 正文 H1 | `"Accounts Receivable Purchase"` |
| `stage` | 判断：pre-shipment / post-shipment | `"post-shipment"` |
| `requires_buyer_anchor` | Eligibility 段落 | `true` |
| `requires_confirmed_po` | Eligibility 段落 | `true` |
| `tenor_max_days` | 正文找 tenor | `180` |
| `file` | 相对路径 | `"layer-2-entities/financing-products/PROD-ARP.md"` |

### 5.3 Cypher 示例
```cypher
MERGE (prod:Product {id: "PROD-ARP"})
SET prod.name = "Accounts Receivable Purchase",
    prod.stage = "post-shipment",
    prod.requires_buyer_anchor = true,
    prod.requires_confirmed_po = true,
    prod.tenor_max_days = 180,
    prod.file = "layer-2-entities/financing-products/PROD-ARP.md"
```

---

## 6. 边（Relationships）

**⚠️ 建边前，所有节点必须先建完。**

### 6.1 Persona → Tag（TAGGED_WITH）
从每个 COMBO 文件的 Dimensions 段落提取，对应 Tag 值：

```cypher
// COMBO-001 示例：
MATCH (p:Persona {id:"COMBO-001"})

// country tags（多国的每个都建一条边）
MATCH (t1:Tag {scope:"country", value:"BD"}) MERGE (p)-[:TAGGED_WITH]->(t1)
MATCH (t2:Tag {scope:"country", value:"IN"}) MERGE (p)-[:TAGGED_WITH]->(t2)
MATCH (t3:Tag {scope:"country", value:"PK"}) MERGE (p)-[:TAGGED_WITH]->(t3)
MATCH (t4:Tag {scope:"country", value:"KH"}) MERGE (p)-[:TAGGED_WITH]->(t4)

// material tag
MATCH (tm:Tag {scope:"material", value:"knit"}) MERGE (p)-[:TAGGED_WITH]->(tm)

// buyer_geo tags
MATCH (tg1:Tag {scope:"buyer_geo", value:"US"}) MERGE (p)-[:TAGGED_WITH]->(tg1)
MATCH (tg2:Tag {scope:"buyer_geo", value:"EU"}) MERGE (p)-[:TAGGED_WITH]->(tg2)

// company_type tag
MATCH (tc:Tag {scope:"company_type", value:"FOB"}) MERGE (p)-[:TAGGED_WITH]->(tc)

// domain tag
MATCH (td:Tag {scope:"domain", value:"apparel"}) MERGE (p)-[:TAGGED_WITH]->(td)
```

### 6.2 Persona → Regulation（EXPOSED_TO）
来源：`linkage/linkage-persona-full.md` Compliance 列

```cypher
// COMBO-001: UFLPA, REACH, CSDDD
MATCH (p:Persona {id:"COMBO-001"}), (r:Regulation {id:"REG-UFLPA"})
MERGE (p)-[:EXPOSED_TO {context:"cotton→US market"}]->(r)

MATCH (p:Persona {id:"COMBO-001"}), (r:Regulation {id:"REG-REACH"})
MERGE (p)-[:EXPOSED_TO {context:"EU market"}]->(r)

MATCH (p:Persona {id:"COMBO-001"}), (r:Regulation {id:"REG-CSDDD"})
MERGE (p)-[:EXPOSED_TO {context:"EU buyers"}]->(r)
```

### 6.3 Persona → Product（RECOMMENDS）
来源：`linkage/linkage-persona-full.md` Products 列

```cypher
// COMBO-001: ARP, RT2C, PayGuard
MATCH (p:Persona {id:"COMBO-001"}), (prod:Product {id:"PROD-ARP"})
MERGE (p)-[:RECOMMENDS {rank:"primary", weight:0.90}]->(prod)

MATCH (p:Persona {id:"COMBO-001"}), (prod:Product {id:"PROD-PRESHIP-RT2C"})
MERGE (p)-[:RECOMMENDS {rank:"secondary", weight:0.70}]->(prod)

MATCH (p:Persona {id:"COMBO-001"}), (prod:Product {id:"PROD-PAYGUARD"})
MERGE (p)-[:RECOMMENDS {rank:"secondary", weight:0.65}]->(prod)
```

### 6.4 完整 Persona → Linkage 对照表
（直接从 `linkage/linkage-persona-full.md` 提取）

| Persona | EXPOSED_TO (Regulation) | RECOMMENDS (Product) |
|---|---|---|
| COMBO-001 | UFLPA, REACH, CSDDD | ARP, RT2C, PayGuard |
| COMBO-002 | UFLPA(if US), REACH(if EU) | ARP, RT2C, PayGuard |
| COMBO-003 | UFLPA(advantage), CSDDD, REACH | ARP, OBF, Pool, SmartWallet |
| COMBO-004 | UFLPA(high), REACH, CSDDD | ARP, SmartWallet, Pool |
| COMBO-005 | REACH, CSDDD | ARP, Pool |
| COMBO-006 | UFLPA(if cotton), CSDDD | ARP, PayGuard |
| COMBO-007 | UFLPA(if cotton), REACH, GPSR | MiniARP→ARP |
| COMBO-008 | UFLPA(advantage), CSDDD, REACH | ARP, RT2C, SmartWallet |
| COMBO-009 | UFLPA(cotton), REACH | ARP, Pool |
| COMBO-010 | Depends on expansion market | Case-by-case |
| COMBO-011 | OPS-KYC-002 | Back-to-Back TCS |
| COMBO-012 | EBA risk, CSDDD | ARP, MiniARP |
| COMBO-013 | ALL regs × ALL countries | ARP, Pool, SmartWallet |
| COMBO-014 | UFLPA(if cotton→US), REACH(if EU) | ARP, RT2C |
| COMBO-015 | Basic compliance only | MiniARP |
| COMBO-HG-001 | GPSR, REACH(hardgoods) | ARP |
| COMBO-HG-002 | REACH(metals), GPSR | ARP |
| COMBO-HG-003 | REACH(metals), GPSR | ARP |
| COMBO-HG-004 | REACH(electrical), GPSR | ARP |

---

## 7. 建库顺序（必须按此顺序）

```
Step 1  建所有 Tag 节点        （第 3 节 Cypher 全部跑）
Step 2  建所有 Regulation 节点 （第 4 节）
Step 3  建所有 Product 节点    （第 5 节）
Step 4  建所有 Persona 节点    （第 2 节）
Step 5  建 Persona→Tag 边      （第 6.1 节）
Step 6  建 Persona→Regulation 边（第 6.2 节）
Step 7  建 Persona→Product 边  （第 6.3 节）
Step 8  验证（第 8 节）
```

---

## 8. 验证查询（建完必须跑）

```cypher
// 8.1 检查节点总数是否合理
MATCH (p:Persona) RETURN count(p) AS persona_count
// 期望: 19（15 apparel + 4 hardgoods）

MATCH (r:Regulation) RETURN count(r) AS reg_count
// 期望: 7

MATCH (prod:Product) RETURN count(prod) AS product_count
// 期望: 8+

MATCH (t:Tag) RETURN count(t) AS tag_count
// 期望: 50+

// 8.2 检查 COMBO-005 能否正确查到（Turkey Denim）
MATCH (p:Persona {id:"COMBO-005"})-[:TAGGED_WITH]->(t:Tag)
RETURN p.name, collect(t.scope+":"+t.value) AS tags
// 期望: tags 包含 country:TR, material:denim, buyer_geo:EU

// 8.3 检查 Persona → Regulation 边是否存在
MATCH (p:Persona {id:"COMBO-001"})-[:EXPOSED_TO]->(r:Regulation)
RETURN p.id, collect(r.id) AS regulations
// 期望: [REG-UFLPA, REG-REACH, REG-CSDDD]

// 8.4 检查 Persona → Product 边是否存在
MATCH (p:Persona {id:"COMBO-001"})-[:RECOMMENDS]->(prod:Product)
RETURN p.id, collect(prod.id) AS products
// 期望: [PROD-ARP, PROD-PRESHIP-RT2C, PROD-PAYGUARD]

// 8.5 Event routing 核心测试（最重要）
MATCH (p:Persona)-[:TAGGED_WITH]->(t:Tag)
WHERE t.value IN ["TR", "denim", "EU"]
RETURN p.id, count(t) AS tag_overlap
ORDER BY tag_overlap DESC
// 期望: COMBO-005 排第一，overlap=3
```

---

## 9. 常见错误 & 注意事项

| 错误 | 正确做法 |
|---|---|
| 把 Structural Nuances 长文字放进 property | ❌ 只放 file 路径，运行时 agent 自己读文件 |
| 建边前没建节点 | ❌ 必须先跑 Step 1-4，再跑 Step 5-7 |
| Tag value 大小写不一致（"bd" vs "BD"） | ✅ 全部用大写国家代码，其他小写 |
| 多国 Persona 只建一条边 | ❌ 每个国家单独一条 TAGGED_WITH 边 |
| 把 NEO4J 作为唯一数据源 | ❌ 文件依然需要保留，agent 会读文件拿长文字内容 |

---

## 10. 不在 Phase 1 范围内的节点（留 Phase 2）

以下节点设计已在 neo4j-graph-design.md 定义，但 Phase 1 不需要建：

- `(:EventType)` — 运行时动态输入，Phase 2 加
- `(:Scenario)` — 直接用 scenario/ 文件，Phase 2 再建节点
- `(:Principle)` — 推理指令，留文件，Phase 2 考虑
- `(:CachedEvent)` — 运行时写入，Phase 2 加
- `(:Signal)` — 运行时产生，Phase 2 加
- `(:Country)` — 已用 Tag {scope:"country"} 覆盖，Phase 2 可升级为独立节点

Phase 1 只需建好 **Persona + Regulation + Product + Tag + 三类边**，就能支撑完整的 Persona matching 和 BD card 生成。
