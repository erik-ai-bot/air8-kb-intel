# Scenario Routing — Module Relevance Matrix

> Version: 2.0 | Owner: Jerri Zhou + Snowman | Updated: 2026-07-01

---

## File Linkage
> This file is read by: S1 (Step 2), S5 (Step 1)
> Scenario files: _scenarios/S1-event-insights.md, S3-individual-assessment.md, S5-event-impact-assessment.md
> Master rules: air8-kb-v2-LLM-SKILL.md CHANGELOG section

## Module Relevance by Scenario

| Module | S1 Event→Insights | S2 Pain→BD Advice | S3 Individual Assessment | S4 Portfolio Monitoring |
|---|---|---|---|---|
| `personas/` | HIGH — always | HIGH — always | HIGH — always | HIGH — always |
| `products/` | HIGH — always | HIGH — always | HIGH — always | MED |
| `L0-principles/` | HIGH — always | MED | HIGH — always | MED |
| `_reasoning/primitives.md` | HIGH — always (fallback) | LOW | HIGH — always (fallback) | LOW |
| `pain-points/` | MED | HIGH — always | HIGH | LOW |
| `regulations/` | HIGH if event_type:Regulation | MED | HIGH if compliance flagged | LOW |
| `_playbooks/cliff-playbook.md` | HIGH if has_cliff=true | LOW | HIGH if has_cliff=true | HIGH if cliff <30d |
| `_runtime/active_events.json` | WRITE (S1 output) | READ — Why Now hook | READ — active signals | READ — portfolio cross-ref |
| `hardgoods/` | HIGH if material:hardgoods | HIGH if material:hardgoods | HIGH if hardgoods | MED |
| `_links/` | HIGH — edge walk | MED | HIGH | HIGH |

---

## Event Type → Module Priority

### Regulation Events
```
Primary: L0-principles/risk-principles.md, personas/instances/*
Secondary: regulations/*, L0-principles/persona-principles.md
Tertiary: pain-points/compliance/*, products/*
```

### Financial Events (FX / Interest Rate)
```
Primary: L0-principles/persona-principles.md, personas/instances/*
Secondary: products/*, L0-principles/risk-principles.md
Tertiary: pain-points/country/*
```

### Commodity Events (Raw Material Price/Shortage)
```
Primary: personas/instances/* (via material tag match)
Secondary: L0-principles/persona-principles.md, L0-principles/event-principles.md
Tertiary: products/PROD-PRESHIP-OBF.md, _links/cross-module-edges.md
```

### Geopolitical Events
```
Primary: personas/instances/* (via country tag match)
Secondary: L0-principles/risk-principles.md, _links/cross-module-edges.md
Tertiary: regulations/*, pain-points/country/*
```

### Buyer Events (Strategy Shift, Credit Event)
```
Primary: personas/instances/* (via sells_to edge walk)
Secondary: products/PROD-PAYGUARD.md, L0-principles/persona-principles.md
Tertiary: pain-points/universal/PP-003-buyer-concentration.md
```

### Market Events (Product Trend / Demand Shift)
```
Primary: personas/instances/* (via product_type tag match)
Secondary: L0-principles/event-principles.md (RP-EVT-PRODTREND-01)
         L0-principles/persona-principles.md (RP-COMPETITIVE-01)
Tertiary: _meta/assessment-question-framework.md (Section 7 — Market angles)
Note: product_trend_change activates combos whose product_type matches the trending/declining category
      product_technology_disruption activates combos that rely on the disrupted production method
```

### Supply Chain Events
```
Primary: personas/instances/* (via sources_from edge walk)
Secondary: L0-principles/event-principles.md
Tertiary: regulations/*, pain-points/universal/*
```

---

## Tag Routing — Entry Point Rules

**Rule 1: Country tag match (strong)**
- `country:BD` → load all COMBO-002, COMBO-001 instances first
- `country:IN` → load COMBO-003, COMBO-008, COMBO-014 instances first
- `country:TR` → load COMBO-005 instance first
- `country:CN` → load COMBO-004 instance first
- `country:PK` → load COMBO-009 instance first
- `country:VN` → load COMBO-006 instance first

**Rule 2: Edge walk from country (indirect impact)**
- `country:IN` + `material:cotton` → also load COMBO-002 (BD), COMBO-009 (PK) via `sources_from:IN` edge
- `country:CN` + buyer event → also load COMBO-006 (VN), COMBO-014 (IN) via `sourcing_strategy_shift` propagation

**Rule 3: Buyer event propagation**
- Buyer event for FastFashion buyer → load all combos with `sells_to: FastFashion` weight > 0.6
- Buyer event for USMassMarket → load COMBO-002, COMBO-009 first

**Rule 4: Material tag match (secondary)**
- `material:denim` → load COMBO-005 first, then check COMBO-002 (BD denim exposure)
- `material:home_textile` → load COMBO-009 (PK), then check hardgoods/ module

**Rule 5: Minimum activation**
- Cascade must activate minimum 3 combo nodes to proceed
- If < 3 matches: expand to archetype-level match before rejecting

---

## Combo Scoring Formula

```
combo_relevance_score = 
  (tag_overlap_count × 0.4) + 
  (edge_walk_weight × 0.35) + 
  (archetype_match × 0.25)

Primary combos:   score ≥ 0.70
Secondary combos: score 0.35–0.69  ← lowered from 0.45 to capture moderately affected combos
Indirect combos:  score 0.25–0.34
Below 0.25: exclude
```

**Note on threshold change:** Secondary threshold lowered from 0.45 to 0.35 to ensure combos with strong edge-walk signals (e.g., COMBO-001 via sources_from:IN at weight 0.70) are not missed when the primary event affects a closely linked origin country.

---

## S2 Round Routing

| Round | Input | KB Loaded | Output |
|---|---|---|---|
| R1 | Company name + country only | Archetype node + top 3 universal pain points | Opening pain themes + R1 qualifying questions |
| R2 | R1 answers (material, buyer, cash cycle) | Specific instance node + country pain points | Quantified offer shape + R2 qualifying questions |
| R3 | R2 answers + financial data | Full instance + product eligibility + risk rules | Confirmed product + limit + credit recommendation |

---

## Hardgoods Routing (Josephine's Domain)

- Trigger `material:hardgoods` → route to `hardgoods/` module first
- Hardgoods runs its own defect/QC intelligence chain (not the apparel chain)
- For financing overlay, use same product nodes (ARP, PreShip-OBF)
- For risk scoring, use QC gate pass/fail as eligibility signal

---

## S5 — Event-Triggered Supplier Impact Assessment (Added: 2026-07-14)
Trigger: S1 output signal ∈ {CAUTION, DO_NOT_EXPAND, CONDITIONAL} AND combo_score ≥ 0.35
NOT triggered for: MONITOR signal (→ S4 portfolio watch only)
Route: S1 output → S5 (platform lookup → web enrichment → gap analysis → targeted outreach → S3 per supplier → dual output)
File: _scenarios/S5-event-impact-assessment.md
Platform query params per COMBO: supplier_country · product_category[] · buyer_country[] · annual_sales_range · financing_product[]
Output: Air8 internal signal per supplier + client comms draft (both require Air8 review before sending)
