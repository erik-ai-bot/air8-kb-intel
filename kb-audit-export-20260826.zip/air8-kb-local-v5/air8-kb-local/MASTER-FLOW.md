# Air8 KB v2 — Master Flow & Hierarchy
> Owner: Jerri Zhou | Version: 2026-07-15
> Single source of truth for: how the KB is structured, how LLM navigates it, how Neo4j maps to it
> Read this first. All other files are referenced from here.

---

## 1. The One-Line Summary

```
External Event → Parse & Route → Load Reasoning Rules → Match Personas → Compute Signal → Output Card
```

Every scenario (S0 through S5) is a variation of this loop.

---

## 2. Node Hierarchy (What Exists in the KB)

```
KB ROOT
│
├── EVENT (trigger input — not stored, parsed at runtime)
│   └── fields: event_type · event_subtype · country[] · material[] · window · magnitude
│
├── SCENARIO (the reasoning flow to run)
│   ├── S0  News Understanding        — classify raw news into structured event
│   ├── S1  Event → Insights          — event trigger → signal per persona
│   ├── S2  Pain Point → BD Advice    — supplier pain → BD outreach card
│   ├── S3  Individual Assessment     — one supplier → full assessment
│   ├── S4  Portfolio Monitoring      — scheduled portfolio-wide risk scan
│   └── S5  Event Impact Assessment   — S1 output → match live portfolio suppliers
│
├── PRINCIPLE (reasoning rule — governs how signals are computed)
│   ├── L0 Event Principles           — when/how event types affect personas
│   │   ├── RP-EVT-DUTY-01            commodity duty → pass-through
│   │   ├── RP-EVT-ENVCOMP-01         environmental compliance scope
│   │   ├── RP-EVT-DOUBLE-COMPRESS    input + output tariff co-occurrence
│   │   ├── RP-EVT-SEASONAL-LOCK      annual purchase cycle step-down
│   │   ├── RP-EVT-SEGMENT-BIFURCATE  apparent substitution vs bifurcation
│   │   ├── RP-EVT-CORRELATED-PAIR    multi-event combined read
│   │   └── [9 more — see event-principles.md]
│   ├── L0 Persona Principles         — structural rules about persona types
│   ├── L0 Risk Principles            — concentration caps, cliff rules
│   ├── L0 Product Principles         — eligibility rules per product
│   └── PRIMITIVE (first-principles constructs — fire when no L0 principle matches)
│       ├── RP-DEPENDENCY             input dependency → pass-through
│       ├── RP-PASSTHROUGH            who captures the benefit
│       ├── RP-CLIFF                  cliff date → latest safe disbursement
│       ├── RP-PEER-FAILURE           survivor bias correction
│       └── RP-WINDOW                 cash cycle window calculation
│
├── PERSONA (supplier archetype — the core knowledge node)
│   ├── Identity block                country · revenue · product · archetype · cash_cycle
│   ├── Structural Nuances            durable truths LLM would miss (5–10 bullets)
│   ├── Buyer Edges                   sells_to[] with weights
│   ├── Assessment Dimensions         what variables determine magnitude for this persona
│   ├── Signal Flip Conditions        when default signal reverses
│   ├── Pain Hooks                    which pain points are primary/secondary
│   ├── Product Links                 which Air8 products, ranked by weight
│   ├── LLM Directives                runtime web-lookup questions
│   └── Air8 Risk Parameters          advance ratio, review frequency, triggers
│   [Instances: COMBO-001 through COMBO-015, COMBO-HG-001 through HG-004]
│
├── COUNTRY (origin intelligence — linked from Persona)
│   ├── BD, CN, IN, PK, TR, VN, ID, KH
│   └── fields: structural_context · regulatory_env · air8_entity · llm_directives
│
├── PAIN POINT (supplier problem — triggers BD advice)
│   ├── country/  — PP-BD-001 wage hike, PP-BD-002 political instability, ...
│   ├── product/  — compliance cost, WC gap, buyer concentration
│   └── fields: pain_description · angle · logic · view · product_recommendation
│
├── PRODUCT (Air8 financing product — recommended per persona × event)
│   ├── PROD-ARP          accounts receivable purchase
│   ├── PROD-PRESHIP-OBF  pre-shipment order-backed finance
│   ├── PROD-SMARTWALLET  buyer health monitoring product
│   └── fields: eligibility · tenor · advance_ratio · self_liquidation_chain
│
├── REGULATION (compliance framework — loaded for regulation events)
│   └── fields: regulation_name · scope · effective_date · affected_combos · enforcement
│
├── ACTIVE EVENT CACHE (runtime state — written by S1, read by S2/S3/S5)
│   └── fields: trigger_id · title · event_type · window · ttl · s2_hook · state · correlated_events
│
└── SIGNAL (computed output — not stored, derived per Persona × Event run)
    └── values: EXPAND · CONDITIONAL · CAUTION · NEUTRAL · DO_NOT_EXPAND
```

---

## 3. Flow Step-by-Step (S1 — most common path)

```
STEP 0: INPUT
  Raw event text / news article / regulatory notice

STEP 1: PARSE → Event Node
  Files: _meta/tag_dictionary.md
  Output: { event_type, event_subtype, country[], material[], window, magnitude, confidence }
  Gate: classification_confidence ≥ 0.80 → else flag for human review

STEP 2: ROUTE → Scenario + Module List
  Files: _meta/scenario_routing.md
  Output: active_modules[] ordered by relevance for this event_type
  Logic: event_type → module priority matrix → ordered read list

STEP 3: MATCH → Persona List
  Files: personas/instances/* (tag index via retrieval_map.md)
         _links/cross-module-edges.md (edge walk 1–2 hops)
  Output: scored_combos[] (primary ≥0.70, secondary 0.45–0.69, indirect 0.25–0.44)
  Gate: ≥3 combos activated → else expand to archetype match

STEP 3b: CORRELATED EVENT CHECK (P0-8 — MANDATORY)
  Files: _runtime/active_event_cache_schema.md (runtime state)
  Logic: query active_event_cache for events with ≥2 overlapping tags
  Output: relationship_type (AMPLIFYING / REFRAMES / OFFSETS / INDEPENDENT)
  → If AMPLIFYING or REFRAMES: generate COMBINED card (not standalone)

STEP 4: LOAD PRINCIPLES → Reasoning Checklist
  Files: L0-principles/event-principles.md (match on event_type)
         L0-principles/persona-principles.md
         L0-principles/risk-principles.md
         _reasoning/primitives.md (ALWAYS loaded alongside — augments L0)
  Cliff check: IF has_cliff=true → ALSO load _playbooks/cliff-playbook.md
  Fallback: IF no L0 principle matches → rely on primitives.md first-principles

STEP 5: FACT LOOKUP → Hydrated Frames
  Files: personas/instances/COMBO-XXX.md (structural_nuances + llm_directives)
         _country/XX.md (country context)
  Action: Execute LLM directives (web lookup / compute) against structural nuances
  Output: { structural_truth + current_number } per combo

STEP 5b: INTENSITY SCORING
  Files: _meta/intensity-scoring-engine.md
  Output: impact_level (CRITICAL/HIGH/MEDIUM/LOW) with reasoning trace

STEP 6: COMPUTE SIGNAL → Signal per Combo
  Logic: Apply assessment_dimensions → check signal_flip_conditions
  Output: signal + magnitude + WHY (with confidence labels)
  Mandatory checks:
    P0-6: Competitive dynamics — who gained/lost (name source or tag PENDING DATA)
    P0-7: Claim confidence labels [VERIFIED/EXPERT/HYPOTHESIS/PENDING DATA] on all WHY claims
    P0-8: Correlated event check (done at Step 3b, result applied here)

STEP 7: MAP PRODUCTS → Product Recommendation
  Files: products/PROD-*.md
         L0-principles/risk-principles.md (concentration caps)
  Output: product + limit_guidance + tenor + risk_narrative + self_liquidation_chain

STEP 8: OUTPUT → S1 Event Card
  Files: _templates/S1-event-card.md
  Gate G3: card has WHY + SIGNAL + WHAT TO DO + QUALIFYING QUESTIONS + IF branches
  Gate G7: all WHY/INSIGHT claims have confidence labels
  → Write summary to Active Event Cache
  → Invoke kb-expert-review skill (if confidence < 0.85)
```

---

## 4. File Map — One File, One Responsibility

```
air8-kb-v2/
│
├── MASTER-FLOW.md          ← THIS FILE — hierarchy + flow reference
├── README.md               ← KB overview + version + changelog
│
├── _meta/                  ← HOW TO USE THE KB (routing + schema)
│   ├── tag_dictionary.md        Step 1: canonical vocabulary for event parsing
│   ├── scenario_routing.md      Step 2: event_type → module priority matrix
│   ├── retrieval_map.md         Steps 2–5: minimum file chain per trigger
│   ├── node_schema.md           Schema: 4 node types + required fields
│   ├── signal-decision-rules.md Step 6: how to resolve conflicting signals
│   ├── intensity-scoring-engine.md  Step 5b: CRITICAL/HIGH/MEDIUM/LOW scoring
│   ├── assessment-question-framework.md  Step 6: question angle library
│   ├── web-lookup-directives.md     Step 5: which claims need web lookup
│   ├── skill-architecture.md        How skills relate (kb-management, kb-llm-flow, kb-expert-review)
│   ├── terminology.md           ← CANONICAL TERMS — always check before writing new content
│   ├── correlated-event-combinations.md  Alice event combination definitions
│   └── qa-gaps-2026-07-15.md    Current open gaps tracker
│
├── L0-principles/          ← REASONING RULES (Step 4)
│   ├── event-principles.md       When/how event types hit personas (12 principles)
│   ├── persona-principles.md     Structural rules about persona archetypes
│   ├── product-principles.md     Eligibility + self-liquidation rules per product
│   └── risk-principles.md        Concentration caps, cliff rules, advance ratio rules
│
├── _reasoning/             ← FIRST-PRINCIPLES CONSTRUCTS (Step 4 fallback)
│   ├── primitives.md             RP-DEPENDENCY, RP-PASSTHROUGH, RP-CLIFF, RP-PEER-FAILURE, RP-WINDOW
│   └── persona-synthesis.md      How to synthesize a draft persona when no exact COMBO matches
│
├── _scenarios/             ← SCENARIO FLOW INSTRUCTIONS (one file per scenario)
│   ├── S0-news-understanding.md  Classify raw news → structured event
│   ├── S1-event-insights.md      Event trigger → signal + card per persona [MAIN FLOW]
│   ├── S2-supplier-pain-bd.md    Pain point → BD outreach advice
│   ├── S3-individual-assessment.md  One supplier → full assessment questions
│   ├── S4-portfolio-monitoring.md   Portfolio-wide scheduled risk scan
│   └── S5-event-impact-assessment.md  S1 output → match live portfolio suppliers
│
├── _templates/             ← OUTPUT FORMATS (one file per scenario output)
│   ├── S1-event-card.md          S1 output format (Event Card)
│   ├── S2-bd-card-r1.md          S2 R1 output (BD advice, first touch)
│   ├── S2-bd-card-r2.md          S2 R2 output (BD advice, follow-up)
│   ├── S2-bd-card-r3.md          S2 R3 output (BD advice, final)
│   └── S3-assessment-questions.md  S3 output format (Assessment)
│
├── personas/               ← PERSONA NODES (Step 3 + Step 5)
│   ├── archetypes/               Base archetypes (CMT-LowMargin, FullPackage-MidMargin, etc.)
│   └── instances/                COMBO-001 through COMBO-015, COMBO-HG-001 through HG-004
│
├── _country/               ← COUNTRY NODES (Step 5 — load after persona match)
│   ├── BD.md, CN.md, IN.md, PK.md, TR.md, VN.md, ID.md, KH.md
│   └── BD_KH_common.md
│
├── pain-points/            ← PAIN POINT NODES (Step 7 — load for S2 + S3)
│   ├── country/                  PP-BD-001, PP-BD-002 (country-specific pain points)
│   └── product/                  PP-001-cashflow-gap, PP-003-buyer-concentration (universal)
│
├── products/               ← PRODUCT NODES (Step 7)
│   ├── PROD-ARP.md
│   ├── PROD-PRESHIP-OBF.md
│   └── PROD-SMARTWALLET.md
│
├── regulations/            ← REGULATION NODES (Step 4 — regulation events only)
│
├── hardgoods/              ← HARDGOODS DOMAIN (Step 5 — hardgoods events only)
│   ├── geo-swot.md               Country intelligence for hardgoods
│   ├── wip-categories.md         WIP gate knowledge by material type
│   └── defect-classification.md  QC defect patterns
│
├── _links/                 ← EDGES (Step 3 — edge walk)
│   └── cross-module-edges.md     sources_from / sells_to / competes_with edges
│
├── _playbooks/             ← SPECIAL CASE GUIDES (Step 4 conditional)
│   ├── cliff-playbook.md         Cliff date → cadence rules
│   └── china-operations.md       Hengqin entity rules
│
└── _runtime/               ← RUNTIME STATE (Step 3b + Step 8)
    └── active_event_cache_schema.md  Schema for active event cache entries
```

---

## 5. Neo4j Graph Model

### Node Labels and Properties

```cypher
// PERSONA node
(:Persona {
  id: "COMBO-005",
  name: "Turkey Denim Specialist",
  archetype: "FullPackage-MidMargin",
  country: "TR",
  revenue_band: "mid $20-50M",
  product_type: "denim",
  company_type: "FOB",
  buyer_geo: ["EU", "US"],
  cash_cycle_days_min: 60,
  cash_cycle_days_max: 90,
  air8_signal_default: "CONDITIONAL",
  advance_ratio_normal: 0.85,
  domain: "apparel"
})

// EVENT node (transient — created when event fires)
(:Event {
  trigger_id: "T-2026-MMDD-TR-DENIM",
  title: "Turkey EU Apparel Volume Contraction -17.83%",
  event_type: "financial",
  event_subtype: "demand_shift",
  country: ["TR"],
  material: ["denim", "cotton"],
  magnitude: -0.1783,
  confidence: 0.88,
  window_start: "2026-01-01",
  window_end: "2026-04-30",
  has_cliff: false,
  state: "active"
})

// PRINCIPLE node
(:Principle {
  id: "RP-EVT-CORRELATED-PAIR",
  type: "L0_event",
  applies_when: "active_event_cache.overlapping_tags >= 2",
  relationship_types: ["AMPLIFYING", "REFRAMES", "OFFSETS", "INDEPENDENT"],
  file: "L0-principles/event-principles.md"
})

// COUNTRY node
(:Country {
  id: "TR",
  name: "Turkey",
  region: "MENA",
  currency: "TRY",
  currency_risk: "HIGH",
  air8_entity: "none",
  file: "_country/TR.md"
})

// PAIN_POINT node
(:PainPoint {
  id: "PP-001-cashflow-gap",
  title: "Cash Flow Gap",
  type: "universal",
  primary_for: ["COMBO-002", "COMBO-005", "COMBO-HG-001"],
  product_recommendation: "PROD-ARP"
})

// PRODUCT node
(:Product {
  id: "PROD-ARP",
  name: "Accounts Receivable Purchase",
  tenor_max_days: 180,
  requires_buyer_anchor: true,
  self_liquidation: "invoice → buyer payment → Air8 repaid"
})

// SIGNAL node (computed output per Persona x Event)
(:Signal {
  id: "SIG-COMBO005-EVENTE-20260715",
  persona_id: "COMBO-005",
  event_id: "T-2026-MMDD-TR-DENIM",
  value: "CONDITIONAL",
  amplified_by: "Event_B_CSDDD",
  relationship_type: "AMPLIFYING",
  confidence: 0.82,
  generated_at: "2026-07-15"
})

// ACTIVE_EVENT_CACHE node
(:CachedEvent {
  trigger_id: "T-2026-MMDD-TR-DENIM",
  ttl_days: 90,
  expires_at: "2026-10-01",
  s2_hook: "Turkey denim volume -17.83% + CSDDD compliance...",
  state: "active",
  correlated_with: ["Event_B_CSDDD"],
  relationship_type: "AMPLIFYING"
})
```

### Edge Types

```cypher
// Persona located in Country
(p:Persona)-[:LOCATED_IN]->(c:Country)

// Persona has Pain Point
(p:Persona)-[:HAS_PAIN {rank: "primary"}]->(pp:PainPoint)

// Persona recommends Product
(p:Persona)-[:RECOMMENDS {weight: 0.90, condition: "confirmed POs"}]->(prod:Product)

// Persona sells to buyer type
(p:Persona)-[:SELLS_TO {buyer_type: "EUFastFashion", weight: 0.95}]->(b:BuyerType)

// Event matches Persona (Step 3 scoring)
(e:Event)-[:MATCHES {score: 0.85, role: "primary"}]->(p:Persona)

// Event triggers Scenario
(e:Event)-[:TRIGGERS]->(s:Scenario)

// Principle governs Scenario
(prin:Principle)-[:GOVERNS]->(s:Scenario)

// Principle applies to Event type
(prin:Principle)-[:APPLIES_TO {when: "event_subtype:demand_shift"}]->(e:Event)

// Signal derived from Principle
(sig:Signal)-[:DERIVED_FROM]->(prin:Principle)

// Events correlated
(e1:Event)-[:CORRELATED_WITH {type: "AMPLIFYING"}]->(e2:Event)

// PainPoint belongs to Country
(pp:PainPoint)-[:SOURCED_FROM]->(c:Country)

// Scenario reads Node types
(s:Scenario)-[:READS {step: 3}]->(p:Persona)
(s:Scenario)-[:READS {step: 4}]->(prin:Principle)
(s:Scenario)-[:READS {step: 5}]->(c:Country)
(s:Scenario)-[:READS {step: 7}]->(prod:Product)
```

### Key Cypher Queries for Data Team

```cypher
// Q1: Which personas are affected by a Turkey event?
MATCH (e:Event {country: "TR"})-[:MATCHES]->(p:Persona)
RETURN p.id, p.name, e.title ORDER BY p.id

// Q2: Which principles apply when event_type = demand_shift?
MATCH (prin:Principle)-[:APPLIES_TO]->(e:Event {event_subtype: "demand_shift"})
RETURN prin.id, prin.type

// Q3: Find all AMPLIFYING event pairs in the cache
MATCH (e1:Event)-[:CORRELATED_WITH {type: "AMPLIFYING"}]->(e2:Event)
RETURN e1.trigger_id, e2.trigger_id, e1.country, e2.country

// Q4: Full path from Event to recommended Product
MATCH (e:Event)-[:MATCHES]->(p:Persona)-[:RECOMMENDS]->(prod:Product)
WHERE e.trigger_id = "T-2026-MMDD-TR-DENIM"
RETURN e.title, p.id, prod.id, prod.name

// Q5: Personas with high buyer concentration risk
MATCH (p:Persona)-[:HAS_PAIN {rank: "primary"}]->(pp:PainPoint {id: "PP-003-buyer-concentration"})
RETURN p.id, p.name, p.country

// Q6: Full reasoning chain for S1 Event E
MATCH path = (e:Event {trigger_id: "T-2026-MMDD-TR-DENIM"})
  -[:TRIGGERS]->(s:Scenario {id: "S1"})
  -[:READS]->(p:Persona)
  -[:HAS_PAIN]->(pp:PainPoint)
  -[:RECOMMENDS]->(prod:Product)
RETURN path
```

---

## 6. Terminology Standard

> These are the canonical terms. Use ONLY these in new content. Do not invent new labels.

| Canonical Term | Use For | NOT These |
|---|---|---|
| **Persona** | A supplier archetype node (noun) | ~~combo~~, ~~archetype~~, ~~profile~~ (use COMBO-xxx only as ID prefix) |
| **Assessment Dimension** | A variable that determines signal magnitude | ~~qualifying question~~, ~~dim~~ (dim is OK as shorthand in code), ~~key variable~~ |
| **Structural Nuance** | A durable truth LLM would miss (bullet in Persona) | ~~structural note~~, ~~insight~~, ~~nuance~~ |
| **LLM Directive** | A runtime web-lookup or compute instruction | ~~web lookup~~, ~~runtime check~~, ~~live query~~ |
| **Principle** | A named L0 reasoning rule (RP-EVT-*, RP-RISK-*) | ~~rule~~, ~~logic~~, ~~guideline~~ |
| **Primitive** | A first-principles construct (RP-DEPENDENCY, RP-CLIFF, etc.) | ~~fallback rule~~, ~~base principle~~ |
| **Signal** | The output recommendation (EXPAND/CONDITIONAL/CAUTION/NEUTRAL/DO_NOT_EXPAND) | ~~recommendation~~, ~~call~~, ~~verdict~~, ~~Air8 signal~~ |
| **Event Card** | The S1 output document | ~~S1 card~~, ~~event insight~~, ~~output card~~ |
| **Assessment** | The S3 output document | ~~S3 card~~, ~~assessment card~~ |
| **Active Event Cache** | Runtime state: events currently in window | ~~event cache~~, ~~active events~~, ~~cache~~ |
| **Claim Label** | Confidence tag on a factual claim | ~~confidence label~~, ~~tag~~, ~~flag~~ — use: [VERIFIED] [EXPERT] [HYPOTHESIS] [PENDING DATA] |
| **Pain Point** | A supplier problem that creates an Air8 BD opportunity | ~~pain~~, ~~problem~~, ~~issue~~ |
| **Correlated Event Pair** | Two events linked by RP-EVT-CORRELATED-PAIR | ~~related events~~, ~~combined events~~, ~~linked events~~ |
| **Signal Flip** | When a signal reverses due to a specific condition | ~~signal change~~, ~~override~~, ~~exception~~ |
| **Scenario** | A named reasoning flow (S0–S5) | ~~use case~~, ~~mode~~, ~~track~~ |
| **Domain** | A subject area (apparel / hardgoods) | ~~category~~, ~~sector~~, ~~vertical~~ |

---

## 7. Two Main Tracker Scenarios

### Tracker A: Event Trigger (S1 → S5 → S3)

```
Trigger: External event detected
  ↓
S0: Parse event → structured payload
  ↓
S1: Load principles → match personas → compute signals → write Event Cards
  ↓ (if signal = CAUTION or CONDITIONAL)
S5: Match S1 output against live Air8 portfolio → identify impacted clients
  ↓
S3: Individual supplier assessment → targeted questions → action plan
  ↓
Output: Event Card (S1) + Portfolio Alert (S5) + Client Assessment (S3)
Cache: Active Event Cache updated
```

**Key files for this tracker:**
`_scenarios/S1-event-insights.md` → `_templates/S1-event-card.md`
→ `_scenarios/S5-event-impact-assessment.md`
→ `_scenarios/S3-individual-assessment.md` → `_templates/S3-assessment-questions.md`

### Tracker B: Pain Point → BD Advice (S2)

```
Trigger: Supplier pain point identified (from client meeting / news / proactive scan)
  ↓
S2: Match pain point → load persona → load products → generate BD advice card
  ↓
Output: BD Advice Card (R1 first touch → R2 follow-up → R3 close)
Cache: Active Event Cache S2 hook consumed
```

**Key files for this tracker:**
`_scenarios/S2-supplier-pain-bd.md`
→ `_templates/S2-bd-card-r1.md` → `S2-bd-card-r2.md` → `S2-bd-card-r3.md`
Pain point source: `pain-points/country/` + `pain-points/product/`
