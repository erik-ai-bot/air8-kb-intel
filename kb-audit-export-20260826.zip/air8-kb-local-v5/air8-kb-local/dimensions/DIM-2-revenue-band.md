---
type: dimension-index
id: DIM-2
---
# DIM-2: Revenue Band

## Sub-nodes (Level 2)

| Band | Revenue | Key Products Available |
|------|---------|----------------------|
| [[revenue-bands/Micro]] | <$5M | MiniARP only |
| [[revenue-bands/Small]] | $5–20M | ARP, RT2C |
| [[revenue-bands/Medium]] | $20–50M | ARP, OBF, Pool, SmartWallet |
| [[revenue-bands/Large]] | $50M+ | All products + ESG Financing |
