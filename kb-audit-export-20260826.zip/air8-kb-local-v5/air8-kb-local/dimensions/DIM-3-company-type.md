---
type: dimension-index
id: DIM-3
---
# DIM-3: Company Type

## Sub-nodes (Level 2)

| Type | Cash Cycle | Pre-ship Need | Key Products |
|------|-----------|--------------|-------------|
| [[company-types/CMT]] | 90–120 days | Low | ARP, MiniARP |
| [[company-types/FOB]] | 120–180 days | Medium-High | ARP, RT2C, OBF |
| [[company-types/VerticalIntegrator]] | 180–240 days | CRITICAL | OBF, ARP, Pool, ESG |
| [[company-types/Trader]] | Variable | Medium | Back-to-Back TCS |
