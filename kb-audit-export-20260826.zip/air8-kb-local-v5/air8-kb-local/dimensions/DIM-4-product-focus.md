---
type: dimension-index
id: DIM-4
---
# DIM-4: Product Focus

## Sub-nodes (Level 2)

| Product | Lead Time | Top Compliance Risk |
|---------|-----------|-------------------|
| [[product-focus/KnitApparel]] | 60–90 days | UFLPA, REACH |
| [[product-focus/WovenApparel]] | 90–120 days | UFLPA, REACH |
| [[product-focus/Denim]] | 90–120 days | REACH (HIGHEST) |
| [[product-focus/OrganicSustainable]] | 90–120 days | UFLPA advantage |
| [[product-focus/HomeTextiles]] | 60–90 days | UFLPA, REACH |
