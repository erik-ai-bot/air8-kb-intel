---
type: dimension-value
dimension: DIM-3
id: type-trader
---
# Trader / Sourcing Agent

## Definition
No factory assets. Acts as intermediary between buyer and manufacturer. Sits between buyer payment and factory payment.

## Financial Profile
- Cash cycle: variable (depends on position)
- Margin: 3–8% (very thin)
- Capital need: bridge financing between buyer payment receipt and factory payment obligation

## Critical Compliance Rule
- OPS-KYC-002: Third-party account prohibition — cannot pay to unrelated entities
- [[../../compliance/COMP-KYC]] — Air8 requires verification of ultimate manufacturer
- Risk profile: higher due to lack of factory assets

## Air8 Product Fit
- Back-to-Back TCS (with recourse)
- NOT standard ARP without special structuring

## Linked Personas
- [[../../personas/COMBO-011-trader-sourcing-agent]]
