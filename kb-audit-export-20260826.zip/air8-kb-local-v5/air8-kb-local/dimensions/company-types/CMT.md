---
type: dimension-value
dimension: DIM-3
id: type-cmt
---
# CMT: Cut-Make-Trim Manufacturer

## Definition
Buys fabric from buyer-nominated mills, cuts/sews/finishes garments. Buyer supplies fabric, supplier supplies labour and trim.

## Financial Profile
- Cash cycle: 90–120 days (fabric purchase to buyer payment)
- Margin: 5–12% (thin — finance cost matters enormously)
- Capital need: mainly POST-shipment (fabric is small % of pre-pay)
- Pre-shipment need: lower than FOB (buyer handles fabric procurement)

## Air8 Product Fit
- [[../../layer-2-entities/financing-products/PROD-ARP]] — primary product (post-shipment gap)
- [[../../layer-2-entities/financing-products/PROD-MINIARP]] — entry point for small CMTs
- Pre-shipment less critical than FOB

## Linked Personas
- [[../../personas/COMBO-006-vietnam-fdi-knit]] (often CMT structure)
- [[../../personas/COMBO-012-cambodia-eba-dependent]]
