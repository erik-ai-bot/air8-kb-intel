---
type: dimension-value
dimension: DIM-3
id: type-vertical
---
# Vertical Integrator (Fiber-to-Fashion)

## Definition
Controls entire production chain: spinning → knitting/weaving → dyeing/finishing → garment. Often connected to agriculture (farmer programs for organic cotton).

## Financial Profile
- Cash cycle: 180–240 days (raw cotton to buyer payment — longest of all types)
- Margin: 12–25% (higher but requires massive working capital)
- Capital need: VERY HIGH at pre-shipment stage (buying raw cotton from farmers 90+ days before production)
- Pre-shipment gap: CRITICAL

## Quantification
Pre-shipment need = annual_revenue × (pre_production_days / 365) × 0.4
Example: $60M revenue × (90/365) × 0.4 = ~$5.9M needed before production starts

## Air8 Product Fit
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-OBF]] — PRIMARY (largest pre-ship need of any type)
- [[../../layer-2-entities/financing-products/PROD-ARP]] — post-shipment
- [[../../layer-2-entities/financing-products/PROD-POOL]] — multiple buyer relationships
- [[../../layer-2-entities/financing-products/PROD-ESG-FINANCING]] — organic cotton = IFC eligible
- [[../../layer-2-entities/financing-products/PROD-SMARTWALLET]] — complex multi-buyer cash flow

## Linked Personas
- [[../../personas/COMBO-003-india-large-vertical-integrator]]
- [[../../personas/COMBO-008-india-organic-cotton-medium]]
- [[../../personas/COMBO-013-multi-country-group]]
