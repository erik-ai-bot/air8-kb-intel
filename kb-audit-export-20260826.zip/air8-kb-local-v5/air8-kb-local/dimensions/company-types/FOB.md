---
type: dimension-value
dimension: DIM-3
id: type-fob
---
# FOB: Full Package Manufacturer

## Definition
Sources all materials independently, manages full production cycle from fabric/yarn to finished garment.

## Financial Profile
- Cash cycle: 120–180 days (yarn/fabric + production + payment wait)
- Margin: 8–15%
- Capital need: PRE-shipment (material procurement) + POST-shipment
- Pre-shipment gap: significant — must buy fabric/yarn 60–90 days before ship

## Air8 Product Fit
- [[../../layer-2-entities/financing-products/PROD-ARP]] — post-shipment gap
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] — if existing ARP client >6 months
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-OBF]] — if revenue >$10M

## Linked Personas
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-002-bangladesh-bank-lc]]
- [[../../personas/COMBO-004-china-medium-woven]]
- [[../../personas/COMBO-005-turkey-denim-specialist]]
- [[../../personas/COMBO-008-india-organic-cotton-medium]]
- [[../../personas/COMBO-014-india-small-woven]]
