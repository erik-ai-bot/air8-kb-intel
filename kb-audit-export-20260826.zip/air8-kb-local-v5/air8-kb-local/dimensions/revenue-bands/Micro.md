---
type: dimension-value
dimension: DIM-2
id: revenue-micro
---
# Micro: Revenue <$5M

## Characteristics
- Typically 1 factory, <200 workers, 1–3 buyers
- Owner = CEO = CFO = sales = everything
- No finance team; personal banking used for business
- Bank facility: usually none or very small OD
- One lost buyer = existential threat
- May not understand factoring concepts

## Air8 Product Eligibility
- [[../../layer-2-entities/financing-products/PROD-MINIARP]] — if revenue >$1M and ops >2yr
- NOT eligible for ARP, PreShip, Pool, SmartWallet

## Linked Personas
- [[../../personas/COMBO-015-micro-first-time]]

## Key Pain Points
- [[../../pain-points/universal/PP-001-cashflow-gap]] (CRITICAL — no cash buffer)
- [[../../pain-points/universal/PP-006-trade-finance-literacy]]
