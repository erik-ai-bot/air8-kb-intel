---
type: dimension-value
dimension: DIM-2
id: revenue-medium
---
# Medium: Revenue $20–50M

## Characteristics
- 2–4 factories, 1,000–5,000 workers, 5–10 buyers
- Dedicated finance team (1–3 people), CFO or Finance Director
- Multiple bank relationships = admin overhead
- Compliance obligations growing (CSDDD, UFLPA, REACH)
- Board/management wants professional financial reporting

## Air8 Product Eligibility
- [[../../layer-2-entities/financing-products/PROD-ARP]] — eligible
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-OBF]] — eligible (>$10M threshold met)
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] — eligible
- [[../../layer-2-entities/financing-products/PROD-POOL]] — eligible if 5+ buyers
- [[../../layer-2-entities/financing-products/PROD-SMARTWALLET]] — eligible if 3+ buyers and finance team

## Linked Personas
- [[../../personas/COMBO-004-china-medium-woven]]
- [[../../personas/COMBO-005-turkey-denim-specialist]]
- [[../../personas/COMBO-008-india-organic-cotton-medium]]
- [[../../personas/COMBO-009-pakistan-home-textile]]
- [[../../personas/COMBO-014-india-small-woven]]
