---
type: dimension-value
dimension: DIM-2
id: revenue-large
---
# Large: Revenue $50M+

## Characteristics
- 4+ factories, 5,000+ workers, 10+ buyers
- Professional management, possibly PE/institutional investment
- Multi-entity, multi-country possible
- Institutional-grade reporting needed
- ESG as competitive advantage, not just compliance
- Can leverage sustainability credentials for better financing terms

## Air8 Product Eligibility
- ALL products eligible
- [[../../layer-2-entities/financing-products/PROD-POOL]] — ideal (10+ buyers)
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-OBF]] — ideal (vertical integrators)
- [[../../layer-2-entities/financing-products/PROD-ESG-FINANCING]] — eligible if IFC criteria met
- [[../../layer-2-entities/financing-products/PROD-SMARTWALLET]] — CFO persona fits
- [[../../layer-2-entities/financing-products/PROD-DDP]] — multi-country groups

## Linked Personas
- [[../../personas/COMBO-003-india-large-vertical-integrator]]
- [[../../personas/COMBO-013-multi-country-group]]
