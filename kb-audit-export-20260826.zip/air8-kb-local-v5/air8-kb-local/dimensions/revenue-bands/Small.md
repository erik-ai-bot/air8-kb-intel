---
type: dimension-value
dimension: DIM-2
id: revenue-small
---
# Small: Revenue $5–20M

## Characteristics
- 1–2 factories, 200–1,000 workers, 3–5 buyers
- May have basic bookkeeper but not CFO
- Bank facility: maxed out LC, struggling to grow limits
- Starting to face ESG/compliance demands from buyers
- Raw material cost volatility directly hits margin

## Air8 Product Eligibility
- [[../../layer-2-entities/financing-products/PROD-ARP]] — eligible (LF: >$1M ops >2yr; Non-LF: >$3M ops >3yr)
- [[../../layer-2-entities/financing-products/PROD-MINIARP]] — eligible
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] — if existing ARP client >6 months
- NOT eligible for OBF (requires >$10M)

## Linked Personas
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-002-bangladesh-bank-lc]]
- [[../../personas/COMBO-007-indonesia-family-run]]
- [[../../personas/COMBO-012-cambodia-eba-dependent]]
