---
type: dimension-value
dimension: DIM-8
id: growth-expanding
---
# Expanding

## Characteristics
- Adding buyers, entering new markets, growing capacity
- Bank facility can't keep pace with order growth
- Rejecting orders due to working capital constraints ([[../../pain-points/universal/PP-004-scalability-constraint]])

## Air8 Value
Scalable facility that grows with each new buyer pair — no new collateral required per buyer.

## Key Products
- [[../../layer-2-entities/financing-products/PROD-ARP]] — scales with new buyer pairs
- [[../../layer-2-entities/financing-products/PROD-PRESHIP-RT2C]] or [[../../layer-2-entities/financing-products/PROD-PRESHIP-OBF]] — fund production ramp-up
- [[../../layer-2-entities/financing-products/PROD-PAYGUARD]] — protect against new/unfamiliar buyers

## Linked Personas
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-003-india-large-vertical-integrator]]
- [[../../personas/COMBO-006-vietnam-fdi-knit]]
- [[../../personas/COMBO-008-india-organic-cotton-medium]]
