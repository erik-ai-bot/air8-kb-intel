---
type: dimension-value
dimension: DIM-8
id: growth-startup
---
# Startup / Early (<3 years operations)

## Characteristics
- High risk, limited track record
- Limited financial history — hard to assess creditworthiness
- Often not eligible for Air8 standard products

## Air8 Eligibility
- MIN 2yr operations for LF (MiniARP)
- MIN 3yr operations for Non-LF (ARP)
- If <$1M revenue OR <2yr ops → NOT eligible for any Air8 product

## Linked Personas
- [[../../personas/COMBO-015-micro-first-time]] (if just crossing eligibility threshold)
