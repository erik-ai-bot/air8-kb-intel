---
type: dimension-value
dimension: DIM-8
id: growth-distressed
---
# Distressed / Struggling

## Characteristics
- Revenue declining, cash-stressed, overdue payments
- Higher risk for Air8 — thorough credit assessment required
- May be approaching Air8 as lender of last resort

## Air8 Risk Flags
- Scorecard score: check carefully
- Overdue history: any pattern of late payments?
- Buyer payment patterns: are buyers slowing down?
- Reason for distress: macro (acceptable) vs operational (higher risk)

## Decision
Distressed suppliers may still be eligible if:
- Distress is clearly macro-driven (e.g. Bangladesh wage hike, Turkey inflation)
- Buyer quality remains strong
- No overdue invoices with Air8

## Linked Pain Points
- [[../../pain-points/country/PP-BD-001-wage-hike]]
- [[../../pain-points/country/PP-TR-001-lira-hyperinflation]]
- [[../../pain-points/country/PP-TR-002-bank-credit-contraction]]
