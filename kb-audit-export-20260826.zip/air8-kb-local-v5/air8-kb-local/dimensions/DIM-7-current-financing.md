---
type: dimension-index
id: DIM-7
---
# DIM-7: Current Financing

## Sub-nodes (Level 2)

| Type | Cost | Air8 Relevance |
|------|------|---------------|
| [[financing-types/BankLC]] | 3–5% | HIGHEST — direct replacement |
| [[financing-types/BankOD]] | 8–22% | HIGH — cost saving |
| [[financing-types/DomesticFactoring]] | 1–5% + hidden fees | MEDIUM — differentiate on speed/data |
| [[financing-types/NoExternalFinancing]] | 0% (personal savings) | HIGH — education needed first |
| [[financing-types/AlreadyAir8]] | SOFR+4% | Focus on expansion |
