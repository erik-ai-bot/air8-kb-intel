---
type: dimension-index
id: DIM-1
---
# DIM-1: Country of Origin

## Sub-nodes (Level 2)

| Country | Air8 Priority | Key Products |
|---------|--------------|-------------|
| [[countries/Bangladesh]] | 🟠 High | ARP, RT2C, PayGuard |
| [[countries/China]] | 🟠 High | ARP (Hengqin), Pool, SmartWallet |
| [[countries/India]] | 🟠 High | ARP, OBF, ESG Financing |
| [[countries/Pakistan]] | 🔴 Critical | ARP (offshore USD), Pool |
| [[countries/Turkey]] | 🔴 Critical | ARP (USD), Pool |
| [[countries/Vietnam]] | 🟡 Medium | ARP (parent pitch), PayGuard |
| [[countries/Indonesia]] | 🟡 Medium | MiniARP → ARP |
| [[countries/Cambodia]] | 🟡 Medium | ARP, MiniARP |
