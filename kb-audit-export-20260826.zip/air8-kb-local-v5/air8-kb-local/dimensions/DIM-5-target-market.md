---
type: dimension-index
id: DIM-5
---
# DIM-5: Target Market

## Sub-nodes (Level 2)

| Market | Payment Terms | Key Regulations |
|--------|--------------|----------------|
| [[target-markets/UnitedStates]] | OA 90–120 days | UFLPA, Section 301 |
| [[target-markets/EuropeanUnion]] | OA 60–90 days | REACH, CSDDD, GPSR |
| [[target-markets/UnitedKingdom]] | OA 60–90 days | UK REACH, Modern Slavery Act |
| [[target-markets/MultiMarket]] | Mixed | All of the above |
