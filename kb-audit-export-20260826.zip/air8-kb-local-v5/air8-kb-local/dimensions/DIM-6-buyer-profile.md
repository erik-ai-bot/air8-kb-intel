---
type: dimension-index
id: DIM-6
---
# DIM-6: Buyer Profile

## Sub-nodes (Level 2)

| Buyer Type | Payment Terms | Dilution | ESG Demand |
|-----------|--------------|----------|-----------|
| [[buyer-profiles/GlobalFastFashion]] | OA 60–90 days | 2–5% | High |
| [[buyer-profiles/USMassMarket]] | OA 90–120 days | 3–8% | Moderate |
| [[buyer-profiles/USDeptSpecialty]] | OA 60–90 days | 5–10% | Low-Moderate |
| [[buyer-profiles/ESGFirstBrands]] | OA 30–60 days | 1–3% | Very High |
| [[buyer-profiles/EmergingMarkets]] | OA 30–60 days | Low | Low |
