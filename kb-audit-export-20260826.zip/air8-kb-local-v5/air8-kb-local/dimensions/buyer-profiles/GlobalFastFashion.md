---
type: buyer-profile
dimension: DIM-6
id: buyer-fast-fashion
---
# Global Fast Fashion (H&M, Zara, Primark, C&A)

| Attribute | Value |
|-----------|-------|
| Order volume | Large, frequent |
| Payment terms | OA 60–90 days |
| Price pressure | Aggressive |
| ESG demands | Increasing rapidly (CSDDD compliance needed) |
| Dilution | 2–5% (relatively low) |
| Loyalty | Medium (will switch for 2–3% cost saving) |

## Compliance They Require
- [[../../regulations/REG-CSDDD]] — sending DD questionnaires to ALL tier-1 suppliers NOW
- GOTS, OEKO-TEX, Sedex/SMETA audits

## Linked Personas
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-002-bangladesh-bank-lc]]
- [[../../personas/COMBO-005-turkey-denim-specialist]]
