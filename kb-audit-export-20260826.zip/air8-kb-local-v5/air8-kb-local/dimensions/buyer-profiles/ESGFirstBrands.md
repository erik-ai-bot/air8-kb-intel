---
type: buyer-profile
dimension: DIM-6
id: buyer-esg-first
---
# ESG-First Brands (Patagonia, Pact, Everlane, Eileen Fisher)

| Attribute | Value |
|-----------|-------|
| Order volume | Smaller but growing 20–30% YoY |
| Payment terms | OA 30–60 days (SHORTEST — most supplier-friendly) |
| Price pressure | Moderate (willing to pay premium for sustainability) |
| ESG demands | Very high (expect farm-to-garment traceability) |
| Dilution | 1–3% (LOWEST — partnership-oriented) |
| Loyalty | High (long-term relationships, co-investment in sustainability) |

## Why This Matters for Air8
ESG-first buyers + organic/sustainable suppliers = [[../../layer-2-entities/financing-products/PROD-ESG-FINANCING]] opportunity.
Shorter payment terms (30–60 days) means lower advance needed but also lower locked capital problem.

## Linked Personas
- [[../../personas/COMBO-003-india-large-vertical-integrator]]
- [[../../personas/COMBO-008-india-organic-cotton-medium]]

## ESG References
- [[../../esg-standards/ESG-GOTS]]
- [[../../esg-standards/ESG-FAIRTRADE]]
- [[../../esg-standards/ESG-C2C]]
