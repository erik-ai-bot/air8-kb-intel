---
type: buyer-profile
dimension: DIM-6
id: buyer-emerging
---
# South Africa / Emerging Market Buyers (Woolworths, Truworths, Mr Price)

| Attribute | Value |
|-----------|-------|
| Order volume | Small–medium |
| Payment terms | OA 30–60 days |
| Currency risk | ZAR volatility for supplier |
| Compliance | Less stringent but growing |

## Air8 Note
Smaller ticket sizes but can be valuable for diversifying supplier buyer base away from US/EU concentration risk. Reduces [[../../pain-points/universal/PP-003-buyer-concentration]].
