---
type: buyer-profile
dimension: DIM-6
id: buyer-us-mass
---
# US Mass Market (Walmart, Target, Costco, Amazon)

| Attribute | Value |
|-----------|-------|
| Order volume | Very large, programmatic |
| Payment terms | OA 90–120 days (longest payers) |
| Price pressure | Extreme |
| ESG demands | Moderate but increasing |
| Dilution | 3–8% (higher — chargebacks, compliance deductions) |
| Loyalty | Low (strongly price-driven) |

## Key Risk
Dilution 3–8% must be factored into Air8 advance ratio calculations.

## UFLPA Exposure
Walmart, Target = top CBP targets for UFLPA enforcement. Supplier must have full cotton traceability.
[[../../regulations/REG-UFLPA]]

## Linked Personas
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-009-pakistan-home-textile]]
