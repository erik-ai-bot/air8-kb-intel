---
type: buyer-profile
dimension: DIM-6
id: buyer-us-dept
---
# US Department / Specialty (Gap, Macy's, Nordstrom, J.Crew)

| Attribute | Value |
|-----------|-------|
| Order volume | Medium, seasonal |
| Payment terms | OA 60–90 days |
| Financial health | Variable — monitor closely |
| Dilution | 5–10% (HIGHEST — markdown allowances, co-op advertising) |
| Loyalty | Medium |

## Financial Health Risk
- Gap FY2024 mixed results
- Macy's store closures ongoing
- JCPenney legacy risk

High dilution (5–10%) requires careful advance ratio adjustment.

## Linked Personas
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-004-china-medium-woven]]
