---
type: dimension-value
dimension: DIM-7
id: financing-already-air8
---
# Already Using Air8

## Focus Shifts to Expansion
Current client — KYC complete, agreement signed. Key metric: **wallet share** (what % of revenue flows through Air8?)

## Expansion Levers
1. **More buyer pairs** — add uncovered buyers to existing facility
2. **More products** — add PreShipment, SmartWallet, PayGuard, ESG Financing
3. **Higher limits** — increase advance rate or facility cap
4. **Better terms** — ESG-linked pricing if eligible

## Active Pain Points
- [[../../pain-points/expansion/PP-EXPAND-001-low-wallet-share]]
- [[../../pain-points/expansion/PP-EXPAND-002-missing-product-coverage]]
- [[../../pain-points/expansion/PP-EXPAND-003-operational-friction]]

## Linked Personas
- [[../../personas/COMBO-010-existing-client-expansion]]
