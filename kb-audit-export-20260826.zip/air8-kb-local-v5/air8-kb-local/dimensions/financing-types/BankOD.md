---
type: dimension-value
dimension: DIM-7
id: financing-bank-od
---
# Bank Overdraft (OD)

| Country | Rate |
|---------|------|
| India | 12–18% p.a. |
| Indonesia | 10–15% p.a. |
| Pakistan | 15–22% p.a. |
| Turkey (2024) | ~75% p.a. |

**Collateral:** Personal guarantee + asset pledge
**Limitation:** Can be frozen/reduced without notice

## Air8 Relevance
HIGH — Air8 at SOFR+4% is significantly cheaper. Saving on $20M OD at 12% vs 6% = $1.2M/year.

## Linked Personas
- [[../../personas/COMBO-003-india-large-vertical-integrator]]
- [[../../personas/COMBO-014-india-small-woven]]
- [[../../personas/COMBO-007-indonesia-family-run]]

## Best Replacement Product
[[../../layer-2-entities/financing-products/PROD-ARP]]
