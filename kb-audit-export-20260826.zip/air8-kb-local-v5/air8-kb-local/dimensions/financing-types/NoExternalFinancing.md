---
type: dimension-value
dimension: DIM-7
id: financing-none
---
# No External Financing

Self-funded from retained earnings or owner's personal savings.

## Risk Profile
- One bad shipment = cash crisis
- May not understand factoring concept
- No financial cushion for buyer delays or order cancellations

## Air8 Relevance
HIGH but needs education first. [[../../pain-points/universal/PP-006-trade-finance-literacy]] is active.

## Entry Point
- [[../../layer-2-entities/financing-products/PROD-MINIARP]] if revenue >$1M and ops >2yr
- [[../../layer-2-entities/financing-products/PROD-ARP]] if revenue >$3M and ops >3yr

## Linked Personas
- [[../../personas/COMBO-015-micro-first-time]]
- [[../../personas/COMBO-007-indonesia-family-run]]
