---
type: dimension-value
dimension: DIM-7
id: financing-bank-lc
---
# Bank LC Only

| Attribute | Value |
|-----------|-------|
| Cost | 3–5% all-in (opening + margin + collateral opportunity cost) |
| Processing | 30–60 days per LC |
| Collateral | 100–150% (land, building, FD, personal guarantee) |
| Limitation | Fixed per-LC, doesn't scale flexibly |

## Air8 Relevance
HIGHEST — Air8 ARP replaces LC with: no collateral, T+1 disbursement, lower cost.

## Linked Personas
- [[../../personas/COMBO-002-bangladesh-bank-lc]] (primary)
- [[../../personas/COMBO-001-south-asian-small-knit]]

## Best Replacement Product
[[../../layer-2-entities/financing-products/PROD-ARP]]
