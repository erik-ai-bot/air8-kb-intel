---
type: dimension-value
dimension: DIM-7
id: financing-domestic-factoring
---
# Domestic Factoring / Competitor

| Attribute | Value |
|-----------|-------|
| Cost | 1–5% per invoice (often with hidden fees) |
| Speed | 2–5 days (slower than Air8 T+1) |
| Data | No buyer intelligence, no ESG integration |
| Transparency | Low — hidden fees common |

## Air8 Relevance
MEDIUM — must differentiate on speed, data, and LF ecosystem.
Key Air8 advantages: T+1 disbursement, PulseLink buyer intelligence, CSDDD data, ESG financing.

## Linked Personas
- [[../../personas/COMBO-004-china-medium-woven]] (200+ CN competitors)
- [[../../personas/COMBO-005-turkey-denim-specialist]] (sophisticated local market)
