---
type: product-focus
dimension: DIM-4
id: product-knit
---
# Knit Apparel

**Products:** T-shirts, polos, activewear, innerwear, thermals, socks
**Raw material:** Yarn (cotton, poly, blends)
**Lead time:** 60–90 days
**Seasonality:** Relatively stable (basics = year-round demand)

## Compliance
- [[../../regulations/REG-REACH]] (dyes)
- [[../../regulations/REG-UFLPA]] (if cotton → US)
- OEKO-TEX Standard 100

## Dimension
- [[../../dimensions/DIM-4-product-focus]]

## Linked Personas
- [[../../personas/COMBO-001-south-asian-small-knit]]
- [[../../personas/COMBO-002-bangladesh-bank-lc]]
- [[../../personas/COMBO-006-vietnam-fdi-knit]]
- [[../../personas/COMBO-007-indonesia-family-run]]
