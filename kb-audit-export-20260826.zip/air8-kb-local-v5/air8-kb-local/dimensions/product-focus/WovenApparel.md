---
type: product-focus
dimension: DIM-4
id: product-woven
---
# Woven Apparel

**Products:** Shirts, trousers, jackets, formal wear
**Raw material:** Woven fabric (cotton, poly, linen, blends)
**Lead time:** 90–120 days (longer due to complexity)
**Seasonality:** Moderate (spring/fall collections drive peaks)

## Compliance
- [[../../regulations/REG-REACH]] (finishing chemicals)
- [[../../regulations/REG-UFLPA]] (if cotton → US)

## Dimension
- [[../../dimensions/DIM-4-product-focus]]

## Linked Personas
- [[../../personas/COMBO-004-china-medium-woven]]
- [[../../personas/COMBO-014-india-small-woven]]
