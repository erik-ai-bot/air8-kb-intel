---
type: product-focus
dimension: DIM-4
id: product-denim
---
# Denim

**Products:** Jeans, jackets, shorts, denim skirts
**Raw material:** Denim fabric (indigo-dyed cotton)
**Lead time:** 90–120 days
**Seasonality:** Low-medium

## Key Quality Issue
Wash/finish consistency critical: laser, ozone, stone wash must match across lots.

## Compliance (HIGHEST CHEMICAL EXPOSURE)
- [[../../regulations/REG-REACH]] — CRITICAL (indigo, permanganate, PP spray, resin finishes)
- [[../../esg-standards/ESG-ZDHC]] — ZDHC MRSL Gateway adherence required
- [[../../regulations/REG-UFLPA]] — if cotton → US

## Wet Process Types
Stone wash, enzyme, acid, laser, ozone, sand/spray, resin, overdye (8–12 types)

## Country Strength
Turkey, Bangladesh, Pakistan, India

## Dimension
- [[../../dimensions/DIM-4-product-focus]]

## Linked Personas
- [[../../personas/COMBO-005-turkey-denim-specialist]]
- [[../../personas/COMBO-004-china-medium-woven]]
