---
type: product-focus
dimension: DIM-4
id: product-home-textiles
---
# Home Textiles

**Products:** Towels, bed sheets, curtains, table linen, soft furnishings, rugs
**Raw material:** Cotton yarn/fabric (often thicker gauges)
**Lead time:** 60–90 days
**Seasonality:** Moderate (Q3–Q4 peak for holiday gifting)

## Compliance
- [[../../regulations/REG-REACH]] (dyes, fire retardant chemical finishes)
- [[../../regulations/REG-UFLPA]] (if cotton → US)
- OEKO-TEX Standard 100

## Country Strength
Pakistan (world-leading terry/woven), India (bed linen, rugs), Turkey (premium), Egypt (long-staple cotton)

## Dimension
- [[../../dimensions/DIM-4-product-focus]]

## Linked Personas
- [[../../personas/COMBO-009-pakistan-home-textile]]
- [[../../personas/COMBO-001-south-asian-small-knit]]
