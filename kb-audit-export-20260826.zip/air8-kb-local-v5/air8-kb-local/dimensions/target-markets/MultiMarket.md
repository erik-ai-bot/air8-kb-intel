---
type: target-market
dimension: DIM-5
id: market-multi
---
# Multi-Market (US + EU + Others)

Most complex compliance environment — must satisfy BOTH US and EU regulations simultaneously.

## Complexity
- Dual regulation: UFLPA (US) + REACH/CSDDD (EU)
- FX complexity: USD + EUR (+ GBP, AUD, ZAR)
- Higher admin burden but more diversified revenue

## Linked Personas
- [[../../personas/COMBO-003-india-large-vertical-integrator]]
- [[../../personas/COMBO-004-china-medium-woven]]
- [[../../personas/COMBO-013-multi-country-group]]

## Products That Help
- [[../../layer-2-entities/financing-products/PROD-POOL]] — whole-turnover across multiple buyer currencies
- [[../../layer-2-entities/financing-products/PROD-SMARTWALLET]] — multi-currency cash flow visibility
