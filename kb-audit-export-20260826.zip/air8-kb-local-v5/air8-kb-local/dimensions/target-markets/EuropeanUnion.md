---
type: target-market
dimension: DIM-5
id: market-eu
---
# European Union 🇪🇺

**Market size:** ~$100B/year apparel imports (2nd largest)
**Payment terms:** OA 60–90 days
**Dilution:** 1–5% (lower, more predictable)

## Key Regulations
- [[../../regulations/REG-REACH]] — chemical compliance (SVHC >0.1% w/w)
- [[../../regulations/REG-CSDDD]] — supply chain due diligence (from 2028)
- [[../../regulations/REG-GPSR]] — general product safety (Dec 2024)
- EU Digital Product Passport (ESPR — from 2027)

## Key Buyers
H&M (Sweden), Zara/Inditex (Spain), Primark (Ireland), C&A (Germany), Zalando (Germany)

## Linked Personas
All combos selling to EU: COMBO-001, 002, 003, 004, 005, 007, 008, 009, 012, 014
