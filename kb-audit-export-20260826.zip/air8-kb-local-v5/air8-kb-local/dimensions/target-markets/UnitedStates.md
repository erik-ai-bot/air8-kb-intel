---
type: target-market
dimension: DIM-5
id: market-us
---
# United States 🇺🇸

**Market size:** ~$120B/year apparel imports (largest globally)
**Payment terms:** OA 90–120 days (longest among major markets)
**Dilution:** 3–8% (chargebacks, compliance deductions)

## Key Regulations
- [[../../regulations/REG-UFLPA]] — cotton traceability (CRITICAL)
- [[../../regulations/REG-TARIFF]] — Section 301 tariffs (China 25–50%, India 50% new)
- CPSIA (children's products)

## Key Buyers
Walmart, Target, Gap, Nike, Amazon, Costco, Macy's, Nordstrom, TJX

## Risk Note
CBP actively detaining cotton shipments — 4,619 detentions in 2024. Apparel clearance rate only 36%.

## Linked Personas
All combos selling to US: COMBO-001, 002, 003, 004, 008, 009, 014
