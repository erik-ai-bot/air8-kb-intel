---
type: target-market
dimension: DIM-5
id: market-uk
---
# United Kingdom 🇬🇧

**Post-Brexit:** Separate regulatory regime (UK REACH vs EU REACH)
**Payment terms:** OA 60–90 days

## Key Regulations
- UK REACH (separate from EU REACH post-Brexit)
- Modern Slavery Act — annual reporting requirement
- UKCA marking (separate from CE)

## Key Buyers
M&S, Next, ASOS, Boohoo, George (Walmart UK)

## Linked Personas
Combos with UK market exposure — overlaps heavily with EU combos
