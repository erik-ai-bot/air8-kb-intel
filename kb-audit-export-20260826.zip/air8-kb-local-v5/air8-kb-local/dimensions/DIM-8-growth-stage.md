---
type: dimension-index
id: DIM-8
---
# DIM-8: Growth Stage

## Sub-nodes (Level 2)

| Stage | Air8 Eligibility | Primary Value |
|-------|----------------|--------------|
| [[growth-stages/Startup]] | Min 2yr ops required | Usually not eligible |
| [[growth-stages/StableMature]] | Full eligibility | Cost optimisation |
| [[growth-stages/Expanding]] | Full eligibility | Scalable facility |
| [[growth-stages/Distressed]] | Case by case | Crisis financing |
