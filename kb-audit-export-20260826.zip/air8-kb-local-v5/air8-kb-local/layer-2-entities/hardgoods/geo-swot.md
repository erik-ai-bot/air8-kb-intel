# Hardgoods Geo-SWOT — Country Intelligence

> Domain Owner: Josephine Cheung | Updated: 2026-07-01
> Source: home-goods-swot-analysis-2026.md + kb-qc-production-intelligence.md

---

## China (CN)

**Strengths:**
- Dominant in ALL 7 hardgoods categories — full vertical integration (resin → mold → product → print → pack)
- Largest plastic decor manufacturing base globally; Keqiao equivalent = Yiwu for home decor
- Speed and variety unmatched; can prototype in 5-7 days

**Structural Pain Points (Air8 BD angle):**
- US tariffs at 145%+ (2025) — US-bound plastic/home decor orders dropping 80%+; factories pivoting to EU, ASEAN
- Overcapacity + cash burn: large inventory stuck with no US buyers; WC locked in finished goods
- ESG/Xinjiang scrutiny: UFLPA applies to any cotton content (bed linen, soft furnishing, rugs)

**Air8 Opportunity:**
- Bridge financing while factories pivot from US to EU/ASEAN markets
- Inventory financing for stuck finished goods
- Pre-season Q3-Q4 PO financing for remaining US/EU programs

---

## India (IN)

**Strengths:**
- Global leader in artisan metalwork (brass, iron, aluminum handcrafted decor)
- Growing share in bed linen, bath linen, rugs
- Cost competitive vs China; no UFLPA risk on cotton (domestic cotton)

**Structural Pain Points:**
- Long buyer payment cycles (60–120 days) + MSME credit gap = classic Air8 opportunity
- Cotton price volatility: raw material for home textile; pre-shipment financing need is high
- Certification costs: OEKO-TEX, GOTS, BCI, Sedex — mandatory for EU/US but expensive for SMEs

**Air8 Opportunity:**
- Invoice financing / ARP on major buyer receivables (IKEA, Walmart, H&M Home)
- Pre-shipment for cotton home textile: fund raw material before production starts
- Compliance financing: OEKO-TEX test costs, audit financing

---

## Vietnam (VN)

**Strengths:**
- Fast-growing as China+1 for plastic decor and simple home goods
- Low labor cost; CPTPP access to Japan/Australia/Canada

**Structural Pain Points:**
- New factories ramping up; working capital inadequate for rapid growth (same pattern as apparel COMBO-006)
- Quality control infrastructure still developing vs China
- Parent company decision authority issue (if FDI factory — same as COMBO-006)

**Air8 Opportunity:**
- WC for fast-growing VN hardgoods factories; same China+1 playbook as apparel

---

## Turkey (TR)

**Strengths:**
- Premium home textile (bath linen especially); strong EU buyer relationships
- Near-shore for EU (2-5 day shipping) — meaningful for seasonal / fashion-driven home decor
- Sophisticated finishing (for home textile: embroidery, special weaves)

**Structural Pain Points:**
- TRY hyperinflation: same as apparel COMBO-005 — bank credit lines being cut
- Energy costs rising; production cost pressure
- EU-dependent; CSDDD compliance starting to matter for home textile supply chains

**Air8 Opportunity:**
- EUR-denominated ARP: same self-hedge logic as COMBO-005
- Pre-season financing for EU seasonal home textile programs

---

## Pakistan (PK)

**Strengths:**
- World's #1 bath linen (towels) exporter; ELS cotton = quality moat for premium towels
- Large established mills with US/EU buyer relationships

**Structural Pain Points:**
- Energy crisis adds 10-20% production cost (same as apparel COMBO-009)
- Bank rates 15-22%; SBP FX controls limit USD availability
- US tariff uncertainty + India competition on commodity home textile

**Air8 Opportunity:**
- Offshore USD ARP: same high-urgency play as apparel COMBO-009
- ELS premium range only — do not expand into commodity home textile

---

## Category SWOT Highlights

### Plastic Decor
- **Biggest opportunity:** Pre-season Q3-Q4 financing gap (demand concentrates); raw material (resin) price volatility financing
- **Risk:** US Section 301 tariffs; REACH/RoHS compliance per SKU

### Metal Decor
- **Biggest opportunity:** India artisan metalwork — long payment cycles; pre-shipment for complex items
- **Risk:** Lead/cadmium compliance testing per batch

### Home Textile (goods)
- **Biggest opportunity:** PK and IN — same as apparel PK/IN play; UFLPA compliance for cotton content
- **Risk:** UFLPA for any cotton content; REACH for dyes and finishing chemicals

### Seasonal + Candles
- **Biggest opportunity:** Extreme seasonality (Q3-Q4 = 70%+ of annual volume); pre-season financing = high demand
- **Risk:** Flammability compliance (EN71-2, UL); battery/electrical compliance

### Furniture
- **Biggest opportunity:** High-ticket items; long lead times; payment terms 60-120 days; WC need is large
- **Risk:** CARB formaldehyde (US wood products); structural integrity testing
