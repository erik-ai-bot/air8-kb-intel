---
type: readme
id: LAYER-2-README
---

# Layer 2 — Entity Layer

This layer contains all **entity reference data** for the Air8 KB engine.
It defines WHAT the entities are — not how to reason about them.

## Contents

| Folder                  | Contents                                                              | Count  |
|-------------------------|-----------------------------------------------------------------------|--------|
| `personas/`             | COMBO-*.md supplier archetypes with full dimension profiles           | 15 files (+ 1 ENH variant) |
| `countries/`            | Country profiles: tariff exposure, political risk, banking access     | 8 files |
| `product-categories/`   | APPAREL.md (5 apparel verticals) + HARDGOODS.md (7 categories, 19 types) | 2 files |
| `financing-products/`   | PROD-*.md Air8 financing product definitions with eligibility         | 9 files |
| `esg-standards/`        | ESG-*.md certification standard definitions                           | 7 files |
| `traceability/`         | TRACE-*.md supply chain traceability frameworks                       | 3 files |

## How Entities Are Used

Entities are **looked up by the event context fields** — not by the reasoning principles.
The event routing engine in Layer 1 determines WHICH entities to retrieve:

- `Event.supplier_country` → direct match → `countries/<Country>.md`
- `Event.buyer_geo` → direct match → `countries/<Country>.md`
- `Event.product_category` + `Event.material` → `product-categories/APPAREL.md` or `HARDGOODS.md`
- `Event.supplier_tier` + `Event.product_category` + `Event.buyer_geo` + `Event.material` → persona tag overlap scoring → `personas/COMBO-*.md`

**Entities never point to principles. Principles never point to entities.**
The event is the only node holding both sets of keys.

## What This Layer Does NOT Contain

- **No reasoning logic** — event routing, principle activation weights, solution playbooks are all in `layer-1-reasoning/`
- **No pain point definitions** — those are in `layer-1-reasoning/pain-points/`
- **No regulatory text** — those are in `layer-1-reasoning/regulations/`

## Linkage to Layer 1

The `linkage/` folder at the KB root bridges the two layers:
- `linkage-persona-full.md` — persona → pain points (L1) + products (L2) + compliance (L1)
- `linkage-regulation-affected.md` — regulation (L1) → affected countries/products/combos (L2)
- `linkage-event-propagation.md` — event traces showing cross-layer impact chains
- `linkage-product-reverse.md` — product (L2) → reverse lookup: pain points (L1) + combos (L2)

## Full Engine Reference

See `ARCHITECTURE.md` at the KB root for the complete reasoning engine specification,
including weight calculation, entity relevance scoring, and the end-to-end Cypher query.
