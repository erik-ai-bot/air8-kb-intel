---
type: review
id: REVIEW-ALICE-EVENTS-A-B-E
version: 2.0
date: 2026-07-16
source: Alice's comments on Events A (BD Closures), B (CSDDD), and E (Turkey EU Apparel)
---

# Review File for Alice — Events A, B, E + Cluster Proposals

**Purpose:** Items in the KB that need Alice's confirmation before they can be treated as established facts. All flagged items are currently marked `⚠️ PENDING ALICE REVIEW` in the relevant KB files.

---

## Item 1 — Istanbul Premium vs Interior Turkey Risk Distinction

**In KB:** `layer-2-entities/personas/COMBO-005-turkey-denim-specialist.md`

**Current KB assertion (hypothesis, not confirmed):**
> Istanbul-area factories (proximity to buyers, full finishing) vs Interior Turkey factories (commodity denim, no finishing moat) may have different risk profiles

**Alice's question:**
> "Where do we get the information to conclude the above statement?"

**What we need:**
- Factory-level data on whether Istanbul-area denim factories actually retained EU buyer volume better than Interior Turkey during the -17.83% contraction
- Source: buyer order allocation data, factory-level export data, or Air8 BD team observations from existing TR clients

**KB status:** Kept as hypothesis only. NOT asserted as fact until Alice validates.

---

## Item 2 — "Air8 may be the only liquidity source" for Turkish suppliers

**In KB:** `layer-2-entities/personas/COMBO-005-turkey-denim-specialist.md` (sub_scenario_1)

**Original claim (removed from KB):**
> Air8 EUR ARP may be the ONLY liquidity source

**Alice's correction:**
> "Too aggressive — how do we know if suppliers can obtain support from local bank, buyer back supplier financial plan, export factoring etc."

**Alice's suggested questions instead:**
- "Has Air8 become a more important source of working capital relative to banks and other funding providers during the downturn?"
- "Have any banks formally reduced credit limits, tightened collateral requirements, or increased financing costs during the past 12 months?"

**KB status:** Claim removed. Alice's questions added to the assessment chain instead.

---

## Item 3 — Zara 14-day Reorder Model "Impossible" from Asia

**In KB:** `layer-2-entities/personas/COMBO-005-turkey-denim-specialist.md`

**Original claim (softened in KB):**
> "Zara 14-day reorder model cannot work with India's 30-day shipping"

**Alice's challenge:**
> "Too absolute — both statements need evidence"

**What we need:**
- Evidence that Zara's specific reorder model requires <14-day lead time and that this is structurally incompatible with Asian sourcing
- OR rephrase as a hypothesis and convert to a buyer-facing question

**Alice's suggested question format:**
> "Beyond denim, have buyers requested development, sampling, pilot orders, or production quotes for adjacent product categories? If yes, have any progressed beyond RFQ stage into actual business?"

**KB status:** Softened to hypothesis. Marked as pending validation.

---

## Item 4 — India 18-24 Month Timeline to Replicate Turkey's Capability

**In KB:** `layer-2-entities/personas/COMBO-005-turkey-denim-specialist.md`

**Original claim (softened in KB):**
> "18-24 months as India invests cotton savings into finishing technology"

**Alice's challenge:**
> "Too absolute — needs evidence on actual Indian denim finishing investment pace"

**What we need:**
- Data or intelligence on Indian denim mills' actual finishing technology investment (laser/ozone capex)
- Rate of EU buyer trial orders going to Indian denim mills

**KB status:** Removed specific timeline. Kept as directional hypothesis only.

---

## Item 5 — Turkey EU Volume Decline: Demand Story or Competitiveness Loss?

**In Alice's simulation:**
> "Turkey's -17% volume decline is largely an EU consumer demand story, not evidence of Turkey losing competitive position"

**Alice's challenge:**
> "How confident are we with this statement? Did we deep dive whether Turkey lost share to Egypt, BD, India etc.?"

**What we need:**
- EU apparel import data broken down by origin country for same period
- If Egypt, BD, India GAINED EU share while Turkey fell → competitiveness story, not demand story
- If ALL origins fell similarly → demand story confirmed

**Alice's suggested question:**
> "When order volumes decline, have buyers indicated that the reduction reflects weaker EU consumer demand across all sourcing countries, or a deliberate reallocation of sourcing away from Turkey?"

**KB status:** This assertion is in the simulation file (`air8-kb-6event-simulation.md`), NOT in the KB. It was NOT carried into any KB file. No KB change needed — but Alice should validate the framing before using this in any BD materials.

---

## Item 6 — Bangladesh CMT -3% EU Volume

**In Alice's simulation:**
> "Bangladesh CMT saw -3% EU volume decline"

**Alice's challenge:**
> "This needs data or source to verify before we share"

**KB status:** NOT in any KB file. Only in the simulation. Do not use this figure in BD materials until Alice confirms the source.

---

## Summary of KB Status

| Item | KB Change Made? | Pending Alice |
|---|---|---|
| Istanbul vs Interior Turkey distinction | ✅ Marked as hypothesis + PENDING | Need factory-level validation |
| "Only liquidity source" claim | ✅ Removed, replaced with open questions | Confirm questions are correct |
| Zara 14-day reorder | ✅ Softened to hypothesis | Need buyer evidence or softer question |
| India 18-24 months | ✅ Removed specific timeline | Need Indian mill investment data |
| Turkey demand vs competitiveness | Not in KB (stays in simulation only) | Alice to advise on framing |
| BD -3% EU volume | Not in KB (stays in simulation only) | Alice to provide source |

---

---

## EVENT A — Bangladesh Factory Closures (Alice's Comments)

### A-1: RP-PEER-FAILURE Correction (in KB)
**Alice's challenge:**
> "Peer closures driven by wage escalation + LDC risk + EU demand contraction — all three apply equally to the surviving factory"
> Cannot assume equal exposure. A surviving factory may have different product mix, buyers, margins, automation, export markets.

**KB change:** RP-PEER-FAILURE reasoning logic updated — do NOT assume shared structural causes apply equally. Each surviving factory requires independent assessment of its specific exposure profile.

### A-2: New PO Price Assertion (in simulation only — not in KB)
**Alice's challenge:**
> "New PO inflow typically offered at same or lower price" — 'typically' may not always be true. Sometimes buyers pay MORE if capacity scarce / factory has better compliance.

**KB status:** Not in KB files. Move to watchlist item at runtime, not asserted as key insight.

### A-3: Alice's Suggested Additional Questions
- **Subcontractor:** "Which subcontractors have you used in the last 12 months, and have any of them ceased operations?"
- **Receivables:** "Over the last 12 months, have your customer payment terms, collection periods, or overdue receivables increased? Which buyers are taking longer to pay?"
- **Margin:** When asking gross margin, also check payment terms and FOB price — not all suppliers measure margin by PO

### A-4: Advance Ratio 70% (figures don't belong in KB)
**Alice's challenge:** Why 70%? Needs justification.
**KB principle:** Advance ratios are runtime decisions, not KB constants. Removed from KB. Runtime assessment uses portfolio risk parameters.

---

## EVENT B — CSDDD 2029 Extension (Alice's Comments)

### B-1: LOGICAL ERROR Fixed — GSP+ Pathway (⚠️ Critical)
**Original claim (in simulation):** Factory obtaining HIGG FEM / GOTS / Better Work → GSP+ pathway
**Alice's correction:** GSP+ is a **country-level** trade preference scheme dependent on government ratification of international conventions. Individual factory certifications do NOT create a GSP+ pathway.
**KB status:** This error is NOT in any KB file — only in the simulation. Do not use in BD materials.

### B-2: "Asian Competitors Cannot Provide ESPR Data" — Too Absolute
**Alice's challenge:** ASEAN + China + BD suppliers already report to HIGG FEM, HIGG FSLM, ZDHC, Carbon metrics for major buyers. Cannot assert Asian competitors lack this data capability.
**KB status:** Captured in EVENT-CLUSTERS.md as an explicit correction. Do not assert at runtime without checking.

### B-3: "False Relief Window" — Cannot Assert as Fact
**Alice's challenge:** Depends entirely on buyer requirements. Cannot treat as established fact.
**KB status:** Captured in EVENT-CLUSTERS.md as a reasoning hypothesis to TEST, not assert.

### B-4: "24-Month Head Start" — No Evidence
**Alice's challenge:** Why 24 months? Any fact to support?
**Alice's better question:** "Have you changed, postponed, accelerated, or maintained any sustainability, traceability, chemical compliance, or ESG-related investments following the recent CSDDD timeline changes?"
**KB status:** Specific figure removed. Open question format adopted.

### B-5: "Zara/H&M Compliance Demands Will Not Relax" — Needs Verification
**Alice's challenge:** Inditex and H&M already had extensive ESG requirements BEFORE CSDDD. Does not automatically mean stricter.
**KB status:** Pending verification. Runtime web search should check current buyer compliance requirements.

### B-6: "Factory Must Comply or Lose Zara/H&M Program" — Too Strong
**Alice's correction:** Rephrase to "may increase the risk of reduced sourcing opportunities, program restrictions, or corrective action requirements."

### B-7: "ESPR 2027 Is The Real Deadline" — Needs Refinement
**Alice's challenge:** ESPR implementation depends on product category, delegated acts, and Digital Product Passport rollout timelines. Not all textile requirements automatically take effect in 2027.
**KB status:** Cannot assert ESPR 2027 as universal deadline. Runtime: check product-specific DPP requirements.

### B-8: Cambodia "Highest Risk Country" + Advance Ratio 65%
**Alice's challenge:** How did we arrive at these? No evidence base shown.
**KB status:** Neither figure is in KB files — only in simulation. Do not assert without evidence.

### B-9: Alice's Mandatory Additional Question (added to EVENT-CLUSTERS.md)
> "Have any of your major EU buyers indicated that future business allocation, supplier ranking, or programme participation will depend on traceability, environmental reporting, or sustainability-performance improvements over the next 24 months?"

### B-10: BSCI/Sedex vs CSDDD — Rephrase Needed
**Alice's note:** Statement is technically correct but could be misunderstood. BSCI and Sedex DO cover parts of labour and social compliance. Rephrase to be more balanced and avoid creating the impression that existing certifications have zero CSDDD relevance.

---

## Cluster Proposals — Alice's Recommendations

**Captured in:** `layer-1-reasoning/EVENT-CLUSTERS.md`

| Cluster | Member Events | Status |
|---|---|---|
| CLUSTER-US-DECOUPLING | D (UFLPA) + F (IEEPA/S301) | ⏳ Run combined analysis |
| CLUSTER-EU-MARKET-ACCESS | B (CSDDD) + C (India-UK FTA) + BD EBA | ⏳ Run combined analysis + compare Cambodia |

---

**Reply to:** Jerri  
**Next step:** Alice confirms / corrects items → run combined cluster analyses for D+F and B+C+BD EU Trade