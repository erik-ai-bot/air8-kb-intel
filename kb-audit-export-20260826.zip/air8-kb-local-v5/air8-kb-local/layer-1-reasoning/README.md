---
type: readme
id: LAYER-1-README
---

# Layer 1 — Reasoning Layer

**START HERE → Read `BRAIN-CHAIN.md` first.**

`BRAIN-CHAIN.md` is the single file that maps every reasoning file to its exact step in the pipeline.
It tells you what file to open, what question it answers, and what output goes to the next step.

---

## File Index

| File | Step | Role |
|------|------|------|
| **BRAIN-CHAIN.md** | — | Master navigation guide — READ FIRST |
| EVENT-TYPES.md | Step 1 | Event type → activated principles + weights |
| EVENT-PRINCIPLES.md | Step 2 | Event subtype → RP-EVT-* reasoning directive |
| PRINCIPLES.md | Step 3 | Principle → Layer 2 entity fetch spec |
| EVENT-CLUSTERS.md | Step 3b | Cluster detection + correlated event logic |
| runtime/active_event_cache_schema.md | Step 3b | Active event cache lookup schema |
| PERSONA-PRINCIPLES.md | Step 5a | Per-persona reasoning frames |
| PRODUCT-PRINCIPLES.md | Step 5a | Per-product reasoning frames |
| RISK-PRINCIPLES.md | Step 5b | Risk overlay rules |
| PRIMITIVES.md | Step 5c | Fallback constructs (no entity data) |
| SOLUTIONS.md | Step 6 | Event × persona → Air8 product match |
| PERSONA-SYNTHESIS.md | Step 7 | Draft persona synthesis (no COMBO match) |
| pain-points/*.md | Step 5 (ref) | Pain point definitions |
| compliance/*.md | Step 5 (ref) | Compliance program details |
| playbooks/*.md | Step 6 (ref) | Scenario-specific playbooks |

## What This Layer Does NOT Contain

- **No entity data** — no personas, no country profiles, no product specs (those are in `layer-2-entities/`)
- **No financing product definitions** — those are in `layer-2-entities/financing-products/`
- **No ESG standard specifications** — those are in `layer-2-entities/esg-standards/`

## Full Architecture Reference

See `ARCHITECTURE.md` at the KB root for:
- Two-layer design rationale
- Linkage table structure
- Complete Cypher query (end-to-end)
- Cross-layer edge rules (PainPoints exception)
