# Active Event Cache — Schema & TTL Rules

> Purpose: Stores S1 event outputs for consumption by S2 (Why Now hook) and S4 (portfolio cross-reference)
> Runtime file: active_events.json (populated at S1 runtime, not stored in KB)
> Updated: 2026-07-01

---

## JSON Schema (per event entry)

```json
{
  "trigger_id": "T-YYYY-MMDD-[COUNTRY]-[MATERIAL]",
  "title": "[Human-readable event title]",
  "event_type": "[Regulation | Financial | Commodity | Geopolitical | Buyer | Supply Chain]",
  "event_subtype": "[import_export_duty | fx_rate | etc.]",
  "summary": "[1-2 sentence summary of the event and its direction]",
  "affected_countries": ["BD", "IN", "TR"],
  "affected_materials": ["cotton", "denim"],
  "effective_window": {
    "start": "YYYY-MM-DD",
    "end": "YYYY-MM-DD",
    "has_cliff": true,
    "cliff_date": "YYYY-MM-DD",
    "days_remaining": 0
  },
  "impacts": [
    {
      "combo": "COMBO-002-BD-CMT",
      "direction": "CAUTION",
      "signal": "CAUTION",
      "magnitude": "medium",
      "why_hook": "[1 sentence: why this event hits this combo specifically — use structural nuance]"
    }
  ],
  "s2_narrative": "[Ready-to-use 'Why Now' hook for BD. 1-2 sentences. Specific, not generic.]",

  "state": "active | draft | incorporated_in | monitoring",
  "sourced_by": null,
  "combined_read_id": null,
  "first_detected_at": "YYYY-MM-DD",
  "last_delta_check": "YYYY-MM-DD",

  "created_at": "YYYY-MM-DD",
  "expires_at": "YYYY-MM-DD",
  "ttl_source": "cliff | regulation_90d | financial_30d | commodity_60d | geopolitical_45d"
}
```

---

## State Field — Lifecycle Values

| State | Meaning | Set when |
|---|---|---|
| `draft` | Surfaced during enrichment of another event; not yet confirmed as a distinct significant event | STEP 0 enrichment finds related news → Phase A-E parses it → staged as draft |
| `active` | Confirmed significant event; generating standalone or combined signals | Direct input arrival OR draft confirmed significant via Step 3b |
| `incorporated_in` | This event was absorbed into a combined card with another event; do NOT generate new standalone card | Step 3b produces COMBINED card from two events |
| `monitoring` | Detected but signal too weak for active card; watching for development | Step 3b classification: INDEPENDENT + low magnitude |

## New Fields — Purpose

| Field | Purpose |
|---|---|
| `state` | Lifecycle position (see table above) |
| `sourced_by` | `null` if arrived independently; `[trigger_id]` if surfaced during enrichment of that event |
| `combined_read_id` | ID of the combined card when `state=incorporated_in`. Format: `COMBINED-[trigger_id_A]-[trigger_id_B]` |
| `first_detected_at` | Date first surfaced (may predate `created_at` if found during enrichment of an earlier event) |
| `last_delta_check` | Date of most recent delta check (used when event arrives independently after `incorporated_in`) |

---

## TTL Rules (Default Expiry by Event Type)

| Event Type | Default TTL | Override |
|---|---|---|
| Regulation | 90 days | Use cliff_date if present |
| Financial / FX | 30 days | Refresh if move reverses |
| Commodity | 60 days | Use cliff_date if present |
| Geopolitical | 45 days | Review if situation evolves |
| Buyer | 90 days | Review if buyer reverses policy |
| Supply Chain | 30 days | Review if disruption resolves |
| Any with cliff | cliff_date | Hard expiry — do not extend |

---

## Usage in S2 (Why Now Hook)

When composing R1 BD card:
1. Check `active_events.json` for entries where `combo` matches client's matched COMBO
2. Filter: `days_remaining > 14` (stale events not useful for BD)
3. If match found: use `s2_narrative` as the "Why Now" hook in the R1 card
4. If multiple matches: use the highest-magnitude event

---

## Usage in S4 (Portfolio Monitoring)

1. Load all entries from `active_events.json` where `expires_at > today` AND `state != draft`
2. Cross-reference `impacts[].combo` against current Air8 client portfolio
3. For cliff events: compute `cliff_date - today` → if < 30 days → URGENT tier
4. Remove expired entries from cache after S4 run
5. For `state=incorporated_in` entries: reference `combined_read_id` for the active signal; do not surface the individual entry

---

## Deduplication Protocol — When an Incorporated Event Arrives Again

When Event C arrives as a direct input AND cache contains C with `state=incorporated_in`:

```
Step 1: Read combined_read_id from cache entry for C
Step 2: Delta check — has Event C developed meaningfully since last_delta_check?
  → Run: STEP 0 enrichment search specifically for Event C (search for developments since last_delta_check date)
  → Ask: is there NEW information not captured in the existing combined card?

If NO new development:
  → Emit: "[Event C title] was incorporated into [combined card ID] on [date].
           No material new development since then. See [combined card] for full analysis."
  → Update last_delta_check = today
  → Do NOT generate a new signal card

If YES new development:
  → Generate ADDENDUM to existing combined card (not a new standalone card)
  → Label: "UPDATE — [Event C title] — new development since [last_delta_check]"
  → Update last_delta_check = today
  → Update combined card with addendum section
```

**Rule:** Never generate a new standalone card for an event that is `state=incorporated_in`. Always reference or update the combined card.

---

## Example Active Entry (India Cotton Duty 2026)

```json
{
  "trigger_id": "T-2026-0601-IN-COTTON",
  "title": "India Cotton Duty Exemption (BCD + AIDC → 0%)",
  "event_type": "Regulation",
  "event_subtype": "import_export_duty",
  "summary": "India CBIC Notification 19/2026: import duty on HS5201 raw cotton reduced from 11% to 0%, effective Jun 1–Oct 31 2026.",
  "affected_countries": ["IN"],
  "affected_materials": ["cotton"],
  "effective_window": {
    "start": "2026-06-01",
    "end": "2026-10-31",
    "has_cliff": true,
    "cliff_date": "2026-10-31",
    "days_remaining": 122
  },
  "impacts": [
    {
      "combo": "COMBO-003-india-vertical",
      "direction": "BENEFIT",
      "signal": "EXPAND",
      "magnitude": "high",
      "why_hook": "India vertical mills buy cotton directly — 11% duty gone on imported cotton; net margin uplift 1-4% depending on import/domestic blend ratio."
    },
    {
      "combo": "COMBO-002-bd-cmt",
      "direction": "INDIRECT",
      "signal": "CAUTION",
      "magnitude": "medium",
      "why_hook": "BD CMT is 90% buyer-nominated fabric — cheaper Indian cotton does not reduce their cost directly; only indirect via yarn price lag in 90-180 days."
    },
    {
      "combo": "COMBO-009-pakistan-home-textile",
      "direction": "THREAT",
      "signal": "CAUTION",
      "magnitude": "medium",
      "why_hook": "Pakistan is a domestic cotton producer — India duty cut makes Indian cotton cheaper, improving India's cost competitiveness against PK on home textile exports."
    }
  ],
  "s2_narrative": "India's cotton import duty is 0% until Oct 31 — if your client is an India vertical supplier buying cotton directly, this is a real margin window. 122 days remaining.",
  "created_at": "2026-07-01",
  "expires_at": "2026-10-31",
  "ttl_source": "cliff"
}
```
