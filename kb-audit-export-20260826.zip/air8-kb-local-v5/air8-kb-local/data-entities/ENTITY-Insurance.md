---
type: entity
id: ENTITY-Insurance
---
# ENTITY: Insurance

## Key Attributes
`insurer (ECIC/Coface/Allianz/Credendo/Sinosure), buyer_limit, policy_period, premium, claim_history`

## Data Source
Air8 Credit

