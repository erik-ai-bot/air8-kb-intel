---
type: entity
id: ENTITY-Factory
---
# ENTITY: Factory

## Key Attributes
`factory_id, factory_name, country, city, worker_count, sewing_lines, monthly_capacity, otd_rate, fipr, defect_rate, claim_ratio, ta_lf_score, audit_expiry_date, certifications`

## Data Source
SDU (factory_dimension, facility_performance, inspection_event, social_compliance)

