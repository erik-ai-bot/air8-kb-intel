---
type: entity
id: ENTITY-RawMaterial
---
# ENTITY: RawMaterial

## Key Attributes
`material_type, rm_supplier_name, rm_supplier_country, tier_level, traceability_status, compliance_docs (BOM BOS SDS)`

## Data Source
T4S Platform, supplier declaration

