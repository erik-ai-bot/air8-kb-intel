---
type: entity
id: ENTITY-Regulation
---
# ENTITY: Regulation

## Key Attributes
`regulation_code, jurisdiction, effective_date, scope, affected_products, affected_countries, affected_buyers`

## Data Source
This KB (Section 6)

