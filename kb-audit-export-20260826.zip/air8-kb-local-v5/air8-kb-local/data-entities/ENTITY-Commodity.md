---
type: entity
id: ENTITY-Commodity
---
# ENTITY: Commodity

## Key Attributes
`commodity_type (cotton/polyester/indigo/steel), current_price, price_trend, volatility, supply_outlook`

## Data Source
Cotlook, ICIS, LME, web search

