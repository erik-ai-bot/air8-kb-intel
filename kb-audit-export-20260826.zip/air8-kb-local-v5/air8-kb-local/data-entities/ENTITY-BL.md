---
type: entity
id: ENTITY-BL
---
# ENTITY: BL

## Key Attributes
`bl_number, shipper, consignee, port_of_loading, port_of_discharge, vessel_name, onboard_date, container_type, carrier, document_type`

## Data Source
Air8 / supplier upload

