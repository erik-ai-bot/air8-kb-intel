---
type: entity
id: ENTITY-Supplier
---
# ENTITY: Supplier

## Key Attributes
`supplier_code, company_name, country, city, year_of_establishment, owner_name, annual_turnover, main_market, product_focus, no_of_factories, no_of_employees, scorecard_rating, scorecard_rating, lane, kyc_status`

## Data Source
Air8 DB, KYC, D&B, Field Survey, Scorecard Engine

