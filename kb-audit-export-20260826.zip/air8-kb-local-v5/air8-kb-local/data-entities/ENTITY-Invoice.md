---
type: entity
id: ENTITY-Invoice
---
# ENTITY: Invoice

## Key Attributes
`invoice_number, related_po_number, supplier_code, buyer_code, invoice_date, invoice_amount, due_date, payment_terms, bank_details`

## Data Source
Air8 / supplier upload

