---
type: entity
id: ENTITY-Buyer
---
# ENTITY: Buyer

## Key Attributes
`buyer_code, buyer_name, country, industry, air8_rating, payment_days_avg, dilution_ratio, overdue_pattern, sourcing_countries, product_categories, store_count, adverse_news, credit_insurance_limit`

## Data Source
Air8 DB, PulseLink, S&P CapIQ, News pipeline
## Sub-types
LF Buyer (richer data from SDU), Non-LF Buyer, ISC Buyer
