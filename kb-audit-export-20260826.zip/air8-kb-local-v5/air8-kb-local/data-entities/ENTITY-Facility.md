---
type: entity
id: ENTITY-Facility
---
# ENTITY: Facility

## Key Attributes
`facility_id, supplier_code, buyer_code, facility_limit, utilisation, advance_ratio, pricing, tenor, insurance_coverage, product_type, approval_level, status`

## Data Source
Air8 SCF system

