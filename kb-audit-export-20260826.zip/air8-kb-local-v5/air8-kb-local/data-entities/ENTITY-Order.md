---
type: entity
id: ENTITY-Order
---
# ENTITY: Order

## Key Attributes
`po_number, buyer_code, supplier_code, factory_id, product_category, hs_code, quantity, unit_cost, total_value, currency, incoterm, payment_terms, po_date, required_shipment_date, destination_country`

## Data Source
SDU order_transaction, Air8 DB

