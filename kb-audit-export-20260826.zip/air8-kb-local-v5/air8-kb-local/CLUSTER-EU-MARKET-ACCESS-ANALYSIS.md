---
type: cluster-analysis
id: CLUSTER-EU-MARKET-ACCESS
version: 1.0
date: 2026-07-16
author: KB Engine — Subagent
cluster_events: [EVT-REGULATION:csddd_scope_expand, EVT-TARIFF:new_fta/gsp_graduation, EVT-MARKET-SHIFT:buyer_country_shift]
domain: apparel_only (Alice's domain)
combos_scored: [COMBO-002, COMBO-003, COMBO-008, COMBO-014, COMBO-005, COMBO-012, COMBO-006]
alice_corrections_applied: [B-1_gsp_plus_error, B-2_asian_espr_data, B-3_false_relief_window, B-4_24month_head_start, B-9_mandatory_buyer_question, B-10_bsci_sedex_balance]
---

# CLUSTER-EU-MARKET-ACCESS — Combined Analysis (Events B + C + BD EU Trade)
## Apparel / Soft Goods Only

> **Cluster purpose:** EU market access for apparel suppliers is shifting simultaneously across three dimensions — regulatory access, tariff access, and buyer preference. Analysing these events separately produces fragmented signals. Combined, the full sourcing reallocation logic is visible: Bangladesh EBA graduation risk + India FTA duty removal + CSDDD compliance capability differential = an observable buyer reallocation trajectory from BD → India that is already in motion.

---

## Step 1 — Event Understanding

### Combined Event Fields

| Field | Value |
|---|---|
| event_type | EVT-REGULATION + EVT-TARIFF + EVT-MARKET-SHIFT (combined cluster) |
| subtype | csddd_scope_expand + new_fta + gsp_graduation + buyer_country_shift |
| affected_buyer_geo | EU, UK |
| affected_countries | BD, IN, KH, TR, VN |
| triage_level | HIGH |
| cliff_date_B (CSDDD) | July 24 (EU consultation deadline — ⚡ ACTIVE) |
| cliff_date_C (FTA) | TBD — India-UK FTA ratification milestone (monitoring) |
| cliff_date_BD (LDC) | 2029 (EU EBA end; buyer pre-positioning begins 2027) |

### The Three Dimensions of EU Market Access

| Dimension | Event Basis | Key Question |
|---|---|---|
| **Regulatory access** | CSDDD, REACH, GPSR (Event B) | Can the supplier's product enter the EU market compliantly? |
| **Tariff access** | India-UK FTA, BD EBA/LDC graduation, KH EBA (Event C + BD EU Trade) | What duty rate applies to the supplier's goods in the EU/UK market? |
| **Buyer preference** | Sourcing shift, buyer PO reallocation (EVT-MARKET-SHIFT) | Is the buyer actively reallocating EU/UK programme spend? |

### Why Combine These Three Events

A sourcing shift from BD → India for EU/UK buyers is NOT just about the India-UK FTA. It is driven simultaneously by:
1. BD's LDC graduation risk (EBA ending post-2029)
2. India's FTA duty removal (removing India's duty disadvantage in UK)
3. CSDDD compliance capability differentials (India GOTS organic vs BD BSCI)

Running each event separately produces fragmented signals. Combined, the full reallocation logic is visible. Alice's addition: Bangladesh EU trade must be explicitly included alongside India-UK FTA — seeing BD losing access at the same time India gains it is the observable signal that matters for Air8's portfolio.

---

## Step 2 — L0/Principles Matched

### Principles Activated — Combined Event

| Principle | Event Basis | Weight | What It Checks |
|---|---|---|---|
| PRIN-COUNTRY-EXPOSURE | EVT-TARIFF (FTA/GSP graduation) | 0.50 | Country-level duty access direction — which countries gaining vs losing tariff access in EU/UK |
| PRIN-BUYER-GEO-EXPOSURE | EVT-REGULATION (CSDDD) | 0.40 | EU buyer jurisdiction — regulations apply at buyer market level; demand trend in EU market |
| PRIN-COMPLIANCE-COST | EVT-REGULATION (CSDDD) | 0.50 | Cost and timeline of compliance with CSDDD, REACH, GPSR; which combos can absorb this |
| PRIN-FINANCING-MATCH | Combined | weighted | Winners need WC pre-positioning (OBF, ARP); losers need bridge + compliance finance |
| PRIN-SUPPLIER-RESILIENCE | EVT-MARKET-SHIFT | 0.20 | Which persona archetypes are winning vs losing in the EU sourcing shift |

### Overlay Rules — ALL Apply

| Overlay | Trigger | Application |
|---|---|---|
| **RP-STRUCTURAL-CHANGE** | EBA graduation + FTA | EBA graduation = STRUCTURAL once enacted (irreversible). Individual buyer questionnaire = potentially cyclical (buyer can change requirements). S301 forced labor framing = structural once Federal Register. |
| **RP-SOURCSHIFT-01** | EVT-MARKET-SHIFT | Buyer reallocation takes 12-24 months regardless of tariff change. Pre-position Air8 in winning combos BEFORE shift fully materialises. |
| **RP-WINDOW** | CSDDD July 24 deadline | CSDDD extension to 2029 = NOT a signal to pause compliance investment. Treat as hypothesis to TEST with buyer, not assert as fact. Cliff date: consultation deadline is active. |
| **RP-CONCENTRATION** | Portfolio-level | Air8 simultaneous BD/KH exposure while India combos are beneficiaries. Net portfolio EU buyer exposure can be managed by rebalancing from losing to winning combos. |

### Alice's Corrections Applied Throughout

The following corrections from REVIEW-FOR-ALICE.md are applied throughout this analysis:

| Correction | Applied Rule |
|---|---|
| **B-1: GSP+ error** | DO NOT assert that factory certifications (BSCI, HIGG FEM, GOTS, Better Work) create GSP+ eligibility. GSP+ is a country-level trade preference scheme — government ratification of international conventions required, not factory certifications. |
| **B-2: Asian ESPR data capability** | DO NOT assert "Asian competitors cannot provide ESPR data." ASEAN + China + BD suppliers already report HIGG FEM, ZDHC, Carbon metrics for major buyers. Ask buyers directly whether they have received this data from other suppliers. |
| **B-3: False relief window** | DO NOT assert "CSDDD 2029 extension = false relief window" as an established fact. Frame as hypothesis to TEST. Ask supplier directly whether they have changed or postponed sustainability investments. |
| **B-4: 24-month head start** | DO NOT assert "factories maintaining compliance investment have a 24-month head start." No evidence for specific figure. Use open question format instead. |
| **B-9: Mandatory buyer question** | Alice's mandatory question MUST appear in Step 8 for relevant combos: "Have any EU buyers indicated future business allocation will depend on traceability, environmental reporting, or sustainability improvements over the next 24 months?" |
| **B-10: BSCI/Sedex balance** | BSCI and Sedex DO cover parts of labour and social compliance — they are not irrelevant to CSDDD. Describe accurately: they provide a foundation but do not fully satisfy CSDDD supply chain due diligence requirements. |

---

## Step 3 — Combo Routing

### Three-Dimension Scoring Table

| Combo | Duty-Free Access Direction | CSDDD Compliance Direction | Buyer Preference Trend |
|---|---|---|---|
| **COMBO-002** (BD CMT) | DETERIORATING — EBA graduation risk; post-graduation EU tariff incoming | LOW-MEDIUM — BSCI/RSC foundation but supply chain traceability gap for CSDDD | LOSING share to India and nearshore |
| **COMBO-003** (IN Large Vertical) | IMPROVING — FTA removes UK duty disadvantage; rules-of-origin compliant (domestic cotton) | STRONG — GOTS/FAIRTRADE/C2C/ROC = best-in-class CSDDD documentation head start | GAINING EU/UK allocation |
| **COMBO-008** (IN Organic Cotton Medium) | IMPROVING — FTA; rules-of-origin compliant (organic domestic cotton) | STRONGEST — farm-to-gin traceability via organic chain; GOTS + FAIRTRADE + OCS; IFC-eligible | GAINING |
| **COMBO-014** (IN Small Woven) | IMPROVING — FTA; but smaller player, slower UK buyer development | MEDIUM — woven cotton; some UFLPA traceability challenge; moderate CSDDD readiness | GAINING secondary allocation |
| **COMBO-005** (TR Denim) | STABLE — Customs Union = 0% EU duty already; no FTA benefit, no EBA graduation risk | MEDIUM-HIGH — REACH/ZDHC advanced for denim chemicals; EU regulatory alignment via Customs Union | HOLDING — speed/finishing moat; but volume under pressure (Event E) |
| **COMBO-012** (KH) | HIGH RISK — EU EBA dependent; graduation possible; EU withdrew EBA partially in 2020 | LOW — limited CSDDD preparation; compliance infrastructure gaps | LOSING |
| **COMBO-006** (VN FDI Knit) | STABLE-LOW — EU GSP access but limited; not as advantaged as India FTA | MEDIUM — HIGG FEM/ZDHC for Nike/Adidas; CSDDD moderate readiness | MIXED — US primary market; EU secondary |

**S3 eligibility:** All 7 combos score ≥ 0.35 against the combined cluster and signal ≠ MONITOR → All 7 included.

**Winners (all three dimensions positive or stable):** COMBO-003, COMBO-008, COMBO-014, COMBO-005
**Losers (deteriorating on multiple dimensions):** COMBO-002, COMBO-012
**Mixed:** COMBO-006 (US-primary; EU secondary)

---

## Step 4 — Signal Computation

### COMBO-002: Bangladesh CMT — Loser on All Three Dimensions

**Duty Signal — EBA Graduation Risk:**
- BD currently holds EU EBA duty-free access as an LDC (Least Developed Country)
- LDC graduation risk: once graduated, EU tariff applies to BD garment exports — no preferential rate
- BD government and industry actively seek EBA extension, GSP+ pathway, or bilateral arrangement
- RP-STRUCTURAL-CHANGE: EBA graduation = STRUCTURAL once enacted (government decision, irreversible without new treaty)
- RP-SOURCSHIFT-01: EU buyers may begin pre-positioning 12-24 months BEFORE graduation — observable signal is buyer RFQ behaviour
- **Duty Signal: CAUTION (deteriorating; structural once enacted)**

**CSDDD Compliance Signal:**
- BD factories have BSCI, RSC remediation (Accord/NIRACC), Better Work track record
- Alice's B-10 correction: BSCI/Sedex DO cover labour and social compliance — they are not irrelevant
- However: CSDDD requires supply chain-level due diligence documentation at a depth BSCI alone does not cover (Scope 3 emissions, full supply chain mapping, grievance mechanisms per value chain)
- BD factories: compliance infrastructure exists but gap is in traceability depth and reporting systems
- RP-WINDOW: CSDDD 2029 extension → frame as hypothesis to TEST, not false relief certainty
  - Alice's question required: "Have you changed or postponed any sustainability investments following the CSDDD timeline change?"
- **CSDDD Signal: CONDITIONAL** (BSCI foundation exists; supply chain traceability depth is the gap)

**Buyer Preference Signal:**
- EU buyers (H&M, Inditex, Primark) historically heavy BD sourcing — BD EBA has been a key driver
- India gaining: FTA removes India's UK duty disadvantage; India organic/GOTS = stronger CSDDD positioning
- BD losing: cost advantage eroding (wage hike), compliance gap, EBA graduation timeline compressing
- RP-SOURCSHIFT-01: Observable shift takes 12-24 months → pre-positioning may already be underway
- **Buyer Signal: CAUTION** (losing share directionally; shift timeline 12-24 months minimum)

**Combined Signal:**
```
COMBO-002: CAUTION (all three dimensions deteriorating or at risk)

PER_AXIS:
  Tariff access: DETERIORATING (structural once EBA graduation enacted; post-2029 horizon)
  CSDDD compliance: CONDITIONAL (foundation exists; traceability depth is gap to close)
  Buyer trend: CAUTION (losing share to India; shift in progress)

AND_IF [EU buyers explicitly communicate programme reduction OR BD EBA graduation announced]:
  Signal → REDUCE advance ratio on EU-buyer-facing facilities
  ARP maintenance: EU-bound ARP maintained (BD still has EBA until 2029)
  Compliance bridge: ESG Finance eligibility check if BD factory is actively investing in CSDDD-level traceability

TIME_SLICED:
  Now → 2027: EBA intact; CSDDD extension period; BD competitive position defended by EBA moat
  2027-2029: Buyer pre-positioning begins; EU allocation at risk; compliance investment window
  Post-2029: EBA graduation structural break; signal → DO_NOT_EXPAND unless GSP+ pathway confirmed

RP-STRUCTURAL-CHANGE: EBA graduation structural (cannot reverse post-enactment); individual buyer questionnaire cyclical
```

---

### COMBO-003: India Large Vertical Integrator — Winner on All Three Dimensions

**Duty Signal — FTA Beneficiary:**
- India-UK FTA removes 8-12% duty disadvantage for IN garment exports to UK market
- Rules-of-origin: FTA requires "substantial transformation in India" — domestic Indian fabric sourcing
- COMBO-003 (vertical integrator, domestic cotton, 10,000+ farmer base) = FULLY rules-of-origin compliant
- Factories sourcing fabric from Bangladesh or China processed in India = likely NOT FTA-eligible
- RP-STRUCTURAL-CHANGE: FTA ratification = STRUCTURAL (once enacted, permanent duty reduction)
- RP-WINDOW: Pre-ratification = action window — develop UK buyer pipeline before FTA confirms
- **Duty Signal: CONDITIONAL EXPAND** AND_IF [FTA ratified AND domestic fabric origin confirmed]
  - TIME_SLICED: Pre-ratification = CONDITIONAL; post-ratification = EXPAND

**CSDDD Compliance Signal:**
- GOTS/FAIRTRADE/C2C/ROC certifications = strongest compliance position of all 7 combos
- Farm-to-fashion traceability (10,000+ farmers) = actual CSDDD supply chain documentation proof
- Organic cotton origin = inherent non-Xinjiang traceability (cross-benefit: UFLPA compliance)
- ESG Finance eligibility likely: ≥3 certs + IFC performance standards = qualification pathway
- **CSDDD Signal: EXPAND** (best-in-class compliance = competitive moat vs all Asian origins)

**Buyer Preference Signal:**
- M&S, Next, ASOS (UK) → active India sourcing review post-FTA
- EU ESG brands (Patagonia, Pact, etc.) → GOTS = qualification criterion
- BD losing share → India gaining proportional EU allocation
- RP-SOURCSHIFT-01: 12-24 months for full volume transfer → pre-position now
- **Buyer Signal: CONDITIONAL EXPAND** (FTA pre-ratification = pre-positioning window)

**Combined Signal:**
```
COMBO-003: EXPAND AND_IF [FTA ratified OR UK buyers already active in India programme]

PER_AXIS:
  Tariff access: IMPROVING → EXPAND (pending ratification)
  CSDDD compliance: EXPAND (best-in-class; competitive moat confirmed)
  Buyer trend: CONDITIONAL EXPAND (shift underway; 12-24 month full materialisation)

TIME_SLICED:
  Pre-ratification: CONDITIONAL (develop UK buyer pipeline; pre-position OBF for cotton pre-buy)
  Post-ratification: EXPAND (M&S/Next duty saving activates; WC needs accelerate)

RP-SOURCSHIFT-01: Air8 should pre-position OBF/ARP BEFORE shift fully materialises, not after
RP-STRUCTURAL-CHANGE: FTA = structural once enacted; CSDDD compliance advantage = structural (multi-year moat)

ESG Finance: pre-qualify COMBO-003 clients now — IFC criteria likely met; ESG Finance pricing advantage
is the operational unlock for compliance investment continuation
```

---

### COMBO-008: India Organic Cotton Medium — Strongest CSDDD Position

**Duty Signal:** IMPROVING — same FTA logic as COMBO-003; organic domestic cotton = rules-of-origin compliant
**CSDDD Compliance Signal:** STRONGEST — farm-to-gin organic traceability; GOTS + FAIRTRADE + OCS; IFC eligible; buyer ESG credential validation pipeline already exists
**Buyer Signal:** GAINING — ESG-first brands (Pact, Patagonia possibility); sustainable fashion demand growing annually

**Combined Signal:**
```
COMBO-008: EXPAND (all three dimensions positive)

PER_AXIS:
  Tariff: IMPROVING → EXPAND (FTA + rules-of-origin)
  CSDDD: EXPAND (organic chain = best-in-class traceability; IFC-eligible)
  Buyer: EXPAND (ESG-first brands growing; organic demand structural trend)

TIME_SLICED:
  Pre-FTA: EXPAND on CSDDD/buyer dimension (unconditional); CONDITIONAL on tariff dimension
  Post-FTA: EXPAND across all three dimensions

Primary Air8 product: ESG Finance (pre-qualify now) + ARP + RT2C/OBF
ESG Finance: GOTS + FAIRTRADE + OCS = ≥3 certs → IFC criteria likely met → ESG Finance primary target
```

---

### COMBO-014: India Small Woven — Improving Duty, Medium Compliance, Secondary Winner

**Duty Signal:** IMPROVING — FTA benefit applies; but smaller factory, fewer UK buyer relationships to develop quickly
**CSDDD Compliance Signal:** MEDIUM — woven cotton; US market has UFLPA traceability challenge; EU compliance moderate; smaller financial capacity to invest in CSDDD systems
**Buyer Signal:** GAINING SECONDARY — UK/EU buyers diversifying India sourcing; woven = M&S/Next secondary programme category (shirts, basic wovens)

**Combined Signal:**
```
COMBO-014: CONDITIONAL (FTA benefit real; buyer development slower for smaller player)

PER_AXIS:
  Tariff: IMPROVING → CONDITIONAL (FTA benefit applies; smaller player captures benefit more slowly)
  CSDDD: MEDIUM → CONDITIONAL (no immediate compliance barrier; but capacity to invest is limited)
  Buyer: GAINING SECONDARY → CONDITIONAL (UK buyer onboarding takes 12-18 months minimum for small player)

AND_IF [UK buyer pipeline developed AND rules-of-origin confirmed]:
  Signal → CONDITIONAL → EXPAND
  Time horizon: 12-18 months post-FTA ratification for first meaningful UK revenue

Air8 action: ARP + RT2C pre-positioned for UK buyer ramp-up when FTA confirmed and first UK POs confirmed
RP-SOURCSHIFT-01: 12-24 months for meaningful volume; plan accordingly
```

---

### COMBO-005: Turkey Denim Specialist — Stable and Holding

**Duty Signal — Customs Union:**
- Turkey-EU Customs Union = 0% EU duty already in place
- Turkey has NO tariff disadvantage to overcome via FTA; NO EBA graduation risk
- Turkey's EU duty position is the strongest of all non-EU countries in this cluster
- STABLE by design; Turkey's tariff position is not at risk from this cluster's events
- **Duty Signal: STABLE** (no uplift from FTA, no risk from EBA graduation — structurally advantaged)

**CSDDD Compliance Signal:**
- Turkey has REACH compliance infrastructure (Customs Union requires EU regulatory alignment)
- ZDHC MRSL compliance advanced for denim chemical management (denim finishing chemicals are the primary REACH exposure)
- Customs Union means Turkey has been tracking EU regulations in real-time — institutional advantage
- Note from Event B: CSDDD "false relief" window = hypothesis to TEST with buyers, not assert as fact
- Note from Event E: Turkey EU apparel volume contraction (-17.83%) is a SEPARATE signal handled in Event E analysis; this cluster focuses on the structural access position, not the volume trend
- **CSDDD Signal: MEDIUM-HIGH** (REACH/ZDHC advanced; Customs Union institutional advantage; but full CSDDD supply chain depth TBD)

**Buyer Preference Signal:**
- Speed/finishing moat: 2-3 day EU shipping vs 25-30 days from Asia; laser/ozone denim finishing
- Istanbul premium factories: direct Zara/H&M relationships = structurally protected
- Volume contraction (-17%) from Event E is a CYCLICAL overlay; structural access position is STABLE
- HOLDING vs GAINING/LOSING — Turkey is not gaining EU allocation in a directional shift, but it is also not losing structural access
- **Buyer Signal: HOLDING** (nearshore speed advantage maintained; finishing moat; but volume under pressure from Event E macro demand weakness)

**Combined Signal:**
```
COMBO-005: CONDITIONAL (stable tariff, medium-high compliance, buyer trend holding with caveats)

PER_AXIS:
  Tariff access: STABLE (0% Customs Union; strongest tariff position in cluster)
  CSDDD compliance: MEDIUM-HIGH (REACH/ZDHC advanced; Customs Union regulatory alignment)
  Buyer trend: HOLDING (Istanbul premium protected; volume under pressure from Event E macro)

AND_IF [Zara/H&M continue sending buyer questionnaires]:
  Signal: maintain CONDITIONAL; CSDDD investment should continue regardless of 2029 extension
  (Question to ask: "Have you changed or postponed any sustainability investments following the CSDDD timeline change?")

AND_IF [buyer questionnaires cease and volume recovers]:
  Signal: CONDITIONAL → EXPAND on Istanbul premium only

RP-STRUCTURAL-CHANGE:
  Customs Union = structural advantage (durable; EU trade architecture)
  CSDDD 2029 extension = NOT a structural pause — buyer requirements cycle is operative deadline
  Volume contraction (-17%) from Event E = potentially cyclical; treat separately

Istanbul vs Interior: same differentiation as Event E applies here
  Istanbul premium (laser/ozone, direct Zara/H&M): CONDITIONAL
  Interior Turkey (commodity): DO_NOT_EXPAND
```

---

### COMBO-012: Cambodia — Loser on All Three Dimensions (Highest Risk)

**Duty Signal — EBA Graduation Risk:**
- KH is 100% dependent on EU EBA duty-free access; no alternative preferential access pathway
- EU previously withdrew EBA preferences partially (2020) for political/governance reasons — precedent exists
- Any political or governance deterioration can trigger EU EBA review
- KH economic diversification is limited; garment sector is dominant
- RP-STRUCTURAL-CHANGE: EBA graduation = STRUCTURAL once enacted (no reversal mechanism)
- **Duty Signal: HIGH RISK** (EBA dependent; graduation or withdrawal = existential)

**CSDDD Compliance Signal:**
- Low domestic compliance infrastructure
- Limited management capacity for CSDDD supply chain mapping
- Low financing options → compliance investment competes directly with working capital
- **CSDDD Signal: LOW** (no compliance investment underway; capacity gap)

**Buyer Preference Signal:**
- EU buyers already beginning to diversify away from KH as EBA risk increases
- CSDDD compliance gap = additional sourcing risk for EU buyers mandating compliance
- Worker wages rising annually → margin pressure compounding
- **Buyer Signal: LOSING** (EU buyer pre-positioning away from KH already underway)

**Combined Signal:**
```
COMBO-012: DO_NOT_EXPAND (all three dimensions deteriorating or at risk)

PER_AXIS:
  Tariff access: HIGH RISK (EBA graduation → structural break)
  CSDDD compliance: LOW (no near-term pathway)
  Buyer trend: LOSING (pre-positioning away from KH)

AND_IF [EBA graduation enacted]:
  Signal → DO_NOT_EXPAND confirmed; existing positions under severe review; reduce advance ratio

Cross-cluster: COMBO-012 is also in CLUSTER-US-DECOUPLING with dual EU+US threat
Net cross-cluster signal: DO_NOT_EXPAND confirmed across both clusters
This makes KH the single most negative combo across all clusters

RP-STRUCTURAL-CHANGE: both EBA graduation and CSDDD compliance gap are structural issues
No near-term reversal mechanism available for either dimension
```

---

### COMBO-006: Vietnam FDI Knit — Mixed; EU Dimension Secondary

**Duty Signal:** STABLE-LOW (EU GSP access but limited; not as advantaged as India FTA; VN-EU FTA separate and partial)
**CSDDD Compliance Signal:** MEDIUM (HIGG FEM/ZDHC for buyer compliance via Nike/Adidas programmes; CSDDD moderate readiness; parent company may have group-level ESG systems)
**Buyer Preference Signal:** MIXED (US primary market dominates this combo's signal; EU is secondary; parent company drives strategic decisions)

**Combined Signal:**
```
COMBO-006: CONDITIONAL (EU dimension is secondary; primary signal from CLUSTER-US-DECOUPLING)

Note: VN's EU dimension is SECONDARY to the US dimension captured in CLUSTER-US-DECOUPLING.
The combined signal for COMBO-006 is primarily governed by the US cluster analysis.
EU market access for VN is stable (existing FTA partial benefit) but not a growth driver.

PER_AXIS:
  Tariff: STABLE-LOW (no FTA uplift equivalent to India; GSP partial)
  CSDDD: MEDIUM (parent company ESG systems; buyer compliance programs)
  Buyer: MIXED (US primary; EU limited)

Air8 action: Monitor EU exposure; do not treat EU dimension as primary for COMBO-006
Defer to CLUSTER-US-DECOUPLING for primary signal direction on this combo
```

---

## Step 5 — Air8 Product Mapping

### Winner Combos: Pre-Position for Volume Acceleration

| Combo | Signal | Primary Products | Action |
|---|---|---|---|
| **COMBO-003** (IN Large Vertical) | EXPAND (post-FTA) / CONDITIONAL (pre-ratification) | ARP + PreShip-OBF + ESG Finance | Identify clients with existing M&S/Next/UK buyer programmes; pre-position OBF for cotton pre-buy; ESG Finance pre-qualification now |
| **COMBO-008** (IN Organic Cotton Medium) | EXPAND (all dimensions) | ESG Finance + ARP + RT2C/OBF | ESG Finance primary (IFC criteria likely met); ARP + RT2C for longer organic lead times (90-120d) |
| **COMBO-014** (IN Small Woven) | CONDITIONAL | ARP + RT2C | ARP for UK buyer onboarding; RT2C for production ramp-up when first UK POs confirmed |
| **COMBO-005** (TR Denim — Istanbul premium) | CONDITIONAL | ARP (EUR-denominated) + Pool | Maintain EUR ARP (TRY hedge); Pool for multi-buyer EU portfolio management; do NOT pre-ship OBF during volume contraction phase |

### Loser Combos: Maintenance + Compliance Bridge

| Combo | Signal | Action | Air8 Protocol |
|---|---|---|---|
| **COMBO-002** (BD CMT) | CAUTION | ARP maintenance on EU-bound; compliance bridge conversation | If CSDDD investment underway: ESG Finance eligibility check; Do NOT expand on EBA-dependent EU volume until post-2029 clarity |
| **COMBO-012** (KH) | DO_NOT_EXPAND | MiniARP existing only; no new facilities | Dual-cluster DO_NOT_EXPAND confirmed; dual-threat (EU EBA + US S301) = no expansion |
| **COMBO-006** (VN FDI) | CONDITIONAL (EU secondary) | Monitor EU exposure; primary action in US cluster | No EU-specific product expansion; defer to US cluster protocol |

---

## Step 6 — BD Pain Angles

### BD Pain Angles: Winners vs Losers Differentiated

**COMBO-003 (IN Large Vertical) — Winner Positioning:**
> "India-UK FTA removes the duty disadvantage that has been holding M&S and Next back from deepening India sourcing. Your GOTS certification and farm-to-fashion traceability is exactly what CSDDD requires at the supply chain documentation level — you are already ahead of competitors. Air8 wants to fund your UK buyer capacity build before the FTA confirms. Are you tracking which UK buyers are actively reviewing their India sourcing strategy right now?"

**COMBO-008 (IN Organic Cotton Medium) — Winner + ESG Finance:**
> "Your organic supply chain is the best CSDDD compliance position in the market. Air8's ESG Finance product is designed for suppliers like you — GOTS + FAIRTRADE certifications likely meet IFC criteria. This isn't just a compliance story; it's a pricing story. ESG Finance gives you below-market financing rates linked to your sustainability credentials. Has the recent CSDDD timeline change caused you to change, postpone, or maintain any sustainability investments?"

**COMBO-014 (IN Small Woven) — Secondary Winner:**
> "India-UK FTA is coming. M&S and Next will be looking to expand India woven sourcing beyond their existing COMBO-003 verticals. If you don't have UK buyer relationships now, this is the window to start. Air8 can support your first UK-buyer ramp-up with ARP and pre-shipment. Do you have samples or an RFQ process started with any UK buyers?"

**COMBO-005 (TR Denim — Istanbul premium) — Stable + CSDDD Angle:**
> "Your Customs Union position means your EU duty situation is already stable — you don't have an EBA graduation problem or an FTA waiting game. The question is your CSDDD compliance posture. Even with the 2029 extension, your buyers Zara and H&M remain fully in scope — their questionnaires to you won't stop. Have you changed or paused any sustainability or ZDHC compliance investments because of the CSDDD extension? The buyer timeline, not the legal date, is what matters for your programme position."

**COMBO-002 (BD CMT) — Defensive Positioning:**
> "Your EU EBA access gives you a window — but it has a known horizon. Bangladesh will lose LDC status and the duty-free EU access that comes with it. Your EU buyers are aware of this timeline. The question is whether they're pre-positioning for post-2029 sourcing now. Are any EU buyers communicating new programme requirements or asking about your sustainability credentials over the next 24 months? We need to understand what signals you're seeing."

**COMBO-012 (KH) — Risk Assessment:**
> "Your EU revenue depends on EBA access that has already been partially withdrawn before. Simultaneously, any US buyer programmes would face Section 301 risk. We need to understand your contingency if both access pathways deteriorate. What markets outside the EU are you developing? Is there a product category where Cambodia would retain a cost advantage even without preferential access?"

---

## Step 7 — S3 Inclusion

| Combo | Combined Score | Signal Direction | Included? | Rationale |
|---|---|---|---|---|
| **COMBO-003** (IN Large Vertical) | ~0.85 | EXPAND (post-FTA) | ✅ | Primary FTA winner + best CSDDD position; pre-position for M&S/Next volume surge |
| **COMBO-008** (IN Organic Cotton) | ~0.80 | EXPAND | ✅ | Strongest CSDDD position; ESG Finance primary target; organic demand structural |
| **COMBO-002** (BD CMT) | ~0.75 | CAUTION | ✅ | EBA graduation risk is the signal story; existing large book requires monitoring |
| **COMBO-005** (TR Denim) | ~0.65 | CONDITIONAL | ✅ | Customs Union stable; CSDDD compliance question active; Istanbul vs Interior dimension |
| **COMBO-014** (IN Small Woven) | ~0.65 | CONDITIONAL | ✅ | Secondary FTA beneficiary; UK buyer development window |
| **COMBO-012** (KH) | ~0.60 | DO_NOT_EXPAND | ✅ | Dual-cluster DO_NOT_EXPAND; EBA + US S301 dual threat; portfolio risk flag |
| **COMBO-006** (VN FDI) | ~0.50 | CONDITIONAL (EU secondary) | ✅ | EU dimension secondary to US cluster; included for completeness; no EU-specific action |

All 7 combos: score ≥ 0.35, signal ≠ MONITOR → All 7 included.
COMBO-012 included despite DO_NOT_EXPAND signal — existing Air8 positions must be reviewed against dual-threat; exclusion would leave KH exposure unmonitored.

---

## Step 8 — Assessment Questions

**CRITICAL RULES applied throughout:**
- Reasoning-path questions ONLY — no specific figures, no tariff rates, no percentages, no timelines
- Each question references which KB principle it serves
- Alice's mandatory buyer question appears for all EU-facing combos
- CSDDD "false relief window" framed as hypothesis to TEST, not assertion
- "Asian competitors cannot provide ESPR data" framed as buyer question, not assertion
- Alice's BSCI/GSP+ correction applied: factory certifications ≠ GSP+ eligibility

---

### COMBO-002 — Bangladesh CMT (4 Questions)

**Q1 — ALICE'S MANDATORY BUYER QUESTION (lever: Buyer Preference; signal confirmation)**
QUESTION: "Have any of your major EU buyers — H&M, Inditex, Primark, or others — communicated that future business allocation, supplier ranking, or programme participation will depend on traceability improvements, environmental reporting, or sustainability-performance improvements over the next 24 months? Have any buyer questionnaires changed in scope or depth recently?"
KB ANCHOR: EVENT-CLUSTERS.md (Alice's mandatory buyer question); PRIN-BUYER-GEO-EXPOSURE (EU buyer jurisdiction); Alice B-9
COLLECT: Any buyer questionnaire changes; buyer communication on sourcing strategy or programme review; any buyer RFQ reduction or programme audit notification
SIGNAL IMPACT:
  If buyer questionnaires expanding in scope or buyers communicating programme requirements → CSDDD compliance investment is commercially urgent; ESG Finance eligibility check activated; window is NOT false relief
  If no buyer questionnaire change → current programme stable; CSDDD extension buying time; CONDITIONAL holds

**Q2 — CSDDD FALSE RELIEF WINDOW: HYPOTHESIS TEST (lever: Regulatory; signal direction)**
QUESTION: "Following the news that the EU pushed back the CSDDD mandatory implementation timeline to 2029 — have you changed, postponed, accelerated, or maintained any sustainability investments, traceability systems, or environmental reporting initiatives as a result?"
KB ANCHOR: RP-WINDOW (CSDDD consultation deadline July 24 active); Alice B-3 (false relief window = hypothesis to test, not assert); PRIN-COMPLIANCE-COST
COLLECT: Any compliance investment decisions made since CSDDD extension announced; budget changes; any supplier questionnaire responses postponed
SIGNAL IMPACT:
  If investments postponed because of CSDDD extension → factory facing compressed timeline at buyer contract renewal; Air8 compliance bridge conversation activated
  If investments maintained despite extension → factory in stronger competitive position; CSDDD is not the constraint

**Q3 — EBA GRADUATION AWARENESS AND BUYER SIGNALS (lever: Tariff; signal direction)**
QUESTION: "The EU's EBA duty-free access for Bangladesh has a known future horizon. Are your major EU buyers aware of this timeline, and have any of them mentioned it in sourcing discussions? Are you tracking any shifts in EU buyer programme allocation — for example, new styles going to India or Turkey that previously came to Bangladesh?"
KB ANCHOR: PP-BD-003-ldc-graduation; COMBO-002: "moat_horizon 2026-2029 protected by EBA; competitive erosion post-2029"; RP-SOURCSHIFT-01 (12-24 month buyer reallocation timeline)
COLLECT: EU buyer conversation records mentioning LDC graduation or future sourcing; any allocation shift signals; any programme reduction or category exit notices
SIGNAL IMPACT:
  If buyers already mentioning EBA graduation or shifting allocation → SOURCSHIFT-01 is earlier than expected; CAUTION signal broadens; pre-2027 advance ratio review
  If buyers stable and LDC not mentioned → ARP maintenance; begin ESG positioning for post-2029 defensibility

**Q4 — BSCI FOUNDATION AND CSDDD GAP (lever: Regulatory compliance; signal calibration)**
QUESTION: "Your factory has BSCI or equivalent social compliance certifications — these cover important parts of labour and social standards. For EU buyers' CSDDD compliance purposes, they typically also need supply chain documentation one or two tiers up from your factory. Can you trace your fabric and yarn suppliers and share that traceability with buyers? Do you have documentation on your key input suppliers' labour and environmental practices?"
KB ANCHOR: PRIN-COMPLIANCE-COST (CSDDD); Alice B-10: "BSCI/Sedex DO cover parts of labour and social compliance; do not imply they have zero CSDDD relevance"
COLLECT: BSCI/Sedex certificate scope; any supply chain mapping beyond tier 1; fabric/yarn supplier documentation
SIGNAL IMPACT:
  If supply chain documentation extends to tier 2 suppliers → CSDDD gap smaller than assumed; CONDITIONAL signal; compliance bridge shorter
  If documentation is factory-level only → tier 2 gap is the actual CSDDD compliance risk; ESG Finance for documentation system investment

---

### COMBO-003 — India Large Vertical Integrator (4 Questions)

**Q1 — RULES-OF-ORIGIN COMPLIANCE (lever: Tariff/FTA; signal reversal risk)**
QUESTION: "The India-UK FTA is expected to include a rule of origin requirement — goods must undergo substantial transformation in India using Indian inputs to qualify for the duty reduction. What percentage of your fabric and yarn comes from domestic Indian sources versus imports from Bangladesh, China, or elsewhere? And specifically for your conventional cotton lines — is that fabric sourced from Indian mills?"
KB ANCHOR: PRIN-COUNTRY-EXPOSURE (FTA rules-of-origin); COMBO-003 structural nuance: "rules-of-origin clause requires domestic Indian fabric; factories using Bangladesh/China fabric processed in India may NOT qualify"; Event C simulation Q1
COLLECT: Fabric sourcing breakdown by origin country; distinction between organic domestic and conventional import; any import records for fabric
SIGNAL IMPACT:
  If domestic Indian fabric dominant (>70%) → fully FTA-eligible; EXPAND signal confirmed for UK market
  If imported fabric component significant → may NOT qualify for FTA duty reduction; signal drops to CONDITIONAL or NEUTRAL for those product lines; rules-of-origin restructuring needed

**Q2 — UK BUYER PIPELINE: WHO IS ACTIVE? (lever: Buyer Preference; magnitude)**
QUESTION: "Which UK-headquartered buyers do you currently have active programmes with — M&S, Next, ASOS, Tesco F&F? And for buyers you don't currently work with, have any of them requested samples, sent an RFQ, or initiated a qualification process since India-UK FTA negotiations became public?"
KB ANCHOR: PRIN-BUYER-GEO-EXPOSURE (UK buyer jurisdiction); RP-SOURCSHIFT-01 (buyer reallocation 12-24 months); COMBO-003: M&S programme growth signal
COLLECT: UK buyer programme list; any UK buyer new-business conversations or RFQ activity
SIGNAL IMPACT:
  If UK buyers >20% revenue already → FTA ratification = immediate WC acceleration; pre-position OBF now
  If no UK buyers yet → FTA = BD development opportunity; start pipeline now but WC acceleration is 12-24 months out; CONDITIONAL not EXPAND

**Q3 — CSDDD ADVANTAGE: BUYER REQUIREMENTS SURFACED (lever: CSDDD/Regulatory; signal confirmation)**
QUESTION: "Have any EU or UK buyers specifically asked you about your GOTS certification, farm-level traceability, or Scope 3 emissions data as part of their own CSDDD compliance requirements? Are any buyers communicating that future programme allocation will depend on sustainability or traceability credentials?"
KB ANCHOR: PRIN-COMPLIANCE-COST (CSDDD); PRIN-BUYER-GEO-EXPOSURE (EU/UK buyer jurisdiction); Alice B-9 (mandatory buyer question); Alice B-2 (do not assert Asian competitors cannot provide this data — ask buyer)
COLLECT: Any buyer questionnaire changes referencing CSDDD, traceability, or ESG performance; buyer communication on programme requirements
SIGNAL IMPACT:
  If buyers actively referencing CSDDD/traceability in programme requirements → COMBO-003's GOTS advantage is commercially active now, not 2029; EXPAND signal confirmed; ESG Finance urgency elevated
  If no buyer CSDDD questionnaires yet → CSDDD advantage is future-positioned; buyer pipeline development is the current priority; CONDITIONAL

**Q4 — ESG FINANCE ELIGIBILITY CHECK (lever: CSDDD; Air8 product)**
QUESTION: "For the Air8 ESG Finance product — eligibility requires at least three environmental or sustainability certifications meeting IFC performance standards criteria. You hold GOTS, FAIRTRADE, and C2C/ROC — can you share the current certificate status and renewal dates for each? And is your certification infrastructure maintained entirely in-house or through an external certification body?"
KB ANCHOR: PRIN-FINANCING-MATCH; SOLUTIONS.md (ESG Finance: ≥3 certs + IFC criteria); COMBO-003: "ESG credentials = competitive moat + IFC/ESG-linked financing potential"
COLLECT: GOTS certificate (current); FAIRTRADE certificate (current); C2C/ROC certificate (current); renewal schedule
SIGNAL IMPACT:
  If ≥3 certs valid and current → ESG Finance eligibility confirmed; pre-qualify now for below-market financing
  If any cert lapsed or gap exists → ESG Finance conditional on cert renewal; bridge to certification = Air8 compliance conversation

---

### COMBO-008 — India Organic Cotton Medium (3 Questions)

**Q1 — ORGANIC COTTON SUPPLY CHAIN DOCUMENTATION (lever: CSDDD + UFLPA; signal confirmation)**
QUESTION: "Your organic cotton supply chain is your strongest compliance asset. Can you trace your cotton to the field and gin level — and is that documentation maintained in a format that EU buyers or external auditors can access? Are you connected to farmer programmes where you have direct field-level data?"
KB ANCHOR: PRIN-COMPLIANCE-COST (CSDDD); TRACE-ORGANIC-ADVANTAGE; COMBO-008: "cotton traceability advantage for UFLPA; farm-level connection"; COMBO-008 connected to 500-5,000 farmers
COLLECT: Organic cotton traceability documentation; farmer programme connection (direct vs cooperative); certification chain (OCS, GOTS, FAIRTRADE) linked to farm records
SIGNAL IMPACT:
  If farm-level traceability confirmed and documented → CSDDD compliance position is strongest available; EXPAND signal confirmed; ESG Finance eligibility confirmed
  If traceability stops at spinner level → gap exists; farmer programme documentation needed for full CSDDD advantage

**Q2 — ALICE'S MANDATORY BUYER QUESTION (lever: Buyer Preference; signal confirmation)**
QUESTION: "Have any of your EU buyers communicated that future business allocation, programme participation, or supplier ranking will depend on sustainability performance, traceability improvements, or environmental reporting over the next 24 months?"
KB ANCHOR: Alice B-9 (mandatory for EU-facing combos); PRIN-BUYER-GEO-EXPOSURE; EVENT-CLUSTERS.md buyer question
COLLECT: Buyer questionnaire changes; buyer communication on sourcing programme requirements; any ESG performance score requirements
SIGNAL IMPACT:
  If buyers communicating sustainability-linked requirements → organic chain is the commercial answer; EXPAND confirmed
  If no buyer communication yet → organic advantage is future-positioned; buyer pipeline and pre-positioning is the current action

**Q3 — IFC CRITERIA AND ESG FINANCE PRE-QUALIFICATION (lever: ESG Compliance; Air8 product)**
QUESTION: "Air8's ESG Finance product requires a minimum of three environmental or sustainability certifications. You hold GOTS, FAIRTRADE, and OCS — is each of these currently valid and renewed within the last 12 months? Are there any gaps in your certification coverage that could affect eligibility?"
KB ANCHOR: PRIN-FINANCING-MATCH; SOLUTIONS.md (ESG Finance eligibility); COMBO-008: "GOTS + FAIRTRADE + OCS = IFC criteria likely met"
COLLECT: All three certification documents and renewal dates; any lapsed or conditional certifications
SIGNAL IMPACT:
  If all three certs valid → ESG Finance confirmed; this is the first product conversation
  If any cert lapsed → compliance remediation before ESG Finance; bridge the certification gap first

---

### COMBO-014 — India Small Woven (3 Questions)

**Q1 — UK BUYER DEVELOPMENT TIMELINE (lever: FTA Tariff + Buyer Preference; signal calibration)**
QUESTION: "If you're planning to approach UK buyers like M&S or Next once the India-UK FTA confirms — what is your typical timeline from first buyer conversation to first confirmed purchase order? And do you have export experience in the UK market already, or would this be a new market for you?"
KB ANCHOR: RP-SOURCSHIFT-01 (12-24 months for meaningful sourcing shift); PRIN-BUYER-GEO-EXPOSURE (UK buyer); COMBO-014: smaller player, slower buyer development
COLLECT: UK buyer development timeline; any existing UK buyer relationships; export market history
SIGNAL IMPACT:
  If 6-9 month development cycle + existing UK contacts → Air8 should pre-position RT2C and ARP now for fast onboarding once FTA confirmed
  If 18-24 month timeline + no UK contacts → CONDITIONAL; develop pipeline but no WC commitment until first confirmed PO

**Q2 — ALICE'S MANDATORY BUYER QUESTION (lever: Buyer Preference; signal calibration)**
QUESTION: "Have any of your existing EU or UK buyers communicated that future business allocation or programme participation will depend on sustainability credentials or traceability over the next 24 months? Are buyers asking questions about your cotton sourcing origin?"
KB ANCHOR: Alice B-9 (mandatory); PRIN-BUYER-GEO-EXPOSURE; UFLPA cross-signal (IN woven to US market also has UFLPA traceability consideration)
COLLECT: Buyer questionnaire changes; programme requirements communication; cotton origin questions from buyers
SIGNAL IMPACT:
  If buyers requesting sustainability/traceability → CSDDD compliance investment is commercially relevant; signal toward EXPAND
  If no buyer requirements yet → CONDITIONAL remains; UK market development is the priority lever

**Q3 — RULES-OF-ORIGIN AND FABRIC SOURCING (lever: FTA Tariff; signal qualifier)**
QUESTION: "For the India-UK FTA to apply to your woven goods, substantial transformation needs to occur in India using Indian inputs. Where does your fabric come from — Indian mills, or do you import from Bangladesh or China?"
KB ANCHOR: PRIN-COUNTRY-EXPOSURE (FTA rules-of-origin); Event C simulation Q1 rules-of-origin note
COLLECT: Fabric sourcing by origin; any import records; Indian mill relationships
SIGNAL IMPACT:
  If Indian fabric mills (domestic) → fully FTA-eligible; EXPAND signal for UK market
  If imported fabric component → FTA benefit may not apply; assess whether shifting to Indian fabric mills is economically viable

---

### COMBO-005 — Turkey Denim Specialist (4 Questions)

**Q1 — CSDDD FALSE RELIEF WINDOW: HYPOTHESIS TEST (lever: Regulatory; signal direction)**
QUESTION: "With the EU CSDDD implementation pushed back to 2029 — have you changed, postponed, accelerated, or maintained your investments in chemical compliance, sustainability reporting, or supply chain traceability as a result of that news?"
KB ANCHOR: RP-WINDOW (CSDDD July 24 consultation deadline); Alice B-3 (false relief window = hypothesis to test, not assert); PRIN-COMPLIANCE-COST
COLLECT: Any compliance investment decisions since CSDDD extension; ZDHC MRSL compliance pace; any sustainability system investments changed
SIGNAL IMPACT:
  If compliance investments postponed → factory is behind on buyer timeline even if legally compliant in 2029; buyer questionnaire is the operative deadline; CONDITIONAL signal; Air8 ESG Finance conversation activated
  If compliance investments maintained → factory in strongest position; CSDDD extension is genuine time buffer; CONDITIONAL → EXPAND eligible

**Q2 — BUYER QUESTIONNAIRE ACTIVITY (lever: Buyer Preference + CSDDD; signal confirmation)**
QUESTION: "Regardless of the CSDDD legal timeline, your buyers Zara and H&M remain fully in scope for CSDDD — they need to manage their supply chain. Have they sent you any supply chain questionnaires, audit requests, or compliance surveys in the last 12 months related to sustainability, chemical use, or supply chain due diligence? Have any other EU buyers sent such questionnaires?"
KB ANCHOR: PRIN-BUYER-GEO-EXPOSURE (EU buyers in CSDDD direct scope); Alice B-9 (mandatory buyer question); Alice B-5 (Zara/H&M compliance requirements not automatically stricter — verify)
COLLECT: Any buyer questionnaire received; any compliance audit request; buyer programme requirement communications
SIGNAL IMPACT:
  If active buyer questionnaires → buyer mandate is operative even before 2029; CSDDD compliance investment is commercially justified now; CONDITIONAL
  If no questionnaires → CSDDD pressure not yet cascaded via buyer; ESPR-2027 may be the more operative deadline (product-specific)

**Q3 — ALICE'S MANDATORY BUYER QUESTION (lever: Buyer Preference; signal direction)**
QUESTION: "Have any EU buyers communicated that future business allocation, supplier ranking, or programme participation will depend on traceability, environmental reporting, or sustainability performance over the next 24 months?"
KB ANCHOR: Alice B-9 (mandatory buyer question); PRIN-BUYER-GEO-EXPOSURE; EVENT-CLUSTERS.md
COLLECT: Buyer forward-looking programme communication; any supplier scorecard changes; quota or allocation adjustment signals
SIGNAL IMPACT:
  If buyers communicating sustainability-linked programme requirements → compliance investment is commercially justified; EXPAND eligible on Istanbul premium once documentation confirmed
  If no programme requirement communication → buyer relationship stable on current terms; volume trajectory (Event E) is the primary signal

**Q4 — ISTANBUL VS INTERIOR DIFFERENTIATION (signal calibration — applies this cluster)**
QUESTION: "Your factory is in [Istanbul / Interior Turkey]. For the CSDDD and buyer compliance discussion — do you have laser and ozone finishing capability? And within your EU buyer base, what proportion are fast fashion direct buyers (Zara, H&M) versus mid-market buyers (C&A, Primark)?"
KB ANCHOR: COMBO-005 sub-scenarios (Istanbul premium vs Interior Turkey); PRINCIPLES.md (PRIN-SUPPLIER-RESILIENCE persona differentiation); Alice review Item 1 (Istanbul vs Interior = hypothesis, validated at factory level)
COLLECT: Factory location; laser/ozone capability; buyer list with revenue split by buyer tier
SIGNAL IMPACT:
  Istanbul + laser/ozone + direct Zara/H&M → CONDITIONAL (protected segment within EU contraction)
  Interior Turkey OR no finishing moat → CAUTION / DO_NOT_EXPAND (commodity segment losing; no CSDDD differentiation)

---

### COMBO-012 — Cambodia (3 Questions)

**Q1 — EBA GRADUATION SCENARIO PLANNING (lever: Tariff; survivability)**
QUESTION: "Your EU business relies entirely on EBA duty-free access. Cambodia's EU EBA status has been reviewed before for governance-related reasons. If EU tariffs were applied to your exports — not immediately, but within a defined horizon — what would that do to your cost position versus your main competitors? Have you done any scenario modelling for post-EBA operations?"
KB ANCHOR: COMBO-012 key risk: "EBA graduation risk: existential if EBA withdrawn"; RP-STRUCTURAL-CHANGE (EBA graduation = structural)
COLLECT: Revenue split EU vs non-EU; any non-EBA buyer development; factory financial runway modelling
SIGNAL IMPACT:
  If no post-EBA plan and 100% EU dependency → DO_NOT_EXPAND confirmed; existing facilities only; reduce if advance quality deteriorates
  If credible non-EU market development underway → CONDITIONAL; contingency plan exists; re-evaluate if non-EU revenue grows meaningfully

**Q2 — ALICE'S MANDATORY BUYER QUESTION (lever: Buyer Preference; signal calibration)**
QUESTION: "Have any EU buyers communicated that future business allocation or programme participation will depend on traceability or sustainability performance improvements? Are buyers beginning to ask about your supply chain, chemical use, or environmental footprint?"
KB ANCHOR: Alice B-9 (mandatory buyer question); COMBO-012: low CSDDD compliance infrastructure
COLLECT: Any buyer questionnaire; programme requirement communication; any ESG audit request
SIGNAL IMPACT:
  If buyers requesting sustainability credentials → CSDDD compliance gap is a commercial risk now, not 2029; urgency escalated; compliance investment needed before Air8 advance expansion
  If no buyer sustainability requirements yet → commercial exposure to CSDDD is future-dated; EBA graduation remains primary near-term threat

**Q3 — DUAL CLUSTER RISK CHECK (cross-cluster signal; portfolio)**
QUESTION: "Your EU EBA access is under structural review, and at the same time US buyers face Section 301 tariff uncertainty on goods from Cambodia. How concentrated are you across these two markets? If both EU and US access deteriorated simultaneously, what markets would you pivot to, and what is your estimated timeline to develop meaningful revenue there?"
KB ANCHOR: RP-CONCENTRATION (portfolio-level dual-market risk); COMBO-012 dual-threat: "EU EBA graduation + US S301 + low compliance = worst combined position"; cross-cluster note
COLLECT: Revenue split EU/US/other; any alternative market development; financial runway estimate
SIGNAL IMPACT:
  If no alternative market and full EU+US dependency → DO_NOT_EXPAND across both clusters confirmed; existing positions at credit review risk
  If credible third-market development → timeline to diversification revenue matters; if >24 months, DO_NOT_EXPAND maintained

---

### COMBO-006 — Vietnam FDI Knit (3 Questions — EU Dimension Only)

**Q1 — EU SECONDARY MARKET EXPOSURE (signal calibration)**
QUESTION: "Your EU-buyer programmes — how significant are they relative to your US-buyer programmes? If EU buyers applied new CSDDD requirements to your production, does your current compliance infrastructure (HIGG FEM, ZDHC for Nike/Adidas) transfer to EU buyer requirements, or are there gaps?"
KB ANCHOR: PRIN-BUYER-GEO-EXPOSURE (EU vs US buyer geo); COMBO-006: "US > EU" buyer geography; PRIN-COMPLIANCE-COST (CSDDD)
COLLECT: Revenue split EU buyers vs US buyers; any EU buyer questionnaire activity; HIGG FEM level status
SIGNAL IMPACT:
  If EU <20% revenue → EU cluster dimension is secondary; US cluster analysis governs; no specific EU action
  If EU approaching 30%+ revenue → EU dimension becomes material; CSDDD compliance infrastructure check needed

**Q2 — ALICE'S MANDATORY BUYER QUESTION (EU buyers; signal calibration)**
QUESTION: "Have any EU buyers communicated that future programme allocation, ranking, or participation will depend on sustainability credentials, traceability, or environmental reporting improvements over the next 24 months?"
KB ANCHOR: Alice B-9 (mandatory); PRIN-BUYER-GEO-EXPOSURE (EU buyer jurisdiction); Alice B-2 (do not assert Asian competitors cannot provide ESPR data — ask buyer whether they have received this data from other suppliers)
COLLECT: EU buyer questionnaire activity; any programme requirement communications; comparison vs US buyer requirements
SIGNAL IMPACT:
  If EU buyers requesting sustainability credentials → CSDDD compliance gap is commercially relevant; parent company ESG systems may cover this; check group-level reporting
  If no EU buyer sustainability requirements → EU dimension is stable; US cluster remains primary signal

**Q3 — ESPR AND BUYER DATA CAPABILITY (lever: Regulatory; do not assert Asian capability gap)**
QUESTION: "Some EU buyers are beginning to ask for ESPR Digital Product Passport data and Scope 3 emissions reporting. Have any of your EU buyers made these requests? And separately — have other suppliers in your category provided this data to these buyers already?"
KB ANCHOR: Alice B-2: "DO NOT assert Asian competitors cannot provide ESPR data"; ASEAN/China/BD suppliers already report HIGG/ZDHC; ask buyer directly; PRIN-COMPLIANCE-COST
COLLECT: Any ESPR/DPP data requests from EU buyers; buyer communication on which suppliers have provided sustainability data; group-level sustainability reporting capability
SIGNAL IMPACT:
  If buyers have received data from other Asian suppliers → competitive landscape is not Turkey-vs-Asia; actual data capability gap must be verified, not assumed
  If buyers have NOT yet requested data → ESPR is future-dated; buyer-driven timeline not yet active

---

## Step 9 — Final Insight Card + Signal Derivation

### Root Cause Narrative

EU market access for apparel suppliers is undergoing a three-dimensional structural shift. The India-UK FTA (removing India's duty disadvantage) and Bangladesh EBA graduation risk (ending BD's duty-free access) operate simultaneously as tariff forces — and the direction of each is opposite. At the same time, CSDDD compliance capability differentials are creating a compliance-driven sourcing selection criterion on top of tariff economics. The result is a systematic reallocation of EU/UK buyer PO spend from Bangladesh (all three dimensions deteriorating) toward India (all three dimensions improving), with Cambodia at highest structural risk (both tariff levers deteriorating) and Turkey holding its position via the Customs Union moat.

### Three-Dimension Signal Derivation

```
CLUSTER-EU-MARKET-ACCESS Signal Derivation

Dimension 1 — Tariff Access:
  BD: DETERIORATING (EBA graduation → EU tariff) ← structural, irreversible once enacted
  IN: IMPROVING (FTA → duty removal in UK) ← structural once FTA ratified
  KH: HIGH RISK (EBA dependent) ← structural risk; precedent for withdrawal in 2020
  TR: STABLE (Customs Union 0% already) ← structurally protected
  VN: STABLE-LOW (GSP partial) ← no material shift in this cluster

Dimension 2 — CSDDD Compliance:
  IN (COMBO-003, 008): STRONGEST (organic + GOTS + farm-to-gin traceability) ← structural moat
  TR (COMBO-005): MEDIUM-HIGH (Customs Union alignment + REACH/ZDHC) ← institutional advantage
  BD (COMBO-002): LOW-MEDIUM (BSCI foundation; supply chain traceability depth gap)
  IN (COMBO-014): MEDIUM
  VN (COMBO-006): MEDIUM (buyer programme compliance)
  KH (COMBO-012): LOW ← no investment capacity; no pathway

Dimension 3 — Buyer Preference:
  IN (all combos): GAINING ← FTA + CSDDD driving buyer pre-positioning
  TR (COMBO-005): HOLDING ← speed/finishing moat; Istanbul premium protected
  BD (COMBO-002): LOSING ← India gaining relative position
  KH (COMBO-012): LOSING ← EU buyers pre-positioning away
  VN (COMBO-006): MIXED ← US primary; EU limited

Combined signal per combo:
  COMBO-003 (IN Large): EXPAND (all three dimensions positive; post-FTA trigger)
  COMBO-008 (IN Organic): EXPAND (strongest CSDDD + gaining + FTA)
  COMBO-014 (IN Small): CONDITIONAL (FTA + gaining secondary; buyer development slower)
  COMBO-005 (TR Denim): CONDITIONAL (Customs Union stable; Istanbul protected)
  COMBO-002 (BD CMT): CAUTION (all three dimensions deteriorating; maintain not expand)
  COMBO-012 (KH): DO_NOT_EXPAND (dual-cluster; all dimensions deteriorating)
  COMBO-006 (VN FDI): CONDITIONAL EU dimension (US primary; refer to US cluster for primary signal)
```

### Observable Sourcing Shift: BD → India

The BD → India trajectory is the observable signal that ties all three dimensions together:
- BD EBA graduation risk removes the tariff moat that has kept BD competitive
- India FTA removes India's duty disadvantage (India was penalised vs BD EBA in UK; that changes)
- CSDDD compliance capability favours India GOTS organic factories over BD BSCI factories
- RP-SOURCSHIFT-01 confirms: this shift takes 12-24 months to fully materialise
- Pre-position India combos before the shift materialises, not after

**Cambodia risk vs Bangladesh risk:**
KH is at higher structural risk than BD for two reasons: (1) KH is FULLY EBA-dependent with no alternative tariff access pathway, whereas BD has some GSP+ negotiation options; (2) KH has lower compliance infrastructure and less economic diversification capacity. BD retains its EBA access until 2029 minimum, giving it a bridge period. KH has no confirmed bridge.

### Air8 Portfolio Action

1. **Pre-position India combos NOW** (before FTA ratification, not after):
   - COMBO-003: OBF pre-position for UK buyer pipeline; ESG Finance pre-qualification
   - COMBO-008: ESG Finance primary; ARP + RT2C for growing organic demand
   - COMBO-014: ARP ready for UK buyer onboarding at FTA confirmation

2. **Maintain Turkey positions** (Istanbul premium only):
   - EUR-denominated ARP maintained; Pool for multi-buyer portfolio
   - Do NOT expand into Interior Turkey; do NOT pre-ship OBF during volume contraction

3. **Maintain BD positions, do NOT expand**:
   - EU-bound ARP maintained (EBA still intact until 2029)
   - Surface CSDDD compliance investment opportunity if buyer questionnaires received
   - Begin ESG compliance positioning for post-2029 defensibility window

4. **Hold KH to MiniARP existing only**:
   - DO_NOT_EXPAND confirmed; cross-cluster signal consistent
   - Dual-threat (EBA + S301) = no expansion rationale exists

### Gaps for Runtime Web Search

The following facts should be fetched at runtime — NOT stored in KB:

| Gap | Why Needed | Runtime Search |
|---|---|---|
| India-UK FTA ratification status and timeline | Cliff date for EXPAND signal on IN combos | UK/India government trade announcements |
| India-UK FTA rules-of-origin clause (domestic vs substantial transformation) | Determines which IN factories are FTA-eligible | UK Department for Business and Trade FTA text |
| Bangladesh LDC graduation precise timeline | Confirms 2029 as operative cliff for BD EU tariff | EU/WTO LDC graduation schedule |
| Cambodia EBA status — current EU review underway? | Determines urgency of KH DO_NOT_EXPAND signal | EU Trade for Development announcements |
| CSDDD product-specific DPP/ESPR requirements by textile category | Alice B-7: not all textile requirements take effect simultaneously | EU DPP delegated acts; ESPR product categories |
| Current Zara/H&M/Primark supplier questionnaire scope changes | Operative buyer deadline for CSDDD compliance | Buyer sustainability reports; programme requirement updates |
| BD government EBA negotiation progress | May extend BD EBA timeline or create GSP+ pathway | Bangladesh Commerce Ministry; WTO trade policy review |
