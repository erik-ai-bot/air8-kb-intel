---
type: linkage
id: LINKAGE-PERSONA
---
# Linkage: Persona → Full Linkage Table (Section 8.1)

| Combo | Pain Points | Products | Compliance |
|-------|------------|----------|------------|
| [[../layer-2-entities/personas/COMBO-001-south-asian-small-knit\|COMBO-001]] | PP-001,002,003,004,006 + PP-BD/IN/PK | ARP, RT2C, PayGuard | UFLPA(cotton→US), REACH(EU), CSDDD |
| [[../layer-2-entities/personas/COMBO-002-bangladesh-bank-lc\|COMBO-002]] | PP-001,002,004,005 + PP-BD-001,002,003 | ARP, RT2C, PayGuard | UFLPA(if US), REACH(if EU), Accord/RSC |
| [[../layer-2-entities/personas/COMBO-003-india-large-vertical-integrator\|COMBO-003]] | PP-001,002,005 + PP-IN-001,002 + PP-ESG-001 | ARP, OBF, Pool, SmartWallet, ESG-Finance | UFLPA(advantage:organic), CSDDD, REACH |
| [[../layer-2-entities/personas/COMBO-004-china-medium-woven\|COMBO-004]] | PP-001,002 + PP-CN-001,002,003 | ARP(Hengqin), SmartWallet, Pool | UFLPA(high), REACH, CSDDD, SAFE |
| [[../layer-2-entities/personas/COMBO-005-turkey-denim-specialist\|COMBO-005]] | PP-001,002,003 + PP-TR-001,002 | ARP(USD), Pool | REACH(highest:chemicals), CSDDD |
| [[../layer-2-entities/personas/COMBO-006-vietnam-fdi-knit\|COMBO-006]] | PP-001,004 + PP-VN-001 | ARP(parent pitch), PayGuard | UFLPA(if cotton), CSDDD |
| [[../layer-2-entities/personas/COMBO-007-indonesia-family-run\|COMBO-007]] | PP-001,002,003,006 + PP-IDN-001 | MiniARP → ARP | UFLPA(if cotton), REACH, GPSR |
| [[../layer-2-entities/personas/COMBO-008-india-organic-cotton-medium\|COMBO-008]] | PP-001,002,005 + PP-IN-001,002 + PP-ESG-001 | ARP, RT2C/OBF, ESG-Finance, SmartWallet | UFLPA(advantage), CSDDD, REACH |
| [[../layer-2-entities/personas/COMBO-009-pakistan-home-textile\|COMBO-009]] | PP-001,002 + PP-PK-001,002 | ARP, Pool | UFLPA(cotton), REACH(fire retardants) |
| [[../layer-2-entities/personas/COMBO-010-existing-client-expansion\|COMBO-010]] | PP-EXPAND-001,002,003 | Whatever they lack | Depends on new buyer/market |
| [[../layer-2-entities/personas/COMBO-011-trader-sourcing-agent\|COMBO-011]] | PP-001,006 + PP-TRADER | Back-to-Back TCS | OPS-KYC-002 third-party prohibition |
| [[../layer-2-entities/personas/COMBO-012-cambodia-eba-dependent\|COMBO-012]] | PP-001,002 + PP-KH-001 | ARP, MiniARP | EBA preference risk, CSDDD |
| [[../layer-2-entities/personas/COMBO-013-multi-country-group\|COMBO-013]] | PP-001,002,005 + PP-LARGE | ARP(multi), DDP, Pool, SmartWallet | ALL regs × ALL countries in group |
| [[../layer-2-entities/personas/COMBO-014-india-small-woven\|COMBO-014]] | PP-001,002,003,005 + PP-IN-001,002 | ARP, RT2C | UFLPA(if cotton→US), REACH(if EU) |
| [[../layer-2-entities/personas/COMBO-015-micro-first-time\|COMBO-015]] | PP-001,006 + PP-MICRO | MiniARP (if eligible) | Basic compliance only |
