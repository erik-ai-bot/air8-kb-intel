---
type: linkage
id: LINKAGE-PRODUCT-REVERSE
---
# Linkage: Product → Reverse (Pain Points + Combos) (Section 8.4)

| Product | Solves Pain Points | Best Fit Combos | Pre-conditions |
|---------|-------------------|-----------------|----------------|
| [[../layer-2-entities/financing-products/PROD-ARP\|ARP]] | PP-001, PP-002 | ALL (001–015) | Eligible buyer pair + insurance |
| [[../layer-2-entities/financing-products/PROD-MINIARP\|MiniARP]] | PP-001, PP-006 | 007, 012, 015 | Revenue >$1M, ops >2yr |
| [[../layer-2-entities/financing-products/PROD-PRESHIP-OBF\|PreShip-OBF]] | PP-005 | 003, 008, 013 | Revenue >$10M, existing ARP |
| [[../layer-2-entities/financing-products/PROD-PRESHIP-RT2C\|PreShip-RT2C]] | PP-005 | 001, 002, 008, 014 | Revenue >$1M, existing ARP 6mo+ |
| [[../layer-2-entities/financing-products/PROD-PAYGUARD\|PayGuard]] | PP-003, PP-004 | 001, 003, 006 | Buyer distress signal |
| [[../layer-2-entities/financing-products/PROD-POOL\|Pool Factoring]] | PP-001, PP-002 | 003, 004, 009, 013 | 5+ buyers, $20M+ revenue |
| [[../layer-2-entities/financing-products/PROD-SMARTWALLET\|SmartWallet]] | PP-001 (visibility) | 003, 004, 008, 013 | 3+ buyers, finance team exists |
| [[../layer-2-entities/financing-products/PROD-ESG-FINANCING\|ESG Financing]] | PP-ESG-001 | 003, 008 | ≥3 ESG certs, IFC criteria met |
| [[../layer-2-entities/financing-products/PROD-DDP\|DDP Financing]] | PP-005 (DDP) | 013 | Incoterm = DDP/DDU |
