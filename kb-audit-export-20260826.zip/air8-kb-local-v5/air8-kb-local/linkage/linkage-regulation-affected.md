---
type: linkage
id: LINKAGE-REGULATION
---
# Linkage: Regulation → Affected Entities (Section 8.2)

| Regulation | Countries | Products | Combos | Cascade Start |
|-----------|-----------|----------|--------|---------------|
| [[../regulations/REG-UFLPA\|UFLPA]] | CN(highest), BD, IN, PK, VN | Cotton knit, woven, denim, home | 001-005,008,009,014 | PP-REG-UFLPA-001 |
| [[../regulations/REG-REACH\|REACH]] | TR(highest), CN, BD, IN | Denim, chemical-finish, children's, home | 001,004,005,008,009,014 | PP-REG-REACH-001 |
| [[../regulations/REG-CSDDD\|CSDDD]] | ALL | ALL products | ALL with EU market | PP-REG-CSDDD-001 |
| [[../regulations/REG-GPSR\|GPSR]] | ALL | ALL consumer products to EU | ALL with EU market | Shipment rejection |
| [[../regulations/REG-S211\|S-211]] | ALL | ALL to Canada | Combos with Canadian buyers | Annual reporting |
| [[../regulations/REG-TARIFF\|Section 301]] | CN(direct), IN(new 50%) | ALL to US | 004(CN), 014(IN) | PP-REG-TARIFF-001 |
| BD LDC graduation | BD only | ALL BD→EU | 002, 012 | PP-BD-003 |
