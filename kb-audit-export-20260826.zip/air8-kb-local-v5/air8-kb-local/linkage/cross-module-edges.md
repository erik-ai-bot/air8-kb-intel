# Cross-Module Edges — Full Link Tables

> Updated: 2026-07-01 | Maintained by: Jerri Zhou + Snowman
> These are the edges the cascade WALKS for routing and impact analysis.
> Format is DB-ready: each section is a relationship table.

---

## Edge Schema Definition

Every edge entry must conform to:
```yaml
- from: <node_id>
  to: <node_id>
  type: <edge_type>
  weight: <0.0-1.0>
  confidence: expert | llm_generated | derived
  freshness: stable | annual | quarterly
  rationale: "<brief reason>"
```

**Edge type enum:**
- `sources_from` — Combo → Country (factory sources raw material from this origin)
- `sells_to` — Combo → BuyerType (factory sells to this buyer type)
- `product_combo` — Product ↔ Combo (product serves this combo; bidirectional)
- `pain_combo` — Pain ↔ Combo (pain point applies to this combo)
- `event_regulation` — EventType → Regulation (event activates this regulation file)
- `governed_by` — Action → RiskRule (Air8 action governed by this risk principle)
- `country_ref` — Combo → Country file (combo references this country context file)

---

## Top 5 Critical Edges (YAML format — India cotton event cluster)

```yaml
edges:
  - from: COMBO-002
    to: country:IN
    type: sources_from
    weight: 0.85
    confidence: expert
    freshness: annual
    rationale: "BD imports ~60-85% of cotton/yarn from India; primary dependency. Expert-validated (Alice KB)."

  - from: COMBO-003
    to: country:IN
    type: sources_from
    weight: 0.55
    confidence: expert
    freshness: annual
    rationale: "India Vertical buys domestic MSP cotton (~55% of COGS); import duty events affect imported share only."

  - from: COMBO-008
    to: country:IN
    type: sources_from
    weight: 0.95
    confidence: expert
    freshness: stable
    rationale: "GOTS certified organic: must use 100% domestic certified cotton. India-only source. Import duty events = NEUTRAL for GOTS lines."

  - from: COMBO-009
    to: country:IN
    type: sources_from
    weight: 0.20
    confidence: derived
    freshness: annual
    rationale: "PK sources mainly domestic ELS cotton. India only secondary for some non-ELS yarn. India duty events = competitive THREAT to PK, not benefit."

  - from: COMBO-003
    to: PROD-PRESHIP-OBF
    type: product_combo
    weight: 0.90
    confidence: expert
    freshness: stable
    rationale: "India Vertical is the primary OBF use case: cotton procurement, cliff window, 120-180d self-liquidation. Core product fit."
```

---

## Edge Types

| Edge Type | Direction | Meaning | Used In |
|---|---|---|---|
| `sources_from` | Combo → Country | Factory sources raw material from this origin | S1 indirect impact walk |
| `sells_to` | Combo → BuyerType | Factory sells to this buyer type | S1 buyer event propagation |
| `product_combo` | Product ↔ Combo | Product serves this combo (bidirectional) | S2/S3 product recommendation |
| `pain_combo` | Pain ↔ Combo | Pain point applies to this combo | S2 pain matching |
| `event_regulation` | Event → Regulation | Event activates this regulation file | S1 compliance routing |
| `governed_by` | Action → Risk Rule | Air8 action governed by this risk principle | S1/S3 risk gate |

---

## 1. sources_from Edges (Raw Material Dependency)

> Walk logic: event affects country:X → walk sources_from:X → find indirectly affected combos

| combo_id | sources_from | weight | material | notes |
|---|---|---|---|---|
| COMBO-001 | country:IN | 0.70 | cotton/yarn | SA small knit India-dependent |
| COMBO-001 | country:CN | 0.30 | yarn | secondary source |
| COMBO-002 | country:IN | 0.85 | cotton/yarn | BD ~60% yarn from India |
| COMBO-002 | country:CN | 0.40 | yarn | secondary |
| COMBO-002 | country:PK | 0.25 | yarn | tertiary |
| COMBO-003 | country:IN | 0.55 | domestic cotton | MSP-supported domestic |
| COMBO-003 | country:US | 0.30 | imported cotton | Pima/upland |
| COMBO-003 | country:AU | 0.15 | imported cotton | Pima |
| COMBO-004 | country:CN | 0.70 | Keqiao fabric | dominant self-sourcing |
| COMBO-004 | country:IN | 0.20 | yarn | indirect via Keqiao mills |
| COMBO-005 | country:TR | 0.75 | denim fabric | Turkish mills (Iskur, Calik) |
| COMBO-005 | country:JP | 0.25 | premium denim | Kaihara for premium lines |
| COMBO-006 | country:CN | 0.45 | yarn/fabric | FDI factory, CN-sourced inputs |
| COMBO-006 | country:VN | 0.35 | yarn | local VN spinning |
| COMBO-007 | country:CN | 0.50 | yarn/fabric | IDN factory CN-dependent |
| COMBO-007 | country:IN | 0.30 | yarn | secondary |
| COMBO-008 | country:IN | 0.95 | domestic organic cotton | GOTS: must be domestic certified |
| COMBO-009 | country:PK | 0.80 | domestic PK cotton | PK is cotton producer |
| COMBO-009 | country:IN | 0.20 | yarn | secondary for some lines |
| COMBO-012 | country:CN | 0.50 | yarn/fabric | Cambodia CN-dependent |
| COMBO-012 | country:IN | 0.30 | yarn | secondary |
| COMBO-014 | country:IN | 0.70 | domestic cotton/yarn | small woven, domestic-heavy |

---

## 2. sells_to Edges (Buyer Type)

> Walk logic: buyer event for type X → walk sells_to:X with weight ≥0.6 → activate those combos

| combo_id | sells_to | weight | buyer_examples | notes |
|---|---|---|---|---|
| COMBO-001 | EUDiscountRetail | 0.80 | Primark, Lidl | primary market |
| COMBO-001 | USMassMarket | 0.50 | Walmart | secondary |
| COMBO-002 | EUDiscountRetail | 0.85 | Primark, Lidl, Aldi, Walmart EU | primary |
| COMBO-002 | EUFastFashion | 0.60 | H&M | stretch — requires ESG investment |
| COMBO-002 | USMassMarket | 0.45 | Walmart US | declining |
| COMBO-003 | ESGBrand | 0.90 | Patagonia, Pact, EILEEN FISHER | primary |
| COMBO-003 | GlobalFashion | 0.75 | H&M, M&S | secondary |
| COMBO-004 | EUFastFashion | 0.90 | Zara, H&M | primary |
| COMBO-004 | GlobalDTCBrand | 0.70 | Allbirds, Everlane | growing |
| COMBO-004 | USMassMarket | 0.25 | Walmart US | DECLINING — do not expand |
| COMBO-005 | EUFastFashion | 0.95 | Zara, H&M Denim | dominant |
| COMBO-005 | EUMidMarket | 0.75 | Primark, C&A | secondary |
| COMBO-005 | USPremiumDenim | 0.35 | Madewell, J.Crew | niche |
| COMBO-006 | USGlobalBrand | 0.90 | Nike, Adidas | primary |
| COMBO-006 | EUFastFashion | 0.45 | H&M | secondary |
| COMBO-007 | USMassMarket | 0.55 | Walmart, Target | primary |
| COMBO-007 | EUMidMarket | 0.45 | C&A | secondary |
| COMBO-008 | ESGBrand | 0.95 | Pact, EILEEN FISHER | primary — organic only |
| COMBO-008 | EUFastFashion | 0.50 | H&M Conscious | secondary |
| COMBO-009 | USMassMarket | 0.85 | Walmart, Costco, Target | primary — home textile |
| COMBO-009 | EUHomeRetail | 0.70 | IKEA, H&M Home | secondary |
| COMBO-012 | EUDiscountRetail | 0.80 | Primark, Lidl | primary — EBA dependent |
| COMBO-012 | EUFastFashion | 0.55 | H&M | secondary |
| COMBO-014 | USMassMarket | 0.70 | Walmart | primary |
| COMBO-014 | EUMidMarket | 0.65 | C&A, Marks & Spencer | secondary |

---

## 3. product_combo Links (Bidirectional — DB-ready)

> Single source of truth for product↔combo relationships.
> Source in products: combo references the product. Source in combos: product_ref + condition.
> This table is the JOIN between both.

| product_id | combo_id | weight | rank | stage | condition_summary |
|---|---|---|---|---|---|
| PROD-ARP | COMBO-001 | 0.90 | primary | post_shipment | Entry; replaces bank LC |
| PROD-ARP | COMBO-002 | 0.95 | primary | post_shipment | Core entry; replaces BD bank LC 13.5-18% |
| PROD-ARP | COMBO-003 | 0.85 | primary | post_shipment | Large vertical; pool eligible |
| PROD-ARP | COMBO-004 | 0.85 | primary | post_shipment | Hengqin entity; ≤40% CN portfolio |
| PROD-ARP | COMBO-005 | 0.90 | primary | post_shipment | EUR-denominated; self-hedges TRY |
| PROD-ARP | COMBO-006 | 0.90 | primary | post_shipment | Parent HQ sign-off required |
| PROD-ARP | COMBO-007 | 0.65 | secondary | post_shipment | Upgrade from MiniARP |
| PROD-ARP | COMBO-008 | 0.75 | secondary | post_shipment | Base facility; ESG overlay available |
| PROD-ARP | COMBO-009 | 0.90 | primary | post_shipment | Replace bank LC; not additive |
| PROD-ARP | COMBO-010 | 0.90 | primary | post_shipment | Existing; expand wallet share |
| PROD-ARP | COMBO-011 | 0.70 | primary | post_shipment | Trader TCS with recourse only |
| PROD-ARP | COMBO-012 | 0.65 | secondary | post_shipment | After MiniARP track record |
| PROD-ARP | COMBO-013 | 0.90 | primary | post_shipment | Multi-entity; separate KYC per country |
| PROD-ARP | COMBO-014 | 0.90 | primary | post_shipment | Additive to bank OD; no collateral |
| PROD-MINIARP | COMBO-001 | 0.65 | secondary | post_shipment | If revenue <$5M |
| PROD-MINIARP | COMBO-007 | 0.80 | primary | post_shipment | Entry for family-run; lower KYC burden |
| PROD-MINIARP | COMBO-012 | 0.85 | primary | post_shipment | Entry for EBA-dependent small factory |
| PROD-MINIARP | COMBO-015 | 0.90 | primary | post_shipment | Only eligible product; hard gate check first |
| PROD-POOL | COMBO-003 | 0.70 | secondary | post_shipment | Revenue >$50M; 5+ buyer pairs |
| PROD-POOL | COMBO-004 | 0.65 | secondary | post_shipment | Deliberately diversified buyer base |
| PROD-POOL | COMBO-009 | 0.65 | secondary | post_shipment | Multiple US+EU home textile buyers |
| PROD-POOL | COMBO-010 | 0.70 | secondary | post_shipment | Existing client; simplify admin |
| PROD-POOL | COMBO-013 | 0.80 | primary | post_shipment | Group-level facility across entities |
| PROD-PRESHIP-OBF | COMBO-003 | 0.90 | primary | pre_shipment | Cotton procurement; duty window |
| PROD-PRESHIP-OBF | COMBO-004 | 0.75 | secondary | pre_shipment | Keqiao fabric pre-buy; speed orders |
| PROD-PRESHIP-OBF | COMBO-005 | 0.80 | primary | pre_shipment | Denim fabric pre-buy; reorder model |
| PROD-PRESHIP-OBF | COMBO-006 | 0.65 | secondary | pre_shipment | Capacity ramp for China+1 inflow |
| PROD-PRESHIP-OBF | COMBO-008 | 0.80 | primary | pre_shipment | Organic cotton seasonal procurement |
| PROD-PRESHIP-RT2C | COMBO-001 | 0.50 | tertiary | pre_shipment | After ARP track record established |
| PROD-PRESHIP-RT2C | COMBO-002 | 0.70 | secondary | pre_shipment | Back-to-back LC replacement; 6mo track record |
| PROD-PRESHIP-RT2C | COMBO-010 | 0.65 | secondary | pre_shipment | Natural upgrade for existing client |
| PROD-PRESHIP-RT2C | COMBO-014 | 0.65 | secondary | pre_shipment | Bridges GST refund lag |
| PROD-PRESHIP-RT2C | COMBO-015 | 0.45 | future | pre_shipment | After MiniARP → ARP → RT2C progression |
| PROD-PAYGUARD | COMBO-002 | 0.55 | tertiary | post_shipment | If top 2 buyers >50% and distress signals |
| PROD-PAYGUARD | COMBO-005 | 0.65 | secondary | post_shipment | EU fast fashion concentration >60% |
| PROD-PAYGUARD | COMBO-006 | 0.50 | tertiary | post_shipment | US brand concentration check |
| PROD-ESG-FINANCING | COMBO-003 | 0.80 | secondary | post_shipment | GOTS/BCI certified; IFC eligible |
| PROD-ESG-FINANCING | COMBO-005 | 0.60 | tertiary | post_shipment | ZDHC/CSDDD compliant |
| PROD-ESG-FINANCING | COMBO-008 | 0.95 | primary | post_shipment | Core ESG product; GOTS prerequisite met |
| PROD-ESG-FINANCING | COMBO-012 | 0.50 | tertiary | post_shipment | GSP+ compliance pathway |
| PROD-DDP | COMBO-004 | 0.55 | tertiary | pre_shipment | EU DDP for premium buyers |
| PROD-DDP | COMBO-013 | 0.60 | secondary | pre_shipment | Complex international DDP structures |
| PROD-SMARTWALLET | COMBO-003 | 0.65 | tertiary | ongoing | Revenue >$30M; CFO exists |
| PROD-SMARTWALLET | COMBO-004 | 0.70 | secondary | ongoing | Tech-ready; KAM system; 5+ buyers |
| PROD-SMARTWALLET | COMBO-010 | 0.60 | secondary | ongoing | Existing client; embed Air8 in ops |
| PROD-SMARTWALLET | COMBO-013 | 0.70 | secondary | ongoing | Multi-entity cash management |

---

## 4. pain_combo Links (Pain → Combo Applicability)

| pain_id | combo_ids | intensity | notes |
|---|---|---|---|
| PP-001-cashflow-gap | ALL | HIGH | Universal — every combo has this pain |
| PP-002-financing-cost | COMBO-001,002,007,009,012,014,015 | HIGH | Most acute for bank-dependent combos |
| PP-003-buyer-concentration | COMBO-001,002,005,006,009,012 | HIGH | Top 2 buyers >40% revenue |
| PP-004-scalability-constraint | COMBO-001,002,006,007,012,014 | MEDIUM | Cash gap prevents new orders |
| PP-005-preshipment-capital | COMBO-002,003,004,005,008,009 | HIGH | Yarn/fabric pre-buy requirement |
| PP-006-trade-finance-literacy | COMBO-007,012,015 | HIGH | First-time/family-run factories |
| PP-007-dilution-deductions | COMBO-001,002,003,004,005 | MEDIUM | Buyer deductions on receivables |
| PP-BD-001-wage-hike | COMBO-001,002 | CRITICAL | BD minimum wage +56% 2024 |
| PP-BD-002-political-instability | COMBO-002 | MEDIUM | BD hartal/disruption |
| PP-BD-003-ldc-graduation | COMBO-001,002,012 | CRITICAL | EU EBA transition risk |
| PP-CN-001-safe-complexity | COMBO-004 | MEDIUM | SAFE cross-border |
| PP-CN-002-sinosure | COMBO-004 | MEDIUM | Monthly declaration burden |
| PP-CN-003-hengqin-cap | COMBO-004,013 | LOW | Internal Air8 cap |
| PP-IN-001-gst-refund | COMBO-003,008,014 | MEDIUM | 30-90d GST lock-up |
| PP-IN-002-bank-od-cost | COMBO-003,008,014 | HIGH | 12-18% OD rate |
| PP-IN-003-inr-depreciation | COMBO-003,008,014 | MEDIUM | INR FX risk |
| PP-TR-001-lira-inflation | COMBO-005 | CRITICAL | 300%+ TRY inflation |
| PP-TR-002-bank-contraction | COMBO-005 | HIGH | Turkish bank credit reducing |
| PP-VN-001-fdi-authority | COMBO-006 | MEDIUM | Parent HQ decision |
| PP-PK-001-energy-crisis | COMBO-009 | CRITICAL | 2x energy cost vs peers |
| PP-IDN-001-rupiah | COMBO-007 | MEDIUM | IDR/USD volatility |
| PP-ESG-001-credentials-not-monetized | COMBO-003,008 | HIGH | ESG cert not reflected in pricing |
| PP-ESG-002-buyer-esg-escalating | COMBO-002,004,005,012 | HIGH | Buyer ESG requirements rising |

---

## 5. event_regulation Links (Event Type → Regulation Files)

| event_subtype | regulation_files | routing_note |
|---|---|---|
| environmental_compliance | REG-REACH.md, REG-CSDDD.md | Load for EU-selling combos |
| traceability | REG-UFLPA.md, REG-S211.md | Load for US-selling combos with cotton |
| labor_standards | REG-CSDDD.md, REG-S211.md, REG-NYFASHION.md | Load for EU/US combos |
| product_safety | REG-GPSR.md, REG-REACH.md | Load for hardgoods or chemical-intensive |
| import_export_duty | REG-TARIFF.md | Load for all duty events |
| trade_agreement | REG-TARIFF.md, REG-CSDDD.md | Load for EBA/GSP+ events |

---

## Edge Weight Formula

```
edge_weight = base_strength × confidence × recency_factor

base_strength:  0.30 (weak) | 0.60 (moderate) | 0.90 (strong)
confidence:     expert=1.0  | llm_generated=0.7 | derived=0.5
recency_factor: stable=1.0  | annual=max(1 - months/24, 0.5) | quarterly=max(1 - months/6, 0.3)
```

---

## ⚠️ Edges Pending Expert Validation

| Edge | Default | Validate With | Priority |
|---|---|---|---|
| COMBO-002 sources_from:IN weight | 0.85 (60% yarn) | Alice / Jerri | HIGH |
| COMBO-003 sources_from:IN vs US/AU split | 0.55/0.30/0.15 | Alice | HIGH |
| COMBO-005 sells_to:EUFastFashion weight | 0.95 | BD team | HIGH |
| All product_combo weights 0.50-0.65 | Low-confidence | Alice + Jerri | MEDIUM |
