---
type: linkage
id: LINKAGE-EVENTS
---
# Linkage: Event → Impact Propagation (Section 8.3)

## Trace 1: "Cotton price rises 15%"
```
Entity: COMMODITY (cotton)
→ AFFECTS: Raw Material cost for ALL cotton products
→ TRIGGERS: PP-005 intensity increase
→ AFFECTS COMBOS: 001,002,003,004,005,008,009,014,015
→ SECONDARY: supplier may use lower-grade cotton → claim risk rises
→ SECONDARY: vertical integrators (003,008) LESS affected (own cotton sourcing)
→ DATA TO MONITOR: commodity.cotton_price (Cotlook A-Index)
```

## Trace 2: "Bangladesh political crisis escalates"
```
Entity: COUNTRY (BD)
→ TRIGGERS: PP-BD-002 (production disruption)
→ AFFECTS COMBOS: 002 directly, 001 partially
→ SECONDARY: OTD drops → scorecard degrades → facility terms worsen
→ SECONDARY: buyers shift to India/Vietnam → COMBO-008,014,006 surge demand
→ TERTIARY: India/Vietnam absorb → PP-004 triggers for new orders
→ DATA TO MONITOR: news.bangladesh_political, sdu.otd_trend_bd
```

## Trace 3: "ECHA adds new SVHC affecting denim"
```
Entity: REGULATION (REACH)
→ TRIGGERS: PP-REG-REACH-001 for ALL denim→EU
→ AFFECTS COMBOS: 005 (Turkey denim) most directly
→ SECONDARY: re-testing cost $2-5K per factory → PP-002
→ SECONDARY: shipment detained → invoice unpayable → Air8 AR at risk
→ TERTIARY: buyer pauses orders → PP-003 (revenue gap)
→ DATA TO MONITOR: regulation.echa_svhc_list, sdu.item_level_compliance
```

## Trace 4: "Existing client Pratibha Syntex wants to expand"
```
Entity: SUPPLIER (Air8 client, India Large Vertical Integrator)
→ MATCHES: COMBO-003 + COMBO-010
→ ACTIVE: PP-EXPAND-001 (wallet share ~26%), PP-EXPAND-002 (ARP only)
→ PRODUCTS NEEDED: OBF (vertical integrator = massive pre-ship need),
    Pool (20+ buyers), SmartWallet (multi-buyer CFO),
    ESG Financing (C2C + GOTS + Fairtrade + ROC = IFC eligible)
→ COMPLIANCE VALUE: UFLPA advantage (organic = inherent traceability)
```
