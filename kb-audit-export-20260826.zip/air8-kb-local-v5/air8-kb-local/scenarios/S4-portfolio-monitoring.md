# S4: Portfolio Monitoring (Scheduled Cross-Reference)

> Scenario Type: S4 | Direction: Portfolio-wide | Owner: Jerri Zhou + Risk Team | Updated: 2026-07-01
> Track: C — Portfolio Monitoring | Position: Standalone (scheduled, periodic)
> Trigger: Scheduled OR S1 MONITOR signal (not CAUTION/DO_NOT_EXPAND — those go to S5)
> Expert Validation: invoke kb-expert-review after generating portfolio report

---

## Trigger

Scheduled runs (weekly / monthly / quarterly) or:
- A significant S1 event has been cached that affects multiple combos
- Credit team requests portfolio exposure report for a specific event/risk
- New S1 event activates and risk team wants to know existing client exposure

---

## LLM Flow

```
Step 1: DEFINE SCOPE
  Input: 
    - Active S1 events in cache (or new event to cross-reference)
    - Portfolio of existing Air8 clients (COMBO type + facility size + tenor)
    - Requested analysis type (event exposure / country concentration / commodity concentration)
  Output: scoped analysis request

Step 2: CROSS-REFERENCE EVENT × PORTFOLIO
  Action: for each active S1 event, identify which client combos are impacted
  KB reads: S1 Active Event Cache, _links/cross-module-edges.md
  Logic:
    - Direct match: client's COMBO matches event's primary impacted combos
    - Indirect match: client sources from affected country (sources_from edge)
    - Sells-to match: client sells to buyer type affected by buyer event (sells_to edge)
  Output: impact matrix (event × client, with signal and magnitude)

Step 3: COMPUTE CONCENTRATION METRICS
  Action:
    a. Single-commodity exposure: % of portfolio book exposed to one material
    b. Country concentration: % of book in one source country
    c. Buyer concentration: % of book secured by top-5 buyers
  KB reads: L0-principles/risk-principles.md (concentration caps)
  Output: concentration metrics vs thresholds

Step 4: APPLY RISK RULES
  Action:
    - Single commodity >30% → alert
    - Country concentration > threshold → alert
    - Cliff event within 30 days → urgent review for affected positions
    - Any client with 2+ deteriorating monitoring signals → escalate
  KB reads: L0-principles/risk-principles.md
  Output: risk flags + escalation list

Step 5: GENERATE PORTFOLIO SIGNAL
  Action:
    a. For each flagged client: determine action (monitor / reduce ratio / proactive conversation)
    b. For benefiting clients: determine expansion opportunity
    c. New BD opportunity: combos NOT in portfolio that benefit from active event
  Output: Portfolio Action Report

Step 6: COMPOSE REPORT
  Action: produce tiered report:
    Tier A (urgent): clients requiring immediate action (cliff, >2 signals, concentration breach)
    Tier B (watch): clients to monitor monthly
    Tier C (opportunity): non-clients to target for S2 outreach based on active event
  Output: S4 Portfolio Monitoring Report
```

---

## P0 Guidance (Always Check)

**P0-1: Cliff Urgency**
Any portfolio position with tenor that would cross an active event's cliff date → flag as URGENT. Calculate exactly: cliff_date - tenor_days - 5_day_buffer = latest_safe_booking_date. If past this date → escalate immediately.

**P0-2: Concentration Caps**
Always compute single-commodity, single-country, and single-buyer-type concentrations before making any expand recommendations. The system is designed to prevent portfolio-level concentration even when individual signals are positive.

**P0-3: Edge Walk for Indirect Exposure**
Do not only check direct COMBO matches. Run the edge walk:
- India cotton event → check all clients with `sources_from:IN` edge, not just IN clients
- US tariff event → check all clients with `sells_to:USMassMarket` edge ≥ 0.5 weight

**P0-4: Opportunity Generation**
S4 must always produce a Tier C list. If an active event benefits COMBO-003 (IN Vertical) and we have no IN Vertical clients → flag as S2 outreach opportunity, link to active S1 event cache for "Why Now" hook.

**P0-4b: Survivor Bias — Cluster Stress Check (RP-PEER-FAILURE)**
When ≥2 combos in the same country show CAUTION/DO_NOT_EXPAND signals in the same S4 run:
- Load `_reasoning/primitives.md` → RP-PEER-FAILURE and trigger for ALL remaining combos in that country
- Ask: are the "healthy" factories in that country genuinely differentiated, or are they "not-yet-failed"?
- If same structural causes present across cluster → escalate ALL country positions to CAUTION review
- Flag: "Cluster stress detected in [country] — survivor bias check required on all active positions"
- This prevents the portfolio from over-concentrating in factories that appear healthy only because their peers failed first

**P0-5: Signal Decay**
Events in the Active Event Cache expire. Check TTL:
- Regulation events: 90 days default
- Financial (FX/rate): 30 days default
- Commodity: 60 days default
- Geopolitical: 45 days default
- Events with cliff date: expire at cliff_date
Remove expired events from cache before running S4.

---

## Output Template Reference
Portfolio Action Report format (inline — no separate template required):

```
S4 PORTFOLIO MONITORING REPORT
Date: [YYYY-MM-DD]
Active Events Analyzed: [N]
Clients Cross-Referenced: [N]

TIER A — URGENT (N clients)
  [Client A]: [COMBO type] | Signal: CAUTION | Reason: [specific trigger] | Action: [specific]
  
TIER B — WATCH (N clients)
  [Client B]: [COMBO type] | Signal: MONITOR | Review Frequency: [monthly/quarterly]
  
TIER C — OPPORTUNITY (N non-clients)
  [COMBO type] benefits from [Event]. Active cache hook: "[Why Now text]"
  Target: [country/product description] → route to S2 Round 1

CONCENTRATION METRICS
  Commodity exposure (cotton): [X]% | Cap: 30% | Status: [OK / ALERT]
  Country exposure (BD): [X]% | Status: [OK / ALERT]
  
CLIFF ALERTS
  [List any active cliff dates within 30 days]
```

---

## Quality Gates

| Gate | Check | Failure Action |
|---|---|---|
| G1 | All active S1 cache events included | Pull from cache before running |
| G2 | Edge walk performed (not just direct match) | Required — indirect exposure is often bigger |
| G3 | Concentration metrics computed | Required — prevents expand errors |
| G4 | Expired events removed from cache | Required — stale signals corrupt analysis |
| G5 | Tier C opportunity list generated | Required — S4 always produces new leads |

---

## Expert Validation (After S4 Output)

```yaml
invoke: kb-expert-review
input:
  result_type: risk_assessment
  archetype: [portfolio-level]
  claims: [LOGIC_ANGLE_VIEW claims with KB source refs]
  threshold: [from _meta/expert-review-config.json]
output:
  validated_result
  kb_updates_applied
  pending_items
```

# See skills/kb-expert-review/SKILL.md for all routing, scoring, and KB update logic.
# This scenario file does not duplicate that logic — it only calls the skill.
