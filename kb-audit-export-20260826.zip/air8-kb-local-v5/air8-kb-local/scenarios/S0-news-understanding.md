# S0: News Understanding (Pre-Cascade Intake Layer)

> Scenario Type: S0 | Direction: Input Pre-Processing | Owner: Jerri Zhou | Updated: 2026-07-01

---

## Role

S0 is the **PRE-S1 layer**. It handles raw unstructured input — news articles, regulatory PDFs, WhatsApp messages, market reports — and decides: is this relevant? If yes, it standardises the signal into a structured **Trigger Payload** for S1 to consume.

S0 does NOT produce BD cards or insights. It produces clean, validated JSON for S1.

---

## Trigger

Any unstructured text input:
- News article or headline
- Regulatory notice or PDF
- WhatsApp forwarded message
- Market report excerpt
- Broker note or circular
- Buyer financial announcement

---

## LLM Flow (5 Steps)

```
Step 1: RELEVANCE FILTER
  Input: raw text
  Action: determine whether this text contains any signal that could affect
          Air8's 6 event domains:
            1. Regulation (import duty, compliance, trade agreement)
            2. Financial (buyer distress, FX move, bank policy)
            3. Commodity (cotton price, denim price, energy cost)
            4. Geopolitical (tariff, sanctions, sourcing shift)
            5. Buyer (H&M, Walmart, Zara — sourcing strategy, payment, M&A)
            6. Supply Chain (port disruption, logistics, lead time)
  Output: YES / NO + confidence score (0.0–1.0)
  Rule: If confidence < 0.5 → LOG and DISCARD; do not proceed to Step 2
  Quality gate G1: relevance filter passed

Step 2: ENTITY EXTRACTION
  Input: text that passed G1
  Action: extract all available structured fields:
    - country: [list of affected countries]
    - material: [cotton, denim, yarn, fabric, polyester, etc.]
    - regulation_name: [if named regulation/policy]
    - effective_date: [when the event takes effect]
    - cliff_date: [hard deadline if applicable, e.g. tariff end date]
    - magnitude: [estimated % impact, if quantifiable]
    - affected_buyer_types: [EU fast fashion, US mass market, etc.]
    - affected_archetype: [CMT, FOB, Vertical — if determinable]
  Rule: At minimum, either country OR material must be extractable to proceed
  Output: partial or full entity dict
  Quality gate G2: entity extraction complete (country OR material required)

Step 3: EVENT CLASSIFICATION
  Input: extracted entities
  Action: map to tag_dictionary.md controlled vocabulary
    → assign event_type (from 6 domains above)
    → assign event_subtype (from tag_dictionary enum)
    → assign confidence per classification (0.0–1.0)
  KB reads: _meta/tag_dictionary.md
  Output: event_type + event_subtype + classification_confidence
  Quality gate G3: event_type classified with confidence score

Step 4: TRIAGE ASSESSMENT
  Input: entities + event classification
  Action: assign triage level:
    HIGH: triggers full S1 cascade immediately
      Conditions: cliff event present OR magnitude >5% OR affects multiple country+combo combinations
    MEDIUM: S1 cascade at lower priority (queue, not immediate)
      Conditions: affects 1-2 combos OR magnitude unclear but directionally meaningful
    LOW: log to watch list, no S1 cascade
      Conditions: speculative/early signal, single market, <2% magnitude, no cliff
  Output: triage_level (HIGH | MEDIUM | LOW) + rationale
  Quality gate G4: triage level assigned

Step 5: STANDARDISE → TRIGGER PAYLOAD
  Input: all above outputs
  Action: assemble structured JSON Trigger Payload for S1
  Output: Trigger Payload JSON (see format below)
```

---

## Trigger Payload Format (Output for S1)

```json
{
  "source": "news_article | regulatory_pdf | whatsapp | market_report | other",
  "source_date": "YYYY-MM-DD",
  "raw_excerpt": "first 200 chars of source text",
  "event_type": "Regulation | Financial | Commodity | Geopolitical | Buyer | SupplyChain",
  "event_subtype": "<from tag_dictionary.md controlled vocab>",
  "classification_confidence": 0.85,
  "country": ["IN", "BD"],
  "material": ["cotton"],
  "regulation_name": "India Cotton Import Duty Reduction (optional)",
  "effective_date": "2026-06-01",
  "cliff_date": "2026-10-31 (if applicable, else null)",
  "magnitude_pct": 5.0,
  "affected_buyer_types": ["EUDiscountRetail", "USMassMarket"],
  "triage_level": "HIGH | MEDIUM | LOW",
  "triage_rationale": "Cliff date present AND magnitude >5% → HIGH",
  "s1_ready": true
}
```

---

## P0 Guidance (Always Check)

**P0-1: Never Trigger S1 Without Classification Confidence ≥ 0.80**
If classification_confidence < 0.80 on event_type → do NOT set s1_ready: true. Route to human review queue with a note: "Event detected but classification uncertain. Confidence: [X]. Manual review required before cascade."

**P0-2: Cliff Date Extraction is Critical**
Any mention of a specific end date, expiry date, tariff sunset, or deadline → extract as cliff_date. Do not embed in narrative text. Cliff dates trigger HIGH triage automatically.

**P0-3: Magnitude vs Speculative Language**
If source uses words like "may", "could", "expected to", "possible" → reduce confidence by 0.2. Apply MEDIUM or LOW triage unless a cliff date is present.

**P0-4: WhatsApp / Forwarded Message Handling**
These often lack dates and sources. Apply strict confidence floor. Never emit HIGH triage from a WhatsApp-only source without corroboration from a second source.

**P0-5: Discard Rule**
LOG discards. Don't silently drop. Format: `{ "status": "DISCARDED", "reason": "relevance_confidence < 0.5", "raw_excerpt": "..." }`

---

## Quality Gates

| Gate | Check | Failure Action |
|---|---|---|
| G1 | Relevance filter passed (confidence ≥ 0.5) | LOG and DISCARD; stop here |
| G2 | Entity extraction complete: country OR material present | FLAG; request additional context |
| G3 | event_type classified with confidence score | If confidence <0.80 → human review queue; do NOT cascade |
| G4 | Triage level assigned with rationale | Required before payload output |

---

## Output

On success: Trigger Payload JSON → pass to S1 Step 1
On discard: log entry with reason
On human review queue: flagged payload with confidence and uncertainty note

→ See S1-event-insights.md for how S1 consumes the Trigger Payload
