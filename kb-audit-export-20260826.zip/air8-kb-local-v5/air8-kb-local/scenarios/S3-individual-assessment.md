# S3: Individual Supplier Assessment (Drill-Down)

> Scenario Type: S3 | Direction: Drill-down from generic signal | Owner: Jerri Zhou | Updated: 2026-07-01
> Updated: 2026-07-14 — WHAT TO DO added to output; PENDING SCENARIOS logic added for unanswered dims
> Track: A — Event-triggered | Position: Step 4 of 4 (S0 → S1 → S5 → S3)
> Triggered by: S5 (batch supplier impact) — NOT triggered directly by BD
> Input: platform data + web enrichment + client Q+doc answers (gaps from S5 Phase 6-7)
> Expert Validation: invoke kb-expert-review after generating S3 assessment (EV2)
>   ≥ 0.85 confidence → auto-pass to Dual Output
>   < 0.85 → route to domain expert → feedback loop → re-score → KB gap flag

## File Linkage
> Output template: `_templates/S3-assessment-questions.md` — read for every S3 output card
> Question framework: `_meta/assessment-question-framework.md` — MANDATORY read at Step 3
> Orchestration: `air8-kb-v2-LLM-SKILL.md` — master rules and CHANGELOG

---

## Trigger

One of:
- S1 cascade produced a generic signal for a combo → BD needs to assess a specific named supplier
- BD has a specific supplier they want to evaluate against the current event landscape
- Credit team needs to assess an existing client’s risk profile given a new development

## Combo Inclusion Rule (Which Combos Reach S3)

Not every activated combo requires individual assessment. Apply this filter after S1 Step 3:

```
Include in S3 (show in Steps 8–9) IF:
  combo_score ≥ 0.35 (secondary threshold)
  AND signal ≠ MONITOR

Exclude (track in S4 only) IF:
  signal = MONITOR (insufficient data for action)
  OR combo_score < 0.35

Rationale: MONITOR = "no specific Air8 action required yet"
            Everything else = Air8 has a specific decision to make
```

**In practice per event:**
- HIGH-impact events: typically 3–5 combos reach S3
- MEDIUM-impact events: typically 2–3 combos
- Narrow events: 1–2 combos
- MONITOR-only combos: appear in S4 portfolio monitoring, not S3

**Why this matters:** Using "top 2 by score" is wrong — a combo scoring 0.52 with signal CONDITIONAL is more important than a combo scoring 0.71 with signal MONITOR. The signal type, not just the score, determines whether individual assessment is needed.

---

## LLM Flow

```
Step 1: IDENTIFY BASELINE
  Input: supplier name + country + basic identity
  Action: match to COMBO instance
  KB reads: _meta/scenario_routing.md → personas/instances/COMBO-XXX.md
  Output: matched COMBO + confidence

Step 2: LOAD ACTIVE SIGNALS
  Action: check _runtime/active_events.json for active events affecting this combo
  Output: list of active events with generic signals (EXPAND/CAUTION/etc.) + why_hook

Step 3: GENERATE ASSESSMENT QUESTIONS (3-step process)
  Input: COMBO.assessment_dimensions + active event list

  Step A — Load event-type angle framework:
    KB reads: _meta/assessment-question-framework.md
    Match: trigger.event_type → select relevant angle set
    (RM / Regulation / Buyer / Financial / Geopolitical)
    For compound events: combine angle sets + deduplicate angles

  Step B — KB cross-reference:
    For each angle, read COMBO.structural_nuances
    Identify which nuances make the angle question more specific
    Rewrite generic angle question → specific question using KB nuances

  Step C — Order by signal-flip potential:
    1. Questions that reverse the signal (most important first)
    2. Questions that quantify magnitude
    3. Questions that affect Air8 product structure (tenor, eligibility)
    4. Monitoring / watchlist questions

  Output: 4–6 questions per combo, each with:
    - question text (specific, not generic)
    - KB anchor (which nuance/principle triggered it)
    - collect (specific documents)
    - signal_impact (if A → X; if B → Y)

Step 4: COLLECT SUPPLIER DATA
  Action: BD conducts call/meeting, collects answers to question set
  Output: populated data points per dimension

Step 5: SHARPEN SIGNAL
  Input: generic signal + supplier answers
  Action:
    a. Replace generic defaults with actual values
    b. Check signal_flip_conditions from COMBO node
    c. Recompute signal with real data
  Output: supplier-specific signal + delta from generic

Step 6: MAP AIR8 ACTION
  Input: supplier-specific signal + COMBO.air8_products
  Action: load PROD-XXX.md eligibility → confirm product fit
  Output: specific Air8 recommendation (product + limit range + tenor)

Step 7: COMPOSE ASSESSMENT CARD
  Output: individual assessment with:
    - Generic signal vs specific signal (and what caused the difference)
    - Key data points that determined the signal
    - Air8 recommendation
    - Monitoring triggers

  WHAT TO DO section — REQUIRED in every S3 output:
    Four sub-sections, grounded in THIS supplier's confirmed answers (NOT copied from S1 generic actions):
    1. IMMEDIATE — action specific to THIS supplier's confirmed situation and timing
    2. COMMERCIAL — pricing/contract based on their actual buyer mix and contract type
    3. COMPETITIVE — peer positioning based on their actual product lines and certs
    4. WC / AIR8 — their specific OBF schedule and WC plan based on confirmed exposure
    State as facts using actual data from supplier answers (e.g. "Your 30% organic lines don't benefit;
    focus your 70% conventional cotton procurement before Jul 27")

  PENDING SCENARIOS rule (for unanswered dims):
    For any assessment dimension that is still unanswered (PROVISIONAL):
      - Generate one PENDING SCENARIO block per unanswered dim
      - Block format:
          Dim [X] — pending. Assumed [default].
          If [answer A] → [signal / action stays or changes — be specific]
          If [answer B] → [signal flips to / action changes to — be specific]
          Priority: HIGH (if this answer could flip the signal) | LOW (if magnitude only)
      - Purpose: shows Air8 what's at stake while waiting; prioritizes which gap to chase first
    If ALL dims are answered → OMIT PENDING SCENARIOS entirely from output.
    State all conclusions as confirmed facts in WHAT TO DO section.
```

---

## ⚡ Event × Dimension Matrix - How to Generate Assessment Questions

> **See `_meta/assessment-question-framework.md` for full angle sets per event type.** The framework file defines: which angles to probe per event type, how to cross-reference combo `structural_nuances` to make questions specific, and quality standards (generic question vs KB-anchored question).

This matrix shows which dimensions activate per event type. The framework file shows how to generate specific questions from those dimensions.

### Step-by-Step Formula

```
FOR each assessment_dimension in COMBO.assessment_dimensions:

  1. CHECK: Is this dimension affected by the active event?
     Use the mapping table below.

  2. IF YES → generate a 3-part question block:

     QUESTION: "[Specific question scoped to event context]"
     COLLECT:  "[Specific documents or data to request]"
     IMPACT:   "If [answer A] → signal = [X] because [reason from structural_nuance]
                If [answer B] → signal flips to [Y] because [signal_flip_condition]"

  3. ORDER questions by signal-flip potential:
     Priority 1: dimensions where one answer completely reverses the signal
     Priority 2: dimensions that quantify the magnitude of benefit/risk
     Priority 3: dimensions that affect Air8 product structure (tenor, eligibility)
     Priority 4: dimensions that are monitoring signals (not decision-critical today)
```

### Event Type × Dimension Mapping

Which dimensions get activated for which event types:

| Event Type | Key Dimensions to Activate |
|---|---|
| `import_export_duty` | buyer_nominated_pct, import_vs_domestic_blend, organic_vs_conventional, buyer_passthrough_terms, stockpile_plan |
| `commodity_price` | sourcing_origin_pct, buyer_nominated_pct, supply_contract_type, forward_buying_position |
| `buyer_credit_event` | buyer_concentration_pct, dso_trend, buyer_anchor_quality, replacement_pipeline |
| `sourcing_strategy_shift` | buyer_geo_mix, us_vs_eu_revenue_pct, capacity_headroom, has_target_country_entity |
| `market_entry_exit` | sells_to_buyer_type, buyer_geo_mix, product_category_fit, existing_buyer_relationship |
| `fx_rate` | revenue_currency_pct, cost_currency_pct, eur_invoice_pct, hedging_in_place |
| `trade_agreement` | eu_revenue_pct, ldc_graduation_preparedness, gsp_plus_status, alternative_buyer_geo |
| `political_instability` | bank_od_utilisation, buyer_relationship_stability, production_disruption_days |
| `logistics_disruption` | shipment_lead_time, port_dependency, air_freight_option, buyer_tolerance |
| `supplier_consolidation` | buyer_scorecard_standing, esg_certification_status, otd_score, quality_score |
| `environmental_compliance` | certification_status, compliance_gap, buyer_mandatory_date, remediation_budget |

---

### Worked Example: India Cotton Duty (import_export_duty) × COMBO-003 (IN Vertical)

**Active event:** India cotton duty cut, 11% → 0%, cliff Oct 31

**Step 1 - Check which dims are activated:**
- `buyer_nominated_vs_own_sourced` → YES (duty saving only flows through if factory buys directly)
- `import_vs_domestic_blend` → YES (saving applies to imported portion only)
- `organic_vs_conventional_split` → YES (organic lines use domestic cotton - duty irrelevant)
- `buyer_passthrough_terms` → YES (determines how much saving the factory keeps)
- `stockpile_plan_if_cliff_event` → YES (cliff = Oct 31; over-stockpiling risk)

**Step 2 - Generate question blocks (ordered by signal-flip potential):**

```
Q1 [Priority 1 - signal reversal risk]
QUESTION: "Do you buy raw cotton directly from farmers and traders, or do you purchase
           pre-spun yarn or finished fabric?"
COLLECT:  Cotton purchase orders (last 12 months) showing raw cotton vs yarn/fabric
IMPACT:   If buys raw cotton directly → formula activates; proceed to Q2
          If buys yarn/fabric → duty saving = ZERO; signal flips from EXPAND to NEUTRAL
          (structural_nuance: "Duty saving only applies to raw cotton purchases, not yarn")

Q2 [Priority 2 - magnitude quantification]
QUESTION: "What % of your cotton is imported vs domestic MSP cotton this season?"
COLLECT:  Procurement breakdown by origin (% imported vs domestic MSP, by volume)
IMPACT:   If 100% imported → full 11% saving on all cotton COGS
          If 50% imported → saving applies to 50% only → recalculate: 11% × 50% × COGS%
          (structural_nuance: "Blend: domestic + imported; duty saving on imported ONLY")

Q3 [Priority 2 - scope of savings]
QUESTION: "What % of your production lines are GOTS organic certified, and what % conventional?"
COLLECT:  GOTS certificate (scope), revenue breakdown organic vs conventional lines
IMPACT:   If 100% GOTS organic → signal flips to NEUTRAL (uses domestic certified cotton only)
          If 30% organic / 70% conventional → apply formula to conventional COGS only
          (structural_nuance: "GOTS organic lines CANNOT use imported conventional cotton")

Q4 [Priority 3 - factory keeps saving or buyer takes it]
QUESTION: "Are your supply contracts with buyers fixed-price seasonal, or cost-plus/variable?"
COLLECT:  Contract pricing clause or buyer correspondence on cost adjustments
IMPACT:   If fixed-price → 0% passthrough; factory retains full saving
          If cost-plus → calculate passthrough %; net saving = gross × (1 - passthrough%)
          (L0 principle RP-MATERIAL-01: buyer_passthrough quantification required)

Q5 [Priority 3 - Air8 tenor structure]
QUESTION: "Do you plan to stockpile cotton before October 31? How many months above normal?"
COLLECT:  Procurement forward plan (Sep-Oct); bank OD headroom if stockpile needs bridge
IMPACT:   If 1-2x normal → manageable; OBF tenor ≤ 90d, front-load Jun-Aug
          If 3-5x normal → CAUTION; post-cliff WC stress; require WC plan before expanding
          (L0 principle RP-TARIFF-CLIFF-01: over-stockpiling = post-cliff WC stress)
```

---

### Worked Example: Buyer Sourcing Shift × COMBO-002 (BD CMT)

**Active event:** H&M China+1 - shifting 30% of basics to Bangladesh

**Step 1 - Check which dims are activated:**
- `buyer_nominated_pct` → YES (if H&M nominates, savings and control remain with H&M)
- `eu_revenue_pct` → YES (H&M is EU buyer - validates or extends LDC risk)
- `compliance_certification_status` → YES (H&M consolidation criteria = ESG score)
- `has_india_entity` → YES (if BD group has India entity, different playbook)

**Step 2 - Generate question blocks:**

```
Q1 [Priority 1]
QUESTION: "Is H&M currently a buyer, and if so what % of your revenue?"
COLLECT:  H&M order schedule, revenue breakdown by buyer
IMPACT:   If H&M ≥ 20% → strong EXPAND signal (direct beneficiary)
          If H&M = 0% → assess whether to target H&M BD programme (BD outreach opportunity)

Q2 [Priority 1 - compliance determines retention]
QUESTION: "What compliance certifications do you hold? BSCI, Sedex, HIGG - which audit tier?"
COLLECT:  Latest audit certificates and scores
IMPACT:   If HIGG FEM + BSCI at high score → strong fit for H&M consolidation preference
          If basic BSCI only → risk of being cut from H&M vendor list, not beneficiary
          (structural_nuance: "compliance invisibility - factory doesn't know its scorecard standing")

Q3 [Priority 2]
QUESTION: "What is your current production capacity utilisation %?"
COLLECT:  Monthly production capacity vs actual output (last 3 months)
IMPACT:   If < 70% utilisation → can absorb new H&M volume; EXPAND signal confirmed
          If > 90% utilisation → would need capital investment to fulfil; conditional only
```

---

## P0 Guidance (Always Check)

**P0-1: Event Context First**
Before generating questions, always state the active event and generic signal for context:
"Active event: [title]. Generic signal for [COMBO]: [signal]. Now assessing: [supplier name]."

**P0-2: Dimension Activation Transparency**
For each question, explicitly tag which assessment_dimension and which structural_nuance triggered it. This is the "why we're asking" that makes the assessment credible to the supplier.

**P0-3: Question Order = Signal Priority**
Questions that can completely reverse the signal come first. Never bury a signal-reversal question at Q4 or Q5 - if the answer to Q1 is "we buy yarn not cotton" the whole assessment changes.

**P0-4: Generic vs Specific Signal Comparison**
Always conclude with:
"Generic signal for [COMBO-XXX]: [signal]
Specific signal for [supplier name] after assessment: [signal]
Key differentiator: [which data point caused the difference, if any]"

**P0-5: Unanswered Dimensions**
If supplier did not answer a dimension → state the default assumption explicitly:
"Assumed [default] for [dimension] - not confirmed. Flag for follow-up before final recommendation."

**P0-6: ABC Options at Authoring Time**
When an expert is building or reviewing assessment_dimensions for a COMBO (KB authoring, not runtime):
- Generate A/B/C alternative framings of each dimension question
- Expert picks the clearest one and validates the impact mapping
- This improves KB quality without adding cognitive load at runtime

---

## Output Template

```
INDIVIDUAL SUPPLIER ASSESSMENT
Supplier: [Name] | COMBO Match: [COMBO-XXX] | Date: [YYYY-MM-DD]
Active Event: [Title] | Generic Signal: [SIGNAL]

QUESTION SET (Event: [event] × Combo: [COMBO-XXX])
Q1: [question] | Collect: [what] | Impact: [if A → X; if B → Y]
Q2: [question] | Collect: [what] | Impact: [if A → X; if B → Y]
Q3: [question] | Collect: [what] | Impact: [if A → X; if B → Y]
Q4: [question] | Collect: [what] | Impact: [if A → X; if B → Y]
Q5: [question] | Collect: [what] | Impact: [if A → X; if B → Y]

SUPPLIER ANSWERS
[After BD call - populate here]

SIGNAL COMPUTATION
Generic: [COMBO signal] | Actual: [supplier-specific signal]
Key flip trigger (if any): [dimension + answer + rule applied]

AIR8 RECOMMENDATION
Product: [PROD-XXX] | Estimated limit: $X-Y | Tenor: ≤Xd
Risk basis: [from product risk_reduction_narrative]
Condition: [what must be confirmed before proceeding]

MONITORING TRIGGERS
[List 2-3 signals that would change the recommendation]
```

---

## 2026-07-14 OUTPUT RULES (MANDATORY — apply every S3 run)

### WHAT TO DO section — REQUIRED in every S3 output card
Generate after SIGNAL COMPUTATION. Must be grounded in THIS supplier's confirmed answers.
NOT a copy of S1 generic actions — use actual data from supplier answers.

Four sub-sections:
1. IMMEDIATE — action specific to THIS supplier's confirmed situation and timing
   e.g. "Your 70% conventional lines benefit — import cotton now before Jul 27 OBF deadline (13 days)"
2. COMMERCIAL — pricing/contract based on their actual buyer mix and contract type
   e.g. "Lock downstream supply contracts now — buyers don't know your input cost fell"
3. COMPETITIVE — peer positioning based on their actual product lines and certs
   e.g. "Your UFLPA farm-to-fashion traceability is a moat — pitch US buyers while Indian cost parity holds"
4. WC / AIR8 — their specific OBF schedule and WC plan based on confirmed exposure
   e.g. "Front-load OBF drawdowns this week; Air8 hard stop on new OBF after Jul 27"

### PENDING SCENARIOS — CONDITIONAL section (only when dims are unanswered)
Rule:
  IF all dims answered → OMIT PENDING SCENARIOS entirely. State everything as facts.
  IF any dim is PROVISIONAL (unanswered) → generate one block per pending dim:

    Format per pending dim:
    Dim [X] — pending. Assumed [default assumption used in signal computation].
    If [answer A] → [specific: signal stays X / action unchanged because Y]
    If [answer B] → [specific: signal flips to Z / action changes to W]
    Priority: HIGH (this answer can flip the signal — chase before acting)
             | LOW (magnitude only — does not change the go/no-go decision)

Purpose: Air8 knows exactly what's at stake while waiting for the answer.
         HIGH priority dims must be resolved before Air8 acts on the recommendation.

---

## Quality Gates

| Gate | Check | Failure Action |
|---|---|---|
| G1 | Generic combo signal loaded before specific assessment | Required baseline |
| G2 | Each question tagged to triggering dimension AND structural_nuance | Required - no unanchored questions |
| G3 | Questions ordered by signal-flip potential (highest risk first) | Re-order if not |
| G4 | All 5 dimensions covered (Demand/Buyers/Product/Cash/Capacity) | Flag incomplete |
| G5 | Signal flip conditions explicitly checked | Must be documented |
| G6 | Generic vs specific signal delta stated | Required |
| G7 | Unanswered dimensions flagged with default assumption | Required |

---

## Expert Validation (After S3 Output)

```yaml
invoke: kb-expert-review
input:
  result_type: risk_assessment
  archetype: [matched COMBO-id]
  claims: [LOGIC_ANGLE_VIEW claims with KB source refs]
  threshold: [from _meta/expert-review-config.json]
output:
  validated_result
  kb_updates_applied
  pending_items
```

# See skills/kb-expert-review/SKILL.md for all routing, scoring, and KB update logic.
# This scenario file does not duplicate that logic — it only calls the skill.
