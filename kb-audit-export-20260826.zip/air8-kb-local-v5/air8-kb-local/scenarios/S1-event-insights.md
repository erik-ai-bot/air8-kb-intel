# S1: Event → Insights (Forward Cascade)

> Scenario Type: S1 | Direction: Forward | Owner: Jerri Zhou | Updated: 2026-07-01
> Updated: 2026-07-14 — WHAT TO DO added to output card; 5-dim qualifying questions required; computed numbers mandatory in WHY
> Track: A — Event-triggered | Position: Step 2 of 4 (S0 → S1 → S5 → S3)
> Expert Validation: invoke kb-expert-review after generating S1 event card (EV1)
>   ≥ 0.85 confidence → auto-pass to Event Impact Gate
>   < 0.85 → route to domain expert via Telegram → feedback loop → re-score → KB gap flag

## File Linkage
> Output template: `_templates/S1-event-card.md` — read for every S1 output card
> Routing rules:   `_meta/scenario_routing.md` — read for combo routing decisions
> Orchestration:   `air8-kb-v2-LLM-SKILL.md` — master rules and CHANGELOG

---

## Trigger

Any external event matching the event taxonomy:
- Regulatory notice / policy announcement
- Commodity price move (>5% weekly or >10% monthly)
- FX rate move (>3% on a critical pair)
- Buyer financial news (downgrade, late payment, M&A)
- Geopolitical event affecting trade routes or sourcing
- Supply chain disruption signal

**Minimum tag set required**: `event_type:*` + `event_subtype:*` + affected `country:*` or `material:*`

---

## LLM Flow (8 Steps)

```
Step 1: PARSE EVENT
  Input: raw event text / news article / regulatory notice
  Action: extract → event_type, event_subtype, affected_country, affected_material, 
          effective_window (start, end, cliff), magnitude, confidence
  Output: Trigger Payload (structured JSON)
  KB reads: _meta/tag_dictionary.md (controlled vocabulary)
  Quality gate: classification_confidence ≥ 0.80 → else flag for human review

Step 2: ROUTE MODULES
  Input: Trigger Payload tags
  Action: lookup _meta/scenario_routing.md → determine 2-4 active modules
  Output: ordered module list (e.g., [personas, products, L0-principles, regulations])
  Cost: near-zero (index lookup)

Step 3: MATCH COMBOS
  Input: Trigger Payload tags + active modules
  Action: 
    a. Tag match → combos with ≥2 strong tag overlaps
    b. Edge walk → traverse sources_from and sells_to edges 1-2 hops
    c. Score each combo (see scenario_routing.md formula)
  Output: scored combo list (primary ≥0.70, secondary 0.45-0.69, indirect 0.25-0.44)
  KB reads: personas/instances/* (tag index), _links/cross-module-edges.md
  Quality gate: ≥3 combos activated → else expand to archetype match

Step 4: LOAD L0 PRINCIPLES + CONDITIONAL MODULES
  Input: matched combos + event_type + trigger payload
  Action: load relevant principles from L0-principles/ based on event_type match
  Output: reasoning checklist (which dimensions to think about)
  KB reads: L0-principles/persona-principles.md, L0-principles/risk-principles.md,
            L0-principles/event-principles.md
  ALWAYS LOAD: _reasoning/primitives.md — load alongside L0 principles every run
               (not just as fallback — primitives augment L0 for any event type)
  CONDITIONAL: IF trigger_payload.has_cliff = true → ALSO load _playbooks/cliff-playbook.md
               Apply cliff cadence rules (T-60d/30d/15d/7d/0 alerts, latest safe disbursement)
  FALLBACK: If no L0 principle matches event_type → rely primarily on _reasoning/primitives.md
            and identify applicable reasoning primitives (RP-DEPENDENCY, RP-PASSTHROUGH, etc.)
            Use primitives to compose first-principles analysis for novel event types

Step 5: FACT LOOKUP (most critical step)
  Input: L0 principle directives + structural nuances from matched combo nodes
  Action: 
    a. Load structural_nuances for each matched combo (what LLM would miss)
    b. Execute LLM directives (retrieve current facts, calculate specific values)
    c. Apply structural nuances as constraints on retrieved facts
  Output: hydrated frames (structural truths + current numbers combined)
  KB reads: personas/instances/* (structural_nuances + llm_directives)
  CRITICAL: LLM directives must be specific — "quantify blend ratio" not just "check sourcing"

Step 6: COMPUTE IMPACT
  Input: hydrated frames per combo
  Action: 
    a. Apply assessment_dimensions (what variables determine magnitude)
    b. Check signal_flip_conditions (does any condition reverse the default signal?)
    c. Generate impact signal: EXPAND | CONDITIONAL_EXPAND | CAUTION | NEUTRAL | DO_NOT_EXPAND
  Output: signal + magnitude + WHY (with structural nuances surfaced) per combo
  KB reads: _links/cross-module-edges.md (edge weights)

Step S1-Xb: COMPUTE EVENT IMPACT INTENSITY
  For each impacted combo:
    - Read factory profile dimensions from context (if available) or use archetype defaults
    - Apply intensity-scoring-engine.md framework:
        relevance_score: does this factory's supply chain intersect with the event? (0–20)
        capacity_discount: can the factory absorb the event impact? (0–20)
        urgency_bonus: how soon does the event take effect? (0–15)
        compound_bonus: other active events or PPs compounding? (0–15 per)
    - Output computed impact level (CRITICAL/HIGH/MEDIUM/LOW) with one-sentence reasoning trace
    - Never output a static label — always show which dimensions drove the level

Step 7: MAP AIR8 PRODUCTS
  Input: signal per combo + combo identity (revenue, buyer profile)
  Action:
    a. Match pain_hooks to product nodes
    b. Check eligibility (revenue, buyer anchor, tenor)
    c. Apply risk_reduction_narrative (why is the product low risk for Air8 here?)
    d. Apply risk rules (risk-principles.md — concentration caps, cliff constraints)
  Output: product recommendation + limit range + tenor + risk narrative
  KB reads: products/PROD-*.md, L0-principles/risk-principles.md

Step 8: COMPOSE S1 CARD
  Input: everything from steps 1-7
  Action: compose output following template in _templates/S1-event-card.md
  Output: S1 Event Card + write summary to Active Event Cache (for S2 use)
  KB reads: _templates/S1-event-card.md
  Quality gate: card must contain WHY + SIGNAL + RECOMMENDATION + ACTIONS + IF sections
```

## 2026-07-14 OUTPUT CARD REQUIREMENTS (MANDATORY)

1. WHAT TO DO section — REQUIRED after AIR8 RISK SIGNAL
   Generate 4 supplier-strategic numbered actions per combo (specific to event × combo):
   - IMMEDIATE: timing-critical action for this event window (with deadline if cliff exists)
   - COMMERCIAL: pricing/contract action before buyers discover cost change
   - COMPETITIVE: peer positioning, export opportunity, or market timing
   - WC / AIR8: OBF drawdown schedule, tenor, cliff deadline if applicable
   These must be specific — not generic. Use structural nuances from the combo to make them precise.

2. Qualifying questions — MUST use 5-dim structure
   Dims: DEMAND · BUYERS · PRODUCT · CASH · CAPACITY
   Each dim: question text + collect (specific doc or data) + signal_impact (if A→X; if B→Y)
   Order: signal-flip-critical dim FIRST (the question that could completely reverse the signal)

3. WHY section — MUST include ≥1 computed number
   Retrieve via LLM directive at runtime. Surface the actual result in WHY.
   Examples: "5–8% saving on total cotton cost", "+1–2% gross margin uplift", "WC need increases 30–50%"
   Do NOT leave as "~X%" or "significant" without a number.

---

## Where the 3 New Mechanisms Plug In

```
S0: News Understanding
    ↓
Step 1: Parse Event
    ↓
Step 2: Route Modules
    ↓
Step 3: Match Combos ←─── B2 Persona Synthesis fires HERE if match score < 0.7
    ↓                      (synthesizes draft combo from nearest neighbors)
Step 4: Load L0 Principles ←─── B1 Primitives fire HERE as FALLBACK
    ↓                            (if no L0 principle matches event_type)
Step 5: Fact Lookup
    ↓
Step 6: Compute Impact ←─── B3 Signal Grammar applies HERE
    ↓                        (produces structured signal with operators)
Step 7: Map Products
    ↓
Step 8: Compose Card ←─── A1 Signal Decision Matrix resolves conflicts HERE
    ↓                      (priority hierarchy + conflict resolution)
    ↓                      signal_derivation block generated HERE (M2)
Output: S1 Event Card
```

---

## P0 Guidance (Always Check)

These are mandatory checks for every S1 run. Do not skip.

**P0-1: Structural Nuance Surface**
The WHY section MUST contain at least one structural nuance from the combo's `structural_nuances` field, not just a headline statistic. If the card only says "India cotton = cheaper" without explaining the blend ratio or MSP floor mechanism → it fails.

**P0-2: Signal Flip Check**
Before finalizing signal, check all `signal_flip_conditions` for each matched combo. Common flips:
- CMT factory with buyer-nominated fabric → BENEFIT signal flips to NEUTRAL (savings don't flow through)
- Organic certified lines → import duty signal flips to NEUTRAL (domestic cotton only)
- Interior Turkey (no finishing moat) → EXPAND flips to DO_NOT_EXPAND
- US-heavy CN factory → EXPAND flips to DO_NOT_EXPAND for buyer strategy events

**P0-3: Post-Cliff Risk**
Any event with a cliff date: explicitly calculate:
- Days remaining from today
- Latest safe disbursement date = cliff_date - tenor - 5 day buffer
- Over-stockpiling risk in the quarter after cliff
- Whether existing A8 positions mature before cliff

**P0-4: Self-Liquidation Validation**
For every PSF/OBF recommendation: explicitly state the self-liquidation chain:
"Cotton → production → buyer receivable, ~120-180 days. Low Air8 risk when buyer investment-grade."
Do NOT recommend PreShip-OBF if buyer anchor is not confirmed.

**P0-4b: Survivor Bias Correction (fires on any peer failure / factory_capacity_change event)**
When peer factory closures, competitor exits, or market participant failures are detected, apply **RP-PEER-FAILURE primitive** (see `_reasoning/primitives.md`) BEFORE generating any EXPAND signal for survivors.
Rule: peer failure → EXPAND is NOT the default. Burden of proof is on EXPAND.
- Load: `_reasoning/primitives.md` → RP-PEER-FAILURE
- Ask the 4 key questions in order (root cause, same exposure, commitment duration, margin trend)
- If survivor faces same structural cause → CONDITIONAL, label "not-yet-failed"
- If genuine differentiation confirmed → EXPAND approved with named advantage
- If margin declining despite higher volume → CAUTION regardless of volume

**P0-5: Risk Cap Check**
Before recommending EXPAND: confirm:
- Single commodity exposure cap (>30% triggers alert, +20% max incremental without credit committee)
- Country concentration cap (check current book exposure)
- Tenor does not cross cliff date

**P0-6: Competitive Dynamics (MANDATORY — not optional)**
For any commodity, regulation, or demand event: the WHY section MUST include a structured competitive context section:
- "Which origins GAINED if [combo country] lost volume? Source or tag PENDING DATA before emitting."
- "Is the shift substitution (same segment) or bifurcation (different buyer tier/price point)? Apply RP-EVT-SEGMENT-BIFURCATE."
- Required for ALL events with event_subtype: demand_shift, sourcing_strategy_shift, import_export_duty
- Minimum output: "[Origin A] lost [X] to [Origin B/C/D]. Mechanism: [substitution / bifurcation / pull-forward]. Source: [verified / PENDING DATA]." 
- Cards that say only 'Turkey lost volume' without naming who gained → G5 fail, card not emitted

**P0-7: Claim Confidence Labels (MANDATORY)**
Every factual claim in the WHY and INSIGHT sections must carry a confidence label inline:
- [VERIFIED] — sourced from published data (Eurostat, official trade body, buyer announcement)
- [EXPERT] — from KB structural nuance marked as expert-reviewed and approved
- [HYPOTHESIS] — logical inference from known structural nuances; not directly sourced
- [PENDING DATA] — claim direction is plausible but specific figure/fact not yet sourced; do NOT cite as fact
Cards with any unlabeled claim in WHY or INSIGHT → G5 fail, not emitted
Example: "Turkey EU apparel volume contracted -17.83% [VERIFIED: Eurostat Jan-Apr 2026]; Istanbul premium segment likely retained better than average [HYPOTHESIS: based on price-volume split]; Bangladesh saw parallel contraction [PENDING DATA: Eurostat confirmation needed]"

**P0-8: Correlated Event Check (MANDATORY for every run)**
Before generating output: check active_event_cache for events with ≥2 overlapping tags (country, material, buyer_geo).
- If found: apply RP-EVT-CORRELATED-PAIR (see event-principles.md) — classify relationship (AMPLIFYING / REFRAMES / OFFSETS / INDEPENDENT)
- If AMPLIFYING or REFRAMES: generate combined card; do NOT emit standalone cards
- If INDEPENDENT: emit separately; note the other event in the card with a 1-sentence context
- Example: Event B (CSDDD) + Event E (Turkey volume): AMPLIFYING for COMBO-005 — revenue decline + compliance pressure = double WC need

---

## Output Template Reference
→ See `_templates/S1-event-card.md`

---

## Quality Gates

| Gate | Check | Failure Action |
|---|---|---|
| G1 | Classification confidence ≥ 0.80 | Flag for human review — do not emit |
| G2 | ≥3 combo nodes activated | Expand to archetype match, then re-check |
| G3 | S1 card has: WHY + SIGNAL + RECO + ACTIONS + IF | Not emitted |
| G4 | WHY contains structural nuances (not just headline) | Flag for expert review |
| G5 | All P0 checks completed (P0-1 through P0-8) | Not emitted |
| G7 | All WHY/INSIGHT claims carry confidence labels [VERIFIED/EXPERT/HYPOTHESIS/PENDING DATA] | Not emitted |
| G6 | Active Event Cache written | Required for S2 hook |

---

## Expert Validation (After S1 Output)
```yaml
invoke: kb-expert-review
input:
  result_type: event_insight
  archetype: [impacted COMBO-ids]
  claims: [LOGIC_ANGLE_VIEW claims with KB source refs]
  threshold: [from _meta/expert-review-config.json]
output:
  validated_result
  kb_updates_applied
  pending_items
```

# See skills/kb-expert-review/SKILL.md for all routing, scoring, and KB update logic.
# This scenario file does not duplicate that logic — it only calls the skill.
