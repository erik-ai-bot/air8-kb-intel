# S2: Supplier Pain → BD + Service Advice (Reverse Path, 3 Rounds)

> Scenario Type: S2 | Direction: Reverse | Owner: Jerri Zhou | Updated: 2026-07-01
> Track: B — Supplier Pain BD | Position: Standalone (not connected to Track A event flow)
> Trigger: Specific supplier name (not an event/news trigger)
> Purpose: Identify pain points (痛点), BD entry angles (切入点), provide data for BD outreach
> Expert Validation: invoke kb-expert-review after generating S2 BD card

---

## Trigger

BD receives supplier lead with one of:
- Company name + country (cold outreach / Round 1)
- Company name + answers to R1 questions (after first contact / Round 2)
- Full due diligence data (pre-credit decision / Round 3)

Or: existing S1 event cache contains active entries for this supplier's combo type (opportunistic outreach).

---

## LLM Flow (3-Round Progressive Sharpening)

### Round 1 — Archetype Match (Cold Outreach)
```
Input: company_name + country (+ size estimate if available)
  
Step R1-1: IDENTIFY ARCHETYPE
  Action: match country + estimated size to closest archetype (CMT-LowMargin / 
          FullPackage-MidMargin / Vertical-HighMargin)
  KB reads: personas/archetypes/*.md
  Output: archetype match + confidence
  FALLBACK: If archetype match confidence < 0.7 → trigger persona-synthesis protocol
            before proceeding. Load _reasoning/persona-synthesis.md and follow
            Steps 1-4 (nearest neighbor identification → axis inheritance →
            synthesise draft → confidence flags for R1 qualifying questions)

Step R1-2: LOAD ARCHETYPE PAIN MATRIX
  Action: load top 3 universal pain hooks for this archetype + country-specific pain hooks
  KB reads: pain-points/universal/PP-001 through PP-007, pain-points/country/PP-[COUNTRY]-*
  Output: ranked pain list (primary + secondary + watch)

Step R1-3: CHECK ACTIVE EVENT CACHE
  Action: find any active S1 events that impact this country/archetype
  Output: "Why Now" hook if event is active and relevant

Step R1-4: COMPOSE R1 CARD
  Action: produce archetype-level BD card with opening pain themes + qualifying questions
  KB reads: _templates/S2-bd-card-r1.md
  Output: R1 BD Card + qualifying questions for Round 2
```

**R1 Qualifying Questions to send (get answers before Round 2):**
- "What % of your fabric/yarn is buyer-nominated vs own-sourced?"
- "Who are your top 2-3 buyers by revenue share?"
- "Typical PO-to-payment cycle in days?"
- "What material do you primarily work with?"
- "Do you use bank LC, OD, or other financing currently?"

---

### Round 2 — Instance Match (After First Contact)
```
Input: R1 answers (material type, buyer mix, cash cycle, financing type)

Step R2-1: MATCH INSTANCE
  Action: use R1 answers to match to specific COMBO instance
  KB reads: personas/instances/*.md (tag match on material + country + company_type)
  Output: matched COMBO instance with confidence score

Step R2-2: LOAD INSTANCE DATA
  Action: load structural_nuances + assessment_dimensions + pain_hooks
  KB reads: matched COMBO-XXX.md
  Output: instance-level pain framing

Step R2-3: QUANTIFY PAIN WITH CLIENT DATA
  Action: apply client-provided data to assessment dimensions
  Example: "client said 90-day cycle + 30% prepay → WC need = $X tied up per cycle"
  Output: client-specific pain quantification

Step R2-4: SHAPE OFFER
  Action: map pain to Air8 product; check eligibility gates; frame benefit in client terms
  KB reads: products/PROD-*.md
  Output: offer shape (product + estimated limit range + tenor + savings vs current)

Step R2-5: COMPOSE R2 CARD
  KB reads: _templates/S2-bd-card-r2.md
  Output: R2 BD Card with quantified pain + offer shape + R2 qualifying questions
```

**R2 Qualifying Questions to send (get answers before Round 3):**
- "Do buyers issue back-to-back POs or blanket/open orders?"
- "Have you used pre-shipment financing before? At what annualized cost?"
- "Any current capacity overhang or PO pipeline concern?"
- "Happy to share last 12 months' buyer payment history?"
- "Do you have any entity in [other country] for sourcing?"

---

### Round 3 — Full Offer (After Due Diligence)
```
Input: R2 answers + financial data (revenue, buyer payment history, bank facility)

Step R3-1: CONFIRM ELIGIBILITY
  Action: run eligibility gates for recommended product
  KB reads: products/PROD-*.md (eligibility fields)
  Checks: revenue_min, buyer_PO_anchor, buyer_min_rating, tenor_band
  Output: eligible / not eligible + specific constraints

Step R3-2: APPLY RISK RULES
  Action: check risk concentration, country caps, signal_flip_conditions
  KB reads: L0-principles/risk-principles.md
  Output: signal + limit recommendation + any caps or restrictions

Step R3-3: BUILD CREDIT RECOMMENDATION
  Action: structure full offer with specific product, limit, tenor, pricing rationale
  Output: credit-ready recommendation

Step R3-4: COMPOSE R3 CARD
  KB reads: _templates/S2-bd-card-r3.md
  Output: R3 Full Offer Card (ready for credit committee if needed)
```

---

## P0 Guidance (Always Check)

**P0-1: Active Event Hook**
Every R1 card must check the Active Event Cache. If there is a relevant active event (e.g., India cotton duty cut with 60+ days remaining and client is India-cotton-dependent), lead with it as the "Why Now" hook. Do not bury the hook.

**P0-2: Pain Sequencing**
Order pains by: (1) severity for this client based on what they told you, (2) uniqueness of Air8 solution. Do not lead with pains where Air8 has no solution.

**P0-3: Eligibility First**
Before composing R2 or R3, check eligibility gates. If not eligible for primary product → offer advisory/monitoring only; do not recommend ineligible product. Flag eligibility gap explicitly.

**P0-4: Never Promise Limits**
In R1 and R2, use estimated ranges ("typically $X–Y based on your size and buyer profile"). Never commit to specific limits before R3 due diligence and credit check.

**P0-5: Trader Flag**
If client is a trader/sourcing agent (no factory assets), flag immediately: third-party payment prohibition applies. Do not proceed with standard ARP. Route to Trader TCS with recourse.

**P0-6: Round Integrity**
Do not skip rounds. Round 1 → Round 2 requires actual client answers. Do not generate Round 2 content by assuming answers. "We'll confirm in the next conversation" is better than a fabricated Round 2.

---

## How Client Answers Re-Route the Cascade

| Client Reveals | KB Re-routing Action |
|---|---|
| "70% cotton from India" | Run RP-MATERIAL-01 with specific value; WHY section quantified |
| "Top buyer is H&M, 55% revenue" | Activate PP-003-buyer-concentration; add PROD-PAYGUARD |
| "Payment cycle 60 days" | Recalculate WC saving with actual cycle; refine offer shape |
| "Has India entity" | Switch to COMBO-013 (multi-country) playbook |
| "Buyer-nominated 90%" | Flip any raw material cost event from BENEFIT to NEUTRAL |
| "Revenue $50M+" | Unlock PROD-POOL; reconsider PROD-PRESHIP-OBF eligibility |
| "No financial records" | Flag COMBO-015 (micro); MiniARP only if revenue $1M+, ops 2yr+ |

---

## Output Template References
- Round 1 → `_templates/S2-bd-card-r1.md`
- Round 2 → `_templates/S2-bd-card-r2.md`
- Round 3 → `_templates/S2-bd-card-r3.md`

---

## Quality Gates

| Gate | Check | Failure Action |
|---|---|---|
| G1 | Active event cache checked | Required before composing R1 |
| G2 | Eligibility gates run before R2 offer | If not run → flag, do not promise product |
| G3 | Pain themes tied to specific Air8 solution | Pure pain description without solution = incomplete |
| G4 | Qualifying questions for next round included | Always — drives round sharpening |
| G5 | Trader flag checked at R1 | If trader → different flow before proceeding |

---

## Expert Validation (After Each Round Output)

After generating any Round output (R1, R2, or R3 card), invoke the expert review skill:

```yaml
invoke: kb-expert-review
input:
  result_type: bd_card
  archetype: [matched COMBO-id]
  claims: [list of LOGIC_ANGLE_VIEW claims with KB source refs]
  threshold: [from _meta/expert-review-config.json]
output:
  validated_result
  kb_updates_applied
  pending_items
```

See `skills/kb-expert-review/SKILL.md` for all routing, scoring, expert messaging, and KB update logic.
This scenario file does not duplicate that logic — it only calls the skill.
