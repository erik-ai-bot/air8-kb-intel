# S5: Event-Triggered Supplier Impact Assessment

> Scenario Type: S5 | Direction: Event → Individual (Batch) | Owner: Jerri Zhou | Updated: 2026-07-14
> Track: A — Event-triggered | Position: Step 3 of 4 (S0 → S1 → S5 → S3)
> Triggered by: S1 output signal ∈ {CAUTION, DO_NOT_EXPAND, CONDITIONAL}
> Outputs to: S3 (individual assessment per supplier) — Step 4
> Expert Validation: EV2 fires in S3 (Step 7), not directly in S5
> Client Q+doc collection: Phase 6-7 of S5 (gap analysis → targeted outreach → Air8 review gate)

## File Linkage
> Triggered by:  S1 output signal ∈ {CAUTION, DO_NOT_EXPAND, CONDITIONAL}
> Invokes:       S3-individual-assessment.md (Step 7, per supplier)
> Templates:     _templates/S3-assessment-questions.md (Step 7 output card)
> Routing ref:   _meta/scenario_routing.md (S5 entry)
> Orchestration: air8-kb-v2-LLM-SKILL.md — master rules and CHANGELOG

---

## Role

S5 is triggered automatically after S1 produces a CAUTION, DO_NOT_EXPAND, or CONDITIONAL signal.
It bridges the gap between combo-level insight (S1) and individual supplier assessment (S3) by:
1. Querying the platform for all active suppliers matching each impacted COMBO
2. Enriching each supplier via web search
3. Gap-analysing against S3 assessment dimensions
4. Producing targeted outreach to clients (Air8-reviewed before sending)
5. Running individual S3 assessment once client answers received
6. Delivering dual output: Air8 internal + client-facing

S5 does NOT replace S3 — it batch-triggers S3 for multiple named suppliers from a single event.

---

## Trigger

S1 output contains one or more COMBOs with signal:
- CAUTION
- DO_NOT_EXPAND
- CONDITIONAL (when event magnitude is HIGH or cliff is present)

Signal = MONITOR → S4 portfolio watch only, S5 does NOT trigger.

---

## LLM Flow (8 Steps)

```
Step 1: IDENTIFY IMPACTED COMBOs
  Input: S1 output (scored combo list + signals)
  Action: filter combos where signal ∈ {CAUTION, DO_NOT_EXPAND, CONDITIONAL}
          AND combo_score ≥ 0.35 (same threshold as S3 combo inclusion rule)
  Output: impacted COMBO list (e.g. [COMBO-003: CAUTION, COMBO-002: DO_NOT_EXPAND])
  Note: one S1 event may trigger S5 for multiple COMBOs simultaneously → batch all

Step 2: GENERATE PLATFORM LOOKUP CRITERIA
  Input: each impacted COMBO identity block
  Action: translate COMBO identity fields → platform query parameters

  Per COMBO, output exactly this parameter set:
    supplier_country   = COMBO.identity.country
    product_category   = COMBO.identity.product_type (list — all types, not just primary)
    buyer_country      = COMBO.identity.buyer_geo (list — all buyer geos in buyer_edges)
    annual_sales_range = COMBO.identity.revenue_band (USD range)
    financing_product  = COMBO.identity.company_type proxy:
                           CMT / FOB only → ARP
                           Vertical       → [ARP, PSF]
                           Trader         → [TCS]

  Example for COMBO-003 (India Large Vertical):
    supplier_country   = IN
    product_category   = [knit, woven, cotton, organic cotton]
    buyer_country      = [US, EU]
    annual_sales_range = $50M+
    financing_product  = [ARP, PSF]

  Example for COMBO-002 (Bangladesh CMT Small-Mid):
    supplier_country   = BD
    product_category   = [knit, T-shirt, basics, cotton garments]
    buyer_country      = [EU, US]
    annual_sales_range = $5M–$20M
    financing_product  = [ARP]

  Quality gate G1: all 5 parameters populated before sending to platform

Step 3: RECEIVE MATCHED SUPPLIERS FROM PLATFORM
  Platform returns per matched supplier:
    supplier_name
    supplier_country
    product_category        (all categories, not just primary)
    buyer_name
    buyer_country
    annual_sales            (USD)
    current_outstanding     (Air8 exposure, USD)
    avg_tenor_days
    financing_product_type

  Action:
    a. Confirm COMBO match: verify returned supplier parameters match the queried COMBO
       (some suppliers may straddle two COMBOs — assign to closest match by majority fields)
    b. Log: matched_combo, supplier_name, current_outstanding, signal inherited from S1
  Output: confirmed supplier list with COMBO assignment and current Air8 exposure

  Quality gate G2: at least supplier_name + current_outstanding present for each supplier

Step 4: WEB SEARCH ENRICHMENT
  Input: confirmed supplier list (names + countries)
  Action: for each supplier, run targeted web search to retrieve:
    - Company profile (size, factory locations, years in operation)
    - Certifications (BSCI, GOTS, Sedex, HIGG, ZDHC — which ones, which level)
    - Known buyer relationships (publicly referenced buyer programmes)
    - Recent news (capacity changes, financial distress signals, compliance issues)
    - Any publicly available revenue / financial indicators
  Output: enriched supplier profile per supplier (structured notes, not raw text)

  Quality gate G3: web search attempted for every supplier; if no public info found → note explicitly

Step 5: GAP ANALYSIS AGAINST S3 ASSESSMENT DIMENSIONS
  Input: platform data (Step 3) + web enrichment (Step 4) + COMBO.assessment_dimensions
  Action: for each supplier, map available information against the COMBO's assessment_dimensions:

    For each dim in COMBO.assessment_dimensions:
      IF answerable from platform data OR web search → mark ✅ ANSWERED, record the value
      IF not answerable → mark ❓ MISSING → add to targeted question list

  Output per supplier:
    answered_dims:  [list of dims with values from platform/web]
    missing_dims:   [list of dims with r1_question + collect fields from COMBO node]

  Note: use the assessment-question-framework.md to ensure questions are event-type specific,
        not generic — same quality bar as S3 Step 3.

  Quality gate G4: gap analysis run against ALL dims in the COMBO node, none skipped

Step 6: TARGETED CLIENT OUTREACH (Air8 review before sending)
  Input: missing_dims per supplier
  Action: compose outreach per supplier containing ONLY the missing dimensions:
    - Professional framing (event context without alarm)
    - Questions: only the ❓ MISSING dims, ordered by signal-flip potential (highest risk first)
    - Documents: specific collect items from each missing dim
    - Tone: partnership / routine review, not risk warning

  ⚠️ HOLD FOR AIR8 REVIEW — do NOT send automatically.
  Output: draft outreach per supplier → Air8 team reviews and approves before sending

  Outreach template:
  ---
  Subject: [Supplier Name] — Routine Portfolio Review | [Event Context]

  Dear [Supplier Name],

  In light of [brief event description — 1 sentence], we are conducting a routine
  review of our active portfolio. We would appreciate your help clarifying a few
  points for [Supplier Name].

  Questions:
  Q1: [missing dim r1_question — most signal-flip-critical first]
  Q2: [next missing dim]
  Q3: [next missing dim — max 4 questions]

  Documents we would find helpful:
  - [collect item from missing dim 1]
  - [collect item from missing dim 2]

  Thank you — we aim to complete this review within [X] business days.

  Best regards,
  [Air8 team]
  ---

Step 7: INDIVIDUAL S3 ASSESSMENT (after client response)
  Input: platform data + web enrichment + client answers (from Step 6 outreach)
  Action: run S3 individual assessment for each supplier with full dataset:
    a. Replace generic COMBO signal with supplier-specific signal
    b. Check all signal_flip_conditions from COMBO node
    c. Recompute signal with actual supplier data
    d. Map to Air8 product recommendation
  Output: S3 individual assessment result per supplier
  KB reads: S3-individual-assessment.md (full flow), COMBO-XXX.md assessment_dimensions

  Note: if client has NOT yet responded → produce partial assessment with assumptions flagged;
        mark signal as PROVISIONAL until client confirms.

  Quality gate G5: generic vs specific signal delta stated for every supplier

Step 8: DUAL OUTPUT
  For each supplier, produce two outputs:

  OUTPUT A — Air8 Internal:
    supplier_name:       [name]
    combo_match:         [COMBO-XXX]
    event:               [S1 event title]
    signal_generic:      [S1 combo signal]
    signal_specific:     [supplier-specific signal after S3]
    signal_delta:        [what changed the signal, if anything]
    current_outstanding: $X / avg tenor Xd
    risk_flag:           [LOW | MEDIUM | HIGH | URGENT]
    recommended_action:  [one of below]
      - MONITOR: no immediate action, re-assess in 30d
      - PROACTIVE_CALL: schedule relationship check-in
      - PAUSE_NEW: pause new disbursements pending client answers
      - REDUCE_RATIO: reduce advance ratio for new transactions
      - ESCALATE: escalate to credit committee immediately
    pending_items:       [list of unanswered dims + docs not yet received]

  OUTPUT B — Client Communication (post-assessment, if action warranted):
    SIGNAL = MONITOR → no client communication required
    SIGNAL = CONDITIONAL / CAUTION → soft touchpoint:
      "We'd like to schedule a call to discuss your programme and current situation."
    SIGNAL = DO_NOT_EXPAND → facility review notice:
      "We are conducting a review of your facility in light of [event].
       We will be in touch within [X] business days."
    ⚠️ HOLD FOR AIR8 REVIEW before sending — same as Step 6.
```

---

## COMBO → Platform Query Reference

| COMBO | supplier_country | product_category | buyer_country | annual_sales | financing_product |
|-------|-----------------|-----------------|---------------|-------------|-------------------|
| COMBO-001 (SA Knit) | SA | [knit, cotton] | [EU] | $5–20M | [ARP] |
| COMBO-002 (BD CMT) | BD | [knit, T-shirt, basics, cotton garments] | [EU, US] | $5–20M | [ARP] |
| COMBO-003 (IN Vertical) | IN | [knit, woven, cotton, organic cotton] | [US, EU] | $50M+ | [ARP, PSF] |
| COMBO-004 (CN Woven) | CN | [woven, shirting, fabric] | [EU, US] | $20–50M | [ARP, PSF] |
| COMBO-005 (TR Denim) | TR | [denim, jeans, woven] | [EU] | $20–50M | [ARP, PSF] |
| COMBO-006 (VN FDI) | VN | [woven, knit, mixed] | [US, EU] | $20–50M | [ARP, PSF] |
| COMBO-007 (ID Family) | ID | [knit, woven, basics] | [EU, US] | $5–20M | [ARP] |
| COMBO-008 (IN Organic) | IN | [organic cotton, knit] | [EU] | $5–20M | [ARP] |
| COMBO-009 (PK Home Textile) | PK | [home textile, bedding, towels] | [EU, US] | $20–50M | [ARP] |
| COMBO-010 (Existing Client) | any | any | any | any | any (active) |
| COMBO-011 (Trader) | any | any | any | any | [TCS] |
| COMBO-012 (KH EBA) | KH | [knit, basics] | [EU] | $5–20M | [ARP] |
| COMBO-013 (Multi-Country) | multi | mixed | mixed | $20M+ | [ARP, PSF] |
| COMBO-014 (IN Small Woven) | IN | [woven, shirting] | [EU, US] | $5–20M | [ARP] |
| COMBO-015 (Micro) | any | any | any | <$5M | [MiniARP] |

---

## P0 Guidance (Always Check)

**P0-1: Signal Threshold**
Only trigger S5 for CAUTION, DO_NOT_EXPAND, CONDITIONAL signals.
MONITOR-only combos go to S4 portfolio watch — not S5.

**P0-2: Human Review Gate**
Both client outreach (Step 6) and client communication (Step 8 Output B) MUST be reviewed
by Air8 team before sending. LLM produces drafts only — never sends autonomously.

**P0-3: Partial Assessment**
If client has not responded by review deadline, produce a provisional S3 assessment with all
unanswered dims explicitly flagged as assumed defaults. Never suppress the assessment
just because data is incomplete.

**P0-4: Multi-COMBO Suppliers**
If a supplier matches multiple impacted COMBOs (e.g., IN factory doing both knit and woven),
assess under the COMBO with the higher-severity signal. Note the secondary COMBO match.

**P0-5: Cliff Date Urgency**
If the S1 event has a cliff date AND avg_tenor_days > days_remaining_to_cliff:
→ flag as URGENT regardless of signal type
→ calculate latest safe disbursement date = cliff_date - avg_tenor_days - 5 day buffer
→ escalate immediately to credit team; do not wait for client outreach response

**P0-6: RP-PEER-FAILURE**
If Step 3 returns multiple suppliers in the same country and product category:
→ apply RP-PEER-FAILURE cluster check (see _reasoning/primitives.md)
→ a supplier gaining POs from a closed competitor may be masking deterioration
→ treat volume growth in a distressed cluster as a CAUTION signal, not EXPAND

**P0-7: Outreach Framing**
Client outreach must NEVER mention the signal level or internal risk flag.
Frame as routine portfolio review. The purpose is to gather facts, not signal distress.

---

## Quality Gates

| Gate | Check | Failure Action |
|------|-------|---------------|
| G1 | All 5 platform query parameters populated per COMBO | Do not send incomplete query |
| G2 | supplier_name + current_outstanding present for every returned supplier | Flag missing records; do not proceed without name |
| G3 | Web search attempted for all suppliers | If zero public info: note explicitly; do not skip |
| G4 | Gap analysis run against ALL COMBO assessment_dimensions | Missing dims = targeted questions; none skipped |
| G5 | Generic vs specific signal delta stated per supplier | Required in Output A |
| G6 | Human review gate applied to both client outreach drafts | Never send autonomously |
| G7 | Cliff urgency check run for every supplier when cliff_date present | Escalate immediately if tenor crosses cliff |

---

## Relationship to Other Scenarios

| Scenario | Relationship |
|----------|-------------|
| S1 | S5 is triggered BY S1; inherits combo signals and event context |
| S3 | S5 batch-triggers S3 for each supplier in Step 7; shares assessment_dimensions |
| S4 | MONITOR-only combos go to S4, not S5; S5 and S4 are parallel tracks |
| S2 | S5 Output B (client communication) may lead to S2 BD conversation if signal = CONDITIONAL |

---

## Expert Validation (After S5 Batch Output)

```yaml
invoke: kb-expert-review
input:
  result_type: risk_assessment
  archetype: [all impacted COMBO-ids]
  claims: [LOGIC_ANGLE_VIEW claims from S3 assessments]
  threshold: [from _meta/expert-review-config.json]
output:
  validated_result
  kb_updates_applied
  pending_items
```

See skills/kb-expert-review/SKILL.md for all routing, scoring, and KB update logic.
