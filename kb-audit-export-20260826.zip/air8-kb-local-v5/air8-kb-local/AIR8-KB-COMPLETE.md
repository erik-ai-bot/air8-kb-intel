# Air8 Knowledge Base — Complete Reference
> Air8 KB v2.0 · Pure Knowledge Architecture · Agent-queryable knowledge graph
> For use in BD intelligence, supplier insights, risk review, compliance checks

---

## Table of Contents
1. [Architecture Overview](#architecture)
2. [The 8 Dimensions](#dimensions)
3. [15 Supplier Personas (Combos)](#personas)
4. [Pain Points](#pain-points)
5. [Air8 Products](#products)
6. [Regulations](#regulations)
7. [ESG Standards](#esg-standards)
8. [Linkage Tables](#linkage)

---

## 1. Architecture Overview {#architecture}

The KB is a knowledge graph with 4 traversal entry points:

```
SUPPLIER PROFILE
       ↓
  8 DIMENSIONS  →  match to  →  PERSONA (COMBO)
       ↓                              ↓
  PAIN POINTS  ←──────────────  LINKAGE TABLE
       ↓                              ↓
  PRODUCTS  ←────────────────  COMPLIANCE EXPOSURE
```

**How to use:**
- Start with **Dimensions** → classify the supplier
- Match to a **Persona (COMBO)** — or combine multiple
- Follow **Pain Points** → understand their vulnerabilities
- Follow **Products** → identify Air8 fit
- Check **Regulations** → compliance exposure
- Use **Linkage Tables** → full traversal and event propagation

---

## 2. The 8 Dimensions {#dimensions}

Every supplier is classified across 8 dimensions. Together they resolve to a Persona.

### DIM-1: Country of Origin

| Country | Air8 Priority | Key Products |
|---|---|---|
| Bangladesh | 🟠 High | ARP, RT2C, PayGuard |
| China | 🟠 High | ARP (Hengqin), Pool, SmartWallet |
| India | 🟠 High | ARP, OBF, ESG Financing |
| Pakistan | 🔴 Critical | ARP (offshore USD), Pool |
| Turkey | 🔴 Critical | ARP (USD), Pool |
| Vietnam | 🟡 Medium | ARP (parent pitch), PayGuard |
| Indonesia | 🟡 Medium | MiniARP → ARP |
| Cambodia | 🟡 Medium | ARP, MiniARP |

### DIM-2: Revenue Band

| Band | Revenue | Products Available |
|---|---|---|
| Micro | <$5M | MiniARP only |
| Small | $5–20M | ARP, RT2C |
| Medium | $20–50M | ARP, OBF, Pool, SmartWallet |
| Large | $50M+ | All products + ESG Financing |

### DIM-3: Company Type

| Type | Cash Cycle | Pre-ship Need | Key Products |
|---|---|---|---|
| CMT | 90–120 days | Low | ARP, MiniARP |
| FOB | 120–180 days | Medium-High | ARP, RT2C, OBF |
| Vertical Integrator | 180–240 days | CRITICAL | OBF, ARP, Pool, ESG |
| Trader | Variable | Medium | Back-to-Back TCS |

### DIM-4: Product Focus

| Product | Lead Time | Top Compliance Risk |
|---|---|---|
| Knit Apparel | 60–90 days | UFLPA, REACH |
| Woven Apparel | 90–120 days | UFLPA, REACH |
| Denim | 90–120 days | REACH (HIGHEST) |
| Organic/Sustainable | 90–120 days | UFLPA advantage |
| Home Textiles | 60–90 days | UFLPA, REACH (fire retardants) |

### DIM-5: Target Market

| Market | Payment Terms | Key Regulations |
|---|---|---|
| United States | OA 90–120 days | UFLPA, Section 301 |
| European Union | OA 60–90 days | REACH, CSDDD, GPSR |
| United Kingdom | OA 60–90 days | UK REACH, Modern Slavery Act |
| Multi-Market | Mixed | All of the above |

### DIM-6: Buyer Profile

| Buyer Type | Payment Terms | Dilution | ESG Demand |
|---|---|---|---|
| Global Fast Fashion | OA 60–90 days | 2–5% | High |
| US Mass Market | OA 90–120 days | 3–8% | Moderate |
| US Dept/Specialty | OA 60–90 days | 5–10% | Low-Moderate |
| ESG-First Brands | OA 30–60 days | 1–3% | Very High |
| Emerging Markets | OA 30–60 days | Low | Low |

### DIM-7: Current Financing

| Type | Cost | Air8 Relevance |
|---|---|---|
| Bank LC | 3–5% | HIGHEST — direct replacement |
| Bank OD | 8–22% | HIGH — major cost saving |
| Domestic Factoring | 1–5% + hidden fees | MEDIUM — differentiate on speed/data |
| No External Financing | 0% (personal savings) | HIGH — education needed first |
| Already Air8 | SOFR+4% | Focus on expansion / wallet share |

### DIM-8: Growth Stage

| Stage | Air8 Eligibility | Primary Value |
|---|---|---|
| Startup | Min 2yr ops required | Usually not eligible |
| Stable/Mature | Full eligibility | Cost optimisation |
| Expanding | Full eligibility | Scalable facility |
| Distressed | Case by case | Crisis financing |

---

## 3. 15 Supplier Personas (Combos) {#personas}

### COMBO-001: South Asian Small Knit Manufacturer
**Profile:** BD/IN/PK/KH · $5–20M · FOB · Knit · US+EU · Bank LC · Expanding · Fast Fashion + Mass Market

**Key Characteristics:**
- Cash cycle 120–150 days; margin 8–12%, hyper-sensitive to financing cost
- 3–5 buyers, top buyer >30% revenue = concentration risk
- Owner makes all decisions; no CFO
- 500–2,000 workers, mostly women

**Pain Points:** PP-001, 002, 003, 004, 006 + country-specific (BD/IN/PK)
**Products:** ARP, RT2C, PayGuard
**Compliance:** UFLPA (cotton→US), REACH (EU), CSDDD

---

### COMBO-002: Bangladesh Bank-LC-Dependent Factory Owner
**Profile:** BD · $5–20M · FOB · Knit/Woven · EU>US · Bank LC only · Stable/Expanding · Fast Fashion

**Key Characteristics:**
- LC from local bank (Sonali/Janata/IFIC/Dhaka): 3–5% cost, 45–60 day processing
- Factory/land pledged as collateral
- Post-2024 minimum wage hike (+56%) squeezing margins critically
- Accord/RSC remediation costs ($50–200K) compete with working capital
- Political instability (hartals) disrupts 15–20 production days/year

**Pain Points:** PP-001, 002, 004, 005 + PP-BD-001 (wage hike), PP-BD-002 (political), PP-BD-003 (LDC graduation)
**Products:** ARP (replace LC), RT2C (replace B2B LC), PayGuard
**Compliance:** UFLPA (if US), REACH (if EU), Accord/RSC

---

### COMBO-003: India Large Vertical Integrator
**Profile:** IN · $50M+ · Vertical Integrator · Knit Organic/Sustainable · US+EU+Multi · Bank OD+Air8 · Expanding · ESG Brands

**Key Characteristics:**
- Farm-to-fashion: buys raw cotton from 10,000+ farmers
- Cash cycle 180–240 days (longest of all combos)
- Certifications: GOTS, Fairtrade, C2C, ROC
- 5,000–10,000 workers, professional management
- ESG credentials = competitive moat + IFC/ESG-linked financing eligible
- Already sophisticated; compares financing options analytically
- Real-world example: Pratibha Syntex Limited

**Pain Points:** PP-001, 002, 005 + PP-IN-001 (GST refund), PP-IN-002 (bank OD cost), PP-ESG-001 (credentials not monetized)
**Products:** ARP, OBF, Pool, SmartWallet, ESG Financing
**Compliance:** UFLPA (advantage: organic = inherent traceability), CSDDD (data provider advantage), REACH

---

### COMBO-004: China Medium Woven Exporter
**Profile:** CN · $20–50M · FOB · Woven/Denim · US+EU · Bank LC + Domestic Factoring · Stable

**Key Characteristics:**
- Dual market (US+EU) = dual compliance burden
- Sinosure insurance: monthly paper declaration by 15th = admin pain
- SAFE cross-border regulations add friction
- Rising labor costs in coastal cities ($700–900/month)
- Contract signing via SSQ (上上签) for CN entities
- CFO persona: numbers-driven, expects transparency

**Pain Points:** PP-001, 002 + PP-CN-001 (SAFE complexity), PP-CN-002 (Sinosure burden), PP-CN-003 (Hengqin capacity)
**Products:** ARP (via Hengqin entity), SmartWallet, Pool
**Compliance:** UFLPA (HIGH for CN cotton), REACH, CSDDD, SAFE

---

### COMBO-005: Turkey Denim Specialist
**Profile:** TR · $20–50M · FOB · Denim · EU>US · Local Factoring/Bank OD · Stable/Struggling

**Key Characteristics:**
- TRY hyperinflation: cost base in TRY, earning EUR/USD
- Near-shoring advantage: 2–3 day ship to EU vs 25–30 days from Asia
- Sophisticated denim finishing capabilities (laser, ozone, enzyme)
- REACH compliance burden for denim chemicals is heavy
- Bank credit lines being cut amid macro instability

**Pain Points:** PP-001, 002, 003 + PP-TR-001 (lira hyperinflation), PP-TR-002 (bank credit contraction)
**Products:** ARP (USD-denominated), Pool
**Compliance:** REACH (HIGHEST — denim chemicals), CSDDD

---

### COMBO-006: Vietnam FDI Knit Factory
**Profile:** VN · $10–50M · CMT/FOB · Knit Activewear · US>EU · Parent Company/Bank LC · Expanding

**Key Characteristics:**
- Often Korean or Taiwanese-owned; parent HQ makes financing decisions
- Strong in sportswear/activewear (Nike, Adidas supply chain)
- Worker shortage in peak season → production risk
- Local GM may not have authority to sign financing agreement
- Rapid growth from China+1 → WC can't keep pace

**Pain Points:** PP-001, 004 + PP-VN-001 (FDI decision authority)
**Products:** ARP (pitch to parent HQ), PayGuard
**Compliance:** UFLPA (if cotton), CSDDD

---

### COMBO-007: Indonesia Family-Run 2nd Generation
**Profile:** ID · $5–20M · FOB · Knit · EU/US · Bank LC/None · Expanding

**Key Characteristics:**
- Father founded; son/daughter taking over
- Tension: legacy relationships vs modern tools
- Personal banking used for business; no AR aging system
- Rupiah volatility erodes margins (5–10% swings)
- Trust-based decision making; relationship-first

**Pain Points:** PP-001, 002, 003, 006 + PP-IDN-001 (rupiah volatility)
**Products:** MiniARP (start small) → ARP (graduate to)
**Compliance:** UFLPA (if cotton), REACH, GPSR

---

### COMBO-008: India Organic Cotton Knit (Medium)
**Profile:** IN · $20–50M · FOB/Vertical · Knit Organic · US+EU · Bank OD/Air8 · Expanding

**Key Characteristics:**
- Located near organic cotton belt (MP, Gujarat, Rajasthan)
- Connected to farmer programs (500–5,000 farmers)
- Certifications: GOTS, Fairtrade, OCS minimum
- Buyer base includes ESG-first brands (Pact, Patagonia)
- Cotton traceability advantage for UFLPA (can trace to farm/gin)
- Growing 10–20% annually as sustainable fashion demand rises
- Bank OD at 12–18% = high financing cost

**Pain Points:** PP-001, 002, 005 + PP-IN-001, PP-IN-002 + PP-ESG-001
**Products:** ARP, OBF, RT2C, ESG Financing, SmartWallet
**Compliance:** UFLPA (advantage: organic traceability), CSDDD (data provider), REACH

---

### COMBO-009: Pakistan Home Textile Exporter
**Profile:** PK · $10–50M · FOB · Home Textiles · US+EU · Bank LC · Stable

**Key Characteristics:**
- Towels, bed sheets, table linen (large order volumes, lower margins)
- Pakistani cotton = UFLPA traceability needed (not Xinjiang but scrutinized)
- Energy crisis adds 10–20% to production costs
- SBP FX controls limit USD availability
- Bank rates: 15–22% p.a.

**Pain Points:** PP-001, 002 + PP-PK-001 (energy crisis)
**Products:** ARP, Pool
**Compliance:** UFLPA (cotton), REACH (fire retardants in home textiles)

---

### COMBO-010: Existing Air8 Client — Expansion Scenario
**Profile:** Already Air8 client · Any country · Any dimensions

**Key Characteristics:**
- Already onboarded, KYC complete, agreement signed
- Key question: wallet share % and unused product coverage
- Expansion levers: more buyer pairs / more products / higher limits / better terms (ESG)

**Pain Points:** PP-EXPAND-001 (low wallet share), PP-EXPAND-002 (missing product coverage), PP-EXPAND-003 (operational friction)
**Products:** Whatever they don't have yet (focus on upsell gaps)
**Agent Note:** Check facility.wallet_share — if <50%, massive upsell opportunity

---

### COMBO-011: Trader / Sourcing Agent
**Profile:** Any country · Any revenue · Trader type

**Key Characteristics:**
- No factory assets → banks won't lend
- Sits between buyer payment and factory payment → needs financing badly
- Margin: 3–8% (paper thin)
- ⚠️ Third-party payment prohibition (OPS-KYC-002) — Air8 cannot pay into unrelated accounts

**Pain Points:** PP-001, PP-006
**Products:** Back-to-Back/Trader TCS (with recourse)
**Compliance:** COMP-KYC (OPS-KYC-002 third-party prohibition)

---

### COMBO-012: Cambodia Garment Factory (EU EBA Dependent)
**Profile:** KH · $5–20M · CMT · Knit/Woven · EU · Bank LC/None · Stable

**Key Characteristics:**
- Revenue heavily dependent on EU EBA duty-free access
- Risk: EU could withdraw EBA preferences (happened partially in 2020)
- USD-dollarized economy = natural FX hedge but limited monetary policy
- Worker wages rising ~$10–15/year → margin pressure
- ⚠️ EBA graduation risk: political/governance deterioration triggers EU review

**Pain Points:** PP-001, 002, 003
**Products:** ARP, MiniARP
**Compliance:** UFLPA (if cotton), EBA preference risk, CSDDD

---

### COMBO-013: Multi-Country Corporate Group
**Profile:** $50M+ · Vertical/FOB · Multi-country (e.g. IN+BD, CN+VN) · US+EU+Multi · Multi-bank+Air8

**Key Characteristics:**
- Operates factories in 2+ countries
- Holding company in one jurisdiction, operating entities in others
- Multi-entity KYC complexity
- Different insurance routes per entity-country combination
- Transfer pricing and intercompany flow considerations

**Pain Points:** PP-001, 002, 005
**Products:** ARP (multi-entity), DDP, Pool, SmartWallet
**Compliance:** ALL regulations × ALL countries in the group

---

### COMBO-014: India Small Woven Manufacturer (Bank OD Dependent)
**Profile:** IN · $5–20M · FOB · Woven · US/EU · Bank OD · Expanding

**Key Characteristics:**
- Bank OD at 12–18% p.a. = among highest financing costs globally
- Personal guarantee from owner
- Woven = longer lead times (90–120 days) → bigger cash gap
- Noida/Gurugram cluster: well-connected but higher overhead

**Pain Points:** PP-001, 002, 003, 005 + PP-IN-001, PP-IN-002
**Products:** ARP (cost savings vs OD), RT2C
**Compliance:** UFLPA (if cotton→US), REACH (if EU)

---

### COMBO-015: Micro Supplier First-Time Financing
**Profile:** <$5M revenue · No external financing · CMT · Any country · Startup/Expanding

**Key Characteristics:**
- Never had external financing; runs on personal savings or informal loans
- One buyer = 60–100% of revenue
- No financial records (maybe handwritten ledger)
- ⚠️ Eligibility gate: Revenue <$1M OR ops <2yr → NOT ELIGIBLE for any Air8 product

**Pain Points:** PP-001, PP-006
**Products:** MiniARP (only if revenue >$1M AND ops >2yr)

---

## 4. Pain Points {#pain-points}

### Universal Pain Points (affect all combos)

#### PP-001: Post-Shipment Cash Flow Gap
Supplier ships goods but waits 60–120 days for buyer payment. Cash locked during this gap.

**Trigger:** Any supplier with OA payment terms
**Quantification:** `locked_capital ≈ annual_revenue × (avg_payment_days/365) × 0.7`
Example: $20M × (90/365) × 0.7 = **$3.45M locked at any given time**

**Cascade:** → can't take new orders (PP-004) → delays fabric payment → takes high-interest loans (PP-002) → quality cutting → claims
**Solves with:** ARP (primary), MiniARP

#### PP-002: Financing Cost Burden
Current financing (bank LC/OD/informal) consumes 25–60% of already-thin margins.

**Trigger:** financing = bank LC/OD/informal; margin <12%
**Quantification:** `savings_vs_air8 = outstanding × (bank_rate − air8_rate) × (days/365)`
Example: $30M × 30% utilization × (12%−6%) = **$540K/year savings**

**Cascade:** → no capex → aging equipment → quality drops → collateral trapped → credit frozen during macro downturn
**Amplified by:** India OD 12–18%, Turkey instability, Pakistan 15–22%
**Solves with:** ARP, SmartWallet

#### PP-003: Buyer Concentration Risk
Supplier depends on 1–3 buyers for >50% revenue.

**Trigger:** top buyer >30% revenue OR top-3 >50%
**Critical:** single buyer >50% OR buyer showing distress signals
**Cascade:** → buyer reduces orders → can't cover fixed costs → buyer dictates longer terms (PP-001 worsens) → buyer demands price cuts (margins collapse)
**Solves with:** PayGuard

#### PP-004: Scalability Constraint
Buyer demand exceeds working capital capacity. Must reject orders.

**Trigger:** growth_stage = expanding AND bank utilization >80% AND new/growing buyer
**Quantification:** `opportunity_cost = rejected_order_value × margin`
**Cascade:** → rejected orders → buyer finds alternative → permanent revenue loss → supplier overstretches → quality/delivery suffers
**Solves with:** ARP (scalable, no fixed LC cap), RT2C

#### PP-005: Pre-Shipment Capital Gap
Needs cash BEFORE production (raw materials, workers, logistics). Bank LC doesn't cover this.

**Trigger:** type = FOB/Vertical + product = woven/denim/organic (long cycle) + revenue >$10M (OBF) or >$1M (RT2C)
**Quantification:** `pre_ship_need ≈ annual_revenue × (pre_production_days/365) × 0.4`
**Critical for:** Vertical integrators (buy cotton 60–90 days before production)
**Solves with:** OBF (>$10M, existing ARP client), RT2C (>$1M, existing ARP 6mo+)

#### PP-006: Trade Finance Literacy Gap
Owner doesn't understand factoring/receivable purchase. Thinks bank loan is the only option.

**Trigger:** revenue <$20M + owner/CEO role (no CFO) + financing = bank LC/none
**Amplified in:** BD, PK, KH, IDN (less developed TF market)
**Sales implication:** Education is prerequisite to conversion
**Solves with:** MiniARP (simplified entry), ARP (after education)

#### PP-007: Dilution / Buyer Deductions
Buyer deducts chargebacks, markdowns, quality claims from invoice payment.

**Trigger:** buyer = US Mass Market or US Department
**Rates:** Walmart/Target 3–8%, Macy's/Nordstrom 5–10%, Fast Fashion EU 2–5%
**Air8 impact:** Dilution data feeds into advance ratio calculation. Persistent dilution = quality/relationship risk signal.

---

### Country-Specific Pain Points

| ID | Country | Pain Point | Key Detail |
|---|---|---|---|
| PP-BD-001 | Bangladesh | Wage Hike | +56% minimum wage hike post-2024; squeezing margins critically |
| PP-BD-002 | Bangladesh | Political Instability | Hartals disrupt 15–20 production days/year |
| PP-BD-003 | Bangladesh | LDC Graduation | Losing EU duty-free access as BD graduates from LDC status |
| PP-CN-001 | China | SAFE Complexity | Cross-border FX regulations add admin friction |
| PP-CN-002 | China | Sinosure Burden | Monthly declaration by 15th; admin-heavy |
| PP-CN-003 | China | Hengqin Capacity | Air8's Hengqin entity has portfolio capacity constraints |
| PP-IN-001 | India | GST Refund Delay | GST refunds locked up, adding working capital strain |
| PP-IN-002 | India | Bank OD Cost | 12–18% p.a. — among the highest globally |
| PP-IN-003 | India | INR Depreciation | Currency risk on USD-priced orders |
| PP-TR-001 | Turkey | Lira Hyperinflation | Cost base in TRY, revenue in EUR/USD; severe squeeze |
| PP-TR-002 | Turkey | Bank Credit Contraction | Local banks cutting credit lines amid macro instability |
| PP-VN-001 | Vietnam | FDI Decision Authority | Local GM can't sign financing; must reach parent HQ in Korea/Taiwan |
| PP-IDN-001 | Indonesia | Rupiah Volatility | IDR swings 5–10% erode USD-based margins |
| PP-PK-001 | Pakistan | Energy Crisis | Power outages add 10–20% to production costs |

---

### Compliance Pain Points

| ID | Pain Point | Key Detail |
|---|---|---|
| PP-REG-UFLPA-001 | UFLPA Traceability | Missing gin-to-garment docs → 16% detention rate, 23-day average hold, $12–18K penalty |
| PP-REG-REACH-001 | REACH Chemical Compliance | SVHC list updated twice/year; re-testing $2–10K per substance; highest for denim |
| PP-REG-CSDDD-001 | EU CSDD Due Diligence | Buyers already sending DD questionnaires NOW (H&M, Zara, Primark, C&A) |
| PP-REG-TARIFF-001 | US Section 301 / New Tariffs | India: 50% (Aug 2025); China: 25–50%; Vietnam: 10–25% |

---

### Expansion Pain Points (Existing Air8 Clients)

| ID | Pain Point | Key Detail |
|---|---|---|
| PP-EXPAND-001 | Low Wallet Share | <50% of supplier's receivables flowing through Air8 = upsell opportunity |
| PP-EXPAND-002 | Missing Product Coverage | ARP-only client not using OBF/SmartWallet/PayGuard etc. |
| PP-EXPAND-003 | Operational Friction | Doc matching issues, FR holds, insurance limit blocks |

---

### ESG Pain Points

| ID | Pain Point | Key Detail |
|---|---|---|
| PP-ESG-001 | Credentials Not Monetized | Has GOTS/Fairtrade/C2C but not getting financing discount or buyer premium |
| PP-ESG-002 | Buyer ESG Escalating | Buyers requiring more ESG data faster than supplier can provide |

---

## 5. Air8 Products {#products}

### ARP — Accounts Receivable Purchase (Post-Shipment)
Air8 purchases supplier's invoice after shipment. Pays T+1 at 70–90% advance. Collects from buyer at maturity.

**Eligibility:**
- LF Vendor (Lane A): Revenue >$1M, ops >2yr, buyer_rel >2yr, KPI >90%
- Non-LF (Lane B/C): Revenue >$3M, ops >3yr, buyer_rel >3yr, KPI >90%

**vs Bank LC:** No collateral · No personal guarantee · T+1 disbursement (vs 30–60d LC) · SOFR+4% (vs 3–18% banks)
**Solves:** PP-001, PP-002 · **Fits:** All combos (core product)

---

### MiniARP — Simplified ARP for Small Suppliers
Same mechanics as ARP, simplified KYC, lower limits. Entry point for micro/small suppliers.

**Limits:** Max $300K exposure
**Eligibility:** Revenue >$1M, ops >2yr
**Solves:** PP-001, PP-006 · **Fits:** COMBO-007, 012, 015

---

### PreShip-OBF — Order Book Financing (Pre-Shipment)
Financing based on confirmed PO, disbursed BEFORE production starts.

**Eligibility:** Revenue >$10M + existing ARP client + LF vendor preferred
**Solves:** PP-005 · **Fits:** COMBO-003, 008, 013

---

### PreShip-RT2C — Rapid Trade 2 Cash (Pre-Shipment, lighter)
Pre-shipment financing based on existing ARP track record. Faster to approve than OBF.

**Eligibility:** Revenue >$1M + existing ARP client >6 months good track record
**Solves:** PP-005 · **Fits:** COMBO-001, 002, 008, 014

---

### PayGuard — Buyer Credit Protection
Protects supplier against buyer insolvency. Air8 absorbs the loss (backed by credit insurance).

**Trigger:** Buyer distress signals (adverse news, late payments) or high concentration
**Solves:** PP-003, PP-004 · **Fits:** COMBO-001, 003, 006

---

### Pool Factoring — Whole Turnover Facility
One facility covers ALL buyer relationships. Simpler admin for suppliers with 5+ buyers.

**Eligibility:** Revenue >$20M + 5+ active buyer pairs + good overall scorecard
**Solves:** PP-001, PP-002 · **Fits:** COMBO-003, 004, 009, 013

---

### SmartWallet — Cash Flow Intelligence (Non-Financing)
AI-powered dashboard: AR aging, payment forecasting, cash flow projection, multi-buyer reconciliation.

**Trigger:** buyer_count ≥3 + CFO or finance team exists
**Solves:** PP-001 (visibility layer) · **Fits:** COMBO-003, 004, 008, 013

---

### ESG Financing — ESG-Linked Preferential Pricing
10–25 bps discount for suppliers meeting ESG criteria. Funded via IFC green/social bond eligibility.

**Eligibility:** ≥3 ESG certs (GOTS/Fairtrade/C2C/ROC) + IFC criteria + renewable energy >20% + women >40% workforce
**Solves:** PP-ESG-001 · **Fits:** COMBO-003, 008

---

### DDP Financing
Financing for DDP/DDU shipments where supplier is importer of record in destination country.

**Note:** When Air8 entity is importer of record → Air8 bears direct REACH compliance risk
**Fits:** COMBO-013

---

## 6. Regulations {#regulations}

### REG-UFLPA: Uyghur Forced Labor Prevention Act
**Jurisdiction:** US · **Effective:** June 21, 2022

Rebuttable presumption for Xinjiang-origin content. Must prove "clear and convincing evidence" goods are NOT made with forced labor.

**2024 Enforcement:** 4,619 shipments detained (+14.9% YoY) · 876 apparel · 36% clearance rate (vs 58% all-sector)

**Required docs by tier:**
| Tier | Documents |
|---|---|
| Tier 1 (factory) | PO, Invoice, Packing List, BL |
| Tier 2 (mill) | PO/Contract, Invoice, Mill certs, Test reports |
| Tier 3 (spinner) | PO/Contract, Invoice, Origin certification |
| Tier 4+ (farm) | Origin certs, Farm/plantation records, Lab results |

**Risk by country:** CN (VERY HIGH) → BD/IN/PK/VN (MEDIUM) → Organic cotton with farm traceability (LOW)
**Air8 advantage:** T4S Platform — 264+ POs traced, 164 styles, 74 suppliers, 7,000+ trade docs

---

### REG-REACH: EU REACH (Chemicals)
**Jurisdiction:** EU (+ UK REACH separately) · **Continuously updated**

Products must NOT contain SVHC >0.1% w/w. SVHC candidate list updated TWICE per year (Jan + Jul).

**Testing cost:** $2,000–10,000 per substance per factory
**Highest risk:** Denim (indigo, permanganate, PP spray, resin finishes), children's apparel, home textiles with fire retardant
**Air8 risk:** DDP transactions where Air8 is importer of record → direct compliance liability

---

### REG-CSDDD: EU Corporate Sustainability Due Diligence Directive
**Jurisdiction:** EU · **Published:** July 2024 · **Omnibus amendment:** Feb 2026

**Timeline:**
| Phase | Date | Threshold |
|---|---|---|
| 1 | Jul 2028 | >€1.5B + 5,000 employees |
| 2 | Jul 2029 | >€900M + 3,000 employees |
| 3 | Jul 2029+ | >€450M + 1,000 employees |

**Already happening:** H&M, Zara/Inditex, Primark, C&A already sending DD questionnaires NOW.
**Air8 advantage:** LF ecosystem provides factory-level VOICES ratings, HiggFEM, social audits, T4S → Air8 suppliers ahead of curve.

---

### REG-GPSR: EU General Product Safety Regulation
**Jurisdiction:** EU · **Effective:** December 13, 2024

All consumer products must have EU "economic operator" designated. Name + contact info on product/packaging.
Affects ALL EU-bound suppliers across all product categories.

---

### REG-TARIFF: US Section 301 + New Tariffs (2025)
| Country | Tariff Rate |
|---|---|
| China | 25–50% on most apparel |
| India | 50% on apparel (NEW — Aug 2025) |
| Vietnam | 10–25% |
| Bangladesh | Under discussion post-LDC graduation |

---

### REG-S211: Canada Bill S-211 (Forced Labour)
**Jurisdiction:** Canada · **Effective:** January 1, 2024

Annual public reporting on forced labor / child labor risk for entities with ≥$20M assets or ≥$40M revenue operating in Canada.
Air8 T4S data supports S-211 reporting requirements.

---

### REG-NYFASHION: NY Fashion Act (Proposed)
**Status:** Proposed — not yet enacted · **Scope:** NY-based brands >$100M global revenue
If enacted: supply chain mapping (≥50% of suppliers) + Scope 1/2/3 GHG disclosure.
Affected buyers: Ralph Lauren, PVH, Tapestry.

---

## 7. ESG Standards {#esg-standards}

| Standard | Description | Air8 Relevance |
|---|---|---|
| **GOTS** | Global Organic Textile Standard. ≥70% organic content. Annual renewal. | UFLPA risk ↓, ESG financing eligible |
| **Fairtrade** | Fair price + premium for cotton farmers, labor standards. | CSDDD compliance, ESG financing eligible |
| **C2C** | Cradle to Cradle Certified. Material health, circularity, clean air/water. Levels: Bronze→Platinum. | Strongest ESG signal, IFC eligible |
| **ROC** | Regenerative Organic Certified. Beyond organic: soil health + animal welfare + social fairness. | Rarest, highest value for CSDDD conversations |
| **Higg Index** | FEM (Environmental), FSLM (Social Labor), BRM (Brand/Retail) scores. | Feeds Air8 scorecard Market Insights dimension |
| **ZDHC** | Zero Discharge of Hazardous Chemicals. Gateway: approved chemical formulations database. | Reduces REACH PP-REG-REACH-001 risk |
| **IFC** | IFC green/social finance eligibility. | ≥3 ESG certs + renewables >20% + women >40% → 10–25 bps discount |

---

## 8. Linkage Tables {#linkage}

### 8.1 Persona → Full Linkage

| Combo | Pain Points | Products | Compliance |
|---|---|---|---|
| COMBO-001 | PP-001,002,003,004,006 + PP-BD/IN/PK | ARP, RT2C, PayGuard | UFLPA(cotton→US), REACH(EU), CSDDD |
| COMBO-002 | PP-001,002,004,005 + PP-BD-001,002,003 | ARP, RT2C, PayGuard | UFLPA(if US), REACH(if EU), Accord/RSC |
| COMBO-003 | PP-001,002,005 + PP-IN-001,002 + PP-ESG-001 | ARP, OBF, Pool, SmartWallet, ESG-Finance | UFLPA(advantage:organic), CSDDD, REACH |
| COMBO-004 | PP-001,002 + PP-CN-001,002,003 | ARP(Hengqin), SmartWallet, Pool | UFLPA(high), REACH, CSDDD, SAFE |
| COMBO-005 | PP-001,002,003 + PP-TR-001,002 | ARP(USD), Pool | REACH(highest:chemicals), CSDDD |
| COMBO-006 | PP-001,004 + PP-VN-001 | ARP(parent pitch), PayGuard | UFLPA(if cotton), CSDDD |
| COMBO-007 | PP-001,002,003,006 + PP-IDN-001 | MiniARP → ARP | UFLPA(if cotton), REACH, GPSR |
| COMBO-008 | PP-001,002,005 + PP-IN-001,002 + PP-ESG-001 | ARP, RT2C/OBF, ESG-Finance, SmartWallet | UFLPA(advantage), CSDDD, REACH |
| COMBO-009 | PP-001,002 + PP-PK-001 | ARP, Pool | UFLPA(cotton), REACH(fire retardants) |
| COMBO-010 | PP-EXPAND-001,002,003 | Whatever they lack | Depends on new buyer/market |
| COMBO-011 | PP-001,006 | Back-to-Back TCS | OPS-KYC-002 third-party prohibition |
| COMBO-012 | PP-001,002 + EBA risk | ARP, MiniARP | EBA preference risk, CSDDD |
| COMBO-013 | PP-001,002,005 | ARP(multi), DDP, Pool, SmartWallet | ALL regs × ALL countries |
| COMBO-014 | PP-001,002,003,005 + PP-IN-001,002 | ARP, RT2C | UFLPA(if cotton→US), REACH(if EU) |
| COMBO-015 | PP-001,006 | MiniARP (if eligible) | Basic compliance only |

---

### 8.2 Regulation → Affected Entities

| Regulation | Countries | Products | Combos | Cascade Start |
|---|---|---|---|---|
| UFLPA | CN(highest), BD, IN, PK, VN | Cotton knit, woven, denim, home | 001–005, 008, 009, 014 | PP-REG-UFLPA-001 |
| REACH | TR(highest), CN, BD, IN | Denim, chemical-finish, children's, home | 001, 004, 005, 008, 009, 014 | PP-REG-REACH-001 |
| CSDDD | ALL | ALL products | ALL with EU market | PP-REG-CSDDD-001 |
| GPSR | ALL | ALL consumer products to EU | ALL with EU market | Shipment rejection |
| S-211 | ALL | ALL to Canada | Combos with Canadian buyers | Annual reporting |
| Section 301 | CN, IN (new 50%) | ALL to US | 004(CN), 014(IN) | PP-REG-TARIFF-001 |
| BD LDC graduation | BD only | ALL BD→EU | 002, 012 | PP-BD-003 |

---

### 8.3 Event → Impact Propagation (How News Cascades)

**"Cotton price rises 15%"**
```
→ Raw material cost ↑ for ALL cotton products
→ PP-005 intensity ↑
→ Affects COMBO: 001,002,003,004,005,008,009,014,015
→ Secondary: supplier uses lower-grade cotton → claim risk ↑
→ Secondary: vertical integrators (003,008) LESS affected (own cotton sourcing)
→ Monitor: commodity.cotton_price (Cotlook A-Index)
```

**"Bangladesh political crisis escalates"**
```
→ PP-BD-002 (production disruption) triggers
→ Directly affects COMBO-002, partially COMBO-001
→ Secondary: OTD drops → scorecard degrades → facility terms worsen
→ Secondary: buyers shift to India/Vietnam → COMBO-008, 014, 006 surge demand
→ Tertiary: India/Vietnam absorb → PP-004 triggers for new orders
```

**"ECHA adds new SVHC affecting denim"**
```
→ PP-REG-REACH-001 for ALL denim→EU
→ COMBO-005 (Turkey denim) most directly affected
→ Secondary: re-testing cost $2–5K per factory → PP-002
→ Secondary: shipment detained → invoice unpayable → Air8 AR at risk
→ Tertiary: buyer pauses orders → PP-003 (revenue gap)
```

**"Existing client (India Large Vertical Integrator) wants to expand"**
```
→ Match: COMBO-003 + COMBO-010
→ Active: PP-EXPAND-001 (wallet share ~26%), PP-EXPAND-002 (ARP only)
→ Products needed: OBF (massive pre-ship need), Pool (20+ buyers),
    SmartWallet (multi-buyer CFO), ESG Financing (IFC eligible)
→ Compliance value: UFLPA advantage (organic = inherent traceability)
```

---

### 8.4 Product → Reverse (Pain Points + Best Fit Combos)

| Product | Solves | Best Fit Combos | Pre-conditions |
|---|---|---|---|
| ARP | PP-001, PP-002 | ALL (001–015) | Eligible buyer pair + insurance |
| MiniARP | PP-001, PP-006 | 007, 012, 015 | Revenue >$1M, ops >2yr |
| PreShip-OBF | PP-005 | 003, 008, 013 | Revenue >$10M, existing ARP |
| PreShip-RT2C | PP-005 | 001, 002, 008, 014 | Revenue >$1M, existing ARP 6mo+ |
| PayGuard | PP-003, PP-004 | 001, 003, 006 | Buyer distress signal |
| Pool Factoring | PP-001, PP-002 | 003, 004, 009, 013 | 5+ buyers, $20M+ revenue |
| SmartWallet | PP-001 (visibility) | 003, 004, 008, 013 | 3+ buyers, finance team exists |
| ESG Financing | PP-ESG-001 | 003, 008 | ≥3 ESG certs, IFC criteria met |
| DDP Financing | PP-005 (DDP) | 013 | Incoterm = DDP/DDU |

---

*Air8 KB v2.0 · Consolidated Reference · Generated June 2026*
*Source: air8-kb-local/ · 15 personas · 35+ pain points · 9 products · 7 regulations · 7 ESG standards · 4 linkage tables*
