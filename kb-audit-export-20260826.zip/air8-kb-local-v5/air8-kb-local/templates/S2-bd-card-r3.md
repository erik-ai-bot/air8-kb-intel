# Template: S2 BD Card — Round 3 (Full Offer / Pre-Credit Decision)

> Input: R2 answers + financial data (revenue, buyer payment history, bank facility)
> KB used: Full instance + product eligibility gates + risk rules

---

```
╔══════════════════════════════════════════════════════════════╗
║ BD OFFER CARD · Round 3 — CREDIT READY                      ║
║ Client: [Name] · [COMBO-XXX] · Eligibility: [CONFIRMED]     ║
╚══════════════════════════════════════════════════════════════╝

━━━ ELIGIBILITY CONFIRMATION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Product: [PROD-ARP / PROD-PRESHIP-OBF / etc.]

✅ Revenue: $[X]M — [meets $[threshold] minimum]
✅ Operations: [X] years — [meets [threshold] year minimum]
✅ Buyer relationship: [X] years with [buyer] — [meets threshold]
✅ Buyer PO: [confirmed / indicative] — [eligible / flag]
✅ Buyer rating: [BB equivalent / investment grade] — [eligible]
✅ Insurance: [available / pending] for [buyer name]

[⚠️  Any constraint that limits the offer — state explicitly]

━━━ FINAL OFFER ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Product: [Product Name]
Facility Size: $[X]M
Advance Rate: [X]%
Tenor: ≤[X] days
Pricing: [SOFR+X% or equivalent]
Buyer Pairs Covered: [list or "up to X buyer pairs"]

Net Annual Saving vs Current: $[X]K (vs current [method] at [rate])

Risk Basis for Air8:
"[Self-liquidation chain] | [Collateral] | [Risk label]"

━━━ RISK SIGNAL ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Signal: [EXPAND / CONDITIONAL / CAUTION]

[Any risk rules that apply — RP-RISK-CONC-01 if commodity concentration, etc.]
[Any monitoring triggers — what to watch quarterly]

━━━ CREDIT RECOMMENDATION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Recommended action: [Approve / Approve with conditions / Refer to credit committee]
Advance ratio: [X]%
Review frequency: [Monthly / Quarterly]
Monitoring signals:
1. [Signal 1 — e.g., PO volume trend]
2. [Signal 2 — e.g., payment speed vs terms]
3. [Signal 3 — e.g., dilution rate]
Trigger for reduction: [specific condition]

━━━ NEXT STEPS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. [KYC/document collection — what's needed]
2. [Insurance confirmation for buyer pair]
3. [Agreement signing — timeline]
4. [First disbursement — expected timeline]
```
