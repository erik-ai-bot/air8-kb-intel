# Template: S2 BD Card — Round 2 (Instance Match / After First Contact)

> Input: R1 answers (material, buyer mix, cash cycle, financing type)
> KB used: Specific COMBO instance + pain points + product eligibility

---

```
╔══════════════════════════════════════════════════════════════╗
║ BD OUTREACH CARD · Round 2                                   ║
║ Client: [Name] · Match: [COMBO-XXX: Name] · Conf: [0.XX]    ║
╚══════════════════════════════════════════════════════════════╝

✅ CONFIRMED PAIN (with your data)

Based on what you told us:
• "[Client answer] → [Structural implication]"
  Example: "90% buyer-nominated fabric → India cotton savings don't reduce your cost directly"
  Example: "90-day cycle + 30% prepay → ~$[X]M working capital tied up per cycle"
  Example: "Top buyer = [X]% revenue → significant concentration risk"

Why this matters for Air8:
[1-2 sentences connecting their specific situation to the Air8 value proposition]

━━━ AIR8 OFFER SHAPE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 Product: [PROD-ARP / PROD-PRESHIP-OBF / etc.]
   
   Estimated limit: $[X–Y]M (based on your revenue × buyer quality)
   Tenor: ≤[X] days
   
   Saving vs your current:
   → You pay: [current rate] / [current method]
   → With Air8: [Air8 rate / T+1 vs current delay]
   → Estimated net saving: $[X]K per year / per $[Y]M financed
   
   [If PSF: self-liquidation chain]
   → "[Cotton purchase / fabric procurement] → production → buyer payment → Air8 repaid"
   → Air8 risk: [Low] when buyer is [investment-grade / confirmed PO anchor]

━━━ ROUND 3 QUALIFYING QUESTIONS ━━━━━━━━━━━━━━━━━━━━━━━━━━

To finalize the offer, we need to confirm:
1. "Do buyers give you back-to-back POs or blanket/open orders?"
2. "Have you used pre-shipment financing before? At what annualized cost?"
3. "What is your current bank credit line size and utilisation %?"
4. "Happy to share last 12 months' buyer payment history?"
5. [Any specific question from assessment_dimensions not yet answered]

━━━ IF NOT YET ELIGIBLE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[Only include if eligibility gate not yet confirmed]
⚠️ To unlock [Product], we need: [specific eligibility requirement]
While we confirm this, here's what you can access immediately: [alternative or monitoring]
```

---

## Notes for BD

- Use real client data — do not fabricate numbers
- Estimated limit is a range, NOT a commitment (use language: "typically" or "based on your profile")
- If eligibility gate fails → say so clearly; offer advisory/monitoring rather than wrong product
- Saving calculation must use actual client data from R1 answers — not generic benchmarks
