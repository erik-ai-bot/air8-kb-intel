# Template: S1 Event Card

> Use this template for every S1 output. All sections are REQUIRED.
> Quality Gate G3: card must have WHY + SIGNAL + RECOMMENDATION + WHAT TO DO + IF + QUALIFYING QUESTIONS
> Updated: 2026-07-14 — added WHAT TO DO (supplier-strategic), structured 5-dim qualifying questions, computed numbers required in WHY

---

```
╔═══════════════════════════════════════════════════════════════╗
║ 🎯 S1 EVENT CARD                                              ║
║ [Event Title] · Source: [Regulation/News/Market]              ║
║ Confidence: [0.80+] · Window: [Start] → [End / cliff if any] ║
╚═══════════════════════════════════════════════════════════════╝

━━━ PRIMARY IMPACT COMBO ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📍 [COMBO-XXX: Name] — [Direction: BENEFIT / THREAT] — [Severity: HIGH / MEDIUM]

WHY THIS EVENT HITS THEM
• [Structural nuance from combo KB — LLM would miss this]
  → [Retrieved fact that QUANTIFIES the nuance — MUST include computed number]
  → e.g. "blended saving X-Y% on total cotton cost; +Z% gross margin uplift"
• [Second mechanism — e.g. domestic price floor / blend ratio]
• [Competitive context vs peer origins — always include 1 sentence]
• [Second-order effect — post-cliff, over-stockpiling, substitution risk]

⚠️ MANDATORY: WHY section must include at least ONE computed number
   (margin uplift %, cost saving %, WC increase %, days, price per kg, etc.)
   Retrieve via LLM directive → surface the result here. Do NOT leave as "~X%".

🚦 SIGNAL: [EXPAND | CONDITIONAL_EXPAND | CAUTION | NEUTRAL | DO_NOT_EXPAND]

Signal rationale: [1-2 sentences — why this specific signal, not generic]

━━━ AIR8 RISK SIGNAL ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 Product: [PROD-ARP / PROD-PRESHIP-OBF / etc.]
   Risk basis: [Self-liquidation chain if applicable — required for PSF/OBF]
   → "[Raw material] → production → buyer receivable → Air8 repaid"
   → Typical: [X] days | Risk label: [Low / Medium] Air8 risk

   Limit guidance: [+X% / hold / reduce] (per risk rule RP-RISK-CONC-01)
   Tenor: ≤[X]d [if cliff: must settle before [cliff_date]]
   Eligibility check: [buyer PO confirmed? revenue threshold? buyer rating?]

━━━ WHAT TO DO ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Supplier-strategic actions (specific, numbered, time-bound where applicable):
1. [Immediate action — what supplier/BD should do NOW, and why the timing matters]
2. [Commercial action — pricing, contracts, buyer negotiation angle]
3. [Competitive/market action — position vs peers, export opportunity, market timing]
4. [Working capital / Air8 action — WC planning, OBF drawdown schedule, risk]

⚠️ Risk Actions (Air8 internal):
   1. [Concentration check — single commodity/country % vs cap]
   2. [Post-cliff monitoring / disbursement deadline if applicable]

📋 Monitoring:
   [What signals to watch, at what frequency, and what would trigger re-assessment]

━━━ QUALIFYING QUESTIONS FOR BD ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Structured across 5 dimensions. Questions are event × combo specific — not generic.
Order: signal-flip-critical first.

📊 DEMAND
Q: [What PO volume trend / buyer pipeline signal matters for this event × combo?]
   Signal impact: [if growing → X; if declining → Y]

👥 BUYERS
Q: [Buyer concentration, geography, or specific buyer exposure relevant to this event?]
   Signal impact: [if US-heavy → X; if EU-only → Y]

🏭 PRODUCT
Q: [Which product lines / materials / certifications are affected by this event?]
   Signal impact: [if organic → flip; if conventional → benefit applies]

💰 CASH
Q: [Payment terms, OD utilisation, or cash cycle question relevant to this event?]
   Signal impact: [if OD maxed → constrained; if headroom → can pre-buy]

⚙️ CAPACITY
Q: [Production headroom, entity structure, or operational constraint relevant to this event?]
   Signal impact: [if full capacity → can absorb stockpile; if constrained → timing risk]

Note: each dimension may have 1-2 specific sub-questions depending on event complexity.
      Replace generic placeholders with event × combo specific language every time.

━━━ KEY SCENARIOS (IF BRANCHES) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔀 IF [specific condition — e.g. GOTS-certified organic lines]:
   [What changes in signal, product, or action]
   Air8: [specific modified recommendation]

🔀 IF [cliff / timing condition]:
   [What changes in tenor, disbursement schedule, or risk posture]
   Air8: [specific modified recommendation]

🔀 IF [buyer PO not confirmed / buyer not investment-grade]:
   [Hold PSF; do not disburse; switch to ARP only]

━━━ SECONDARY COMBOS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[COMBO-YYY]: [Direction] — [1 sentence WHY] — Signal: [X]
[COMBO-ZZZ]: [Direction] — [1 sentence WHY] — Signal: [X]

━━━ SIGNAL DERIVATION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

primary_signal: [SIGNAL]
triggered_by:
  - primitive: [RP-XXX or L0-principle-id]
    fact: "[specific fact that activated this — quote from structural_nuance or LLM directive result]"
    edge: "[combo_id] [edge_type] [target_id]"
overriding_flips:
  - flip_condition: "[which signal_flip_condition fired]"
    original_signal: "[what signal would have been without flip]"
    overridden_to: "[actual signal after flip]"
    tier: "[compliance|risk|structural|commercial]"
confidence: [0.0-1.0]
missing_data: ["[dimension not answered — using default assumption]"]

━━━ ACTIVE EVENT CACHE ENTRY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

trigger_id: T-[YYYY-MMDD]-[COUNTRY]-[MATERIAL/EVENT]
cliff: [date or null]
ttl_days: [90 / 60 / 45 / 30]
s2_hook: "[Ready-to-use 'Why Now' sentence for BD outreach]"
expires_at: [cliff_date or today + ttl_days]
```

---

## Checklist Before Emitting

- [ ] WHY section contains ≥1 structural nuance (not just headline %)
- [ ] WHY section contains ≥1 **computed number** (margin uplift %, cost saving %, WC %, price/kg)
- [ ] Competitive context included (1 sentence on peer origin comparison)
- [ ] Second-order effect mentioned (post-cliff, over-stockpiling, substitution)
- [ ] Signal flip conditions checked
- [ ] PSF/OBF includes self-liquidation chain + risk label
- [ ] WHAT TO DO has ≥3 specific numbered actions (supplier-strategic, not just BD internal)
- [ ] Qualifying questions structured across all 5 dims (Demand/Buyers/Product/Cash/Capacity)
- [ ] Each qualifying question has explicit signal_impact (if A → X; if B → Y)
- [ ] Each qualifying question passes the leading-question test: can it be answered YES or NO without implying the answer? If the question embeds the answer (e.g., “Has Air8 become the only source?”) → rewrite as open-ended (e.g., “Relative to banks and export factoring, how important has Air8’s facility become in the past 12 months?”)
- [ ] Correlated event check completed (P0-8) — active_event_cache queried for ≥2 overlapping tags; relationship type stated
- [ ] All WHY / INSIGHT claims carry inline confidence labels [VERIFIED / EXPERT / HYPOTHESIS / PENDING DATA]
- [ ] KEY SCENARIOS covers: main signal flip condition + cliff condition (if applicable)
- [ ] Concentration cap checked (risk rule RP-RISK-CONC-01)
- [ ] Cliff date → latest safe booking date calculated (if applicable)
- [ ] Active Event Cache entry written
- [ ] SIGNAL DERIVATION block completed
