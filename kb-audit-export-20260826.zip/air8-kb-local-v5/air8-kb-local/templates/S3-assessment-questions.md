# Template: S3 Individual Supplier Assessment Card

> All sections REQUIRED.
> Updated: 2026-07-14
> KEY RULE: By S3 we have the supplier's answers — state conclusions as facts.
> PENDING SCENARIOS only appear when a dim is still unanswered (PROVISIONAL). Omit entirely if all dims answered.

---

```
INDIVIDUAL SUPPLIER ASSESSMENT
Supplier:     [Name]
COMBO Match:  [COMBO-XXX]
Active Event: [Event title]
Date:         [YYYY-MM-DD]
Generic Signal (S1): [SIGNAL] — [1-line rationale]

QUESTION SET
Structured across 5 dims. Signal-flip-critical first.

DEMAND    Q: [PO volume / stockpile plan relevant to event]  Collect: [doc]  Impact: [if A→X; if B→Y]
BUYERS    Q: [Concentration / geo / specific buyer exposure] Collect: [doc]  Impact: [if A→X; if B→Y]
PRODUCT   Q: [Lines / materials / certs affected by event]  Collect: [doc]  Impact: [if A→X; if B→Y]
CASH      Q: [Payment / OD / cash cycle for this event]     Collect: [doc]  Impact: [if A→X; if B→Y]
CAPACITY  Q: [Headroom / entity / operational constraint]   Collect: [doc]  Impact: [if A→X; if B→Y]

SUPPLIER ANSWERS  ← state confirmed facts, not hypotheticals
  Demand:   [confirmed answer]
  Buyers:   [confirmed answer]
  Product:  [confirmed answer]
  Cash:     [confirmed answer]
  Capacity: [confirmed answer]
  PROVISIONAL: [dim] — not yet answered; assumed [default]; pending [doc/call]

SIGNAL COMPUTATION
  Generic (S1): [COMBO signal] — [rationale]
  Specific:     [supplier-specific signal]
  Delta:        [which answer caused the change, if any]
  Formula:      [actual numbers — e.g. 11% × 60% import × 65% COGS × 70% conv = 3.0% margin uplift]
  Flip conditions checked:
    • [Condition 1]: [fired / not fired — state evidence from supplier answers]
    • [Condition 2]: [fired / not fired — state evidence]

WHAT TO DO
  Based on confirmed answers — stated as facts, not conditions:
  1. IMMEDIATE   — [what to do NOW, specific to their confirmed situation + timing]
  2. COMMERCIAL  — [pricing / contract based on their actual buyer mix and contracts]
  3. COMPETITIVE — [market positioning based on their actual product lines and certs]
  4. WC / AIR8  — [their specific OBF schedule and WC plan based on confirmed exposure]

AIR8 RECOMMENDATION
  Product:         [PROD-XXX]
  Estimated limit: [$X–Y based on their revenue and confirmed answers]
  Tenor:           ≤[X]d  [if cliff: disburse by [date]]
  Risk basis:      [material → production → receivable; X days; Low/Medium risk]
  Condition:       [what must still be confirmed before proceeding]
  Co-product:      [PROD-YYY — when and why, if applicable]

MONITORING TRIGGERS
  1. [Signal that upgrades recommendation — specific threshold]
  2. [Signal that downgrades — specific threshold]
  3. [Timing gate — e.g. date passes → switch product]

PENDING SCENARIOS  ← ONLY if dims are still PROVISIONAL; omit entirely if all answered
  [Dim X] not yet confirmed — assumed [default].
    If [answer A] → [signal / action stays — be specific why]
    If [answer B] → [signal flips to / action changes to — be specific]
    Priority: HIGH (this answer can flip the signal — resolve before Air8 acts)
             | LOW (magnitude only — does not change the go/no-go decision)
  [One block per unanswered dim only]
```

---

## Checklist Before Emitting

- [ ] Questions structured across all 5 dims; signal-flip-critical FIRST
- [ ] Each dim has explicit collect + signal_impact
- [ ] Supplier answers are confirmed facts; unanswered dims marked PROVISIONAL with stated default
- [ ] Signal computation: formula with actual numbers from answers
- [ ] Generic vs specific signal delta explicitly stated
- [ ] All COMBO flip conditions checked with evidence (fired / not fired)
- [ ] WHAT TO DO: ≥3 actions grounded in THIS supplier's confirmed answers (not copied from S1)
- [ ] Air8 recommendation: product + limit + tenor + self-liquidation chain + condition
- [ ] Monitoring: upgrade trigger + downgrade trigger
- [ ] PENDING SCENARIOS: present ONLY for unanswered dims; each block has Priority HIGH/LOW flag; omit entirely if all answered
