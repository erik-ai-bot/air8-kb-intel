# Template: S2 BD Card — Round 1 (Cold Outreach / Archetype Match)

> Input: Company name + country + estimated size
> KB used: Archetype node + top universal pain points + active event cache

---

```
╔══════════════════════════════════════════════════════╗
║ BD OUTREACH CARD · Round 1                           ║
║ Client: [Name] · Country: [XX] · Match: [Archetype]  ║
║ Confidence: [Low/Med/High — based on available info] ║
╚══════════════════════════════════════════════════════╝

🔥 ACTIVE EVENT HOOK (only if relevant event in cache)
"[s2_hook text from Active Event Cache — Why Now sentence]"
→ Days remaining in window: [X] days

━━━ PAIN #1 · [Pain Name] ━━━━━━━━━━━━━━━━━━━━━━━━━━━

What they typically say:
"[Quote that resonates — the pain in their words]"

Root cause:
[1-2 sentences: structural reason this pain exists for this archetype]

Air8 solution:
[Product name] — [1 sentence on HOW it solves the pain, not WHAT it is]

Opening line (use this):
"[Ready-to-use BD opening line — direct, specific, no jargon]"

━━━ PAIN #2 · [Pain Name] ━━━━━━━━━━━━━━━━━━━━━━━━━━━

What they typically say:
"[Quote]"

Root cause:
[1-2 sentences]

Air8 solution:
[Product + 1 sentence]

Opening line:
"[Ready-to-use line]"

━━━ PAIN #3 · [Pain Name — country-specific if applicable] ━━━

What they typically say: "[Quote]"
Root cause: [1 sentence]
Air8 solution: [Product + 1 sentence]

━━━ ROUND 2 QUALIFYING QUESTIONS ━━━━━━━━━━━━━━━━━━━━━━

Ask these before the next conversation:
1. "What % of your fabric/yarn is buyer-nominated vs own-sourced?"
2. "Who are your top 2-3 buyers by revenue share?"
3. "Typical PO-to-payment cycle in days?"
4. "What material do you primarily work with?"
5. "What financing do you use currently (bank LC, OD, other)?"

━━━ ELIGIBILITY PRE-CHECK ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️  Before Round 2: confirm revenue and operations years
Revenue ≥ $1M AND operations ≥ 2yr → eligible for MiniARP minimum
Revenue ≥ $3M AND operations ≥ 3yr → eligible for standard ARP

⚠️  OBF (Pre-Shipment) — DO NOT promise at R1:
PROD-PRESHIP-OBF requires: (1) confirmed buyer PO anchor, (2) buyer rating ≥ BB equivalent.
Neither can be confirmed at R1 from archetype match alone.
If client asks about pre-shipment → say: "We can explore that — I'll need to confirm your buyer details first."
OBF eligibility gates confirmed only at R2/R3 after buyer identity and rating are known.

If not confirmed → do NOT discuss specific limits or OBF yet.
```

---

## Notes for BD

- Round 1 is archetype-level only — do not promise specific limits or products
- Active Event Hook dramatically increases response rates when relevant — use it
- Pain themes are archetype-level averages; they sharpen significantly in Round 2 with real client data
- Three pains = standard for R1; two pains + strong event hook is acceptable if hook is very relevant
