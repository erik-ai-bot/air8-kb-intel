---
type: review
id: REVIEW-ALICE-CLUSTERS
version: 1.0
date: 2026-07-16
source: KB Engine combined cluster analysis — Subagent run
reviews: [CLUSTER-US-DECOUPLING-ANALYSIS.md, CLUSTER-EU-MARKET-ACCESS-ANALYSIS.md]
domain: apparel_only (Alice's domain — no hardgoods)
---

# Review File for Alice — Cluster Analyses (D+F and B+C+BD EU Trade)

**Purpose:** Items that need Alice's expert validation before engine outputs can be used in BD materials, client conversations, or further KB updates. All engine reasoning is documented in the full analysis files; this review focuses on the items where Alice's expert knowledge is the deciding input.

---

## Part 1: CLUSTER-US-DECOUPLING (Events D+F Combined)

### Combined Framing Summary

The engine framed the CLUSTER-US-DECOUPLING as a two-lever, two-mechanism analysis where UFLPA (access denial via traceability documentation) and Section 301 / IEEPA (cost penalty via country-of-origin tariff) are scored INDEPENDENTLY for each combo. A supplier can be fully UFLPA-compliant and still face S301 tariff costs; a supplier can have zero Xinjiang cotton exposure and still be subject to country-level S301 duties. The engine applied RP-STRUCTURAL-CHANGE to each lever separately: IEEPA is cyclical (reversible by executive order), S301 once published in the Federal Register is structural (5-10+ year horizon). This distinction materially changes how Air8 should frame the conversation with clients.

The engine identified an asymmetric portfolio structure: the same cluster event that creates negative signals for CN (COMBO-004) and KH (COMBO-012) creates conditional positive signals for PK (COMBO-009) via the Punjab cotton UFLPA advantage, and for BD (COMBO-002) via the Indian yarn origin advantage. The portfolio action is therefore not just "reduce exposure to tariffed countries" but simultaneously "pre-position in beneficiary combos to capture diverted US buyer spend."

### Signal Direction Summary per Combo (No Figures)

| Combo | UFLPA Signal Direction | S301 Signal Direction | Net Combined Direction |
|---|---|---|---|
| COMBO-004 (CN Woven) | DO_NOT_EXPAND US-bound (high Xinjiang exposure risk; RP-PEER-FAILURE on survivors) | DO_NOT_EXPAND US-bound (structural once Federal Register; CN is primary target) | Negative — most negative US cluster combo |
| COMBO-006 (VN FDI Knit) | CONDITIONAL (cotton origin documentation required; brand cert insufficient) | CAUTION (US primary exposure; parent relocation risk activated at structural break moment) | Caution — structural risk if S301 confirmed |
| COMBO-002 (BD CMT) | CONDITIONAL POSITIVE (Indian yarn = hidden UFLPA compliance advantage if documented) | CAUTION conditional (US secondary; forced labor framing may narrow/delay vs CN/VN) | Low-Medium risk; BD has hidden UFLPA advantage |
| COMBO-009 (PK Home Textile) | CONDITIONAL POSITIVE (Punjab cotton = strongest UFLPA moat in cluster) | MONITOR (lower probability S301 targeting than BD/VN/KH) | Positive conditional — strongest net signal in cluster |
| COMBO-012 (KH) | COMPLIANCE_BLOCK (US-bound; low documentation infrastructure) | DO_NOT_EXPAND (dual-threat: S301 + EU EBA; cross-cluster confirmed) | Most negative combined signal across both clusters |

### Items Alice Needs to Validate

**US-DECOUPLING-V1: UFLPA vs S301 dual-mechanism framing**

Engine assertion: UFLPA and Section 301 / IEEPA are independently scoreable mechanisms; a factory can satisfy one and still be fully exposed to the other. They should have separate Air8 protocols (documentation check vs advance ratio decision).

Question for Alice: Is this dual-mechanism framing correct as the operative description for how CBP and USTR treat these two enforcement streams? Are there any cases where UFLPA compliance status affects S301 tariff treatment, or are they genuinely independent in commercial practice?

---

**US-DECOUPLING-V2: BD Indian yarn UFLPA advantage — directionally correct?**

Engine assertion: BD factories sourcing yarn from India (approximately 60% industry average, per COMBO-002 structural nuance in KB) have a UFLPA compliance advantage because Indian cotton is not Xinjiang-origin, and the rebuttable presumption under UFLPA can be met with Indian gin-level origin documentation.

Question for Alice:
- Is this framing directionally correct — does Indian yarn origin genuinely reduce UFLPA rebuttable presumption risk for BD factories shipping to the US?
- Is the ~60% India yarn sourcing figure the right directional default for BD CMT factories, or is it segment-specific (knit vs woven)?
- Does the UFLPA compliance pathway for BD via Indian yarn require gin-level documentation, or is spinner-level sufficient?

---

**US-DECOUPLING-V3: PK home textile UFLPA positive signal — correct framing?**

Engine assertion: Pakistan Punjab cotton is clearly non-Xinjiang origin and is documentable at field/gin level. This creates a UFLPA compliance moat for PK home textile exporters selling to US mass market buyers (Walmart, Target) who need supply chain compliance certainty.

Question for Alice:
- Is PK Punjab cotton genuinely clean from a UFLPA standpoint — does the engine correctly characterise it as low-risk for Xinjiang exposure?
- Is the field-level documentation claim for PK cotton realistic — do Pakistani cotton producers typically maintain the traceability infrastructure CBP would require?
- Are US mass market buyers (Walmart, Target) actually requesting UFLPA documentation from PK home textile suppliers, or is this a future opportunity not yet buyer-driven?

---

**US-DECOUPLING-V4: Combined net signal per combo — directionally right?**

Engine conclusion: CN and KH are the most negative combos; PK and BD are net positive or neutral; VN is the middle caution case with parent-company relocation as the amplifier.

Question for Alice:
- Is this relative ordering correct from her market knowledge?
- The engine assigns PK a more positive signal than BD — does Alice agree that PK Punjab cotton UFLPA advantage is stronger than BD's Indian yarn advantage, or should these be ranked differently?
- VN as the swing case: is the parent-company relocation risk the right primary signal amplifier for COMBO-006, or is there a different dynamic Alice sees with Korean/Taiwanese FDI factories?

---

## Part 2: CLUSTER-EU-MARKET-ACCESS (Events B+C+BD EU Trade Combined)

### Combined Framing Summary

The engine structured the EU market access cluster around three simultaneous dimensions: tariff access direction (FTA / EBA graduation), CSDDD compliance capability, and buyer preference trend. The key analytical insight is that BD → India sourcing reallocation is NOT driven by any single event — it is the product of BD losing tariff advantage (EBA graduation) at the same time India gains tariff advantage (FTA), compounded by CSDDD compliance capability differentials (India organic/GOTS vs BD BSCI). Analysing these events separately would miss the combined reallocation signal.

The engine also incorporated Alice's corrections from REVIEW-FOR-ALICE.md throughout: the "false relief window" is framed as a hypothesis to test with buyers (not an assertion), the "Asian competitors cannot provide ESPR data" claim is replaced with a buyer-facing question, and factory certifications are explicitly NOT treated as creating GSP+ eligibility (Alice's B-1 critical correction). Turkey's Customs Union 0% EU duty position is treated as a stable, structurally protected starting point — not as something that changes in this cluster.

### Three-Dimension Summary per Combo (Direction Only)

| Combo | Duty-Free Access Direction | CSDDD Compliance Direction | Buyer Preference Trend |
|---|---|---|---|
| COMBO-002 (BD CMT) | DETERIORATING — EBA graduation risk (structural once enacted; 2029 horizon) | LOW-MEDIUM — BSCI foundation but supply chain traceability depth gap | LOSING share to India; buyer pre-positioning underway |
| COMBO-003 (IN Large Vertical) | IMPROVING — FTA removes UK duty disadvantage; domestic cotton = rules-of-origin compliant | STRONG — GOTS/FAIRTRADE/C2C/ROC; farm-to-fashion traceability; ESG Finance eligible | GAINING EU/UK allocation; M&S/Next sourcing review active |
| COMBO-008 (IN Organic Cotton) | IMPROVING — FTA + rules-of-origin; organic domestic cotton | STRONGEST — organic chain = CSDDD documentation head start; IFC eligible | GAINING — ESG-first buyers growing demand |
| COMBO-014 (IN Small Woven) | IMPROVING — FTA; but smaller player, UK buyer development slower | MEDIUM — woven cotton; moderate CSDDD readiness | GAINING SECONDARY — UK/EU diversification of India sourcing |
| COMBO-005 (TR Denim) | STABLE — Customs Union = 0% EU duty already; no EBA risk | MEDIUM-HIGH — REACH/ZDHC advanced; Customs Union institutional alignment | HOLDING — Istanbul premium protected; but overall volume under Event E pressure |
| COMBO-012 (KH) | HIGH RISK — EBA dependent; graduation possible; EU withdrawal precedent in 2020 | LOW — no compliance investment capacity | LOSING — EU buyers pre-positioning away |
| COMBO-006 (VN FDI Knit) | STABLE-LOW — EU GSP partial; no FTA uplift equivalent to India | MEDIUM — HIGG/ZDHC for buyer compliance; parent ESG systems | MIXED — US primary market; EU secondary dimension |

### Items Alice Needs to Validate

**EU-ACCESS-V1: BD EBA graduation risk — framing correct?**

Engine assertion: BD's LDC graduation risk will bring EU tariffs into effect on BD garment exports post-2029. The COMBO-002 structural nuance references "9.6-12% EU tariff incoming" as the directional outcome. The engine does NOT use a specific figure in the KB analysis — it flags the tariff range as a runtime web search item.

Question for Alice:
- Is BD EBA graduation risk framed correctly — is the post-graduation EU tariff direction the most important commercial signal for BD's EU book?
- What is Alice's read on the BD government's negotiation position for post-EBA access (GSP+ or bilateral arrangement)? Should the KB signal treat BD EBA graduation as certain vs conditional on negotiation outcome?
- Is 2029 the right planning horizon for buyer pre-positioning, or should Air8 expect EU buyers to start programme reviews earlier?

---

**EU-ACCESS-V2: Turkey Customs Union = 0% EU duty — is this correct?**

Engine assertion: Turkey already enjoys 0% EU duty via the Turkey-EU Customs Union for industrial goods including apparel. Turkey has no EBA graduation risk and no FTA waiting game. This is the most stable tariff position in the cluster.

Question for Alice: Is this characterisation of Turkey's Customs Union position accurate for garment exports specifically? Are there any product categories within apparel/denim where Turkey does NOT enjoy 0% EU duty, or where the Customs Union protection is incomplete?

---

**EU-ACCESS-V3: India-UK FTA rules-of-origin direction**

Engine assertion: The India-UK FTA is expected to include a "substantial transformation in India" rules-of-origin requirement. Vertical integrators using domestic Indian cotton (COMBO-003, COMBO-008) are fully eligible. Factories using imported fabric from Bangladesh or China processed in India may NOT qualify for the FTA duty reduction.

Question for Alice:
- Is the "substantial transformation in India" rules-of-origin expectation directionally correct for the India-UK FTA?
- Is "domestic fabric sourcing" the primary criterion, or is it defined at the yarn/fibre level (which would favour COMBO-003 even more)?
- For COMBO-014 (India Small Woven) — are they typically sourcing from domestic Indian mills, or do they import fabric? The engine treated this as a question to verify, not an assumption.

---

**EU-ACCESS-V4: Cambodia risk vs Bangladesh risk — which is higher and why?**

Engine conclusion: Cambodia (COMBO-012) is at HIGHER structural risk than Bangladesh (COMBO-002) because: (1) KH is fully EBA-dependent with no alternative tariff access pathway or negotiation leverage, whereas BD has GSP+ negotiation options; (2) KH has lower compliance infrastructure and no comparable economic diversification capacity; (3) EU has already partially withdrawn KH's EBA preferences in 2020 (precedent exists), whereas BD has not faced EBA withdrawal.

Question for Alice:
- Does Alice agree with this comparative risk assessment — that KH is structurally more at risk than BD?
- Is the 2020 KH partial EBA withdrawal precedent correctly characterised? Was it politically/governance driven or trade-driven?
- Is there any angle on Cambodia that would reduce its structural risk assessment — for example, any EU buyer initiatives to support KH garment sector compliance?

---

**EU-ACCESS-V5: Buyer PO reallocation direction — BD losing, India gaining**

Engine assertion: EU buyer PO reallocation from BD toward India is directionally supported by the three-dimension analysis (BD EBA deteriorating, India FTA improving, CSDDD capability in India's favour). The engine treats this as an observable trend in motion, not a future forecast, per RP-SOURCSHIFT-01 (12-24 months for full materialisation).

Question for Alice:
- Does Alice's buyer-side market knowledge support the BD → India reallocation direction for EU programmes?
- Is the shift from BD to India already visible in buyer conversations, or is this still a forward-looking signal?
- For UK specifically (M&S, Next, ASOS) — are these buyers actively deepening India sourcing conversations, or is the FTA still too uncertain for buyers to act on it?

---

## Part 3: What the Engine Did NOT Do That Alice's Original Simulation Did

The following gaps exist between the engine output and Alice's expert analysis from the 6-event simulation. These are the delta items — areas where Alice's simulation added a level of specificity or nuance that the engine either flagged as "pending validation" or did not replicate.

| Gap | Alice's Simulation | Engine's Handling | Delta |
|---|---|---|---|
| **Volume figures** | Alice's simulation referenced specific volume changes (Turkey -17.83%, BD -3% EU, M&S ~15-20% India sourcing) | Engine explicitly EXCLUDES all specific figures from KB; all volume/rate data flagged as runtime web search items | By design — no figures in KB. Delta is intentional. |
| **Buyer-specific programme knowledge** | Alice's simulation referenced M&S India sourcing at specific % range; Zara 14-day reorder model specificity | Engine treats buyer-specific figures as unverified hypotheses; converts to open questions | Alice's buyer intelligence needs validation before KB assertion |
| **S3 scoring specificity** | Alice's simulation showed S3 overlap scores (e.g., 0.88, 0.82) for individual events | Cluster analysis shows combined directional scoring bands; individual event scores in simulation file | Engine preserves directional scoring; individual numeric scores available in simulation for reference |
| **Istanbul vs Interior Turkey validation** | Alice's review flagged Istanbul/Interior distinction as needing factory-level validation | Engine maintains as hypothesis pending validation; does NOT assert as confirmed KB fact | Item US-DECOUPLING Istanbul/Interior is still pending Alice review |
| **Air8 role as "only liquidity source"** | Original simulation (Events D, E) referenced Air8 EUR ARP as potentially only source | Engine replaces with open question: "Has Air8's role grown relative to banks?" | Alice's B correction applied correctly |
| **24-month head start / false relief** | Original simulation used specific "24-month head start" language for CSDDD compliant factories | Engine converts to hypothesis + open question format (Alice B-3 and B-4) | Alice's corrections applied; no specific figure retained in KB |
| **BD -3% EU volume** | Referenced in Alice's simulation (Events B/E context) | Engine does NOT use this figure; flagged as runtime web search (Alice B-6) | No sourced data → not in KB |
| **GSP+ via factory certification** | Original simulation incorrectly linked factory HIGG/GOTS certs to GSP+ pathway | Engine explicitly corrects: GSP+ = country-level; factory certs ≠ GSP+ eligibility | Alice B-1 critical error corrected throughout |

---

## Part 4: Gaps for Runtime Web Search

The following facts are **NOT in the KB** by design — they require current-date web retrieval at runtime. This list confirms the KB-vs-runtime boundary is clean.

### CLUSTER-US-DECOUPLING Runtime Gaps

| Fact Needed | Why Runtime | Search Target |
|---|---|---|
| S301 Federal Register publication date (actual) | Cliff date — structural break moment; changes signal horizon | US Federal Register; USTR announcement feed |
| Which countries are formally listed in S301 investigation | Determines which combos face confirmed structural exposure | USTR investigation listing; Federal Register |
| Current UFLPA entity list (supplier and input-level) | Identifies direct entity list exposure for any Air8 client or their input partners | CBP UFLPA entity list (updated periodically) |
| Bangladesh government response to S301 forced labor framing | Determines BD tariff probability and likely delay/narrowing | BGMEA statements; US State Dept/USTR communications; Bangladesh Commerce Ministry |
| VN parent company (Korean/Taiwanese FDI) capex announcements | FDI relocation signal; amplifier for COMBO-006 signal direction | Korean Investment Commission; Taiwanese MOEA FDI announcements; individual company IR |
| Pakistan S301 investigation status | Confirm PK is not a primary S301 target | USTR investigation scope documents |
| UFLPA rebuttable presumption documentation standard (gin vs spinner level) | Determines what documentation actually meets CBP standard | CBP UFLPA guidance documents; CBP importer guidance |

### CLUSTER-EU-MARKET-ACCESS Runtime Gaps

| Fact Needed | Why Runtime | Search Target |
|---|---|---|
| India-UK FTA ratification status and confirmed timeline | EXPAND trigger for IN combos; conditional pre-ratification | UK Department for Business and Trade; India Ministry of Commerce |
| India-UK FTA rules-of-origin clause (exact definition of substantial transformation) | Determines which IN factories qualify for duty reduction | FTA legal text (once released); UK DTI guidance |
| Bangladesh LDC graduation precise confirmed timeline | Confirms 2029 as BD EU tariff cliff | EU trade for development; WTO LDC graduation records |
| Cambodia EBA status — current EU review underway? | Determines urgency of KH signal | EU Trade for Development; EU Commission trade announcements |
| CSDDD product-specific DPP/ESPR delegated acts timeline by textile category | Alice B-7: not all textile ESPR requirements activate simultaneously | EU Official Journal; ESPR implementing regulation tracking |
| Current Zara/H&M/Primark supplier questionnaire scope (post-CSDDD extension) | Operative buyer deadline; false relief hypothesis test | Buyer sustainability reports; Inditex/H&M Group sustainability policy |
| BD government EBA negotiation progress (GSP+ or bilateral arrangement discussions) | May extend BD EBA timeline; changes BD signal horizon | Bangladesh Commerce Ministry; WTO Trade Policy Review |
| India EU FTA negotiation status (separate from India-UK FTA) | EU-side duty uplift for India complementing UK FTA | EU Commission DG Trade; India Ministry of External Affairs |

---

**Review prepared by:** KB Engine subagent  
**Date:** 2026-07-16  
**Next step:** Alice reviews items and confirms/corrects → engine updates KB signals accordingly  
**Files for Alice's reference:** 
- `CLUSTER-US-DECOUPLING-ANALYSIS.md` — full Step 1-9 analysis
- `CLUSTER-EU-MARKET-ACCESS-ANALYSIS.md` — full Step 1-9 analysis
- `REVIEW-FOR-ALICE.md` — Alice's prior corrections (applied throughout)
