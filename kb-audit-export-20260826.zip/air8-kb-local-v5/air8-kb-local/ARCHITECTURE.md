---
type: architecture
id: KB-ARCHITECTURE
version: 2.0
---

# Air8 KB — Two-Layer Architecture & Reasoning Engine

This document is the authoritative reference for the Air8 KB reasoning engine.
Read this before modifying any KB files, writing query logic, or building new LLM pipelines.

---

## Section 1: Overview — Two-Layer KB Architecture

The Air8 KB is organized into two logical layers separated by purpose:

```
┌─────────────────────────────────────────────────────────────────────┐
│                          LAYER 1: REASONING                         │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────┐             │
│  │ EVENT-TYPES  │  │  PRINCIPLES  │  │   SOLUTIONS   │             │
│  │  (routing)   │  │   (rules)    │  │  (playbooks)  │             │
│  └──────────────┘  └──────────────┘  └───────────────┘             │
│  + pain-points/    + regulations/    + compliance/                  │
└─────────────────────────────────────────────────────────────────────┘
                              ↕  (linkage tables at root)
┌─────────────────────────────────────────────────────────────────────┐
│                          LAYER 2: ENTITIES                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐ ┌───────────────┐  │
│  │ personas │ │countries │ │product-categories│ │financing-prod │  │
│  └──────────┘ └──────────┘ └──────────────────┘ └───────────────┘  │
│  + esg-standards/    + traceability/                                │
└─────────────────────────────────────────────────────────────────────┘
```

### Layer 1 — Reasoning Layer (`layer-1-reasoning/`)
Contains all **logic** about how to think about trade finance scenarios:
- **EVENT-TYPES.md** — defines 6 event categories and which principles they activate, with weights
- **PRINCIPLES.md** — defines 6 reasoning rules and what data each rule requires from Layer 2
- **SOLUTIONS.md** — solution playbooks mapping event × persona to recommended Air8 products
- **pain-points/** — granular pain point definitions (universal + country-specific + ESG)
- **regulations/** — regulatory definitions (UFLPA, REACH, CSDDD, GPSR, S-211, Section 301)
- **compliance/** — compliance program details and audit requirements

### Layer 2 — Entity Layer (`layer-2-entities/`)
Contains **reference data** about real-world entities:
- **personas/** — 15 COMBO-*.md supplier archetypes with full dimension profiles
  > **Neo4j label mapping:** `Persona` in KB = `:Supplier` node label in Neo4j schema. The `personas/` folder name is preserved for internal KB consistency; the Neo4j graph uses `:Supplier` as the canonical label.
- **countries/** — 8 country files covering tariff exposure, political risk, banking access
- **product-categories/** — APPAREL.md and HARDGOODS.md covering all product verticals
- **financing-products/** — 9 PROD-*.md Air8 product definitions with eligibility criteria
- **esg-standards/** — 7 ESG certification standards (GOTS, FAIRTRADE, ZDHC, HIGG, IFC, C2C, ROC)
- **traceability/** — supply chain traceability frameworks

### Linkage Tables (`linkage/` — stays at root)
Four linkage files bridge the two layers:
- `linkage-persona-full.md` — persona → pain points + products + compliance
- `linkage-regulation-affected.md` — regulation → affected countries/products/combos
- `linkage-event-propagation.md` — event traces (impact chains)
- `linkage-product-reverse.md` — product → reverse (pain points + best-fit combos)

### Critical Design Constraint
> **Entities never point to principles. Principles never point to entities.**
> The **EVENT node** is the only node that holds both sets of keys.
> An event activates principles (Layer 1) AND references entities (Layer 2) simultaneously.
> This separation prevents circular dependencies and enables clean weight calculation.

### Cross-Layer Edge: PainPoints

PainPoints live in **Layer 1** (they are reasoning-level problem definitions), but **Layer 2 entities link TO them** via cross-layer edges. This is the one exception to the "entities don't point to Layer 1" rule — because PainPoints are problem DATA, not reasoning LOGIC.

```cypher
// PainPoint is a Layer 1 node (problem definition)
(Persona:COMBO-004)-[:HAS_PAIN_POINT {severity: "HIGH"}]->(PainPoint:PP-001)
(Country:CN)-[:HAS_PAIN_POINT {severity: "HIGH"}]->(PainPoint:PP-CN-001)
(Persona:COMBO-012)-[:HAS_PAIN_POINT {severity: "HIGH"}]->(PainPoint:PP-BD-003)  // EBA graduation
```

**Why PainPoint ≠ Principle:**

| Node type | What it is | Who points to it | Example |
|---|---|---|---|
| **Principle** (PRIN-/RP-) | Reasoning logic — HOW to think | Event Type only (via `[:ACTIVATES]`) | "Is country exposed to this tariff?" |
| **PainPoint** (PP-*) | Problem data — WHAT the pain is | Entity nodes (via `[:HAS_PAIN_POINT]`) | "SAFE compliance is complex for CN entities" |

**Structured `pain_points:` frontmatter** on each entity file enables direct Neo4j import:
```yaml
pain_points:
  - id: PP-001          # cashflow-gap — universal
    severity: HIGH
  - id: PP-CN-001       # SAFE complexity — CN-specific
    severity: HIGH
  - id: PP-CN-003       # Hengqin capacity — CN-specific
    severity: MEDIUM
```

This makes `[:HAS_PAIN_POINT]` edges loadable from YAML without parsing prose.

---

## Section 2: Event Routing — How an Event Maps to Principles

### Event Structure
Every event arrives with these fields:
```json
{
  "event_id":         "EVT-20260715-001",
  "type":             "EVT-TARIFF",
  "subtype":          "section_301",
  "supplier_country": "CN",
  "buyer_geo":        "US",
  "product_category": "woven_apparel",
  "material":         "cotton",
  "supplier_tier":    "tier_2",
  "timestamp":        "2026-07-15T10:00:00Z"
}
```

### Principle Activation via `[:ACTIVATES]` Edges
Each event TYPE activates a set of principles through `[:ACTIVATES]` relationships.
The edge carries a `weight` property (0.0–1.0); all weights for a given event type sum to 1.0.

```cypher
// Example: EVT-TARIFF activates these principles
(EVT-TARIFF)-[:ACTIVATES {weight: 0.5}]->(PRIN-COUNTRY-EXPOSURE)
(EVT-TARIFF)-[:ACTIVATES {weight: 0.3}]->(PRIN-PRODUCT-TARIFF)
(EVT-TARIFF)-[:ACTIVATES {weight: 0.2}]->(PRIN-SUPPLIER-RESILIENCE)
```

### `entity_focus` Property on Principles
Each Principle has an `entity_focus` property that declares which Layer 2 entity type it reasons about:

| Principle             | entity_focus         |
|-----------------------|---------------------|
| PRIN-COUNTRY-EXPOSURE | "country"           |
| PRIN-PRODUCT-TARIFF   | "product_category"  |
| PRIN-SUPPLIER-RESILIENCE | "persona"        |
| PRIN-BUYER-GEO-EXPOSURE | "country"         |
| PRIN-COMPLIANCE-COST  | "product_category" + "persona" |
| PRIN-FINANCING-MATCH  | "persona" + "financing_product" |

### Type Weight Aggregation
The **type weight** for an entity focus type = sum of `[:ACTIVATES]` weights for all principles with that focus:

For EVT-TARIFF:
- `country` type_weight = 0.5 (Country_Exposure) — no Buyer_Geo in EVT-TARIFF
- `product_category` type_weight = 0.3 (Product_Tariff)
- `persona` type_weight = 0.2 (Supplier_Resilience)

---

## Section 3: Entity Location — How an Event Finds Its Entities

Two lookup paths run **in parallel** from the same event node.

### Path A: Country + Product (Direct Match)

```
Event.supplier_country  →  direct match  →  Country node
                              role: "supplier_origin"
                              role_weight: 0.7

Event.buyer_geo         →  direct match  →  Country node
                              role: "buyer_geo"
                              role_weight: 0.3

Event.product_category + Event.material  →  direct match  →  ProductCategory node
                              role: "primary_product"
                              role_weight: 1.0
```

This match is stored as a `[:INVOLVES]` edge between Event and entity, with the role and role_weight.

### Path B: Persona (Tag Overlap Scoring)

Event context fields are normalized to a tag set at ingestion:
```
supplier_tier + product_category + buyer_geo + material  →  eventTags = Set[String]
```

Example: `{tier_2, woven_apparel, US, cotton}`

All Persona nodes are scored:
```cypher
MATCH (p:Persona)
WITH p, size([t IN p.tags WHERE t IN $eventTags]) AS overlap
WHERE overlap >= 2
RETURN p, overlap
ORDER BY overlap DESC
```

**Threshold rules:**
- overlap ≥ 4 = **HIGH impact** — full context block
- overlap 2–3 = **MEDIUM impact** — summary block
- overlap < 2 = dropped (noise floor)

**Return ALL personas with overlap ≥ 2**, not just the top match.
Multiple personas are often simultaneously impacted; each gets its own signal block.

---

## Section 4: Weight Calculation — Final Entity Relevance Score

```
Final entity relevance = type_weight × role_weight × match_quality
```

Where:
- **type_weight** = sum of `[:ACTIVATES]` weights for principles with this `entity_focus` (comes from EVENT TYPE)
- **role_weight** = stored on `[:INVOLVES]` edge between Event and entity (supplier vs buyer role distinction)
- **match_quality** = `1.0` for direct country/product matches; `overlap_count / total_persona_tags` for persona overlap

### Worked Example: EVT-TARIFF on CN→US woven cotton

| Entity              | type_weight | role_weight | match_quality       | **Final Score** |
|---------------------|-------------|-------------|---------------------|-----------------|
| Country:CN          | 0.5         | 0.7         | 1.0 (direct)        | **0.350**       |
| Country:US          | 0.5         | 0.3         | 1.0 (direct)        | **0.150**       |
| Product:WovenApparel| 0.3         | 1.0         | 1.0 (direct)        | **0.300**       |
| Persona:COMBO-004   | 0.2         | 1.0         | 5/7 tags = 0.71     | **0.142**       |
| Persona:COMBO-014   | 0.2         | 1.0         | 4/7 tags = 0.57     | **0.114**       |
| Persona:COMBO-001   | 0.2         | 1.0         | 3/7 tags = 0.43     | **0.086**       |

**Noise floor:** Entities below 0.05 are dropped from the signal context.

---

## Section 5: Signal Generation — What the LLM Receives

### Context Block Priority by Relevance Score

| Score Range | Block Type    | Content                                   |
|-------------|---------------|-------------------------------------------|
| ≥ 0.20      | Full block    | All entity attributes, all pain points, all linked products |
| 0.10–0.19   | Summary block | Key risk factors, top 3 pain points, primary product |
| 0.05–0.09   | Brief mention | Entity name + single risk sentence        |
| < 0.05      | Dropped       | Not included in context                   |

### Per-Persona Signal Blocks (Critical Design Point)
Each matched persona generates its **own separate signal block**:
```
[Signal: COMBO-004 — China Medium Woven]
  Pain points: PP-CN-001 (UFLPA), PP-CN-002 (section 301 direct hit), PP-002 (financing cost)
  Regulations: UFLPA (HIGH), REACH (MEDIUM), CSDDD (EU buyers)
  Financing needs: ARP (cashflow), SmartWallet (multi-buyer), Pool (revenue diversification)

[Signal: COMBO-014 — India Small Woven]
  Pain points: PP-IN-001 (GST/bank access), PP-002 (financing cost), PP-REG-TARIFF-001 (new 50% tariff)
  Regulations: UFLPA (if cotton→US), REACH (if EU)
  Financing needs: ARP, RT2C
```

**NOT merged** — personas get differentiated blocks to enable segment-specific advice.
Merged signals lose the precision that makes Air8's BD advice actionable.

---

## Section 6: Cypher Query (Full End-to-End)

```cypher
// Input event
WITH {
  type: 'EVT-TARIFF',
  supplier_country: 'CN',
  buyer_geo: 'US',
  product_category: 'woven_apparel',
  material: 'cotton',
  supplier_tier: 'tier_2'
} AS event

// Step 1: Get principle weights for this event type
MATCH (et:EventType {id: event.type})-[a:ACTIVATES]->(p:Principle)
WITH event, collect({principle: p, weight: a.weight, focus: p.entity_focus}) AS principles

// Step 2: Compute type_weight per entity focus
WITH event, principles,
  reduce(s = 0.0, x IN [px IN principles WHERE px.focus = 'country'] | s + px.weight)           AS country_type_weight,
  reduce(s = 0.0, x IN [px IN principles WHERE px.focus = 'product_category'] | s + px.weight)  AS product_type_weight,
  reduce(s = 0.0, x IN [px IN principles WHERE px.focus = 'persona'] | s + px.weight)           AS persona_type_weight

// Step 3: Score countries (direct match)
OPTIONAL MATCH (supplier_country:Country {iso: event.supplier_country})
OPTIONAL MATCH (buyer_country:Country {iso: event.buyer_geo})

WITH event, country_type_weight, product_type_weight, persona_type_weight,
  collect({
    entity: supplier_country,
    entity_type: 'country',
    type_weight: country_type_weight,
    role_weight: 0.7,
    match_quality: 1.0,
    score: country_type_weight * 0.7 * 1.0
  }) +
  collect({
    entity: buyer_country,
    entity_type: 'country',
    type_weight: country_type_weight,
    role_weight: 0.3,
    match_quality: 1.0,
    score: country_type_weight * 0.3 * 1.0
  }) AS country_scores

// Step 4: Score product categories (direct match)
OPTIONAL MATCH (pc:ProductCategory {id: event.product_category})

WITH event, product_type_weight, persona_type_weight, country_scores,
  collect({
    entity: pc,
    entity_type: 'product_category',
    type_weight: product_type_weight,
    role_weight: 1.0,
    match_quality: 1.0,
    score: product_type_weight * 1.0 * 1.0
  }) AS product_scores

// Step 5: Score personas (tag overlap)
WITH event, persona_type_weight, country_scores, product_scores,
  [event.supplier_tier, event.product_category, event.buyer_geo, event.material] AS eventTags

MATCH (persona:Persona)
WITH event, persona_type_weight, country_scores, product_scores, eventTags, persona,
  size([t IN persona.tags WHERE t IN eventTags]) AS overlap,
  size(persona.tags) AS total_tags

WHERE overlap >= 2

WITH event, persona_type_weight, country_scores, product_scores,
  collect({
    entity: persona,
    entity_type: 'persona',
    type_weight: persona_type_weight,
    role_weight: 1.0,
    match_quality: toFloat(overlap) / toFloat(total_tags),
    score: persona_type_weight * 1.0 * (toFloat(overlap) / toFloat(total_tags))
  }) AS persona_scores

// Step 6: Merge all scores, filter noise floor, rank
WITH country_scores + product_scores + persona_scores AS all_scores
UNWIND all_scores AS entity_score

WITH entity_score
WHERE entity_score.score >= 0.05

RETURN entity_score.entity AS entity,
       entity_score.entity_type AS entity_type,
       entity_score.type_weight AS type_weight,
       entity_score.role_weight AS role_weight,
       entity_score.match_quality AS match_quality,
       entity_score.score AS relevance_score,
       CASE
         WHEN entity_score.score >= 0.20 THEN 'FULL'
         WHEN entity_score.score >= 0.10 THEN 'SUMMARY'
         ELSE 'BRIEF'
       END AS context_block_type

ORDER BY relevance_score DESC
```

---

## Section 7: File Reference Map

| Data Type              | File Location                                              | Layer   |
|------------------------|-----------------------------------------------------------|---------|
| Event type definitions  | `layer-1-reasoning/EVENT-TYPES.md`                       | 1       |
| Principle definitions   | `layer-1-reasoning/PRINCIPLES.md`                        | 1       |
| Solution playbooks      | `layer-1-reasoning/SOLUTIONS.md`                         | 1       |
| Pain points (universal) | `layer-1-reasoning/pain-points/universal/PP-*.md`        | 1       |
| Pain points (country)   | `layer-1-reasoning/pain-points/country/PP-*.md`          | 1       |
| Pain points (ESG)       | `layer-1-reasoning/pain-points/esg/PP-*.md`              | 1       |
| Regulations             | `layer-2-entities/regulations/REG-*.md`                 | 1       |
| Compliance programs     | `layer-1-reasoning/compliance/`                          | 1       |
| Supplier personas       | `layer-2-entities/personas/COMBO-*.md`                   | 2       |
| Country profiles        | `layer-2-entities/countries/*.md`                        | 2       |
| Apparel product focus   | `layer-2-entities/product-categories/APPAREL.md`         | 2       |
| Hardgoods product focus | `layer-2-entities/product-categories/HARDGOODS.md`       | 2       |
| Financing products      | `layer-2-entities/financing-products/PROD-*.md`          | 2       |
| ESG standards           | `layer-2-entities/esg-standards/ESG-*.md`                | 2       |
| Traceability frameworks | `layer-2-entities/traceability/TRACE-*.md`               | 2       |
| Persona–product linkage | `linkage/linkage-persona-full.md`                        | bridge  |
| Regulation linkage      | `linkage/linkage-regulation-affected.md`                 | bridge  |
| Event propagation traces| `linkage/linkage-event-propagation.md`                   | bridge  |
| Product reverse lookup  | `linkage/linkage-product-reverse.md`                     | bridge  |
| Dimension definitions   | `dimensions/DIM-*.md`                                    | meta    |
| Raw data entities       | `data-entities/ENTITY-*.md`                              | meta    |
