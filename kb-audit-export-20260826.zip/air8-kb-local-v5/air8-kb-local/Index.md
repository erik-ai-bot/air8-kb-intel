---
type: index
id: INDEX
version: 3.0
---

# Air8 AI Knowledge Base — Index

See `ARCHITECTURE.md` for the full two-layer engine specification.

---

## Layer 1 — Reasoning

### Reasoning Core
- [[layer-1-reasoning/EVENT-TYPES]]
- [[layer-1-reasoning/PRINCIPLES]]
- [[layer-1-reasoning/SOLUTIONS]]

### Dimensions
- [[dimensions/DIM-1-country]]
- [[dimensions/DIM-2-revenue-band]]
- [[dimensions/DIM-3-company-type]]
- [[dimensions/DIM-4-product-focus]]
- [[dimensions/DIM-5-target-market]]
- [[dimensions/DIM-6-buyer-profile]]
- [[dimensions/DIM-7-current-financing]]
- [[dimensions/DIM-8-growth-stage]]

### Pain Points
#### Universal
- [[layer-1-reasoning/pain-points/universal/PP-001-cashflow-gap]]
- [[layer-1-reasoning/pain-points/universal/PP-002-financing-cost]]
- [[layer-1-reasoning/pain-points/universal/PP-003-buyer-concentration]]
- [[layer-1-reasoning/pain-points/universal/PP-004-scalability-constraint]]
- [[layer-1-reasoning/pain-points/universal/PP-005-preshipment-capital]]
- [[layer-1-reasoning/pain-points/universal/PP-006-trade-finance-literacy]]
- [[layer-1-reasoning/pain-points/universal/PP-007-dilution-deductions]]

#### Country-Specific
- [[layer-1-reasoning/pain-points/country/PP-BD-001-wage-hike]]
- [[layer-1-reasoning/pain-points/country/PP-BD-002-political-instability]]
- [[layer-1-reasoning/pain-points/country/PP-BD-003-ldc-graduation]]
- [[layer-1-reasoning/pain-points/country/PP-CN-001-safe-complexity]]
- [[layer-1-reasoning/pain-points/country/PP-CN-002-sinosure-burden]]
- [[layer-1-reasoning/pain-points/country/PP-CN-003-hengqin-capacity]]
- [[layer-1-reasoning/pain-points/country/PP-IN-001-gst-refund-delay]]
- [[layer-1-reasoning/pain-points/country/PP-IN-002-bank-od-cost]]
- [[layer-1-reasoning/pain-points/country/PP-IN-003-inr-depreciation]]
- [[layer-1-reasoning/pain-points/country/PP-TR-001-lira-hyperinflation]]
- [[layer-1-reasoning/pain-points/country/PP-TR-002-bank-credit-contraction]]
- [[layer-1-reasoning/pain-points/country/PP-VN-001-fdi-decision-authority]]
- [[layer-1-reasoning/pain-points/country/PP-IDN-001-rupiah-volatility]]
- [[layer-1-reasoning/pain-points/country/PP-PK-001-energy-crisis]]

#### Compliance Pain Points
- [[layer-1-reasoning/pain-points/compliance/PP-REG-UFLPA-001]]
- [[layer-1-reasoning/pain-points/compliance/PP-REG-REACH-001]]
- [[layer-1-reasoning/pain-points/compliance/PP-REG-CSDDD-001]]
- [[layer-1-reasoning/pain-points/compliance/PP-REG-TARIFF-001]]

#### Expansion
- [[layer-1-reasoning/pain-points/expansion/PP-EXPAND-001-low-wallet-share]]
- [[layer-1-reasoning/pain-points/expansion/PP-EXPAND-002-missing-product-coverage]]
- [[layer-1-reasoning/pain-points/expansion/PP-EXPAND-003-operational-friction]]

#### ESG
- [[layer-1-reasoning/pain-points/esg/PP-ESG-001-credentials-not-monetized]]
- [[layer-1-reasoning/pain-points/esg/PP-ESG-002-buyer-esg-escalating]]

### Regulations
- [[layer-1-reasoning/regulations/REG-UFLPA]]
- [[layer-1-reasoning/regulations/REG-REACH]]
- [[layer-1-reasoning/regulations/REG-CSDDD]]
- [[layer-1-reasoning/regulations/REG-GPSR]]
- [[layer-1-reasoning/regulations/REG-S211]]
- [[layer-1-reasoning/regulations/REG-NYFASHION]]
- [[layer-1-reasoning/regulations/REG-TARIFF]]

### Compliance (Air8 Internal)
- [[layer-1-reasoning/compliance/COMP-THREE-LINES]]
- [[layer-1-reasoning/compliance/COMP-SINOSURE]]
- [[layer-1-reasoning/compliance/COMP-SAFE]]
- [[layer-1-reasoning/compliance/COMP-SANCTIONS]]
- [[layer-1-reasoning/compliance/COMP-KYC]]

---

## Layer 2 — Entities

### Personas (Supplier Combos)
- [[layer-2-entities/personas/COMBO-001-south-asian-small-knit]]
- [[layer-2-entities/personas/COMBO-002-bangladesh-bank-lc]]
- [[layer-2-entities/personas/COMBO-003-india-large-vertical-integrator]]
- [[layer-2-entities/personas/COMBO-004-china-medium-woven]]
- [[layer-2-entities/personas/COMBO-005-turkey-denim-specialist]]
- [[layer-2-entities/personas/COMBO-006-vietnam-fdi-knit]]
- [[layer-2-entities/personas/COMBO-007-indonesia-family-run]]
- [[layer-2-entities/personas/COMBO-008-india-organic-cotton-medium]]
- [[layer-2-entities/personas/COMBO-009-pakistan-home-textile]]
- [[layer-2-entities/personas/COMBO-010-existing-client-expansion]]
- [[layer-2-entities/personas/COMBO-011-trader-sourcing-agent]]
- [[layer-2-entities/personas/COMBO-012-cambodia-eba-dependent]]
- [[layer-2-entities/personas/COMBO-013-multi-country-group]]
- [[layer-2-entities/personas/COMBO-014-india-small-woven]]
- [[layer-2-entities/personas/COMBO-015-micro-first-time]]

### Countries
- [[layer-2-entities/countries/Bangladesh]]
- [[layer-2-entities/countries/Cambodia]]
- [[layer-2-entities/countries/China]]
- [[layer-2-entities/countries/India]]
- [[layer-2-entities/countries/Indonesia]]
- [[layer-2-entities/countries/Pakistan]]
- [[layer-2-entities/countries/Turkey]]
- [[layer-2-entities/countries/Vietnam]]

### Product Categories
- [[layer-2-entities/product-categories/APPAREL]] — Denim, Knit, Woven, Home Textiles, Organic/Sustainable
- [[layer-2-entities/product-categories/HARDGOODS]] — 7 categories, 19 product types + cookware

### Financing Products
- [[layer-2-entities/financing-products/PROD-ARP]]
- [[layer-2-entities/financing-products/PROD-MINIARP]]
- [[layer-2-entities/financing-products/PROD-PRESHIP-OBF]]
- [[layer-2-entities/financing-products/PROD-PRESHIP-RT2C]]
- [[layer-2-entities/financing-products/PROD-PAYGUARD]]
- [[layer-2-entities/financing-products/PROD-POOL]]
- [[layer-2-entities/financing-products/PROD-SMARTWALLET]]
- [[layer-2-entities/financing-products/PROD-ESG-FINANCING]]
- [[layer-2-entities/financing-products/PROD-DDP]]

### ESG Standards
- [[layer-2-entities/esg-standards/ESG-GOTS]]
- [[layer-2-entities/esg-standards/ESG-FAIRTRADE]]
- [[layer-2-entities/esg-standards/ESG-C2C]]
- [[layer-2-entities/esg-standards/ESG-ROC]]
- [[layer-2-entities/esg-standards/ESG-HIGG]]
- [[layer-2-entities/esg-standards/ESG-ZDHC]]
- [[layer-2-entities/esg-standards/ESG-IFC]]

### Traceability
- [[layer-2-entities/traceability/TRACE-TIERS]]
- [[layer-2-entities/traceability/TRACE-T4S]]
- [[layer-2-entities/traceability/TRACE-ORGANIC-ADVANTAGE]]

---

## Linkage Tables (Bridge)
- [[linkage/linkage-persona-full]]
- [[linkage/linkage-regulation-affected]]
- [[linkage/linkage-event-propagation]]
- [[linkage/linkage-product-reverse]]

---

## Data Team — Neo4j Setup
- [[meta/neo4j-ingest-spec]] ← **从这里开始**，给 data 同事的建库操作手册
- [[meta/neo4j-graph-design]] — 图结构设计说明（背景参考）
- [[ARCHITECTURE]] — KB 整体架构（读完再看 ingest spec）

---

## Data Entities
- [[data-entities/ENTITY-Buyer]]
- [[data-entities/ENTITY-Supplier]]
- [[data-entities/ENTITY-Factory]]
- [[data-entities/ENTITY-Order]]
- [[data-entities/ENTITY-Invoice]]
- [[data-entities/ENTITY-BL]]
- [[data-entities/ENTITY-RawMaterial]]
- [[data-entities/ENTITY-Facility]]
- [[data-entities/ENTITY-Insurance]]
- [[data-entities/ENTITY-Regulation]]
- [[data-entities/ENTITY-Commodity]]
