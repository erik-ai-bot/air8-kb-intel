# L1 · Apparel scoring framework v1.1

Single source of truth for thresholds. Do not restate these from memory; read this file each time.

## §1 Points table — max 11

| Component | Points | Threshold | Weight |
|---|---|---|---|
| **Trading activity** — distinct months with a shipment in the trailing 12 | 4 / 2 / 0 | ≥10 / 7–9 / ≤6 | 36.3% |
| **YoY growth** — trailing 12m shipments vs prior 12m | 3 / 1 / 0 | ≥+15% / −15%…+15% / <−15% | 27.3% |
| **Per-buyer density** — shipments per buyer per active month | 2 / 1 / 0 | ≥7.1 / ≥3.2 / below | 18.2% |
| **Category** — apparel segment spread | 2 / 0 | Mixed apparel / single segment | 18.2% |

Weights sum to 100.0%. Tiers: **A ≥9**, **B 6–8**, **C ≤5**.

**Flow-stale gate:** more than 6 months since the last transaction with the target buyer → drop one tier. A stale flow is a different risk from a slow one.

**Buyer factor deliberately removed.** Buyer credit limits are matched upstream in the funnel; scoring it again double-counts and pushes every big-buyer supplier into tier A.

## §2 Where the thresholds come from

Each cut was chosen by the **stickiness gap** — retention of flows above the cut minus retention below — measured on 71 supplier-buyer flows in the apparel financing book. The cut sits at the gap's peak, not at a round number.

| Threshold | Stickiness gap at the cut |
|---|---|
| Activity ≥9–10 months | **65.0pp** — by far the strongest single signal |
| Growth ≥ +15% | 43.8pp |
| Density ≥7.1 | 20.6pp |
| Density ≥3.2 | 15.7pp |
| Category | Fashion/mixed retained 84.6% vs single-segment women's 35.3% |

**Measurement-unit warning.** The book measures invoices per *supplier-buyer flow*; customs data measures shipments per *supplier across all buyers*. The two are not comparable, so the density cuts were re-mapped by percentile — which is why they are 7.1 and 3.2 rather than tidy numbers. If you ever recompute density on a different unit, re-derive the cuts by percentile; do not carry these numbers across.

## §3 Backtest on the financing book

| Tier | Retention (all flows) | Excluding buyer-caused churn |
|---|---|---|
| A | 100% (n=10) | 100% |
| B | 88% (n=17) | 100% |
| C | 30% (n=44) | 52% (n=50) |

**Buyer-caused churn is the dominant failure mode: 21 of 33 churned flows (64%) had `buyer_still_active = False`.** The supplier did nothing wrong; the buyer's programme died. Known dead programmes: Maurices (3 flows / 256 invoices), Chico's (2), GAP UK / Europe / Japan, Kontoor Asia (162 inv), Old Navy (208 inv), ITX Trading, Kurt Geiger, Lavish Alice, zLabels, Venus Fashion, Mark's Work Wearhouse, LF Fashion-1616.

This matters twice over. It rescues the framework from an apparent 30% tier-C failure, and it means **a churn event must be attributed before it is treated as a scoring miss**. Check the buyer before blaming the model.

## §4 Category classification

Mixed apparel (2 pts) = HS lines spanning **two or more** of: knitwear, wovens, outerwear, denim, babywear, intimates, activewear. Single-segment (0 pts) = one segment only, however large. Read HS 61xx/62xx lines at 4-digit level; fall back to product descriptions, then to a web search on the company. If the segment genuinely cannot be established, send to Enrichment — do not default to 0, which silently penalises thin data.

Vertical routing (HS chapter): 61/62 apparel → here. 63/57/9404 → hardgoods funnel. 50–60 → fabric or yarn mill, neither funnel.

## §5 Update protocol

**Trigger A — new FR / lending export.** Re-measure the stickiness gap at each existing cut plus one notch either side. Move a cut only if the gap peak has genuinely moved and n at the new cut is ≥10. Note the new n beside the threshold.

**Trigger B — BD outcome tags.** Validate tiers against contact-to-conversion rates. Do not refit the framework on a handful of calls; retention and conversion are different targets and the framework was built for retention.

**Trigger C — counter-examples.** One surprising name goes in the `Framework feedback` tab with what the framework said and what actually happened. Change a rule only after **three consistent** exceptions pointing the same way.

Every change: date, evidence, the n it rests on, and what it replaced. A framework whose history is unreadable cannot be defended to a boss.

## §6 Known open issues

- **Timing-correct validation is not yet possible.** Validating an already-churned client needs the 12 months *before* it stopped, which needs a pre-2024 FR lending export (supplier, actual_lending_date, buyer, amount). Until that arrives, low scores on long-churned clients are unproven either way — say so rather than claiming a miss.
- **Growth is measured on shipment counts, not value.** Counts are what customs reliably gives. A supplier growing in value but shipping less often scores badly. Flag if the batch has value data.
