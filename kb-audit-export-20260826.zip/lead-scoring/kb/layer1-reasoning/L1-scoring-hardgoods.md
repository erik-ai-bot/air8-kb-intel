# L1 · Hardgoods scoring framework v3.0

Single source of truth for hardgoods thresholds. Do not restate from memory.

**Calibration base:** 139 onboarded suppliers, 14,048 FR/invoice rows, 2024-01 → 2026-06.
**Design principle, shared with the apparel framework:** every weight equals the indicator's *measured* effect on stickiness in our own financing book. Nothing is scored on intuition.

## §1 Points table — max 15

| # | Indicator | Points | Bands | Weight |
|---|---|---|---|---|
| 1 | **Activity regularity** — months with an invoice in the trailing 12 | 4 / 3 / 1 / 0 | ≥10 / 7–9 / 4–6 / ≤3 | 27% |
| 2 | **Growth (YoY)** — shipments p1y vs p2y | 3 / 1 / 0 | Rising / Stable / Declining | 20% |
| 3 | **Product breadth** — distinct products in the flow | 3 / 1 / 0 | ≥8 / 4–7 / ≤3 | 20% |
| 4 | **Buyer quality** — buyer is a US mass / off-price / home retailer | 2 / 0 | Yes / No | 13% |
| 5 | **Product category** | 2 / 1 / 0 | HTB or Home Decor / Kitchen & Dining / Furniture, Lighting, other | 13% |
| 6 | **Ticket structure** — average invoice vs the category band | 1 / 0 / −1 | inside band / between / above the penalty line | 7% |

**Tiers: A ≥10 · B 6–9 · C ≤5.**

**Caps:** Furniture never exceeds tier B (33% durable in the book; points must not stack it into A). Missing activity or invoice data → **Enrichment, not a score of zero**.

### Category ticket bands (indicator 6)

| Category | Inside band | Penalty above |
|---|---|---|
| Home Textile & Bedding | $5K–50K | $60K |
| Home Decor | $2K–20K | $30K |
| Kitchen & Dining | $2K–20K | $30K |
| Furniture | $5K–30K | $40K |
| All other (default) | $2K–30K | $50K |

## §2 Evidence — the stickiness gap behind each weight

| Indicator | Finding in the financing book | Gap |
|---|---|---|
| Activity regularity | Active 7+ of their first 12 months stayed 88%; ≤3 months stayed 5% | **83pp** |
| Product breadth | Shipping >10 distinct products stayed 79% vs 14% — holds even at low activity | 65pp |
| Growth | 2nd half-year beat 1st half-year stayed 82% vs 19% | 64pp |
| Buyer quality | Selling to US major retailers stayed 80% vs 24% (export-only accounts) | 56pp |
| Category | HTB / Decor / K&D stayed 73% vs Furniture and minor hardgoods 27% | 46pp |
| Ticket structure | Inside the category band stayed 59% vs 29% above $50K | 30pp |

**Validation on the book:** score ≥10 → 86% stickiness (n=14) · 6–9 → 77% (n=13) · ≤5 → 16% (n=19). Monotonic.

**Source-field caveat:** the product-count field caps at 10, so breadth is censored at the top — a supplier shipping 40 products and one shipping 10 both read as 10. The ≥8 band is therefore conservative by construction; do not "fix" it by rescaling.

## §3 Deliberately not scored

- **FOB / monthly volume.** Did not differentiate stickiness at all — both durable and churned groups sat at ~$58–66K/month, and FOB coverage is patchy. Volume is a within-tier tie-breaker only; it never promotes a lead across tiers.
- **Country.** Removed on instruction. The book has very few China-origin cases, so the old China penalty rested on thin evidence.
- **Supplier-level buyer count.** Kept as context and as the trading-house flag, not scored at flow level: a single flow tells you nothing about the supplier's diversification.
- **LF status.** Separate funnels upstream; never a scoring input.

## §4 Fallback — v2.1, for thin lead data

v3.0 needs product breadth, buyer identity and average invoice value. Customs-only or 1688-style lead data often has none of them. In that case score on **v2.1 (0–11, tiers A ≥7 / B 4–6 / C ≤3)** and label the output with the framework used:

| Component | Points |
|---|---|
| Cadence (ship/mo) vs category thresholds | ≥cad_hi 3 · ≥cad_good 2 · ≥cad_min 1 · below 0 |
| Category | HTB or Home Decor 3 · Kitchen & Dining 2 · Pet Supply 1 · other 0 |
| Trend | Rising 2 · Stable 1 · Declining or Unknown 0 |
| 2+ buyers | +1 |
| Country India or Hong Kong | +1 |
| Ticket inside the category band | +1; above the penalty line −1 |

Per-category cadence thresholds (cad_min / cad_good / cad_hi): HTB 2/5/10 · Home Decor 2/5/15 · Kitchen & Dining 2/4/8 · Furniture 2/3/6 · default 2/4/10. Ticket bands as in §1.

**v2.1 hard filters, still live:** excluded verticals (components/electronics, apparel, FIBC/packaging, raw materials, beauty, toys) → different funnel. **CNY-domestic-only flow → exclude** (164 of 164 such invoices came from churned suppliers — 0% durable). Kill combo: China + ≤1 buyer + ticket above the category penalty line + cadence below cad_min → exclude, a 4%-durable fingerprint. Caps: Furniture and Declining never exceed tier B.

**Never compare a v3.0 score with a v2.1 or apparel score directly** — 15-point and 11-point scales are not the same number. Compare tiers, or normalise to percent of maximum.

## §5 Update protocol

**Trigger A — new onboarded suppliers** (quarterly, or every ~20 cases): re-fingerprint on updated FR data; re-fit category durability with shrinkage (prior = book average, k=5), and move a category's points band only with n≥5 in the cell; re-tune a threshold only if the new optimum moves more than 25%.

**Trigger B — BD outcome tags:** at 30+ negatives, build the first true conversion model. Tier A must beat tier B on interested-rate within a quarter, or escalate to a full refit.

**Trigger C — single counter-example:** log it, do not change the rule. Three consistent exceptions on one rule → revisit that rule.

**Known limitation:** all calibration measures stickiness *after* onboarding. There are no declined-lead negatives yet, so this measures "converts and sticks", not likelihood of signing.

## §6 Version log

| Version | Date | Change | Basis |
|---|---|---|---|
| v1.0–v1.2 | 2026-07-13 | Kill-rules, 4 archetypes, fallback points; LF removed; value as within-tier sort | 139 suppliers / 14,048 FRs |
| v2.0–v2.1 | 2026-07-14 | Score-primary redesign, 0–11 additive; category-conditional cadence and ticket thresholds | same book |
| **v3.0** | 2026-08 | Realigned to measured stickiness gaps, 0–15: activity re-banded, **product breadth and buyer quality added**, country dropped, category re-weighted. Same methodology as apparel v1.1, which is what lets both live in one skill | same book, flow-level |

**Drift note:** the previously deployed standalone hardgoods skill shipped **v2.1**, while v3.0 was developed later during the apparel work and lived only in a spreadsheet. This file supersedes both. If an older pack shows an 11-point hardgoods score, it was scored on v2.1 — say so rather than re-basing it silently.
