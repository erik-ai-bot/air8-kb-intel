---
id: L1-cp-map
version: 0.1
---

# L1 · CP Map — Which KB file does each checkpoint read?

This file is the routing table for the validation agent.
At each checkpoint the agent must cite the file it used.

| CP | Name | KB files read | What it decides | Blocking? |
|---|---|---|---|---|
| CP0 | Data load & dedup | `L1-db-field-contract.md` | Columns mapped to indicators; duplicates flagged | Yes — stop if key columns missing |
| CP1 | Vertical routing | `L1-vertical-routing.md` | Apparel v1.1 / Hardgoods v3.0 / HG v2.1 / Parked | Yes — unroutable → Enrichment queue |
| CP2 | Component scoring | `L1-scoring-apparel.md` · `L1-scoring-hardgoods.md` | Points per indicator; tier A/B/C | Yes — missing scored component → flag, not zero |
| CP3 | Gate checks | `L1-ordering-and-gates.md` · `L1-adverse-severity.md` | In / out / parked per supplier | No — NOT SCREENED is a valid state; proceed with label |
| CP4 | Sort + call list | `L1-ordering-and-gates.md` | Ranked list; Floor / Bench / Pipeline | No — user can adjust via filter instruction |
| CP5 | Enrichment queue | `L1-financing-need.md` · `L1-evidence-discipline.md` | What research is needed per shortlisted supplier | No — informational |

## Agent rules

1. **Read the KB file at the start of the CP, never before.** Keeps token use tight.
2. **Cite the file and version in the CP output.** e.g. `[KB: L1-scoring-hardgoods.md v3.0]`
3. **Never change a KB file during a run.** All KB mutations are a separate editorial step after the run.
4. **If a supplier is missing a scored component,** send it to the Enrichment queue — do not score it zero. A zero asserts something; a null asserts nothing.

## User adjustment points

After CP4, the agent pauses and accepts a natural-language instruction before producing the final export:

> **Accepted filter commands (examples):**
> - "Focus on India only"
> - "Remove China"
> - "Show me tier A hardgoods only"
> - "Add Pakistan to the priority list"
> - "Push Tier B higher if score ≥ 8"
>
> The agent applies the instruction, re-runs the sort (not the scores — scores are frozen after CP2), and re-presents the top 20 for approval before CP5 export.

## Notion output schema (CP5)

The agent writes each scored supplier to the Notion leads database with these properties:

| Property | Type | Source |
|---|---|---|
| Supplier Name | Title | DB |
| Supplier Code | Text | DB |
| Country | Select | DB |
| Vertical | Select | CP1 |
| Framework | Text | CP1 |
| Tier | Select (A/B/C/Parked) | CP2 |
| Score | Number | CP2 |
| Max Score | Number | CP2 |
| Score % | Number | CP2 |
| Call List Rank | Number | CP4 |
| Call List Tier | Select | CP4 |
| Activity (pts) | Number | CP2 |
| Growth (pts) | Number | CP2 |
| Product Breadth (pts) | Number | CP2 |
| Buyer Quality (pts) | Number | CP2 |
| Category (pts) | Number | CP2 |
| Ticket (pts) | Number | CP2 |
| Adverse Status | Select (NOT SCREENED / CLEAN / MINOR / MATERIAL / CRITICAL) | CP3 |
| Air8 Financed | Checkbox | DB |
| Avg Invoice USD | Number | DB |
| Months Active P1Y | Number | DB |
| Total Buyers | Number | DB |
| Top Buyers | Text | DB |
| Data Flags | Text | CP2 flags (density mismatch, missing fields) |
| **BD Owner** | Person | — BD fills |
| **Status** | Select (New / Contacted / Interested / Not Now / Rejected / Converted) | — BD fills |
| **Notes** | Text | — BD fills |
| **Last Contacted** | Date | — BD fills |
| Run ID | Text | Agent metadata |
| Scored At | Date | Agent metadata |
