# L1 · Vertical routing

Routing happens **before** scoring and decides which framework applies. Getting it wrong does not produce a wrong number — it produces a number on the wrong scale, which is worse, because it looks fine.

## Rules, in order

| Signal | Vertical | Framework |
|---|---|---|
| HS chapter **61, 62** | Apparel | v1.1, 11 points |
| HS chapter **63, 57, 94** — home textile, carpets, furniture, bedding, lighting | Hardgoods | v3.0, 15 points |
| HS chapter **50–60** | Fabric or yarn mill | **Neither funnel.** Park with the reason |
| Ceramics 69, glass 70, plastics 39, wood 44, metal articles 73 | Hardgoods, but only on product text | These chapters mix consumer hardgoods with industrial goods, so the chapter alone is not evidence |
| No HS codes | Route on product description | Then confirm before relying on the tier |
| Neither codes nor usable text | — | **Enrichment queue, not a score of zero** |

## Why parking mills matters

HS 50–60 is fabric and yarn. A mill can look excellent on activity and growth and is still not a fit for either programme — its counterparties are garment factories, not retailers, so the receivable has a different risk shape entirely. Park it, name the reason, and do not let it occupy a slot in a call list.

## Product-description routing is a downgrade, not a fallback

A vertical assigned from text should carry the note *"routed on product text — confirm the vertical"*. It has a real error rate: an HS-based classifier reproduced only **96 of 112** existing hand labels on one batch. Report the discrepancy rate rather than silently overwriting the client's own classification.

## The China HS gap

On the NEXT batch, **188 of 260 China and Hong Kong suppliers had no HS codes at all**. The conclusion "China looks empty" was almost entirely a data gap, not a market fact. Before drawing any regional conclusion, check HS coverage by region and state it.

## Re-routing on richer data

An FR export carrying `product_desc` can re-route names that were misclassified from customs data alone — five names moved verticals this way. A supplier-buyer *pair list* cannot: it looks like lending data but has no dates and no product descriptions. Check which file you have.

If a name re-routes to hardgoods, **re-score it on the hardgoods framework** rather than carrying its apparel score across. The two scales are not interchangeable.
