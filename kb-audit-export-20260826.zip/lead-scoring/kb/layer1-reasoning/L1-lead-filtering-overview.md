# L1 · Lead filtering — overview

**Purpose:** turn a raw supplier list into a ranked, screened, callable BD list, in either vertical, with an audit trail a reviewer can argue with.

**Status:** live. Apparel framework v1.1, hardgoods framework v3.0.

## What the funnel does, in order

| Stage | Input | Decision | Reasoning file |
|---|---|---|---|
| 1 · Route | HS codes or product text | which framework applies, or park | [L1-vertical-routing.md](L1-vertical-routing.md) |
| 2 · Score | DB-derived activity, growth, breadth, category, ticket | tier A/B/C | [L1-scoring-apparel.md](L1-scoring-apparel.md) · [L1-scoring-hardgoods.md](L1-scoring-hardgoods.md) |
| 3 · Gate | adverse verdict, default history, entity resolution | in, out, or parked | [L1-ordering-and-gates.md](L1-ordering-and-gates.md) |
| 4 · Order | region, tier, need, evidence quality | the call sequence | [L1-ordering-and-gates.md](L1-ordering-and-gates.md) |
| 5 · Screen | published filings, court records, press | adverse severity | [L1-adverse-severity.md](L1-adverse-severity.md) |
| 6 · Assess | accounts, ratings, charge registers | financing-need band | [L1-financing-need.md](L1-financing-need.md) |
| 7 · Enrich | company sources, audited disclosures | contacts and other buyers | [L1-evidence-discipline.md](L1-evidence-discipline.md) |

Stages 1–4 are cheap and run on everything. Stages 5–7 are expensive research and run **only** on the ~20 names that survive. Getting that order wrong is the single most costly mistake available here.

## The one thing to understand about the score

**It predicts retention, not appetite.** Both frameworks were fitted on which financed relationships were still alive later — not on who said yes. So a high score means "will still be here in 18 months if we onboard them", not "wants money now".

Roughly a quarter of high scorers turn out to be investment-grade and under-borrowed. A tier A with a `LOW` financing need is the system working correctly, not a contradiction. Report both and let the reader see the shape.

This is also why financing need is **a tie-breaker and never a filter**: it is inferential, frequently unpublished, and it was demoted deliberately after we found how often it could not be established.

## What is never scored

| Excluded input | Why |
|---|---|
| Financing need | Inferential; a separate later screen |
| LF / existing-relationship status | Separate funnels upstream. It changes who calls, not the rank |
| Buyer credit limit (apparel) | Matched upstream in the funnel; scoring it again double-counts |
| Monthly volume / FOB value | Measurably did not differentiate stickiness (~$58–66K in both durable and churned hardgoods groups). Within-tier tie-breaker only |
| Country (hardgoods v3.0) | Dropped on instruction — the book had too few China-origin cases to support the old penalty |

Volume never promotes a lead across a tier. Convertibility first, monetise after.

## Outputs

1. **Full scorelist** — every supplier, every component score, the methodology and the threshold evidence. This is the artefact that makes the ranking arguable rather than magic
2. **Call list** — the ordered top 10–20, one row per name with the researched fields
3. **Gated out / Floor / Bench** — the excluded names, visible, with the evidence. A reviewer's first question is always "why isn't the biggest one here?"
4. **Outreach tracker** — for BD to fill, which is also how stage 8 arrives

## Stage 8 — the feedback loop that is not built yet

BD outcome tags (interested / not-now / competitor-financed / no-response) are collected in the tracker but have **not** yet been used to change anything. At 30+ negatives they permit the first true *conversion* model, which is a different target from retention. Until then, tier A must beat tier B on interested-rate within a quarter or the framework gets escalated to a refit.

Also still missing: a **pre-2024 FR lending export** (supplier, actual_lending_date, buyer, amount). Without it we cannot score a churned client on the 12 months *before* it stopped, so low scores on long-churned clients remain unproven in both directions. Say so rather than claiming a miss.

## Known blind spot

Customs data is US-import based, and the two apparel buyers we have run are UK retailers. UK-bound volume is invisible, so genuinely busy suppliers can read as dormant — measured at 3 of 7 validatable clients. The directional rule: **if book activity exceeds customs activity, the supplier is sticky and the customs record is wrong.** Full list of traps: [L1-data-traps.md](L1-data-traps.md).
