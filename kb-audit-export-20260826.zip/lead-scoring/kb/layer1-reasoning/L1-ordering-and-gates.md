# L1 · Gates, sort order and list construction

Vertical-neutral: applies to apparel and hardgoods lists alike. In a mixed batch, apply it within each vertical and ship two lists — the two scoring scales are not comparable.

The ranked list is the product. Its order was argued over and changed twice; the current rule is below and it should be reproduced in an `Ordering rule` tab of every pack so nobody has to remember it.

## Gate 1 — Adverse news

Run the screen with the adverse screen ([L1-adverse-severity.md](L1-adverse-severity.md)); the severity ladder lives there.
**MATERIAL or worse → out of the call list.** Recorded in `Gated out` with the finding and what would reopen it, never silently deleted. MINOR stays in with a watch-out. NOT SCREENED stays in, honestly labelled.

The bar moved during the project: originally only CRITICAL excluded, then the user corrected it to MATERIAL as well. If a future instruction moves it again, change it here and in the pack's rule tab together.

## Gate 2 — Recent hard default
Out. No tie-breaking, no bench.

## Gate 3 — Entity unresolved
**Parked, not scored.** If the legal entity behind a name cannot be pinned down, a score is false precision. Park with the reason and what would resolve it.

## Sort keys, in order

1. **BD region priority — above the score.** India, Pakistan, then China/HK, then others. The purpose is coverage: every BD team gets names in the first batch. Non-priority countries are not deleted, they slide into `Pipeline 11–20`.
2. **Score**, descending.
3. **Financing need**, descending. A tie-breaker only — it is inferential, often unavailable, and demoting it from a filter was a deliberate decision ("不一定准就很难找").
4. **Buyer-evidence quality**, then adverse-screen cleanliness.

**By-exception promotion.** If the priority regions cannot fill the list on score alone, promote a lower scorer with exceptional need or flow evidence — and write the exception into the rule tab. Precedent: a 6/11 with gearing at 2.96x and a rating placed Under Review, and a 5/11 tier C holding 16.4% of the buyer's flow with the flow still current. An exception you can read is a rule; an exception you can't is a fudge.

**When the region cannot be filled, say so.** On one batch, stripping China and Hong Kong left only seven callable India/Pakistan names, because the buyer's base contained 28 Indian and 5 Pakistani A/B suppliers in total. The right output is "China fills ranks here rather than being a bonus", not a padded list.

## Floor — published evidence of no need
Below the call list, with the numbers. Signals: net cash, zero or trivial short-term borrowings, interest-free parent funding, a very short DSO, or an explicit public statement that the company does not discount receivables. The most instructive floor entry held the **second-largest flow in the entire batch (673 transactions) with zero short-term borrowings** — enormous volume, nothing to sell. Showing it prevents the "why didn't you call the biggest one?" question.

## Bench — promotable by exception
One score band lower but with better evidence. Kept visible so the list can be topped up without re-running the pipeline.

## Already-financed clients
**Keep them in the list, do not replace them.** Backfill additional names to reach the target count, but leave the financed ones ranked in place — the overlap between the model's top picks and the existing book *is* the validation the boss wants to see. Add an `IN CURRENT CALL LIST` column reading e.g. `NEXT #1 (already financed)`, because an outcome-based sort will otherwise scatter them and it looks like only one matched.

## Target-buyer share ≠ importance
Check whether the target buyer is actually the supplier's biggest. Frequently it isn't: cases have surfaced where the real anchor was Carter's, American Eagle, AEO/Talbots, Aldi at 65%, M&S at 76%. Two consequences: the call opens on the anchor buyer, not the one whose list you were given; and some names are cross-sell opportunities for a *different* buyer's programme. Tag rows `ANCHOR` / `LEAD WITH THIS` / `CROSS-SELL` / `WARNING`.

`WARNING` covers related-party receivables — a supplier whose "buyer" is its own UK parent or a Singapore affiliate has intra-group receivables that may be unfinanceable. Three such cases appeared in one batch of twenty.
