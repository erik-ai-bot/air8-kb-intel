# L1 · Financing need — six angles and where to look

Need is inferred from published data and always reported **with the figures**. A band with no numbers cannot be defended and cannot be used downstream.

## The six angles

**1. Rating actions and bank-limit utilisation.** The strongest single tell, and the fastest to find. A placement Under Review, on Watch, or a downgrade means the company's own bankers are re-pricing it. Read the rationale, not just the grade: it names the limits, the utilisation and the covenant pressure.

**2. Receivables growth vs revenue growth, DSO, operating cash flow.** Trade debts growing far faster than revenue is a working-capital gap in plain sight. Real case: trade debts PKR 1.13bn → 4.84bn → 5.93bn over three years while revenue grew a fraction of that, alongside gearing 1.77 → 2.36 → 2.96x and a cash balance of PKR 59.6mn. That is a `VERY HIGH` you can prove.

**3. Short-term borrowing cost and currency mix.** Cheap concessionary local-currency funding means you cannot compete on price — but check the split before concluding. One company borrowed RMB at 2.18–2.31% and **USD at 3.85–5.46%**: the USD leg is a real wedge even though the RMB leg is untouchable. Also look for a cash-conversion-cycle drift (63 → 75 → 98 days) and a falling DSCR (6.96 → 3.07x), which say the pressure is building even while the rate looks fine.

**4. Registered charges and pledged assets.** Collateral exhaustion is a need signal independent of cash. One case had 37.2% of assets pledged including the operating plant's own land and buildings — unsecured receivable purchase is valuable to that company even though it is not short of money. India: MCA charge register. UK: Companies House charges.

**5. Parent-group funding model.** An interest-free holdco loan, a group treasury, or a sponsor loan means the financing conversation belongs at the parent, not the factory. It also caps what you can win: a development-bank loan disclosure (IFC lent USD 50m to one group; StanChart lent a subsidiary USD 11m directly) tells you the price you would have to beat.

**6. Legal form.** Unincorporated firms and partnerships have thinner bank access — a positive need signal, and a warning that personal guarantees will be in scope. Identify it from the GLEIF LEI legal-form code (`A0PS` = partnership) or, in India, the 4th character of the PAN (`F` = firm).

## Bands

| Band | Looks like |
|---|---|
| `VERY HIGH` | Receivables outrunning revenue, gearing rising past ~2.5x, thin cash, rating under review |
| `HIGH` | Already discounting bills, cash cycle lengthening, DSCR falling, sponsor loans |
| `MEDIUM-HIGH` / `MEDIUM` | Structural working-capital dependence with no distress signal; thin equity against large turnover |
| `LOW` | Net cash, negligible short-term borrowings, interest-free parent funding, short DSO, or an explicit refusal to discount receivables |
| `UNKNOWN` | Nothing published. Say so — do not infer from size |

**`LOW` goes to the Floor with its evidence, never to the bin.** And a `VERY HIGH` band can still be unbankable — mark it `VERY HIGH but NOT BANKABLE` where the receivables are intra-group or the entity is unresolved.

## Source registry

| Country | Sources |
|---|---|
| India | CRISIL, ICRA, CARE, Acuité, Infomerics rationales; MCA charge register via ZaubaCorp / TheCompanyCheck; PAN 4th character |
| Pakistan | PACRA, VIS reports; SECP filings; TDAP exporter rankings (scale evidence) |
| Bangladesh | CRAB, CRISL |
| Sri Lanka | Fitch Ratings Lanka |
| UK | Companies House accounts and charges |
| Hong Kong / China | HKEX annual reports and announcements; NEEQ / STAR filings; the parent's material-events index; audited top-five-customer disclosures |
| Any | GLEIF LEI legal-form codes; IFC and development-bank loan disclosures; the contingencies note of any audited account |

## The trap worth naming

The scoring framework predicts **retention**, not appetite. Roughly a quarter of high scorers turn out to be investment-grade and under-borrowed. A high score followed by a `LOW` need is not a contradiction and not a scoring error — it is the system working. Report both.
