# KB — Supplier Lead Filtering

## Where this sits

```
   DB  ────────────────►  AGENT  ◄────────────────  KB
 leads, customs           applies KB              layer 1  reasoning: rules, thresholds, gates
 transactions, FR         to DB                   layer 2  entities: what we know about
 book, buyer lists           │                             specific suppliers, buyers, categories
                             ▼
                    FILTERING RESULT
             scored + tiered + gated + ordered list
```

**The DB holds what is measured. The KB holds what is judged.** Shipment counts, invoice dates, buyer names and HS codes live in the DB and change daily. Thresholds, severity ladders, verified contacts, adverse verdicts and buyer-programme status live in the KB and change deliberately. The agent reads both and writes the filtering result; it never writes back into Layer 1.

A Layer 2 entity record is **not** a copy of a DB row. It holds only what the DB cannot tell you: whether a buyer's programme is still alive, which of two similarly-named companies this actually is, what a rating agency said, which contact is published. If a field is derivable from the DB, it does not belong in the KB — see [L1-db-field-contract.md](layer1-reasoning/L1-db-field-contract.md) for the boundary and the join keys.

## The two layers

Two layers, as the KB is organised everywhere else:

- **Layer 1 — reasoning.** How we decide. Frameworks, thresholds and the evidence behind them, gates, sort order, severity ladders, judgement protocols, and the mistakes we have already made. Stable, versioned, argued over once.
- **Layer 2 — entities.** What we know about specific things: suppliers, buyers, product categories. Facts with sources, plus the verdict Layer 1 produced when applied to them.

The split matters because they change at different speeds. A threshold moves once a quarter with evidence; a supplier's rating moves whenever the agency acts. Keeping them apart means new facts never quietly rewrite a rule, and a rule change never invalidates a fact.

## Files

| Layer 1 — reasoning | What it holds |
|---|---|
| [L1-lead-filtering-overview.md](layer1-reasoning/L1-lead-filtering-overview.md) | The whole funnel on one page. Start here |
| [L1-db-field-contract.md](layer1-reasoning/L1-db-field-contract.md) | Which DB fields feed which indicator, how they are derived, and the join keys |
| [L1-vertical-routing.md](layer1-reasoning/L1-vertical-routing.md) | HS chapter → which framework applies |
| [L1-scoring-apparel.md](layer1-reasoning/L1-scoring-apparel.md) | Framework v1.1, 11 points, with the stickiness-gap evidence |
| [L1-scoring-hardgoods.md](layer1-reasoning/L1-scoring-hardgoods.md) | Framework v3.0, 15 points, and the v2.1 fallback |
| [L1-ordering-and-gates.md](layer1-reasoning/L1-ordering-and-gates.md) | Gates, region priority, sort keys, Floor and Bench |
| [L1-adverse-severity.md](layer1-reasoning/L1-adverse-severity.md) | The four-verdict ladder and what each one does to a lead |
| [L1-financing-need.md](layer1-reasoning/L1-financing-need.md) | Six angles, bands, and the country source registry |
| [L1-evidence-discipline.md](layer1-reasoning/L1-evidence-discipline.md) | Contacts, buyer evidence, entity resolution, what counts as a source |
| [L1-data-traps.md](layer1-reasoning/L1-data-traps.md) | Ten failures already paid for |
| [L1-decision-log.md](layer1-reasoning/L1-decision-log.md) | Every rule change, when, why, and what it replaced |

| Layer 2 — actor types | What it holds |
|---|---|
| [L2-README.md](layer2-entities/L2-README.md) | The type set, the record shape, and how a leads run traverses it |
| [L2-buyer-types.md](layer2-entities/L2-buyer-types.md) | Who the receivable is owed by |
| [L2-supplier-types.md](layer2-entities/L2-supplier-types.md) | What kind of counterparty we would finance |
| [L2-product-types.md](layer2-entities/L2-product-types.md) | Segments, categories, raw materials, excluded verticals |
| [L2-group-and-funding-types.md](layer2-entities/L2-group-and-funding-types.md) | Parents, affiliates, and who already funds them |
| [L2-evidence-source-types.md](layer2-entities/L2-evidence-source-types.md) | Kinds of register and filing, and what each can settle |
| [L2-relationships.md](layer2-entities/L2-relationships.md) | The edges, and what each edge implies |

**Layer 2 holds types, never individuals.** Primark and any named supplier are DB rows. Instance-level facts we have already established are staged as DB seed data in [_to_db/](_to_db/).

## How the layers reference each other

Layer 1 tells the agent **how to decide**. Layer 2 tells it **what kind of thing it is looking at**, so the same score can produce different verdicts. The DB supplies the individuals.

A leads run reads Layer 2 **twice**: before scoring, to route and to catch identity problems; and after scoring, on the shortlist only, to interpret what the type implies for who signs, what to pitch, and what could make the receivable unfinanceable. Detail: [L2-README.md](layer2-entities/L2-README.md).

No thresholds in Layer 2 — a cut written there will drift from the one that executes. Cite the Layer 1 file and version instead.

## Source of truth, and the one governance rule

Layer 1 is **canonical**. The `supplier-lead-scoring`, `supplier-adverse-and-need` and `supplier-bd-enrichment` skills carry executable copies of the same thresholds in their `references/` files, because a script has to have numbers in it.

**Any threshold change must edit the Layer 1 file and the skill's reference file in the same session, and land a row in [L1-decision-log.md](layer1-reasoning/L1-decision-log.md).** Two copies of a number is a real risk — we have already shipped one drift, where hardgoods v3.0 lived in a spreadsheet for weeks while the deployed skill still ran v2.1. The decision log exists so that drift is visible instead of silent.

## Conventions

- Every fact carries a source. A URL, a filing reference, or the internal dataset it came from
- `NOT FOUND` means published nowhere we could reach. `NOT SCREENED` means nobody has looked yet. Neither is a blank
- Absence of evidence is recorded differently from evidence of absence, always
- Dates on everything perishable: ratings, adverse screens, contacts
- English throughout, so the same file serves the boss, BD and the agents
