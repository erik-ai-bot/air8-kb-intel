# Layer 2 — actor types and relationships

Layer 2 answers one question: **what kind of thing is this, and what does that kind imply?**

It holds **types**, never individuals. Primark, Shahkam Industries and Masood Textile Mills are rows in the DB, not files here. What lives here is *"UK/EU value retailer"*, *"trading house"*, *"partnership firm"* — each with its identifying features, what to think about when you meet one, and what it implies for the decision.

## Files

| File | Actor types |
|---|---|
| [L2-buyer-types.md](L2-buyer-types.md) | Who the receivable is owed by |
| [L2-supplier-types.md](L2-supplier-types.md) | What kind of counterparty we would be financing |
| [L2-product-types.md](L2-product-types.md) | Apparel segments, hardgoods categories, raw materials, excluded verticals |
| [L2-group-and-funding-types.md](L2-group-and-funding-types.md) | Parents, affiliates, and who is already funding them |
| [L2-evidence-source-types.md](L2-evidence-source-types.md) | Kinds of register and filing, and what each can and cannot settle |
| [L2-relationships.md](L2-relationships.md) | The edges between the above, and what each edge implies |

## How this differs from the event-trigger KB

Same two layers, **opposite direction of travel**.

```
EVENT TRIGGER          one event ──► L1 decompose ──► L2 which actor types are touched ──► DB which of our clients
                                                                                          (fan OUT: 1 → many)

LEADS                  a DB population ──► L1 score & gate ──► L2 what kind is each row ──► the few worth calling
                                                                                          (funnel IN: many → few)
```

In the event KB, Layer 2 is a **lookup**: the event names a product or a material, and Layer 2 tells you which actor types sit around it so you can go find the affected clients. Layer 2 is consulted *before* you touch the DB.

In leads, Layer 2 is a **classifier and interpreter**: the DB hands you 670 rows, Layer 1 scores them, and Layer 2 tells you what each surviving row actually *is* — a factory or a trading house, an end brand or a sourcing agent, a partnership or a listed group — because the type changes the verdict, the pitch and the risk even when the score is identical.

Practical consequence: **a leads run reads Layer 2 twice.**

1. **Before scoring**, to route and to sanity-check: which product type is this (which framework applies), is this buyer type visible in our customs feed, is this an excluded vertical
2. **After scoring**, on the shortlist only, to interpret: what does this supplier type imply about who signs, what to pitch, what to never lead with, and what could make the receivable unfinanceable

## What each type record contains

The same shape as the event KB, so the two read alike:

```markdown
## <Type name>
**How to recognise it**   the features that identify it, ideally from DB fields
**What to think about**   the questions this type always raises
**What it implies**       for scoring, gating, pitch, and risk
**Where it can mislead**  the mistake this type invites
```

## Boundary rules

- **No individuals.** If a name could appear in the DB, it is not a Layer 2 file
- **No thresholds.** Cite Layer 1; a cut written here will drift from the one that executes
- **No transaction data.** Counts, dates and values are DB-derived — see [L1-db-field-contract.md](../layer1-reasoning/L1-db-field-contract.md)
- Instance-level facts we have already established (which buyer programmes are dead, which names collide) are **DB seed data**, staged in [../_to_db/](../_to_db/), not KB content
