# L2 · Group and funding types

Who already funds the supplier decides whether there is a deal, what it costs, and who we are competing with. This is the actor set behind the financing-need judgement — six angles in [L1-financing-need.md](../layer1-reasoning/L1-financing-need.md).

## Parent / holding company

**How to recognise it** A holdco loan line in the accounts; a shared group name; consolidated filings.

**What to think about** Is the loan interest-free or at a nominal rate? Is it committed, or callable? Where does treasury actually sit?

**What it implies** Interest-free or near-zero parent funding usually means **no receivable gap at all** — a Floor name. It also relocates the conversation: the decision is at the parent, not the factory, and pitching the factory wastes the call. Revisit trigger: the parent funding being withdrawn, repriced, or replaced with third-party debt.

**Where it can mislead** The subsidiary may be busy and impressive on every operating metric while being structurally unfinanceable. Read the funding note before the volume.

## Group affiliate as counterparty

**How to recognise it** A large "buyer" sharing the group name, the address, or sitting in a known affiliate jurisdiction (UK, Singapore, Hong Kong).

**What it implies** Intra-group receivable → **may be unfinanceable regardless of quality**. Structural bar, tag `WARNING`. Common: three cases in one batch of twenty.

## Group treasury

**How to recognise it** A centralised finance function disclosed at group level; subsidiaries with no independent banking relationships.

**What it implies** Any exposure starts as a group-treasury conversation, usually in the group's home city. Individual plants cannot transact. Development-bank lending to the group (for example a multilateral loan to the parent, or a bank lending directly to a named subsidiary) tells you the **price you would have to beat** — and it is often a price we cannot match.

## Concessionary or state lender

**How to recognise it** Named subsidised export or long-term financing schemes in the borrowings note; an average borrowing rate far below market.

**What it implies** **You cannot compete on price on that leg.** Look instead for the leg they cannot fund cheaply — most often the foreign-currency one. One case borrowed local currency at 2.18–2.31% while paying 3.85–5.46% on USD: the USD leg is the wedge and the local leg is untouchable. Always get the currency split before concluding "too cheap for us".

## Existing receivable financier

**How to recognise it** Bill discounting, factoring or export-bill purchase already in the borrowings note or the accounting policy.

**What it implies** The **shortest path to a first deal** — the product is already understood, so the conversation is price, tenor and capacity rather than education. Ask who provides it and at what rate.

**Where it can mislead** Also means a live incumbent relationship and a benchmark you will be measured against immediately.

## Sponsor / director loan

**How to recognise it** Related-party loans from owners or directors in the accounts.

**What it implies** The owner has already funded the working-capital gap personally — a strong need signal and, usually, an owner motivated to replace their own money with a facility.

## Secured lender with registered charges

**How to recognise it** Charge registers — India MCA, UK Companies House — and pledged-asset notes.

**What it implies** **Collateral exhaustion is a need signal independent of cash.** One case had 37.2% of assets pledged including the operating plant's own land, which makes unsecured receivable purchase valuable to a company that is not short of money. This is the angle most often missed on cash-rich names.

## Rating agency

**How to recognise it** A published rationale from a national agency.

**What it implies** The single fastest and strongest need signal, especially a placement **Under Review** or **on Watch** — the company's own bankers are repricing it. Read the rationale, not the grade: it names the limits, the utilisation and the covenant pressure. Note also that a **self-withdrawn rating** is informative in the other direction, often accompanying a company that has decided it does not need external funding.

**Where it can mislead** A rating action is a *need* signal, not an adverse finding. Never record one as adverse news.
