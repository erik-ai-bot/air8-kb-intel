# L2 · Supplier types

The score says whether a supplier will stick. The **type** says who signs, what to pitch, what never to lead with, and what could make the receivable unfinanceable. Two names with the same score and different types are different deals.

## Independent factory

**How to recognise it** Own plant and address, a stated headcount and production-line count, product range consistent with one manufacturing capability, HS codes clustered in one or two chapters.

**What to think about** Is the capacity real and is the flow theirs, or are they booking someone else's? Who in the family or partnership actually signs?

**What it implies** The most desirable type: the receivable belongs to the entity that made the goods, so performance risk and credit risk sit in the same place. Usually the cleanest path to a first deal.

**Where it can mislead** Scarce in some bases. On one buyer's China/Hong Kong A/B set, **8 of 9 names were traders or listed groups and exactly one was an independent factory** — so "no factories here" may be a base characteristic, not a search failure.

## Trading house / export agency

**How to recognise it** Asset-light: tiny registered equity against very large claimed turnover; HS codes spread across **unrelated** chapters (garments *and* tiles *and* furniture *and* sporting goods); no plant; small headcount; customs or AEO status as an exporter rather than a manufacturer.

**What to think about** Whose factories are these? Are they pre-financing those factories, and with what? Is our buyer's flow material to them at all?

**What it implies** Structural dependence on borrowed working capital is real — an agency with a fraction of a percent of its turnover in equity is funding someone else's production. But this type usually holds cheap onshore alternatives and export-credit cover, so **expect price resistance**. The unrelated-HS-spread is the diagnostic tell that separates this type from a factory.

**Where it can mislead** Activity and density score beautifully because an agency aggregates many factories' shipments under one code. High cadence here is not the same signal as high cadence at a factory.

## Listed or state-owned group

**How to recognise it** Exchange listing or state ownership; audited accounts and a material-events index; a company secretary and an IR adviser instead of a reachable owner.

**What to think about** What is their stated balance-sheet objective? How much undrawn capacity do they hold, and at what rate?

**What it implies** Reliable data and a real governance record — a filed "NO" against litigation and penalties is auditable evidence of absence, which is stronger than silence. But **never lead with liquidity**: large undrawn facilities end the call. The pitch is derecognition and a stated deleveraging target, priced off the buyer's rating, not off theirs.

**Where it can mislead** Good disclosure reads as low risk and often is — but it also means any real problem is already public, so an empty search here is more meaningful than an empty search elsewhere.

## Partnership or unincorporated firm

**How to recognise it** Legal-form code rather than a company suffix — GLEIF LEI `A0PS`, or in India the 4th character of the PAN being `F`. Named partners rather than directors.

**What to think about** Whose personal guarantee is in scope? Which partner signs, and is the succession clear?

**What it implies** Thinner bank access, so a **positive financing-need signal**. Also a positive on speed: fewer approval layers. Personal guarantees will be part of the structure, so identify the individual partner early rather than at documentation.

**Where it can mislead** Published finance contacts are frequently absent for this type, which reads as "no route" when the real route is an introduction.

## Vertically integrated manufacturer

**How to recognise it** Owns upstream stages — knitting, spinning, dyehouse, laundry — and appears in trade-body export rankings.

**What to think about** Are they importing trims and fabric, and if so is there a payables angle alongside the receivable?

**What it implies** Scale and stickiness, plus a second product to sell: heavy trim and fabric imports make payables finance relevant. A trade-body export ranking is unusually hard scale evidence in markets where accounts are thin.

**Where it can mislead** Capital intensity means gearing looks high for reasons that are not distress. Read the asset base before treating leverage as need.

## Subsidiary funded by its parent

**How to recognise it** A holding-company loan in the accounts, especially interest-free or near-zero rate; a very short DSO; negligible third-party borrowing.

**What to think about** Is there any receivable gap at all? What would have to change for one to appear?

**What it implies** Usually a **Floor** name — published evidence of no need — even when the flow is enormous. The most instructive case held the second-largest flow in its batch with zero short-term borrowings. Record it visibly with the numbers rather than dropping it, and note the revisit trigger: the parent funding being withdrawn or repriced.

**Where it can mislead** Volume optics. This type looks like the obvious top pick right up until you read the funding note.

## Fabric or yarn mill

**How to recognise it** HS chapters 50–60.

**What it implies** **Neither funnel.** Its counterparties are garment factories, not retailers, so the receivable has a different risk shape. Park it with the reason; do not let it occupy a call-list slot on the strength of good activity numbers.

## Cross-cutting: what to establish for any type

| Question | Why it changes the deal |
|---|---|
| Registration number | A finding attached to the wrong company is worse than no finding |
| Who signs | Partner, director, board, or parent treasury — this is a type property |
| Is the largest buyer the one on our list? | Frequently not. The call opens on the anchor, and the other flow may be a cross-sell |
| Is any large counterparty a group affiliate? | Intra-group receivables may be unfinanceable |
| Are assets already pledged? | Collateral exhaustion makes unsecured receivable purchase valuable even to a cash-rich name |
