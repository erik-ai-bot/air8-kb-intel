# L2 · Product types

Product type does two jobs: it **routes** the lead to a framework, and it carries measured durability that the framework then scores. Points and cuts live in Layer 1 — cited here, never restated.

## Apparel — HS 61 (knitted) and 62 (woven)

| Segment | HS 4-digit |
|---|---|
| Knitwear | 6103–6106, 6109, 6110, 6114, 6115 |
| Wovens | 6204–6206 |
| Outerwear | 6101, 6102, 6201–6203, 6210 |
| Intimates | 6107, 6108, 6207, 6208, 6212 |
| Babywear | 6111, 6209 |
| Activewear | 6112, 6113, 6211 |
| Accessories | 6116, 6117, 6213–6217 |
| Denim | no distinct HS line — read from product description |

**Measured durability:** mixed-segment suppliers retained **84.6%** against single-segment (women's only) **35.3%** — a 49pp gap on 71 supplier-buyer flows.

**What to think about** Breadth across segments is a proxy for how embedded the supplier is in the buyer's range. A single-segment supplier lives or dies with one category decision; a mixed supplier survives a range reshuffle. This is why *spread* is scored and segment *identity* is not — no apparel segment is intrinsically better, but serving two of them is.

**Where it can mislead** Two HS lines in the same segment (6109 and 6104 are both knitwear) look like breadth and are not. Classify to segment, not to line count. If the segment cannot be established → Enrichment, never a default of single-segment.

## Hardgoods — HS 63, 57, 94, plus 69 / 70 / 39 / 44 / 73 on product text

Shrunk durability (prior 0.40, k=5) on 139 suppliers, 14,048 FR rows:

| Category | Durability |
|---|---|
| Home Textile & Bedding | **0.65** |
| Home Decor | **0.64** |
| Kitchen & Dining | 0.58 |
| Pet Supply | 0.43 |
| Lighting / consumer electronics | ~0.37 |
| Furniture | **0.33** |
| Components / electronics manufacturing | **0.05** |

Grouped: HTB / Decor / K&D retained **73%** against Furniture and minor hardgoods **27%** — a 46pp gap.

**What to think about — the discriminator is not the same in every category:**

| Category | What separates durable from churned |
|---|---|
| Furniture | **Ticket size.** Durable ≈ $22K; failed $64–296K. Cadence barely differs |
| Kitchen & Dining | **Cadence.** Durable 3.5 shipments/mo; failed 1.4/mo |

This is why cadence and ticket thresholds are category-conditional rather than global. **Furniture never exceeds tier B** — 33% durable, and points must not stack it into A.

**Where it can mislead** Chapters 69, 70, 39, 44 and 73 mix consumer hardgoods with industrial goods, so the chapter alone is not evidence of vertical. Route on product text and mark the routing as unconfirmed.

## Raw materials — HS 50–60

Fabric and yarn. **Neither funnel** — sells to factories, not retailers. Park with the reason. Relevant to the leads process only as a routing outcome, and to the event KB as an input-cost actor.

## Excluded verticals

Components and electronics manufacturing, apparel *within the hardgoods funnel*, FIBC and industrial packaging, raw materials, beauty, toys. **Excluded means a different funnel, not a low score** — never present an excluded vertical as a tier C.

Also excluded on flow rather than product: **CNY-domestic-only invoicing** — 164 of 164 such invoices came from churned suppliers, 0% durable.

## The persona finding worth carrying across both verticals

High-frequency small-ticket exporters were **11% of the hardgoods book by count but 64% of financed value.** The leads that look biggest — big-ticket, low-frequency, single-buyer China — were the worst at **4% durable**. Volume optics and durability point in opposite directions, which is why monthly volume is a within-tier tie-breaker and never a promoter.
