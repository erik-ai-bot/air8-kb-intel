# L2 · Buyer types

The buyer is who the receivable is actually owed by, so buyer type drives both the credit and the visibility of the supplier in our data. Buyer credit limits are matched **upstream** in the funnel and are deliberately not scored again — see [L1-lead-filtering-overview.md](../layer1-reasoning/L1-lead-filtering-overview.md).

## UK / EU value or mid-market retailer

**How to recognise it** European store base, minimal US retail presence; publishes a factory or tier list; brand known in the UK/EU high street.

**What to think about** Is this supplier's real cadence visible to us at all? What does the buyer's own factory list say about this relationship?

**What it implies** Our customs feed is US-import based, so **UK-bound volume is invisible and cadence is systematically understated**. Measured cost on one book: 3 of 7 validatable clients scored C or Enrichment despite being sticky. Directional rule — if book activity exceeds customs activity, the supplier is sticky and the customs record is wrong. Never conclude "dormant" from customs alone on this buyer type.

**Where it can mislead** A published tier list looks like confirmation but frequently names a *similarly-named different entity*, which is how name collisions enter. Treat it as evidence to check, not to accept.

## US mass, club or off-price retailer

**How to recognise it** Names that dominate US bills of lading: mass merchants, warehouse clubs, off-price and home-goods chains.

**What to think about** Is the supplier's US book the real business, with the buyer on our list a minor line?

**What it implies** Strongly positive for hardgoods durability — suppliers selling to US major retailers retained **80% vs 24%** on export-only accounts, a 56pp gap, which is why buyer quality is a scored indicator in the hardgoods framework. Also the one buyer type our customs feed sees clearly, so cadence here is trustworthy.

**Where it can mislead** Visibility bias: because we see this type best, suppliers oriented to it score better than suppliers of equal quality oriented to the UK. Correct for the feed, not for the supplier.

## Sourcing intermediary / vendor-of-record

**How to recognise it** Appears as a large "customer" in audited disclosures but is an agent, a Hong Kong buying office, or a vendor-of-record rather than a brand. Often a generic trading name.

**What to think about** Which end brand actually sits behind this line? Does the intermediary or the brand carry the credit?

**What it implies** **This is not the credit you underwrite.** A 26% "customer" that is a sourcing agent tells you nothing about the end demand. Name the brand behind it; if you cannot, mark the concentration as unresolved rather than diversified.

**Where it can mislead** It flips concentration readings in both directions — a supplier can look diversified across five agents who all serve one brand, or concentrated in one agent who fronts twenty brands.

## Dead or dying programme

**How to recognise it** Sustained absence of rows for a buyer that used to be active; a public exit, insolvency, or category withdrawal. **Absence of rows alone is a prompt to look, not a conclusion.**

**What to think about** Did this supplier's flow die because of the supplier, or because the buyer's programme did?

**What it implies** The single most important attribution in the whole system: **21 of 33 churned flows (64%) had the buyer inactive, not the supplier.** Excluding buyer-caused churn, tier B retention goes 88% → 100% and tier C 30% → 52%. Attribute churn to the buyer **before** treating it as a scoring miss, and never build a pitch on a flow whose buyer is on the register.

**Where it can mislead** A dead programme makes a good supplier look bad, which is the expensive direction of the error. Known instances are seeded in [../_to_db/buyer_programme_status.csv](../_to_db/buyer_programme_status.csv) — status belongs in the DB, the reasoning stays here.

## Related-party buyer

**How to recognise it** The counterparty shares the supplier's group name, address, or a known affiliate jurisdiction — a UK parent, a Singapore or Hong Kong affiliate.

**What to think about** Is this a real third-party receivable, or an intra-group booking?

**What it implies** Intra-group receivables **may be unfinanceable regardless of quality**. This is a structural bar, not a pricing question. Tag `WARNING`. Three such cases appeared in one batch of twenty, so it is common enough to check every time.

**Where it can mislead** It is invisible unless you look at the group rather than the entity, and the supplier will not volunteer it.

## Brand holding an equity stake in the supplier

**How to recognise it** Joint-venture disclosure in the supplier's accounts naming a customer as a shareholder.

**What to think about** Does the buyer's ownership make the flow stickier, or does it make our receivable subordinate to a relationship we cannot see?

**What it implies** Concentration and governance both need reading together; the flow is usually durable but the pricing conversation may sit with the shareholder rather than the supplier.
