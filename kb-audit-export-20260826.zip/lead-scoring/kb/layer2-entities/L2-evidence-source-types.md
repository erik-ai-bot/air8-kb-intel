# L2 · Evidence source types

What kind of source can settle what kind of question. Discipline for using them: [L1-evidence-discipline.md](../layer1-reasoning/L1-evidence-discipline.md).

| Source type | Settles | Cannot settle | Where it exists |
|---|---|---|---|
| **National company register** | Legal existence, registration number, legal form, directors — the only authoritative answer to "is this the same company?" | Trading reality, buyer relationships | MCA (India), SECP (Pakistan), Companies House (UK), USCC lookup (China), GLEIF for LEI and legal-form code |
| **Credit rating agency** | Bank limits, utilisation, covenant pressure, direction of travel | Anything unrated — most private firms | CRISIL / ICRA / CARE / Acuité / Infomerics (India); PACRA / VIS (Pakistan); CRAB / CRISL (Bangladesh); Fitch Lanka |
| **Charge / security register** | Pledged assets, collateral exhaustion, who is secured | Unsecured borrowing | MCA charge register (via ZaubaCorp, TheCompanyCheck); Companies House charges |
| **Audited accounts + contingencies note** | Borrowings mix and cost, DSO, related-party loans, top-five customers, **unprovided-for demands** | Anything unaudited or private | Company filings, exchange announcements |
| **Exchange filing / material-events index** | Litigation, penalties, pledges, dishonesty listings — a filed "NO" is **auditable evidence of absence** | Private companies | HKEX, NEEQ, STAR, national exchanges |
| **Court record** | Live and past proceedings, and the forum | *What the allegation was*, when the file is sealed or undisclosed | High courts and writ registers; NCLT / NCLAT (India) |
| **Regulator appellate file** | Whether a regulatory matter is open | Substance, when unretrievable — an unretrieved file is a flag, not a null | SECP, SEBI, tax authorities |
| **Environmental / municipal authority** | Site-level penalties, permits, suspensions | Group-level conduct | Provincial and municipal decisions |
| **Sanctions and forced-labour lists** | Hard exclusions | Anything below that bar | OpenSanctions (mirrors UFLPA), UFLPA entity list, CBP WRO |
| **Labour-monitoring NGO** | Site conditions and history | Current state, when the report is old — date-check before grading | Accord and ITUC lists, monitoring reports |
| **Trade body / export council** | **Scale evidence where accounts are thin** — export rankings, membership | Financial condition | TDAP (Pakistan), export promotion councils (India) |
| **Buyer-published factory list** | That a relationship plausibly exists | Which of two similarly-named entities it is — a frequent collision source | Buyer sustainability pages |
| **Customs / bills-of-lading aggregator** | Shipment ranking, named counterparties | Share of business; and **blind outside the US** | Commercial aggregators, ~10–15 min per company, not a bulk feed |
| **Company website** | Published contacts, client logos, plant claims | Anything dated or verified | — |

## Rules that apply to all of them

- **An undisclosed allegation is itself a finding.** A criminal matter resolved in the company's favour is still MATERIAL if no public source says what it was
- **Absence of a search ≠ absence of a finding.** "Every Chinese register blocked automated access" is a reportable state, not a clean result
- **Never construct a contact** from a name pattern, even when the convention is obvious. `NOT FOUND` and still ship
- **Date everything perishable.** Ratings, screens, contacts, buyer relationships
- Coverage is uneven by jurisdiction: rich in India, Pakistan, UK and Hong Kong; thin and often machine-inaccessible in mainland China. Say which situation you are in rather than reporting an empty search as clean
