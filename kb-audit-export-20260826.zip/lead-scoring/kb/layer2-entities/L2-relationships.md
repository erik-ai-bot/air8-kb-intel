# L2 · Relationships

The edges. Each one carries an implication that neither endpoint carries alone — this is where Layer 2 earns its place, because most real findings live on an edge rather than on a node.

## supplier —ships to→ buyer

The core edge. DB-derived: count, months active, share, first and last date.

| Read | Implication |
|---|---|
| The buyer on our list is **not** the largest | Open the call on the anchor buyer instead. Observed anchors elsewhere: Carter's, American Eagle, AEO/Talbots, Aldi at 65%, M&S at 76% |
| A large flow to a buyer on another programme | **Cross-sell** — the name belongs to a different desk |
| Flow stale beyond the gate window | A stale flow is a different risk from a slow one → tier demotion, per [L1-scoring-apparel.md](../layer1-reasoning/L1-scoring-apparel.md) |
| Flow ended and the **buyer** is inactive | Not a supplier failure and not a scoring miss — 64% of churn is this |
| The relationship appears in our data but not in the buyer's own list | Possible name collision → `CONTRADICTED`, do not resolve by preference |

## supplier —belongs to→ group

| Read | Implication |
|---|---|
| Counterparty is a group affiliate | Intra-group receivable, **possibly unfinanceable**. `WARNING` |
| Parent provides interest-free funding | No receivable gap → Floor, with a revisit trigger |
| Group treasury is centralised | The deal is at the parent; the plant cannot transact |
| A customer also holds equity in the supplier | Sticky flow, but pricing power sits with the shareholder |

## supplier —is funded by→ financier

| Read | Implication |
|---|---|
| Already discounting bills | Shortest path to a deal; the conversation is price and capacity |
| Concessionary local-currency funding | Cannot compete on that leg — find the foreign-currency leg |
| Assets already pledged | Collateral exhaustion → unsecured receivable purchase has value even to a cash-rich name |
| Development bank lends to the group | That is the price to beat, and often we cannot |

## supplier —makes→ product type

Routes the framework and carries measured durability. Two lines in the same segment are not breadth. Product mix spanning **unrelated** chapters is the diagnostic of a trading house, not of diversification — see [L2-supplier-types.md](L2-supplier-types.md).

## supplier —is identified by→ register entry

| Read | Implication |
|---|---|
| Registration number confirmed | Findings may be attached |
| Two names, one register entry | Duplicate DB rows — de-duplicate before scoring, or the same company is scored twice at different values |
| One name, two register entries | Collision — unrelated companies sharing a brand word. Confirm before attaching any financial or adverse fact |
| No register entry found | **Entity unresolved → parked, not scored.** A score on an unidentified company is false precision |

## buyer —sources through→ intermediary

An agent or vendor-of-record sitting between the supplier and the end brand. The receivable is owed by the intermediary; the demand belongs to the brand. Resolve the brand or mark the concentration unresolved.

## product type —depends on→ raw material

Not scored in leads, but the edge exists and is the join to the **event-trigger KB**: a cotton or freight shock propagates along this edge to product types, then to supplier types, then to DB clients. In leads we traverse the other way. Keeping the edge described in both KBs is what lets one shock be reasoned about in either direction.

## How the agent uses these edges

1. **Before scoring** — routing (product edge) and de-duplication / identity (register edge)
2. **After scoring, shortlist only** — group edge for financeability, financier edge for pricing, buyer edge for the call opener and cross-sell, intermediary edge for real concentration

An edge finding beats a node finding. A tier A supplier whose only counterparty is its own parent is not a tier A opportunity, and nothing on either node says so.
