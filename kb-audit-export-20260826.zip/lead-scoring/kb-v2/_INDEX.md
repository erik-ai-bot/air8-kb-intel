# Scoring KB — Index & Name Change Log

> **Last updated:** 2026-08-25
> **Basis:** kb-puzzle-v11 (Jerri Zhou). Rebuilt from old `kb/` structure.

---

## Structure

```
lead-scoring/kb-v2/
├── _INDEX.md           ← this file
├── layer1/             ← HOW to think (reasoning, method, discipline — NO numbers)
└── layer2/             ← WHAT things are (weights, thresholds, lookup rules — ALL numbers here)
```

### Layer 1 files

| File | Puzzle ID | Purpose |
|---|---|---|
| `L1-db-field-contract.md` | `contract` | Field mapping · multi-row dedupe · missing-field handling |
| `L1-vertical-routing.md` | `route` | HS chapter → framework routing; PARK logic; China HS gap |
| `L1-scoring-method.md` | `method` | Banded additive scoring logic — reads numbers from NODE-scoring-framework |
| ~~`L1-scoring-apparel.md`~~ | `appa` | **Removed** — apparel scoring logic lives in L2: `NODE-scoring-framework.md` |
| ~~`L1-scoring-hardgoods.md`~~ | `hard` | **Removed** — hardgoods scoring logic lives in L2: `NODE-scoring-framework.md` |
| `L1-ordering-and-gates.md` | `gates` | Gate order · sort policy · list construction logic |
| `L1-evidence-discipline.md` | `evid` | Evidence standard · source credibility · NOT FOUND · audit log |
| `L1-trend-method.md` | `trend` | How trend signals are assessed for supplier (product) and market |
| `L1-adverse-news-method.md` | `advm` | Adverse screening method and protocol — severity reasoning |
| `L1-data-traps.md` | — | Common data traps and how to avoid them |
| `L1-decision-log.md` | — | Framework change log |
| `L1-pipeline-and-gates.md` | — | Old name for `L1-ordering-and-gates.md` — kept for backward compat |

### Layer 2 files

| File | Puzzle ID | Purpose |
|---|---|---|
| `NODE-indicator.md` | `ind` | Indicator column locations · field-name lookup |
| `NODE-scoring-framework.md` | `frame` | ALL numbers: weights · bands · tier cuts · gates · TIEBREAK · ROUTED_FROM |
| `NODE-bs-proxy.md` | `bsp` | **Buyer-Supplier pair proxy** — B/S score (40/100) → extrapolated full scorecard rating. Apparel and hardgoods have separate band tables. Thresholds TBD (Jerri). |
| `NODE-rating-assembly.md` | `rate` | Score-merge weights · A/B/C/D cut thresholds |
| `NODE-adverse-screen.md` | `adv` | §Supplier adverse search rules and severity grading |
| `NODE-financing-need.md` | `fin` | Six-angle financing need assessment · bands · Floor rule |
| `NODE-outreach-profile.md` | `out` | Supplier type profiles → who signs, what to pitch, what not to lead with |
| `NODE-evidence-source.md` | `src` | Source priority hierarchy · contact-finding hierarchy |
| `NODE-product-trend.md` | `pt` | Product trend signal rules · RISING/STABLE/DECLINING bands |
| `NODE-market-trend.md` | `mt` | Buyer market trend signal rules · country routing for data sources |
| `NODE-performance-scorecard.md` | `perf` | F2 Supplier Scorecard · **3 dims: QAQC + Performance + B/S Pair** (QAQC live 2026-08-25) |
| `NODE-buyer-indicator.md` | `bind` | F3 Buyer Assessment — indicator data dictionary · source locators |
| `NODE-buyer-scoring-framework.md` | `bsf` | F3 Buyer Assessment — scoring rules · buyer tier cuts (thresholds TBD) |
| `NODE-pair-terms-matrix.md` | `ptm` | Buyer tier × Supplier tier → pair financing terms (thresholds TBD) |

---

## Flow → File Mapping

| Flow | CP | L1 files used | L2 files used |
|---|---|---|---|
| **F1 Lead Scoring** | CP0 Data Load | L1-db-field-contract | NODE-indicator |
| | CP1 Vertical Routing | L1-vertical-routing | NODE-scoring-framework §ROUTED_FROM |
| | CP2 Component Scoring | L1-scoring-method · L1-scoring-apparel · L1-scoring-hardgoods | NODE-scoring-framework |
| | CP3 Gate Checks | L1-ordering-and-gates | NODE-scoring-framework §Gates |
| | CP4 Sort + Call List | L1-ordering-and-gates | NODE-scoring-framework §TIEBREAK |
| | CP4.5 Research | L1-evidence-discipline · L1-adverse-news-method | NODE-adverse-screen · NODE-financing-need · NODE-outreach-profile · NODE-evidence-source |
| | CP5 Output | — | — |
| **F2 Supplier Scoring** | CP0 Data Load | L1-db-field-contract | NODE-indicator |
| | CP1 Coverage + Buyer Lookup | L1-performance-coverage ❌ TBD | NODE-bs-proxy |
| | CP2 Indicator Scoring | L1-scoring-method · L1-trend-method | NODE-performance-scorecard · NODE-product-trend · NODE-market-trend · NODE-adverse-screen |
| | CP3 Score Assembly | L1-ordering-and-gates | NODE-rating-assembly |
| | CP5 Output | — | — |
| **F3 Buyer Assessment** | CP0 Data Load | `L1-db-field-contract.md` | `NODE-buyer-indicator.md` |
| | CP1 Coverage | `L1-performance-coverage.md` (buyer lookup section) | `NODE-buyer-indicator.md` |
| | CP2 Scoring | `L1-scoring-method.md` | `NODE-buyer-scoring-framework.md` |
| | CP3 Terms | `L1-ordering-and-gates.md` | `NODE-pair-terms-matrix.md` |
| | CP5 Output | — | — |

---

## Name Change Log

| Old Name | New Name | Reason |
|---|---|---|
| `L1-pipeline-and-gates.md` | `L1-ordering-and-gates.md` | Puzzle ID: `gates` → node name `L1-ordering-and-gates` |
| `L1-adverse-severity.md` | `L1-adverse-news-method.md` | Puzzle ID: `advm` → node name `L1-adverse-news-method` |
| `kb/layer1-reasoning/` | `kb-v2/layer1/` | New directory; puzzle-aligned naming |
| `kb/layer2-entities/L2-*.md` | `kb-v2/layer2/NODE-*.md` | NODE-* naming convention to match puzzle |

---

## New Files Added (2026-08-25 PM session)

| File | Status | Notes |
|---|---|---|
| `L1-vertical-routing.md` | ✅ Migrated from old kb/ | |
| `L1-ordering-and-gates.md` | ✅ Renamed from L1-pipeline-and-gates | Old file kept for compat |
| `L1-adverse-news-method.md` | ✅ Migrated + renamed from L1-adverse-severity | |
| `L1-scoring-apparel.md` | ✅ Migrated from old kb/ | Numbers also in NODE-scoring-framework (authoritative) |
| `L1-scoring-hardgoods.md` | ✅ Migrated from old kb/ | Numbers also in NODE-scoring-framework (authoritative) |
| `L1-trend-method.md` | ✅ New | Trend reasoning for F1 + F2 |
| `NODE-bs-proxy.md` | ✅ New | B/S Pair proxy from customs + CI + PulseLink |
| `NODE-rating-assembly.md` | ✅ New | Score merge + final tier logic |
| `NODE-product-trend.md` | ✅ New | Product trend signal rules |
| `NODE-market-trend.md` | ✅ New | Buyer market trend rules |
| `NODE-performance-scorecard.md` | ✅ New (2-dim) | F2 Scorecard: Performance + B/S Pair. QAQC deferred |
| `L1-performance-coverage.md` | ✅ New | F2 CP1 coverage check — FR minimums, buyer lookup, stale vs insufficient |
| `NODE-buyer-indicator.md` | ✅ New (F3 skeleton) | F3 buyer data dictionary — structure confirmed, thresholds TBD |
| `NODE-buyer-scoring-framework.md` | ✅ New (F3 skeleton) | F3 buyer scoring — structure confirmed, bands TBD (Jerri) |
| `NODE-pair-terms-matrix.md` | ✅ New (skeleton) | Buyer × Supplier tier → pair terms. Values TBD (needs F3 calibration) |

---

## Deferred / Not Ready

| File | Reason |
|---|---|
| `NODE-buyer-scoring-framework.md` scoring bands | F3 buyer tier cuts — thresholds TBD (Jerri) |
| `NODE-pair-terms-matrix.md` advance rates / tenors / conc limits | Pair terms values — TBD (calibration required, n ≥ 20 per cell) |
| `NODE-bs-proxy.md` B/S thresholds | Apparel and hardgoods B/S scoring bands — TBD (Jerri) |
| QAQC 3-dim merge weights | Provisional weights live (QAQC 40% / Perf 35% / B/S 25%); calibration pending n ≥ 20 per tier |
| QAQC dimension in scorecard | Inspection thresholds not yet provided |
| All F3 files | Buyer Assessment not ready |

---

## KB vs DB Boundary

**In KB:** reasoning logic (L1) · entity type definitions · weights and thresholds (L2 nodes) · framework versions and calibration basis

**In DB:** individual supplier/buyer/factory records · per-entity scores and verdicts · historical run data · raw data (shipments, invoices, inspections)

**Rule:** KB never stores a named supplier, buyer, factory, or brand as content. A named entity is a DB row.

---

## Governance

To change any number in a NODE file:
1. Fill `valid_to` on the old row
2. Add new row: `valid_from` + new values + **evidence + n**
3. Increment framework version if it's the scoring framework
4. One line in `L1-decision-log.md`

Prerequisites: Trigger A (new data, n≥5 per band) OR Trigger B (30+ BD outcomes) OR Trigger C (3+ consistent counter-examples).
