# KB (skill built-in edition) — Logic layer + Node layer

| Directory | What goes here | Who edits |
|---|---|---|
| `layer1/` | **Layer 1 — How to think**: pipeline sequence, scoring method, evidence discipline, data pitfalls, decision log. **No numbers at all** | Rarely changed |
| `layer2/` | **Layer 2 — What it is**: four determination modes — scoring / adverse / need / outreach — plus indicator definitions + evidence sources. **All numbers live in the tables here** | Business / experts edit tables directly |
| `_to_db/` | Instance seed data (dead buyer programmes, same-name conflicts) — DB content, not KB | Appended as discovered |

## Four determination modes (all act on SUPPLIER)

| Node | Answers | Runs at |
|---|---|---|
| NODE-scoring-framework | Whether it will stay | CP2 |
| NODE-adverse-screen | Whether it can be called | CP4.5 |
| NODE-financing-need | Whether it is worth calling first | CP4.5 |
| NODE-outreach-profile | How to call it | CP4.5 |

Supporting nodes: NODE-indicator (how indicators are derived from DB), NODE-evidence-source (which source type determines which type of question).

## Rules for changing numbers (the only governance rule)

All weights / thresholds / tier cuts exist only in the **tables** of node files. A change = fill the expiry date on the old row, add a new row (effective date + evidence + n), increment framework version by 1, one line in decision log explaining why. **No number may have a second copy anywhere** — threshold text in the skill's Telegram messages must be rendered from the tables at runtime.

## Relationship with your event KB

Entity definitions for SUPPLIER / BUYER / PRODUCT / RM / COUNTRY belong to the event KB — **zero changes here**. All associations are written as links (e.g. `—SCORES→ [EVENT-KB: SUPPLIER]`), replaced with real node IDs when integrated; when loading into Neo4j, create edges from links and rule nodes from table rows.

## CP Reference

Which file each CP reads, core logic, old→new mapping: `CP-MAP.md`.
