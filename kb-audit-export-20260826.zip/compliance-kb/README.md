# Compliance KB — Air8

## Purpose
Standalone compliance assessment knowledge base. Not mixed with lead-scoring.
Covers: how to determine which regulations apply, how to interpret & judge them,
how to respond, how to stay updated, and how to find & fill KB gaps.

## Structure

```
compliance-kb/
├── L1/   ← Methodology layer: HOW to reason and act
│   ├── L1-compliance-scope.md          Routing: product+market → applicable regs
│   ├── L1-compliance-interpretation.md How to read a regulation and judge if it applies
│   ├── L1-compliance-response.md       What to do once a regulation is triggered
│   ├── L1-regulatory-intelligence.md   How to track new regulations effectively
│   └── L1-compliance-gap-method.md     How to identify KB gaps and fill them
│
├── L2/   ← Knowledge layer: WHAT the rules are (framework + logic, NO individual entity data)
│   ├── NODE-compliance-product-eu.md   EU product compliance (REACH/SVHC/PFAS/CE/RoHS/GPSR)
│   ├── NODE-compliance-trade.md        Trade & customs (HS codes, UFLPA, COO, CPSC)
│   ├── NODE-compliance-social.md       Social compliance framework (BSCI/SMETA stub → see buyer-rsl)
│   ├── NODE-compliance-buyer-rsl.md    RSL framework + audit programs (NO individual buyer data → DB)
│   └── NODE-regulatory-intelligence.md Source registry: where to find regulations
│
├── DT/   ← Data sources: WHERE data comes from + source profiles
│   ├── DT-internal-data-map.md         SDU internal data vs external/client-sourced
│   └── DT-reach-svhc.md               ECHA SVHC candidate list data source profile
│
│   NOTE: Individual buyer RSL data (BJ's, IKEA, Costco specifics) → DB: buyer_rsl/ (not in this KB)
│   NOTE: NODE-adverse-screen → lives in Air8 main KB (air8-databases/SHI-KB/), referenced only
│
└── scenarios/
    └── SC-yangzhou-poc.md              YANGZHOU RICH ARTS & CRAFTS compliance POC
```

## Layer Responsibilities

| Layer | Role | Examples |
|-------|------|---------|
| **L1** | Reasoning framework — agent uses these to THINK | "Is this regulation applicable?" |
| **L2** | Rule tables — agent LOOKS UP facts | "REACH SVHC threshold is 0.1% w/w" |
| **DT** | Data availability — agent knows WHERE to get data | "BOM from client, SVHC list from ECHA" |

## Compliance Assessment Flow (CP0–CP5)

```
CP0 → Client + product resolution (entity, HS code, target market)
CP1 → Scope determination (L1-compliance-scope + NODE-compliance-product-eu)
CP2 → Document gap check (L1-compliance-interpretation → compare docs vs requirements)
CP3 → Risk scoring (severity × urgency × buyer specifics)
CP4 → Impact of recent regulatory changes (NODE-regulatory-intelligence + DT)
CP5 → Output: compliance roadmap HTML (gaps + actions + deadlines + sources)
```

## Key Principles
1. **Knowledge ≠ Methodology.** L2 holds rules. L1 holds how to apply them.
2. **Regulation status matters.** Always distinguish: Proposal / Consultation / Adopted / In force / Derogation.
3. **Buyer requirements > regulatory floor.** Brands often require stricter than law.
4. **Internal data first.** Check what Air8 already has before going external.
5. **Gap = opportunity.** Missing data types → flag → recommend source → human approve.
