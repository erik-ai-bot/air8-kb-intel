# SC-yangzhou-poc — Yangzhou Arts & Crafts Compliance Assessment POC

## Scenario Overview

**Client:** YANGZHOU RICH ARTS & CRAFTS CO. LTD
**Location:** Yangzhou, Jiangsu Province, China
**Product:** Arts & crafts decorative items — painted/finished ornamental articles
**HS Code (assumed):** 9505.10 (Christmas decorations) + 6304.90 (textile decorative articles)
**Target Markets:** EU (primary) + US (secondary)
**Financing Exposure:** $11.11M USD
**Assessor:** Air8 Compliance Agent (CP0–CP5 framework)
**Assessment Date:** August 2026

---

## Why This Client

This client was selected from the Air8 CLIENT-DB because it hits the maximum number of recent regulatory changes in a single product category:

| Regulatory Change | Status (Aug 2026) | Applicable to Yangzhou |
|------------------|-------------------|----------------------|
| REACH SVHC — n-Hexane added (Feb 4, 2026) | ✅ In force | 🔴 High — coating solvent process |
| REACH SVHC — BPAF added (Feb 4, 2026) | ✅ In force | 🟡 Medium — epoxy coating possible |
| EU GPSR — EU AR mandatory (Dec 13, 2024) | ✅ In force | 🔴 High — China manufacturer, EU buyer |
| EU PPWR — full application | Aug 12, 2026 (upcoming) | 🟡 Medium — packaging compliance |
| EU PFAS clothing ban (Jul 1, 2026) | ✅ In force | ⚪ N/A — decorative hardgoods not clothing |
| UFLPA enforcement | Ongoing | 🔴 High — China origin, cotton components possible |

---

## Client Data (from Air8 internal records)

**Factory Profile:**
- Legal name: YANGZHOU RICH ARTS & CRAFTS CO. LTD
- Country: China (Jiangsu)
- Product description: Arts, crafts, & decorative items (painted ornaments, decorative textiles)
- Approximate HS code: 9505.10 / 6304.90 (6-digit, unconfirmed at 10-digit)
- Financing: $11.11M USD
- Named buyers (from financing records): BJ's Wholesale (US), Ko***'s (EU) — confirmed
- Social audit on file: BSCI C rating (2024, valid until 2026)

**Known Compliance Gaps (from available data):**
- ❌ No GPSR EU Authorized Representative appointed
- ❌ No SVHC declaration on file
- ❌ No UFLPA supply chain traceability documentation
- ❌ HS code not confirmed at 10-digit level
- ❌ PPWR packaging requirements not assessed

---

## CP0 — Client & Product Resolution

**Output:** Confirmed scope

```
Factory: YANGZHOU RICH ARTS & CRAFTS CO. LTD (China)
Products: Decorative arts & crafts — painted ornaments, textile decorations
HS codes: 9505.10 (Christmas decorations) + 6304.90 (textile decorations)
Target markets: EU + US
Named buyers: BJ's Wholesale, Ko***'s (EU)
Known certifications: BSCI C (2024)

Required L2 nodes to load:
  → NODE-compliance-product-eu.md  (EU rules)
  → NODE-compliance-trade.md        (UFLPA, HS, COO)
  → NODE-compliance-buyer-rsl.md   (BJ's + Ko***'s programs)

Required L1 modules to run:
  → L1-compliance-scope.md  (market routing)
  → L1-compliance-interpretation.md (SVHC threshold check)
  → L1-compliance-response.md (GPSR + SVHC playbooks)
```

---

## CP1 — Scope Determination (via L1-compliance-scope.md)

### Market: EU

Applicable EU regulations for Yangzhou's decorative articles:

| Regulation | Applies? | Reason |
|-----------|---------|--------|
| REACH (SVHC + Annex XVII) | ✅ Yes | All articles imported into EU — REACH applies to downstream users |
| GPSR | ✅ Yes | Consumer product sold in EU — GPSR mandatory since Dec 2024 |
| CE Marking | ⚪ Conditional | Only if electrical component present — need to confirm |
| PPWR | ✅ Yes | Packaging for products shipped to EU — applies Aug 12, 2026 |
| PFAS ban (clothing) | ❌ No | Decorative hardgoods not in scope — different product category |

### Market: US

| Regulation | Applies? | Reason |
|-----------|---------|--------|
| CPSC (GCC) | ✅ Yes | General consumer product — GCC required |
| Prop 65 | ✅ Yes | California sales — lead, cadmium, phthalates |
| UFLPA | ✅ Yes | China origin — rebuttable presumption applies |
| CPSIA | ⚪ Conditional | Only if children's product — need to confirm age grading |

---

## CP2 — Document Gap Check

### EU Requirements vs. Available Documents

| Required Document | On File (Air8) | Status | Action |
|-----------------|----------------|--------|--------|
| BSCI audit report | ✅ 2024 | Valid until 2026 | OK — monitor expiry |
| REACH SVHC declaration | ❌ | Missing | 🔴 Request from factory |
| GPSR EU AR appointment | ❌ | Missing | 🔴 Urgent — hold EU shipments |
| GPSR Technical File (DoC + safety assessment) | ❌ | Missing | 🔴 Urgent |
| PPWR packaging compliance | ❌ | Not assessed | 🟡 Assess before Aug 12, 2026 |
| SCIP notification (if SVHC >0.1%) | ❌ | Unknown | 🟡 Depends on BOM |

### US Requirements (BJ's) vs. Available Documents

| Required Document | On File (Air8) | Status | Action |
|-----------------|----------------|--------|--------|
| BSCI audit | ✅ 2024 | Valid | OK |
| BJ's facility registration | 🟡 Unknown | Check with client | Request confirmation |
| Prop 65 test report | ❌ | Missing | 🔴 Required for CA sale |
| RSL test (BJ's RSL) | ❌ | Missing | 🔴 Required before shipment |
| COO certificate | 🟡 | On file (year unknown) | Verify current |
| UFLPA traceability | ❌ | Missing | 🔴 Required for China origin |

---

## CP3 — Risk Scoring

### EU Market Risk Matrix

| Risk | Regulation | Severity (1-5) | Urgency (1-5) | Buyer Impact | Score |
|------|-----------|---------------|--------------|-------------|-------|
| GPSR EU AR missing | GPSR | 5 | 5 | 🔴 Cannot legally sell in EU | 🔴 CRITICAL |
| n-Hexane SVHC in coating | REACH SVHC | 4 | 4 | 🔴 SCIP fine + buyer claim | 🔴 HIGH |
| BPAF in epoxy coating | REACH SVHC | 3 | 3 | 🟡 Buyer requires declaration | 🟡 MEDIUM |
| PPWR packaging non-compliance | PPWR | 3 | 4 | 🟡 Buyer hold from Aug 12, 2026 | 🟡 MEDIUM |
| Lead in painted surface | REACH Annex XVII | 4 | 4 | 🔴 Hard ban — stop shipment | 🔴 HIGH |
| Phthalates in decorative plastic | REACH Annex XVII | 4 | 4 | 🔴 Hard ban if children product | 🔴 HIGH |

### US Market Risk Matrix

| Risk | Regulation | Severity | Urgency | Score |
|------|-----------|----------|---------|-------|
| Prop 65 lead in paint | Prop 65 | 5 | 5 | 🔴 CRITICAL |
| BJ's RSL test missing | BJ's RSL | 5 | 4 | 🔴 HIGH |
| UFLPA cotton traceability | UFLPA | 4 | 4 | 🔴 HIGH |
| COO certificate expired | US Customs | 3 | 3 | 🟡 MEDIUM |

---

## CP4 — Recent Regulatory Change Impact

### Feb 4, 2026 REACH SVHC Update Impact Assessment

**New substances added:** n-Hexane (CAS 110-54-3) + BPAF (CAS 1478-61-1)

**Yangzhou exposure analysis:**

**n-Hexane:**
- Used in: paint thinners, coating solvents, adhesive cleaners, ink vehicle solvents
- Yangzhou process: painted decorative items → likely uses paint thinners/solvents
- Residual in finished article: YES — n-Hexane evaporates but residual can remain in dried coating
- SCIPC notification trigger: if >0.1% w/w in finished article
- **Recommended action:** Request BOM + SDS from factory immediately. Test representative sample.
- **SCIP deadline:** August 4, 2026 (6 months from Feb 4, 2026) — ⚠️ 9 days from assessment date!
- **Consequence if missed:** EU buyer receives goods without SCIP notification → buyer is legally exposed → buyer will claim damages from Yangzhou

**BPAF:**
- Used in: high-performance epoxy coatings, optical polymer coatings, fluoropolymers
- Yangzhou process: epoxy coating possible for high-end decorative items
- **Recommended action:** Check if epoxy resin is in BOM. If yes, test for BPAF.
- **Note:** BPAF is a bisphenol — bisphenols have high regulatory attention (BPA already SVHC)

### Dec 13, 2024 GPSR — Impact: Ongoing (Missed for 19 months)

**Yangzhou status:** China manufacturer, no EU legal entity → GPSR non-compliant since Dec 13, 2024

**What this means legally:**
- Ko***'s (EU buyer) is the "responsible person" under GPSR for Yangzhou's products
- Ko***'s can legally refuse shipment or hold payment until Yangzhou provides EU AR documentation
- If Ko***'s sells goods without EU AR on file → Ko***'s is fined by EU market surveillance
- Ko***'s will pass this cost back to Yangzhou or drop the supplier

**Recommended action:**
1. Appoint EU AR immediately — cost €300-800/year via service firms
2. Prepare GPSR Technical File (DoC + safety assessment)
3. Provide EU AR appointment letter to Ko***'s
4. Timeline: 2-4 weeks to complete

---

## CP5 — Compliance Roadmap (Output)

### Immediate Actions (within 2 weeks — Aug 2026)

| # | Action | Owner | Deadline | Regulation |
|---|--------|-------|---------|-----------|
| 1 | Appoint EU Authorized Representative | Yangzhou | Aug 30, 2026 | GPSR 🔴 |
| 2 | Provide EU AR appointment letter to Ko***'s | Yangzhou + Air8 | Aug 30, 2026 | GPSR 🔴 |
| 3 | Request BOM from Yangzhou factory | Air8 → Client | Aug 30, 2026 | REACH SVHC 🔴 |
| 4 | Request SDS (Safety Data Sheet) for all coating materials | Air8 → Client | Aug 30, 2026 | REACH SVHC 🔴 |
| 5 | Confirm: does product contain electrical components? | Client | Aug 30, 2026 | CE Marking 🟡 |

### Short-term Actions (within 6 weeks — Sep 2026)

| # | Action | Owner | Deadline | Regulation |
|---|--------|-------|---------|-----------|
| 6 | Submit SCIP notification if n-Hexane >0.1% confirmed | Yangzhou | Sep 30, 2026 | REACH SVHC 🔴 |
| 7 | Commission Prop 65 test (lead, cadmium, DEHP) | Yangzhou | Sep 15, 2026 | Prop 65 🔴 |
| 8 | Commission BJ's RSL test (full panel, ISO 17025 lab) | Yangzhou | Sep 15, 2026 | BJ's RSL 🔴 |
| 9 | Prepare UFLPA Tier 1-3 traceability package | Yangzhou | Sep 30, 2026 | UFLPA 🔴 |
| 10 | Verify/update COO certificate | Yangzhou | Sep 15, 2026 | US Customs 🟡 |

### Medium-term Actions (before Aug 12, 2026 — PPWR deadline)

| # | Action | Owner | Deadline | Regulation |
|---|--------|-------|---------|-----------|
| 11 | Assess packaging materials against PPWR | Yangzhou | Aug 10, 2026 | PPWR 🟡 |
| 12 | Update packaging labels (Triman / material codes) | Yangzhou | Aug 10, 2026 | PPWR 🟡 |
| 13 | Prepare GPSR DoC + safety assessment documentation | Yangzhou | Sep 30, 2026 | GPSR 🔴 |

---

## Compliance Status Summary

| Market | Overall Status | Blocking Issues |
|--------|--------------|----------------|
| EU (Ko***'s) | 🔴 NOT COMPLIANT | GPSR EU AR missing; SVHC declaration missing |
| US (BJ's) | 🟡 PARTIALLY COMPLIANT | Prop 65 test missing; RSL test missing; UFLPA docs missing |

**Confidence score for this assessment:** 72%
**Reason for uncertainty:** BOM not yet confirmed — SVHC exposure is assumed based on product category. n-Hexane residual level unconfirmed.

---

## Key Deadlines

| Deadline | Event | Urgency |
|---------|-------|---------|
| **Aug 30, 2026** | GPSR EU AR must be appointed | 🔴 4 days |
| **Aug 4, 2026** | SCIP notification deadline (6 months from Feb 4 SVHC update) — MISSED if n-Hexane confirmed | 🔴 OVERDUE |
| **Aug 12, 2026** | PPWR full application — packaging compliance required | 🟡 9 days |
| **Jan 1, 2027** | PFAS clothing/footwear ban — grace period ends (not applicable to Yangzhou) | ⚪ N/A |

---

## Files Used in This Assessment

```
L1 (method):
  L1-compliance-scope.md           ← routing product+market → regs
  L1-compliance-interpretation.md   ← n-Hexane residual vs. process use logic
  L1-compliance-response.md         ← GPSR + SVHC playbooks
  L1-regulatory-intelligence.md     ← regulatory status check

L2 (knowledge):
  NODE-compliance-product-eu.md     ← REACH SVHC + GPSR rules
  NODE-compliance-trade.md          ← UFLPA + COO
  NODE-compliance-buyer-rsl.md     ← BJ's + Ko***'s requirements

DT (data):
  DT-internal-data-map.md           ← what Air8 has vs. needs from client
```

---

## Scenario Trigger Keywords

Use this scenario when:
- "run compliance assessment" / "compliance check for Yangzhou"
- "REACH SVHC impact" / "n-Hexane compliance"
- "GPSR EU AR requirement"
- "UFLPA documentation requirements"
- "Prop 65 compliance for decorative items"
- "compliance POC" / "demo compliance assessment"

---

*Assessment conducted: 2026-08-26*
*Assessor: Air8 Compliance Agent v1.0*
*Next scheduled review: After BOM + SDS received from client*
