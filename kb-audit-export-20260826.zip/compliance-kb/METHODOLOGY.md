# Air8 Compliance Intelligence — Methodology Overview

> How we systematically master compliance requirements, stay current with regulatory changes,
> leverage internal data, interpret rules correctly, and continuously improve our knowledge base.

---

## The Core Problem

Compliance is not a checklist. It has four moving parts that must work together:

| Problem | Consequence if missed |
|---------|----------------------|
| **Which rules apply?** — Regulations differ by product, market, and buyer | Wrong rules applied → false confidence |
| **Are we current?** — Regulations change multiple times per year | Outdated knowledge → shipment blocks, buyer claims |
| **What data do we have?** — Many required documents don't exist internally | Gaps undetected → liability passed to buyer |
| **How do we interpret correctly?** — Rules are precise; misreading costs money | Over/under-compliance → unnecessary cost or real risk |

Our methodology addresses all four in sequence.

---

## Layer Architecture

We split compliance knowledge into three distinct layers. Each layer answers a different question.

```
L1 — Methodology   HOW to reason and act
L2 — Knowledge     WHAT the rules are
DT — Data          WHERE the data comes from
```

This separation matters: **knowing the rule is not enough**. You need to know how to apply it,
and whether you actually have the data to check it.

---

## 1. Determining Which Rules Apply

**The problem:** A decorative item exported from China to the EU and US is subject to at least
6 different regulatory frameworks simultaneously. Getting this wrong means either over-engineering
compliance (cost) or missing a critical rule (risk).

**Our approach — L1 compliance scope routing:**

```
Product type (HS code)  ──┐
                           ├── routing table → applicable regulation list
Target market (EU/US)   ──┘
         +
Special triggers:
  → Contains electrical components? → CE marking + RoHS required
  → Children's product? → Toy Safety Directive, stricter phthalate limits
  → China origin? → UFLPA rebuttable presumption
  → Non-EU manufacturer? → GPSR EU AR required
```

Output: a precise list of which L2 knowledge nodes to load — no guessing, no over-scope.

**Example — Yangzhou Rich Arts & Crafts (decorative ornaments, China → EU + US):**
- REACH SVHC + Annex XVII (EU product chemical rules)
- GPSR EU AR (non-EU manufacturer selling to EU consumers)
- PPWR (EU packaging)
- Prop 65 (California chemical limits)
- CPSC GCC (US general product safety)
- UFLPA (China origin, cotton components possible)
- BJ's RSL (named buyer — stricter than regulatory minimum)

---

## 2. Staying Current with Regulatory Changes

**The problem:** EU adds new SVHC substances every 6 months. US updates Prop 65 quarterly.
UFLPA entity list changes without notice. A test report that was valid last quarter may be
insufficient today. No single source covers everything.

**Our approach — 3-tier intelligence network:**

### Tier 1 — Official primary sources (weekly check)
| Source | What it covers | Update frequency |
|--------|---------------|-----------------|
| ECHA candidate list (echa.europa.eu) | REACH SVHC additions | ~Every 6 months (Feb + Jul) |
| EUR-Lex Official Journal (eur-lex.europa.eu) | All EU regulations, exact text + dates | Real-time |
| EU Safety Gate (ec.europa.eu/safety-gate) | Product enforcement alerts by category | Weekly |
| DHS UFLPA entity list (dhs.gov) | Xinjiang forced labor entity list | Monthly (irregular) |
| CPSC (cpsc.gov) | US product recalls + new rules | Real-time |
| OEHHA Prop 65 list (oehha.ca.gov) | California chemical list | Quarterly |

### Tier 2 — Curated interpretation services (on new alerts)
CIRS Group, REACH24H, SGS Safeguards newsletter, Eurofins regulatory news, TÜV SÜD briefs, Intertek regulatory news.
These translate official language into supplier-actionable guidance.

### Tier 3 — Early warning (6–12 months ahead)
ECHA SVHC Intention Registry (substances under assessment before listing),
EU Commission consultation portal, Member State Committee meeting minutes, industry associations (AAFA, AHFA).
These signal what's coming before it becomes law.

**Critical distinction we always apply:**

> "Enters into force" ≠ "Shall apply from"

GPSR entered into force June 2023. Applied from December 2024. An 18-month gap.
Missing this distinction is one of the most common compliance errors. We track both dates for every regulation.

**How to classify a regulatory alert when we see it:**

| Stage | Signal words | Action |
|-------|-------------|--------|
| Proposal | "proposed", "under review", "consultation open" | Monitor only — no client action |
| Adopted | "published in Official Journal", "Regulation (EU) XXXX/XXX" | Note entry into force + application dates |
| In force | "has applied since", "shall apply from [past date]" | Trigger scope check for affected clients |
| Derogation | "with the exception of", "until [date]" | Calculate exact deadline per client |

---

## 3. What Data We Have — and What We Need

**The problem:** A compliance assessment is only as good as its data. If we assume documents
exist that the client hasn't provided, we give false assurance. If we don't know what we already
have internally, we ask for things unnecessarily.

**Our data availability map (honest baseline):**

| Data type | Air8 internal | Must come from client |
|-----------|:-------------:|:---------------------:|
| Factory legal name + country | ✅ | |
| Financing amount + buyer names | ✅ | |
| BSCI/SMETA audit (if Air8 conducted) | ✅ | |
| Bill of Materials (BOM) | | ❌ |
| Safety Data Sheets (SDS/MSDS) | | ❌ |
| Chemical test reports (SGS/BV/Intertek) | | ❌ |
| SVHC declaration | | ❌ |
| GPSR EU AR appointment letter | | ❌ |
| Prop 65 / RSL test report | | ❌ |
| UFLPA Tier 2–3 traceability | | ❌ |
| HS code (10-digit confirmed) | | ❌ |

**What this tells us:** Most compliance-critical data lives with the client or factory, not with Air8.
This is expected — and it defines our data collection strategy for any client assessment.

**Data request protocol:** When a document is missing, we identify:
1. Who holds it (client / factory / third party)
2. Why it's needed (specific regulation + consequence)
3. Deadline for providing it
4. What happens if not provided (worst-case assumption in assessment)

---

## 4. Interpreting Regulations Correctly

**The problem:** The same regulation can be read in ways that lead to very different conclusions.
Misinterpretation is expensive — either unnecessary testing or missed liability.

**Our 4-step reasoning chain:**

**Step 1 — Product classification**
HS code determines scope. A decorative item with LED lights is not HS 9505 (ornaments) —
it's HS 9405 (lamps) — which triggers electrical safety regulations. Getting HS wrong misapplies the entire ruleset.

**Step 2 — Substance presence check**
"Used in factory process" ≠ "present in finished article."
n-Hexane may be used as a solvent during coating but largely evaporates.
The REACH SVHC obligation depends on residual content in the finished article (>0.1% w/w),
not on whether the factory used the substance at any point in production.
This requires a residual test, not just a process declaration.

**Step 3 — Threshold and exemption check**
- 0.1% w/w threshold = per total finished article weight, not per component or coating layer
- Industrial use exemptions exist for some PFAS — consumer product ≠ industrial product
- Transition periods matter: PFAS clothing ban has a grace period to Jan 1, 2027 — not an immediate stop

**Step 4 — Legal entity check**
- "Who is the REACH importer?" determines who files with ECHA — the EU buyer, not the China factory
- "Who must appoint the EU AR?" — the non-EU manufacturer, but the EU buyer bears liability if they don't
- Understanding who is legally responsible changes the action owner, not just the risk

**Common misreadings we correct:**

| Misreading | Correct interpretation |
|-----------|----------------------|
| "PFAS ban means our decorative items are affected" | PFAS clothing ban applies to textiles/apparel — decorative hardgoods are not in scope |
| "We don't use n-Hexane so we're fine" | If factory uses it as solvent, residual test is needed to confirm finished article is below 0.1% |
| "EU AR costs too much" | EU AR service costs €300–800/year — this is administrative overhead, not a barrier |
| "We're China-based so UFLPA blocks us" | UFLPA creates rebuttable presumption — China origin does not automatically block shipment; chain of custody evidence resolves it |
| "Test report is 18 months old but products haven't changed" | Most buyers require re-test annually; buyer RSL or new SVHC listing may require it regardless of material change |

---

## 5. Responding When a Regulation Is Triggered

**The problem:** Knowing a rule applies is one thing. Knowing exactly what to do, who does it,
by when, and at what cost — is where most teams get stuck.

**Our response playbooks (per regulation):**

### REACH SVHC confirmed (>0.1% w/w in article)
| Action | Timeline | Who | Cost |
|--------|---------|-----|------|
| Notify downstream customer (name + content) | Within 45 days | Factory / supplier | Zero |
| Submit SCIP notification to ECHA | Within 6 months | EU importer or EU AR | Zero (ECHA portal is free) |
| Re-check when SVHC list updates | Every ~6 months | Air8 compliance review | Time only |
| Commission residual test if uncertain | Before 45-day clock | Factory | €500–2,000 per product |

### GPSR — non-EU manufacturer selling to EU
| Action | Timeline | Who | Cost |
|--------|---------|-----|------|
| Appoint EU Authorized Representative | Immediately | Manufacturer | €300–800/year |
| Prepare technical file (DoC + safety assessment) | Within 4 weeks | Manufacturer + EU AR | €500–2,000 one-time |
| Label product/packaging with EU AR details | Before next shipment | Manufacturer | Labeling cost only |
| EU AR responds to market surveillance queries | Within 10 days of query | EU AR | Included in service fee |

### UFLPA — China origin
| Action | Timeline | Who | Cost |
|--------|---------|-----|------|
| Map Tier 1–3 supply chain for high-risk components | Immediately | Manufacturer | Time + audit cost |
| Assemble "Clear and Convincing Evidence" package | Before next US shipment | Manufacturer + customs broker | €2,000–5,000 legal/consulting |
| Re-check DHS entity list for Tier 1 suppliers | Monthly | Air8 monitoring | Time only |

### Escalation rules (Air8 to client)
- **REACH Annex XVII hard ban detected** → hold shipment immediately, notify client
- **GPSR EU AR missing** → flag before next EU shipment — buyer bears liability otherwise
- **SVHC declaration outdated** → flag + request updated declaration before accepting documents
- **BSCI rating D or E** → flag to buyer relationship manager — buyer will likely reject

---

## 6. Finding and Filling Knowledge Gaps

**The problem:** No KB is complete on day one. Every new client or new regulation reveals
something we don't yet know — either a missing rule (Type A) or missing data (Type B).

**Our gap taxonomy:**

| Type | Definition | Example |
|------|-----------|---------|
| **Type A** | KB has no rule for this situation | "Does this regulation apply to metallic ink on ceramic?" |
| **Type B** | KB has the rule; we don't have the data to check it | "Need client's BOM to check SVHC — not yet received" |

**Gap identification process:**
At each step of a compliance assessment, we note every "cannot determine because..." — those are gaps.
Type A gaps go to expert review for rule drafting. Type B gaps trigger data requests.

**Gap queue format:**
```
GAP-ID: [auto-assigned]
Type: A (knowledge) / B (data)
Triggered by: [client name] at [assessment step]
Description: [what was missing]
Impact: [which regulations it affects, confidence drop]
Recommended fix: [authoritative source or data request]
Status: pending_review → approved → KB updated
```

**KB update protocol:**
1. Draft new rule or data source entry based on authoritative source
2. Expert review (designated compliance reviewer)
3. If approved: add to L2 node, update cross-links
4. Re-run any previous assessments affected by this gap
5. Log improvement in confidence score

This creates a **self-improving compliance intelligence system** — every client assessment makes the next one more accurate.

---

## Summary: What This Enables

| Capability | How we do it |
|-----------|-------------|
| Know which regulations apply to any client | L1 scope routing (product + market → applicable frameworks) |
| Stay current with regulatory changes | 3-tier intelligence network + lifecycle classification |
| Know what data we have vs. what we need | DT data availability map |
| Interpret regulations correctly | 4-step reasoning chain + common misreadings library |
| Respond effectively when rules are triggered | Per-regulation playbooks (who, what, by when, at what cost) |
| Continuously improve the KB | Type A/B gap taxonomy + expert review + update protocol |

---

*Version 1.0 — 2026-08-26*
*Air8 Compliance Intelligence*
